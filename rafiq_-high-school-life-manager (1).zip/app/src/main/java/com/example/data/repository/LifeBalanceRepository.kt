package com.example.data.repository

import com.example.data.DefaultData
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.remote.GeminiService
import com.example.data.remote.PrayerTimesCalculator
import com.example.data.remote.PrayerTimesResult
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class LifeBalanceRepository(private val database: AppDatabase) {

    val user: Flow<UserEntity?> = database.userDao().getUser()
    val subjects: Flow<List<SubjectEntity>> = database.subjectDao().getAllSubjects()
    val allLessons: Flow<List<LessonEntity>> = database.subjectDao().getAllLessons()
    val tasks: Flow<List<TaskEntity>> = database.taskDao().getAllTasks()
    val goals: Flow<List<GoalEntity>> = database.taskDao().getAllGoals()
    val customDhikrs: Flow<List<CustomDhikrEntity>> = database.dhikrDao().getCustomDhikrs()
    val quranProgress: Flow<QuranProgressEntity?> = database.dhikrDao().getQuranProgress()
    val scheduleBlocks: Flow<List<ScheduleBlockEntity>> = database.scheduleDao().getAllScheduleBlocks()
    val socialLimits: Flow<List<SocialMediaLimitEntity>> = database.scheduleDao().getSocialMediaLimits()
    val sleepRecords: Flow<List<SleepRecordEntity>> = database.healthDao().getSleepRecords()
    val moodRecords: Flow<List<MoodRecordEntity>> = database.healthDao().getMoodRecords()
    val aiMessages: Flow<List<AiChatMessageEntity>> = database.aiChatDao().getAllMessages()
    val summaries: Flow<List<SummaryEntity>> = database.studySessionDao().getAllSummaries()
    val studySessions: Flow<List<StudySessionEntity>> = database.studySessionDao().getAllSessions()

    fun getPrayersForDate(dateString: String): Flow<List<PrayerEntity>> {
        return database.prayerDao().getPrayersForDate(dateString)
    }

    fun getTasksForDate(dateString: String): Flow<List<TaskEntity>> {
        return database.taskDao().getTasksForDate(dateString)
    }

    suspend fun updateUser(user: UserEntity) {
        database.userDao().insertUser(user)
    }

    suspend fun changeDivision(newDivision: String) {
        val defaultSubjects = DefaultData.getDefaultSubjects(newDivision)
        database.subjectDao().insertSubjects(defaultSubjects)
        val current = database.userDao().getUserDirect() ?: UserEntity()
        database.userDao().insertUser(current.copy(division = newDivision))
    }

    suspend fun insertSubject(subject: SubjectEntity) {
        database.subjectDao().insertSubject(subject)
    }

    suspend fun updateSubject(subject: SubjectEntity) {
        database.subjectDao().updateSubject(subject)
    }

    suspend fun deleteSubject(subject: SubjectEntity) {
        database.subjectDao().deleteSubject(subject)
    }

    suspend fun insertLesson(lesson: LessonEntity) {
        database.subjectDao().insertLesson(lesson)
    }

    suspend fun deleteLesson(lesson: LessonEntity) {
        database.subjectDao().deleteLesson(lesson)
    }

    suspend fun insertStudySession(session: StudySessionEntity) {
        database.studySessionDao().insertSession(session)
    }

    suspend fun insertSummary(summary: SummaryEntity) {
        database.studySessionDao().insertSummary(summary)
    }

    suspend fun deleteSummary(summary: SummaryEntity) {
        database.studySessionDao().deleteSummary(summary)
    }

    suspend fun insertTask(task: TaskEntity) {
        database.taskDao().insertTask(task)
    }

    suspend fun updateTask(task: TaskEntity) {
        database.taskDao().updateTask(task)
    }

    suspend fun deleteTask(task: TaskEntity) {
        database.taskDao().deleteTask(task)
    }

    suspend fun insertGoal(goal: GoalEntity) {
        database.taskDao().insertGoal(goal)
    }

    suspend fun updateGoal(goal: GoalEntity) {
        database.taskDao().updateGoal(goal)
    }

    suspend fun deleteGoal(goal: GoalEntity) {
        database.taskDao().deleteGoal(goal)
    }

    suspend fun togglePrayer(prayerName: String, dateString: String, inMosque: Boolean = false) {
        val existing = database.prayerDao().getPrayer(dateString, prayerName)
        if (existing == null) {
            database.prayerDao().insertPrayer(
                PrayerEntity(
                    prayerName = prayerName,
                    dateString = dateString,
                    isDone = true,
                    inMosque = inMosque
                )
            )
        } else {
            database.prayerDao().insertPrayer(
                existing.copy(
                    isDone = !existing.isDone,
                    inMosque = if (!existing.isDone) inMosque else false
                )
            )
        }
    }

    suspend fun insertCustomDhikr(dhikr: CustomDhikrEntity) {
        database.dhikrDao().insertCustomDhikr(dhikr)
    }

    suspend fun deleteCustomDhikr(dhikr: CustomDhikrEntity) {
        database.dhikrDao().deleteCustomDhikr(dhikr)
    }

    suspend fun updateQuranProgress(progress: QuranProgressEntity) {
        database.dhikrDao().insertQuranProgress(progress)
    }

    suspend fun insertScheduleBlock(block: ScheduleBlockEntity) {
        database.scheduleDao().insertScheduleBlock(block)
    }

    suspend fun updateScheduleBlock(block: ScheduleBlockEntity) {
        database.scheduleDao().updateScheduleBlock(block)
    }

    suspend fun deleteScheduleBlock(block: ScheduleBlockEntity) {
        database.scheduleDao().deleteScheduleBlock(block)
    }

    suspend fun updateSocialMediaLimit(limit: SocialMediaLimitEntity) {
        database.scheduleDao().updateSocialMediaLimit(limit)
    }

    suspend fun insertSleepRecord(record: SleepRecordEntity) {
        database.healthDao().insertSleepRecord(record)
    }

    suspend fun insertMoodRecord(record: MoodRecordEntity) {
        database.healthDao().insertMoodRecord(record)
    }

    suspend fun sendAiMessage(userText: String, userDivision: String, userName: String): String {
        // Save user message
        database.aiChatDao().insertMessage(
            AiChatMessageEntity(sender = "user", message = userText)
        )

        // Call Gemini
        val response = GeminiService.generateResponse(userText, userDivision, userName)

        // Save AI message
        database.aiChatDao().insertMessage(
            AiChatMessageEntity(sender = "model", message = response)
        )

        return response
    }

    suspend fun clearAiChat() {
        database.aiChatDao().clearChat()
    }

    fun calculatePrayerTimes(governorate: String): PrayerTimesResult {
        return PrayerTimesCalculator.calculate(governorate)
    }
}
