package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = 1 LIMIT 1")
    fun getUser(): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = 1 LIMIT 1")
    suspend fun getUserDirect(): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)
}

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY id ASC")
    fun getAllSubjects(): Flow<List<SubjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: SubjectEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<SubjectEntity>)

    @Update
    suspend fun updateSubject(subject: SubjectEntity)

    @Delete
    suspend fun deleteSubject(subject: SubjectEntity)

    @Query("SELECT * FROM lessons WHERE subjectId = :subjectId")
    fun getLessonsForSubject(subjectId: Long): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons ORDER BY dayOfWeek ASC, startTime ASC")
    fun getAllLessons(): Flow<List<LessonEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLesson(lesson: LessonEntity)

    @Update
    suspend fun updateLesson(lesson: LessonEntity)

    @Delete
    suspend fun deleteLesson(lesson: LessonEntity)
}

@Dao
interface StudySessionDao {
    @Query("SELECT * FROM study_sessions ORDER BY startTime DESC")
    fun getAllSessions(): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_sessions WHERE dateString = :dateString")
    fun getSessionsForDate(dateString: String): Flow<List<StudySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySessionEntity)

    @Query("SELECT * FROM summaries ORDER BY createdAt DESC")
    fun getAllSummaries(): Flow<List<SummaryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSummary(summary: SummaryEntity)

    @Delete
    suspend fun deleteSummary(summary: SummaryEntity)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, dueDateString ASC, id DESC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE dueDateString = :dateString ORDER BY isCompleted ASC")
    fun getTasksForDate(dateString: String): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<TaskEntity>)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("SELECT * FROM goals ORDER BY isCompleted ASC, id ASC")
    fun getAllGoals(): Flow<List<GoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: GoalEntity)

    @Update
    suspend fun updateGoal(goal: GoalEntity)

    @Delete
    suspend fun deleteGoal(goal: GoalEntity)
}

@Dao
interface PrayerDao {
    @Query("SELECT * FROM prayers WHERE dateString = :dateString")
    fun getPrayersForDate(dateString: String): Flow<List<PrayerEntity>>

    @Query("SELECT * FROM prayers WHERE dateString = :dateString AND prayerName = :prayerName LIMIT 1")
    suspend fun getPrayer(dateString: String, prayerName: String): PrayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrayer(prayer: PrayerEntity)

    @Query("SELECT * FROM prayers WHERE isQada = 1 ORDER BY dateString DESC")
    fun getQadaPrayers(): Flow<List<PrayerEntity>>

    @Query("SELECT COUNT(*) FROM prayers WHERE dateString = :dateString AND isDone = 1")
    fun getCompletedPrayersCount(dateString: String): Flow<Int>
}

@Dao
interface DhikrDao {
    @Query("SELECT * FROM dhikr_records WHERE dateString = :dateString")
    fun getDhikrRecordsForDate(dateString: String): Flow<List<DhikrRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDhikrRecord(record: DhikrRecordEntity)

    @Query("SELECT * FROM custom_dhikrs ORDER BY id ASC")
    fun getCustomDhikrs(): Flow<List<CustomDhikrEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomDhikr(dhikr: CustomDhikrEntity)

    @Delete
    suspend fun deleteCustomDhikr(dhikr: CustomDhikrEntity)

    @Query("SELECT * FROM quran_progress WHERE id = 1 LIMIT 1")
    fun getQuranProgress(): Flow<QuranProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuranProgress(progress: QuranProgressEntity)
}

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM schedule_blocks ORDER BY hourStart ASC")
    fun getAllScheduleBlocks(): Flow<List<ScheduleBlockEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScheduleBlocks(blocks: List<ScheduleBlockEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScheduleBlock(block: ScheduleBlockEntity)

    @Update
    suspend fun updateScheduleBlock(block: ScheduleBlockEntity)

    @Delete
    suspend fun deleteScheduleBlock(block: ScheduleBlockEntity)

    @Query("SELECT * FROM social_media_limits ORDER BY id ASC")
    fun getSocialMediaLimits(): Flow<List<SocialMediaLimitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSocialMediaLimits(limits: List<SocialMediaLimitEntity>)

    @Update
    suspend fun updateSocialMediaLimit(limit: SocialMediaLimitEntity)
}

@Dao
interface HealthDao {
    @Query("SELECT * FROM sleep_records ORDER BY dateString DESC LIMIT 30")
    fun getSleepRecords(): Flow<List<SleepRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSleepRecord(record: SleepRecordEntity)

    @Query("SELECT * FROM mood_records ORDER BY timestamp DESC LIMIT 30")
    fun getMoodRecords(): Flow<List<MoodRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMoodRecord(record: MoodRecordEntity)
}

@Dao
interface AiChatDao {
    @Query("SELECT * FROM ai_chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<AiChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: AiChatMessageEntity)

    @Query("DELETE FROM ai_chat_messages")
    suspend fun clearChat()
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements")
    fun getAllAchievements(): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements WHERE isUnlocked = 1")
    fun getUnlockedAchievements(): Flow<List<AchievementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievements(achievements: List<AchievementEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievement(achievement: AchievementEntity)

    @Update
    suspend fun updateAchievement(achievement: AchievementEntity)
}
