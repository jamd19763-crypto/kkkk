package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: Long = 1L,
    val name: String = "طالب الثانوية",
    val email: String = "student@thanaweya.eg",
    val age: Int = 18,
    val governorate: String = "القاهرة",
    val grade: String = "الصف الثالث الثانوي",
    val division: String = "علمي علوم", // علمي علوم / علمي رياضة / أدبي
    val profilePicture: String = "",
    val joinedTimestamp: Long = System.currentTimeMillis(),
    val isGuest: Boolean = false,
    val ruqyahPin: String = "", // empty means no pin protection
    val isRuqyahLocked: Boolean = false
)

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val division: String, // علمي علوم / علمي رياضة / أدبي / عام
    val colorHex: String,
    val iconName: String,
    val targetHours: Double = 100.0,
    val hoursCompleted: Double = 0.0,
    val totalLessons: Int = 20,
    val completedLessons: Int = 0,
    val notes: String = ""
)

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val subjectName: String,
    val title: String,
    val teacherName: String = "",
    val dayOfWeek: String, // السبت، الأحد، ...
    val startTime: String, // "14:00"
    val endTime: String,   // "16:00"
    val location: String = "سنتر التفوق",
    val price: String = "",
    val notes: String = "",
    val notificationBeforeMinutes: Int = 15,
    val colorHex: String = "#1B6A4B"
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val subjectName: String,
    val startTime: Long,
    val durationMinutes: Int,
    val type: String, // قراءة، حل مسائل، حفظ، مراجعة، سماع، بومودورو
    val rating: Int = 5, // 1-5 stars
    val notes: String = "",
    val difficulties: String = "",
    val dateString: String // YYYY-MM-DD
)

@Entity(tableName = "summaries")
data class SummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectName: String,
    val title: String,
    val content: String,
    val keyPoints: String = "",
    val tags: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val dueDateString: String, // YYYY-MM-DD
    val priority: String = "عالية", // عالية، متوسطة، منخفضة
    val category: String = "مذاكرة", // مذاكرة، ديني، شخصي، صحي
    val isCompleted: Boolean = false,
    val pointsAwarded: Int = 10,
    val reminderTime: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val targetDateString: String = "",
    val progressPercentage: Int = 0,
    val isCompleted: Boolean = false,
    val category: String = "دراسي" // دراسي، ديني، شخصي
)

@Entity(tableName = "prayers")
data class PrayerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val prayerName: String, // الفجر، الظهر، العصر، المغرب، العشاء
    val dateString: String, // YYYY-MM-DD
    val isDone: Boolean = false,
    val inMosque: Boolean = false,
    val isQada: Boolean = false,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "dhikr_records")
data class DhikrRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dhikrId: String,
    val category: String, // صباح، مساء، بعد الصلاة، نوم، استيقاظ، تحصين، رقية
    val dateString: String,
    val countDone: Int,
    val targetCount: Int
)

@Entity(tableName = "custom_dhikrs")
data class CustomDhikrEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val targetCount: Int = 33,
    val reward: String = "",
    val category: String = "مخصص"
)

@Entity(tableName = "quran_progress")
data class QuranProgressEntity(
    @PrimaryKey val id: Long = 1L,
    val targetJuzPerMonth: Int = 30,
    val currentJuz: Int = 1,
    val currentSurah: String = "الفاتحة",
    val currentAyah: Int = 1,
    val lastReadDateString: String = "",
    val completedKhatmas: Int = 0
)

@Entity(tableName = "schedule_blocks")
data class ScheduleBlockEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hourStart: Int, // 5 to 23
    val title: String,
    val category: String, // مذاكرة، درس، صلاة، نوم، أكل، رياضة، راحة، سوشيال
    val colorHex: String = "#1B6A4B",
    val dayOfWeek: String = "الكل",
    val isCompleted: Boolean = false
)

@Entity(tableName = "social_media_limits")
data class SocialMediaLimitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appName: String, // فيسبوك، يوتيوب، تيك توك، واتساب، تليجرام
    val iconName: String = "",
    val maxMinutesPerDay: Int = 45,
    val usedMinutesToday: Int = 0,
    val isBlockedDuringStudy: Boolean = true
)

@Entity(tableName = "sleep_records")
data class SleepRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String,
    val sleepTime: String = "23:00",
    val wakeTime: String = "06:00",
    val durationHours: Double = 7.0,
    val qualityRating: Int = 5,
    val notes: String = ""
)

@Entity(tableName = "mood_records")
data class MoodRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String,
    val moodEmoji: String, // 😃، 😊، 😐، 😟، 😫
    val moodLabel: String, // متحمس، رايق، عادي، قلق، مضغوط
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_chat_messages")
data class AiChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "user" or "model"
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val points: Int,
    val icon: String,
    val isUnlocked: Boolean = false,
    val unlockedDate: String = ""
)
