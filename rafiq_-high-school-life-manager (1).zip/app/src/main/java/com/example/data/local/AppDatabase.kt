package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.DefaultData
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        SubjectEntity::class,
        LessonEntity::class,
        StudySessionEntity::class,
        SummaryEntity::class,
        TaskEntity::class,
        GoalEntity::class,
        PrayerEntity::class,
        DhikrRecordEntity::class,
        CustomDhikrEntity::class,
        QuranProgressEntity::class,
        ScheduleBlockEntity::class,
        SocialMediaLimitEntity::class,
        SleepRecordEntity::class,
        MoodRecordEntity::class,
        AiChatMessageEntity::class,
        AchievementEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun subjectDao(): SubjectDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun taskDao(): TaskDao
    abstract fun prayerDao(): PrayerDao
    abstract fun dhikrDao(): DhikrDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun healthDao(): HealthDao
    abstract fun aiChatDao(): AiChatDao
    abstract fun achievementDao(): AchievementDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "life_balance_thanawya.db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: AppDatabase) {
            // Default User
            db.userDao().insertUser(
                UserEntity(
                    id = 1L,
                    name = "طالب الثانوية",
                    division = "علمي علوم",
                    governorate = "القاهرة",
                    grade = "الصف الثالث الثانوي",
                    isGuest = false
                )
            )

            // Default Subjects for "علمي علوم"
            val defaultSubjects = DefaultData.getDefaultSubjects("علمي علوم")
            db.subjectDao().insertSubjects(defaultSubjects)

            // Default Quran Progress
            db.dhikrDao().insertQuranProgress(
                QuranProgressEntity(
                    id = 1L,
                    targetJuzPerMonth = 30,
                    currentJuz = 1,
                    currentSurah = "الفاتحة",
                    currentAyah = 1,
                    completedKhatmas = 0
                )
            )

            // Default Custom Dhikrs (Daily Tasbih)
            val initialCustomDhikrs = listOf(
                CustomDhikrEntity(text = "سُبْحَانَ اللَّهِ", targetCount = 33, reward = "غرس نخلة في الجنة"),
                CustomDhikrEntity(text = "الْحَمْدُ لِلَّهِ", targetCount = 33, reward = "تملأ الميزان بالخير"),
                CustomDhikrEntity(text = "اللَّهُ أَكْبَرُ", targetCount = 33, reward = "عظمة وقوة ويقين"),
                CustomDhikrEntity(text = "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", targetCount = 100, reward = "تفريج الهموم وفتح المغاليق"),
                CustomDhikrEntity(text = "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", targetCount = 100, reward = "كفاية الهم وغفران الذنب"),
                CustomDhikrEntity(text = "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ", targetCount = 100, reward = "كنز من كنوز الجنة")
            )
            initialCustomDhikrs.forEach { db.dhikrDao().insertCustomDhikr(it) }

            // Default Tasks for today
            val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
            val initialTasks = listOf(
                TaskEntity(title = "أذكار الصباح وسماع ورد القرآن اليومي", dueDateString = todayStr, priority = "عالية", category = "ديني", pointsAwarded = 15),
                TaskEntity(title = "مذاكرة الفصل الأول فيزياء (قانون أوم وكيرشوف)", dueDateString = todayStr, priority = "عالية", category = "مذاكرة", pointsAwarded = 25),
                TaskEntity(title = "حل 30 سؤال كيمياء على الباب الأول (العناصر الانتقالية)", dueDateString = todayStr, priority = "متوسطة", category = "مذاكرة", pointsAwarded = 20),
                TaskEntity(title = "تمارين التنفس 4-7-8 وشرب 2 لتر ماء", dueDateString = todayStr, priority = "منخفضة", category = "صحي", pointsAwarded = 10)
            )
            db.taskDao().insertTasks(initialTasks)

            // Default Goals
            val initialGoals = listOf(
                GoalEntity(title = "الحصول على مجموع 95%+ والالتحاق بالكلية المستهدفة", description = "الاجتهاد اليومي، الالتزام بالصلوات الخمس، وحل امتحانات السنوات السابقة", progressPercentage = 35),
                GoalEntity(title = "ختم القرآن الكريم كاملاً كل شهر خلال الثانوية", description = "قراءة جزء واحد يومياً بعد كل صلاة 4 صفحات", progressPercentage = 20),
                GoalEntity(title = "إنهاء جميع المناهج وبدء المراجعات النهائية في شهر أبريل", description = "خطة مكثفة أسبوعية للمذاكرة والمتابعة", progressPercentage = 40)
            )
            initialGoals.forEach { db.taskDao().insertGoal(it) }

            // Default Schedule Blocks
            val initialSchedule = listOf(
                ScheduleBlockEntity(hourStart = 5, title = "صلاة الفجر + أذكار الصباح + ورد القرآن", category = "صلاة", colorHex = "#1B6A4B"),
                ScheduleBlockEntity(hourStart = 6, title = "جلسة المذاكرة الذهبية (أصعب مادة)", category = "مذاكرة", colorHex = "#23865D"),
                ScheduleBlockEntity(hourStart = 8, title = "إفطار صحي + استراحة قصيرة", category = "أكل", colorHex = "#F4A261"),
                ScheduleBlockEntity(hourStart = 9, title = "المدرسة أو المحاضرات والدروس الخصوصية", category = "درس", colorHex = "#8338EC"),
                ScheduleBlockEntity(hourStart = 13, title = "صلاة الظهر + غداء عائلي", category = "صلاة", colorHex = "#1B6A4B"),
                ScheduleBlockEntity(hourStart = 14, title = "جلسة حل تمارين وامتحانات شاملة", category = "مذاكرة", colorHex = "#23865D"),
                ScheduleBlockEntity(hourStart = 16, title = "صلاة العصر + تمارين تنفس واستراحة", category = "راحة", colorHex = "#2A9D8F"),
                ScheduleBlockEntity(hourStart = 17, title = "حفظ اللغات ومراجعة المواد النظرية", category = "مذاكرة", colorHex = "#23865D"),
                ScheduleBlockEntity(hourStart = 19, title = "صلاة المغرب والعشاء + أذكار المساء", category = "صلاة", colorHex = "#1B6A4B"),
                ScheduleBlockEntity(hourStart = 20, title = "مراجعة اليوم والتخطيط للغد", category = "مذاكرة", colorHex = "#2EA071"),
                ScheduleBlockEntity(hourStart = 22, title = "أذكار النوم + نوم عميق مبكر", category = "نوم", colorHex = "#264653")
            )
            db.scheduleDao().insertScheduleBlocks(initialSchedule)

            // Default Social Limits
            val initialLimits = listOf(
                SocialMediaLimitEntity(appName = "فيسبوك", maxMinutesPerDay = 30, usedMinutesToday = 10),
                SocialMediaLimitEntity(appName = "واتساب وتليجرام", maxMinutesPerDay = 45, usedMinutesToday = 20),
                SocialMediaLimitEntity(appName = "يوتيوب", maxMinutesPerDay = 60, usedMinutesToday = 25),
                SocialMediaLimitEntity(appName = "تيك توك وإنستجرام", maxMinutesPerDay = 15, usedMinutesToday = 5)
            )
            db.scheduleDao().insertSocialMediaLimits(initialLimits)

            // Welcome AI message
            db.aiChatDao().insertMessage(
                AiChatMessageEntity(
                    sender = "model",
                    message = "السلام عليكم ورحمة الله وبركاته يا بطل الثانوية العامة! 👋\nأنا رفيقك ومساعدك الذكي في «رفيق التالتة ثانوي». جاهز أشرح لك أي درس معقد، أحل معاك مسائل، ألخص قوانين، أو أنظم لك وقتك ويومك. تحب نبدأ بإيه النهاردة؟"
                )
            )
        }
    }
}
