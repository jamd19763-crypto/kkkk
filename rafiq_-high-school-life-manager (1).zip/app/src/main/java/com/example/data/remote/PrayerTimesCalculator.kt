package com.example.data.remote

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.*

data class PrayerTimesResult(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val nextPrayerName: String,
    val remainingTimeFormatted: String,
    val governorate: String
)

object PrayerTimesCalculator {

    private data class Coordinates(val lat: Double, val lng: Double, val timeZoneOffset: Double = 2.0)

    private val GOV_COORDS = mapOf(
        "القاهرة" to Coordinates(30.0444, 31.2357, 2.0),
        "الجيزة" to Coordinates(30.0131, 31.2089, 2.0),
        "الإسكندرية" to Coordinates(31.2001, 29.9187, 2.0),
        "الدقهلية" to Coordinates(31.0409, 31.3785, 2.0),
        "الشرقية" to Coordinates(30.5765, 31.5041, 2.0),
        "القليوبية" to Coordinates(30.4660, 31.1856, 2.0),
        "كفر الشيخ" to Coordinates(31.1107, 30.9388, 2.0),
        "الغربية" to Coordinates(30.7865, 31.0004, 2.0),
        "المنوفية" to Coordinates(30.5526, 31.0094, 2.0),
        "البحيرة" to Coordinates(31.0379, 30.4728, 2.0),
        "دمياط" to Coordinates(31.4175, 31.8144, 2.0),
        "بورسعيد" to Coordinates(31.2653, 32.3019, 2.0),
        "الإسماعيلية" to Coordinates(30.5965, 32.2715, 2.0),
        "السويس" to Coordinates(29.9668, 32.5498, 2.0),
        "شمال سيناء" to Coordinates(31.1316, 33.7984, 2.0),
        "جنوب سيناء" to Coordinates(27.9158, 34.3299, 2.0),
        "بني سويف" to Coordinates(29.0661, 31.0994, 2.0),
        "الفيوم" to Coordinates(29.3084, 30.8428, 2.0),
        "المنيا" to Coordinates(28.1099, 30.7503, 2.0),
        "أسيوط" to Coordinates(27.1783, 31.1859, 2.0),
        "سوهاج" to Coordinates(26.5569, 31.6948, 2.0),
        "قنا" to Coordinates(26.1551, 32.7160, 2.0),
        "الأقصر" to Coordinates(25.6872, 32.6396, 2.0),
        "أسوان" to Coordinates(24.0889, 32.8998, 2.0),
        "البحر الأحمر" to Coordinates(27.2579, 33.8116, 2.0),
        "الوادي الجديد" to Coordinates(25.4514, 30.5472, 2.0),
        "مطروح" to Coordinates(31.3543, 27.2373, 2.0)
    )

    fun calculate(governorate: String, calendar: Calendar = Calendar.getInstance()): PrayerTimesResult {
        val coords = GOV_COORDS[governorate] ?: GOV_COORDS["القاهرة"]!!
        val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
        val year = calendar.get(Calendar.YEAR)

        // Solar Declination & Equation of Time (Egyptian General Authority of Survey Standard)
        val d = dayOfYear.toDouble()
        val b = 2.0 * Math.PI * (d - 81.0) / 365.0
        val eot = 9.87 * sin(2.0 * b) - 7.53 * cos(b) - 1.5 * sin(b) // minutes
        val declination = Math.toRadians(23.45 * sin(Math.toRadians(360.0 / 365.0 * (d - 81.0))))

        val latRad = Math.toRadians(coords.lat)
        val timezoneOffset = 2.0 // Egypt Standard Time (UTC+2)

        // Solar Noon (Dhuhr)
        val solarNoonUtc = 12.0 - (coords.lng / 15.0) - (eot / 60.0)
        val dhuhrDec = solarNoonUtc + timezoneOffset

        // Angles for Egyptian Survey: Fajr 19.5°, Isha 17.5°, Sunrise 0.833°
        val fajrAngle = Math.toRadians(19.5)
        val ishaAngle = Math.toRadians(17.5)
        val sunriseAngle = Math.toRadians(0.833)

        fun hourAngle(angle: Double, isBelowHorizon: Boolean = true): Double {
            val cosH = if (isBelowHorizon) {
                (-sin(angle) - sin(latRad) * sin(declination)) / (cos(latRad) * cos(declination))
            } else {
                (sin(angle) - sin(latRad) * sin(declination)) / (cos(latRad) * cos(declination))
            }
            val clamped = cosH.coerceIn(-1.0, 1.0)
            return Math.toDegrees(acos(clamped)) / 15.0
        }

        val fajrHA = hourAngle(fajrAngle)
        val sunriseHA = hourAngle(sunriseAngle)
        val ishaHA = hourAngle(ishaAngle)

        // Asr (Shafi'i/Standard: shadow length = object length + shadow at noon)
        val noonAlt = Math.PI / 2.0 - abs(latRad - declination)
        val asrAlt = atan(1.0 / (1.0 + tan(Math.PI / 2.0 - noonAlt)))
        val asrHA = hourAngle(asrAlt, isBelowHorizon = false)

        val fajrDec = dhuhrDec - fajrHA
        val sunriseDec = dhuhrDec - sunriseHA
        val asrDec = dhuhrDec + asrHA
        val maghribDec = dhuhrDec + sunriseHA
        val ishaDec = dhuhrDec + ishaHA

        fun formatTime(decHours: Double): String {
            var h = (decHours % 24.0)
            if (h < 0) h += 24.0
            val hours = h.toInt()
            val minutes = ((h - hours) * 60.0).roundToInt() % 60
            val adjustedHours = if (minutes == 0 && (h - hours) * 60.0 >= 59.5) (hours + 1) % 24 else hours
            return String.format("%02d:%02d", adjustedHours, minutes)
        }

        val fajrStr = formatTime(fajrDec)
        val sunriseStr = formatTime(sunriseDec)
        val dhuhrStr = formatTime(dhuhrDec)
        val asrStr = formatTime(asrDec)
        val maghribStr = formatTime(maghribDec)
        val ishaStr = formatTime(ishaDec)

        // Determine next prayer and time remaining
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMin = calendar.get(Calendar.MINUTE)
        val currentMinutesTotal = currentHour * 60 + currentMin

        fun toMin(timeStr: String): Int {
            val parts = timeStr.split(":")
            return parts[0].toInt() * 60 + parts[1].toInt()
        }

        val prayerTimesList = listOf(
            "الفجر" to toMin(fajrStr),
            "الظهر" to toMin(dhuhrStr),
            "العصر" to toMin(asrStr),
            "المغرب" to toMin(maghribStr),
            "العشاء" to toMin(ishaStr)
        )

        var nextPrayer = "الفجر"
        var diffMinutes = 0
        var found = false

        for ((name, pMin) in prayerTimesList) {
            if (pMin > currentMinutesTotal) {
                nextPrayer = name
                diffMinutes = pMin - currentMinutesTotal
                found = true
                break
            }
        }

        if (!found) {
            // Next is tomorrow's Fajr
            nextPrayer = "الفجر"
            diffMinutes = (24 * 60 - currentMinutesTotal) + prayerTimesList.first().second
        }

        val remH = diffMinutes / 60
        val remM = diffMinutes % 60
        val remainingFormatted = if (remH > 0) "باقي $remH ساعة و $remM دقيقة" else "باقي $remM دقيقة"

        return PrayerTimesResult(
            fajr = fajrStr,
            sunrise = sunriseStr,
            dhuhr = dhuhrStr,
            asr = asrStr,
            maghrib = maghribStr,
            isha = ishaStr,
            nextPrayerName = nextPrayer,
            remainingTimeFormatted = remainingFormatted,
            governorate = governorate
        )
    }
}
