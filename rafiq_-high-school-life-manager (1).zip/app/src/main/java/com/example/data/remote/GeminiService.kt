package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM_PROMPT = """
أنت "مساعد التالتة ثانوي" الذكي، رفيق ومرشد متفوق لطالب الثانوية العامة في مصر.
مهامك:
1. شرح الدروس والمفاهيم المعقدة (فيزياء، كيمياء، أحياء، جيولوجيا، رياضيات بحتة وتطبيقية، لغة عربية ونصوص ونحو، لغة إنجليزية، تاريخ، جغرافيا، فلسفة).
2. تبسيط الشرح بأسلوب تفاعلي، مشجع، واستخدام أمثلة من واقع المنهج المصري للثانوية العامة.
3. المساعدة في تنظيم الوقت والجدول الدراسي والتحفيز الإيماني والنفسي.
4. الإجابة بلغة عربية فصحى مع لمسة ودية مصرية تشجع الطالب وتزرع فيه الثقة بالله وبقدراته.
5. الرد بإيجاز ووضوح وتنسيق نقاط جميلة.
"""

    suspend fun generateResponse(
        prompt: String,
        userDivision: String = "علمي علوم",
        userName: String = "يا بطل"
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        if (apiKey.isNullOrBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getOfflineIntelligentResponse(prompt, userDivision, userName)
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
            
            val jsonBody = JSONObject().apply {
                val contents = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            val systemAndUser = "$SYSTEM_PROMPT\n[معلومات الطالب: الاسم: $userName، الشعبة: $userDivision]\nسؤال الطالب: $prompt"
                            put(JSONObject().put("text", systemAndUser))
                        }
                        put("parts", parts)
                    }
                    put(contentObj)
                }
                put("contents", contents)
                
                val genConfig = JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 1200)
                }
                put("generationConfig", genConfig)
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                val jsonResponse = JSONObject(responseBody)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    if (parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).getString("text")
                    }
                }
            }

            Log.w(TAG, "Gemini API error code: ${response.code}, falling back to local intelligence.")
            getOfflineIntelligentResponse(prompt, userDivision, userName)
        } catch (e: Exception) {
            Log.e(TAG, "Gemini network exception", e)
            getOfflineIntelligentResponse(prompt, userDivision, userName)
        }
    }

    private fun getOfflineIntelligentResponse(prompt: String, division: String, name: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("جدول") || lower.contains("وقت") || lower.contains("تنظيم") ->
                "أهلاً بك يا $name! 🌟\nإليك استراتيجية تنظيم الوقت الذهبية للثانوية العامة:\n\n1️⃣ ابدأ يومك بعد صلاة الفجر مباشرة (وقت البركة والصفاء الذهني).\n2️⃣ قسّم مذاكرتك إلى جلسات بومودورو: 50 دقيقة تركيز + 10 دقائق راحة بعيداً عن الموبايل.\n3️⃣ حدد 3 مهام أساسية فقط لكل يوم وأنجز الصعب أولاً.\n4️⃣ اختم يومك قبل 11:30 مساءً لتنال قسطاً كافياً من النوم يعزز تثبيت الذاكرة."

            lower.contains("قلق") || lower.contains("خايف") || lower.contains("توتر") || lower.contains("تعبت") ->
                "يا $name، خذ نفساً عميقاً واعلم أن الله لا يضيع أجر من أحسن عملاً. 🤍\n\n- الثانوية العامة ليست نهاية المطاف بل خطوة في طريق نجاحك.\n- تذكر دعاء سيدنا يونس: «لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ».\n- استعذ بالله من الشيطان الرجيم وقسّم المادة الكبيرة إلى دروس صغيرة جداً، وابدأ بخطوة واحدة الآن."

            lower.contains("فيزياء") || lower.contains("كيمياء") || lower.contains("أحياء") || lower.contains("رياضة") ->
                "بالنسبة لمواد شعبة $division:\n\n💡 السر هنا في «الفهم العميق وحل أفكار امتحانات سابقة» وليس مجرد الحفظ!\n- اكتب القوانين والعلاقات في ملخص جانبي بخط يدك.\n- بعد كل درس، حل ما لا يقل عن 30 إلى 50 فكرة متنوعة.\n- علّم على المسائل التي أخطأت فيها وأعد حلها بعد يومين (طريقة التكرار المتباعد)."

            lower.contains("عربي") || lower.contains("نحو") || lower.contains("بلاغة") ->
                "اللغة العربية هي صانعة المجموع في الثانوية! 📖\n\n- النحو: الإعراب فرع المعنى، افهم الجملة وسياقها أولاً قبل تحديد الموقع الإعرابي.\n- البلاغة والنصوص: تدرب على استخراج العلاقات (تعليل، نتيجة، تفصيل) والمحسنات البديعية عملياً.\n- القراءة المتحررة: اقرأ المقال بتركيز واستخرج الفكرة الرئيسة والأفكار الفرعية."

            else ->
                "مرحباً بك يا $name! أنا مساعدك الذكي في رفيق التالتة ثانوي. 🚀\n\nأنا هنا لمساعدتك في أي سؤال دراسي، شرح أي درس في منهج $division، تلخيص القوانين، أو وضع خطة مذاكرة تناسب مستواك. اسألني عن أي نقطة محددة وسأشرحها لك خطوة بخطوة!"
        }
    }
}
