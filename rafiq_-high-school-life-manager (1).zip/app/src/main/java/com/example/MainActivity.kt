package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.more.MoreScreen
import com.example.ui.screens.schedule.ScheduleScreen
import com.example.ui.screens.study.StudyScreen
import com.example.ui.screens.worship.WorshipScreen
import com.example.ui.theme.Emerald700
import com.example.ui.theme.Emerald800
import com.example.ui.theme.Gold400
import com.example.ui.theme.Gold500
import com.example.ui.theme.LifeBalanceTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LifeBalanceTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    LifeBalanceApp(viewModel = viewModel)
                }
            }
        }
    }
}

sealed class NavigationItem(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    object Dashboard : NavigationItem("dashboard", "الرئيسية", Icons.Filled.Home, Icons.Outlined.Home)
    object Study : NavigationItem("study", "المذاكرة", Icons.Filled.MenuBook, Icons.Outlined.MenuBook)
    object Worship : NavigationItem("worship", "العبادات", Icons.Filled.Mosque, Icons.Outlined.Mosque)
    object Schedule : NavigationItem("schedule", "الجدول", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth)
    object More : NavigationItem("more", "المزيد", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeBalanceApp(viewModel: MainViewModel) {
    val activeTab by viewModel.activeTab.collectAsState()

    val navItems = listOf(
        NavigationItem.Dashboard,
        NavigationItem.Study,
        NavigationItem.Worship,
        NavigationItem.Schedule,
        NavigationItem.More
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Emerald800),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Balance,
                                contentDescription = null,
                                tint = Gold400,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "رفيق التالتة ثانوي",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                navItems.forEach { item ->
                    val isSelected = activeTab == item.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setActiveTab(item.route) },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.title
                            )
                        },
                        label = {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Emerald700,
                            selectedTextColor = Emerald700,
                            indicatorColor = Emerald700.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                "dashboard" -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToTab = { tab -> viewModel.setActiveTab(tab) }
                )
                "study" -> StudyScreen(viewModel = viewModel)
                "worship" -> WorshipScreen(viewModel = viewModel)
                "schedule" -> ScheduleScreen(viewModel = viewModel)
                "more" -> MoreScreen(viewModel = viewModel)
            }
        }
    }
}
