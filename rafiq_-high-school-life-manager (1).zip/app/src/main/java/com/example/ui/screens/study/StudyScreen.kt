package com.example.ui.screens.study

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LessonEntity
import com.example.data.model.SubjectEntity
import com.example.data.model.SummaryEntity
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun StudyScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val subjects by viewModel.subjects.collectAsState()
    val allLessons by viewModel.allLessons.collectAsState()
    val summaries by viewModel.summaries.collectAsState()

    var selectedSubTab by remember { mutableStateOf(0) }
    val subTabs = listOf("المواد والمناهج", "جدول الدروس", "بومودورو التركيز", "تقنية فاينمان", "الملخصات")

    var showAddSubjectDialog by remember { mutableStateOf(false) }
    var showAddLessonDialog by remember { mutableStateOf(false) }
    var showAddSummaryDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Sub Tabs Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(subTabs.indices.toList()) { index ->
                TabPill(
                    text = subTabs[index],
                    isSelected = selectedSubTab == index,
                    onClick = { selectedSubTab = index }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedSubTab) {
            0 -> SubjectsTabContent(
                subjects = subjects,
                onAddSubject = { showAddSubjectDialog = true },
                onUpdateProgress = { subj, hours, lessonDone ->
                    viewModel.updateSubjectProgress(subj, hours, lessonDone)
                },
                onDeleteSubject = { subj -> viewModel.deleteSubject(subj) }
            )
            1 -> LessonsScheduleTabContent(
                lessons = allLessons,
                subjects = subjects,
                onAddLesson = { showAddLessonDialog = true },
                onDeleteLesson = { lesson -> viewModel.deleteLesson(lesson) }
            )
            2 -> PomodoroTabContent(
                subjects = subjects,
                onSaveSession = { subjId, subjName, duration, type, rating, notes, diff ->
                    viewModel.saveStudySession(subjId, subjName, duration, type, rating, notes, diff)
                }
            )
            3 -> FeynmanTabContent(
                subjects = subjects,
                onAskAi = { prompt -> viewModel.sendAiPrompt(prompt) }
            )
            4 -> SummariesTabContent(
                summaries = summaries,
                subjects = subjects,
                onAddSummary = { showAddSummaryDialog = true },
                onDeleteSummary = { summ -> viewModel.deleteSummary(summ) }
            )
        }
    }

    if (showAddSubjectDialog) {
        AddSubjectDialog(
            onDismiss = { showAddSubjectDialog = false },
            onConfirm = { name, hours, lessons, color ->
                viewModel.addSubject(name, hours, lessons, color)
                showAddSubjectDialog = false
            }
        )
    }

    if (showAddLessonDialog) {
        AddLessonDialog(
            subjects = subjects,
            onDismiss = { showAddLessonDialog = false },
            onConfirm = { subjId, subjName, title, teacher, day, start, end, loc ->
                viewModel.addLesson(subjId, subjName, title, teacher, day, start, end, loc)
                showAddLessonDialog = false
            }
        )
    }

    if (showAddSummaryDialog) {
        AddSummaryDialog(
            subjects = subjects,
            onDismiss = { showAddSummaryDialog = false },
            onConfirm = { subj, title, content, keys, tags ->
                viewModel.addSummary(subj, title, content, keys, tags)
                showAddSummaryDialog = false
            }
        )
    }
}

@Composable
fun SubjectsTabContent(
    subjects: List<SubjectEntity>,
    onAddSubject: () -> Unit,
    onUpdateProgress: (SubjectEntity, Double, Boolean) -> Unit,
    onDeleteSubject: (SubjectEntity) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "مواد الثانوية العامة ومستوى الإنجاز",
                subtitle = "${subjects.size} مواد مسجلة في خطتك",
                icon = Icons.Default.MenuBook,
                actionText = "+ مادة جديدة",
                onActionClick = onAddSubject
            )
        }

        items(subjects) { subject ->
            val progressHours = if (subject.targetHours > 0) (subject.hoursCompleted / subject.targetHours).toFloat().coerceIn(0f, 1f) else 0f
            val progressLessons = if (subject.totalLessons > 0) (subject.completedLessons.toFloat() / subject.totalLessons.toFloat()).coerceIn(0f, 1f) else 0f

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Emerald800),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoStories,
                                    contentDescription = null,
                                    tint = Gold400,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = subject.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${subject.division} • ${subject.completedLessons}/${subject.totalLessons} درس",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }

                        IconButton(onClick = { onDeleteSubject(subject) }, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "حذف",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        }
                    }

                    // Progress bars
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ساعات المذاكرة: %.1f / %.0f س".format(subject.hoursCompleted, subject.targetHours),
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                text = "${(progressHours * 100).toInt()}%",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Emerald600)
                            )
                        }
                        CustomProgressBar(progress = progressHours, color = Emerald600)
                    }

                    // Quick Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onUpdateProgress(subject, 1.0, false) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+1 ساعة", fontSize = 12.sp)
                        }
                        Button(
                            onClick = { onUpdateProgress(subject, 0.5, true) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald700),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("أنهيت درساً ✓", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LessonsScheduleTabContent(
    lessons: List<LessonEntity>,
    subjects: List<SubjectEntity>,
    onAddLesson: () -> Unit,
    onDeleteLesson: (LessonEntity) -> Unit
) {
    val days = listOf("الكل", "السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
    var selectedDay by remember { mutableStateOf("الكل") }

    val filteredLessons = if (selectedDay == "الكل") lessons else lessons.filter { it.dayOfWeek == selectedDay }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "جدول الدروس والسناتر والمحاضرات",
                subtitle = "مواعيدك وأماكن المعلمين",
                icon = Icons.Default.CalendarToday,
                actionText = "+ درس جديد",
                onActionClick = onAddLesson
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(days) { day ->
                    TabPill(
                        text = day,
                        isSelected = selectedDay == day,
                        onClick = { selectedDay = day }
                    )
                }
            }
        }

        if (filteredLessons.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "لا توجد دروس مسجلة في هذا اليوم. اضغط على «+ درس جديد» لإضافة موعد.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredLessons) { lesson ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Emerald800)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = lesson.dayOfWeek,
                                        style = MaterialTheme.typography.labelSmall.copy(color = Gold400, fontWeight = FontWeight.Bold)
                                    )
                                }
                                Text(
                                    text = lesson.subjectName,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Text(
                                text = "المعلم: ${if (lesson.teacherName.isNotBlank()) lesson.teacherName else "الأستاذ"} • ${lesson.location}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccessTime,
                                    contentDescription = null,
                                    tint = Gold700,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "من ${lesson.startTime} إلى ${lesson.endTime}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Gold700, fontWeight = FontWeight.SemiBold)
                                )
                            }
                        }

                        IconButton(onClick = { onDeleteLesson(lesson) }) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "حذف الدرس",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PomodoroTabContent(
    subjects: List<SubjectEntity>,
    onSaveSession: (Long, String, Int, String, Int, String, String) -> Unit
) {
    var selectedDurationMinutes by remember { mutableStateOf(25) }
    var timeLeftSeconds by remember { mutableStateOf(25 * 60) }
    var isRunning by remember { mutableStateOf(false) }
    var selectedSubject by remember { mutableStateOf(subjects.firstOrNull()?.name ?: "فيزياء") }
    var sessionType by remember { mutableStateOf("حل مسائل") }

    LaunchedEffect(isRunning, timeLeftSeconds) {
        if (isRunning && timeLeftSeconds > 0) {
            delay(1000L)
            timeLeftSeconds--
        } else if (isRunning && timeLeftSeconds == 0) {
            isRunning = false
            val subjObj = subjects.find { it.name == selectedSubject }
            onSaveSession(
                subjObj?.id ?: 0L,
                selectedSubject,
                selectedDurationMinutes,
                sessionType,
                5,
                "جلسة بومودورو مكتملة بنجاح",
                "لا توجد صعوبات"
            )
        }
    }

    val minutes = timeLeftSeconds / 60
    val seconds = timeLeftSeconds % 60
    val progress = (timeLeftSeconds.toFloat() / (selectedDurationMinutes * 60).toFloat())

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "مؤقت بومودورو الذكي",
                subtitle = "ركز بقمة طاقتك وتخلص من التشتت",
                icon = Icons.Default.Timer
            )
        }

        // Duration Presets
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25 to "25 دقيقة (قياسي)", 50 to "50 دقيقة (جلسة مكثفة)", 15 to "15 دقيقة (مراجعة سريعة)").forEach { (dur, label) ->
                    TabPill(
                        text = label,
                        isSelected = selectedDurationMinutes == dur,
                        onClick = {
                            if (!isRunning) {
                                selectedDurationMinutes = dur
                                timeLeftSeconds = dur * 60
                            }
                        }
                    )
                }
            }
        }

        // Circular Timer Display
        item {
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Emerald800.copy(alpha = 0.4f),
                                MaterialTheme.colorScheme.surface
                            )
                        )
                    )
                    .border(4.dp, Emerald600, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "%02d:%02d".format(minutes, seconds),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isRunning) Emerald600 else MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Text(
                        text = if (isRunning) "🔥 جاري التركيز..." else "جاهز للانطلاق",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = if (isRunning) Emerald600 else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Text(
                        text = selectedSubject,
                        style = MaterialTheme.typography.bodySmall.copy(color = Gold700, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        // Controls
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Button(
                    onClick = { isRunning = !isRunning },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRunning) AccentCoral else Emerald700
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("start_pomodoro_button")
                ) {
                    Icon(
                        imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isRunning) "إيقاف مؤقت" else "ابدأ الجلسة")
                }

                OutlinedButton(
                    onClick = {
                        isRunning = false
                        timeLeftSeconds = selectedDurationMinutes * 60
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إعادة ضبط")
                }
            }
        }

        // Study Tip
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald900.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiObjects,
                        contentDescription = null,
                        tint = Gold400
                    )
                    Text(
                        text = "خلال الـ $selectedDurationMinutes دقيقة: اغلق إشعارات الهاتف تماماً، جهز ورقة وقلم، ولا تقم حتى يرن المؤقت!",
                        style = MaterialTheme.typography.bodySmall.copy(color = Emerald100)
                    )
                }
            }
        }
    }
}

@Composable
fun FeynmanTabContent(
    subjects: List<SubjectEntity>,
    onAskAi: (String) -> Unit
) {
    var conceptTitle by remember { mutableStateOf("") }
    var explanationText by remember { mutableStateOf("") }
    var resultAiFeedback by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "تقنية فاينمان (الشرح المبسط)",
                subtitle = "اشرح المفهوم وكأنك تشرحه لطفل لتتأكد من فهمك 100%",
                icon = Icons.Default.Psychology
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = conceptTitle,
                        onValueChange = { conceptTitle = it },
                        label = { Text("اسم المفهوم أو القانون") },
                        placeholder = { Text("مثال: قانون فاراداي، التكاثر في الإنسان، العزم...") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = explanationText,
                        onValueChange = { explanationText = it },
                        label = { Text("شرحك المبسط بأسلوبك الخاص") },
                        placeholder = { Text("اكتب شرحك هنا بلغة سهلة وأمثلة من الحياة اليومية...") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            if (conceptTitle.isNotBlank()) {
                                onAskAi("قيم شرحي لمفهوم ($conceptTitle) بأسلوب تقنية فاينمان: «$explanationText» واذكر لي الثغرات إن وجدت.")
                            }
                        },
                        enabled = conceptTitle.isNotBlank() && explanationText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald700),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("مراجعة الفهم مع المساعد الذكي")
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "خطوات فاينمان الأربعة الذهبية:",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Emerald600)
                    )
                    Text("1. اختر الموضوع واكتب عنوانه في الأعلى.", style = MaterialTheme.typography.bodySmall)
                    Text("2. اشرحه ببساطة شديدة دون استخدام مصطلحات معقدة.", style = MaterialTheme.typography.bodySmall)
                    Text("3. حدد النقاط التي تعثرت في شرحها وعد للكتاب لإعادة فهمها.", style = MaterialTheme.typography.bodySmall)
                    Text("4. بسط الشرح واستخدم تشبيهات وقصص لتثبيته في الذاكرة طويلة المدى.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun SummariesTabContent(
    summaries: List<SummaryEntity>,
    subjects: List<SubjectEntity>,
    onAddSummary: () -> Unit,
    onDeleteSummary: (SummaryEntity) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "بنك الملخصات والقوانين الذهبية",
                subtitle = "${summaries.size} ملخصات محفوظة للمراجعة السريعة",
                icon = Icons.Default.Notes,
                actionText = "+ ملخص جديد",
                onActionClick = onAddSummary
            )
        }

        if (summaries.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "لا توجد ملخصات مضافة. أضف ملخصاتك وقوانينك الهامة لتسترجعها ليلة الامتحان!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(summaries) { summary ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Emerald800)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = summary.subjectName,
                                    style = MaterialTheme.typography.labelSmall.copy(color = Gold400, fontWeight = FontWeight.Bold)
                                )
                            }
                            IconButton(onClick = { onDeleteSummary(summary) }, modifier = Modifier.size(24.dp)) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "حذف",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                )
                            }
                        }
                        Text(
                            text = summary.title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = summary.content,
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddSubjectDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, targetHours: Double, totalLessons: Int, color: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var targetHoursStr by remember { mutableStateOf("60") }
    var totalLessonsStr by remember { mutableStateOf("20") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مادة جديدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المادة") },
                    placeholder = { Text("مثال: فيزياء 3 ثانوي") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = targetHoursStr,
                    onValueChange = { targetHoursStr = it },
                    label = { Text("ساعات المذاكرة المستهدفة") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = totalLessonsStr,
                    onValueChange = { totalLessonsStr = it },
                    label = { Text("إجمالي عدد الدروس") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val hours = targetHoursStr.toDoubleOrNull() ?: 50.0
                    val lessons = totalLessonsStr.toIntOrNull() ?: 20
                    if (name.isNotBlank()) onConfirm(name, hours, lessons, "#1B6A4B")
                },
                enabled = name.isNotBlank()
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AddLessonDialog(
    subjects: List<SubjectEntity>,
    onDismiss: () -> Unit,
    onConfirm: (subjId: Long, subjName: String, title: String, teacher: String, day: String, start: String, end: String, loc: String) -> Unit
) {
    var selectedSubject by remember { mutableStateOf(subjects.firstOrNull()?.name ?: "فيزياء") }
    var title by remember { mutableStateOf("") }
    var teacher by remember { mutableStateOf("") }
    var day by remember { mutableStateOf("السبت") }
    var start by remember { mutableStateOf("14:00") }
    var end by remember { mutableStateOf("16:00") }
    var location by remember { mutableStateOf("سنتر التفوق") }

    val days = listOf("السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة موعد درس / سنتر") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text("اختر المادة:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(subjects) { s ->
                            TabPill(
                                text = s.name,
                                isSelected = selectedSubject == s.name,
                                onClick = { selectedSubject = s.name }
                            )
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = teacher,
                        onValueChange = { teacher = it },
                        label = { Text("اسم المعلم / الأستاذ") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("المكان / السنتر / أونلاين") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Text("اليوم:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(days) { d ->
                            TabPill(
                                text = d,
                                isSelected = day == d,
                                onClick = { day = d }
                            )
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = start,
                            onValueChange = { start = it },
                            label = { Text("من") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = end,
                            onValueChange = { end = it },
                            label = { Text("إلى") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val subjObj = subjects.find { it.name == selectedSubject }
                    onConfirm(
                        subjObj?.id ?: 0L,
                        selectedSubject,
                        if (title.isBlank()) "درس $selectedSubject" else title,
                        teacher,
                        day,
                        start,
                        end,
                        location
                    )
                }
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AddSummaryDialog(
    subjects: List<SubjectEntity>,
    onDismiss: () -> Unit,
    onConfirm: (subj: String, title: String, content: String, keys: String, tags: String) -> Unit
) {
    var selectedSubject by remember { mutableStateOf(subjects.firstOrNull()?.name ?: "فيزياء") }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة ملخص أو قانون") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("المادة:", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(subjects) { s ->
                        TabPill(
                            text = s.name,
                            isSelected = selectedSubject == s.name,
                            onClick = { selectedSubject = s.name }
                        )
                    }
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الفكرة / القانون") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("نص الملخص والقوانين") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onConfirm(selectedSubject, title, content, "", "")
                    }
                },
                enabled = title.isNotBlank() && content.isNotBlank()
            ) {
                Text("حفظ الملخص")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
