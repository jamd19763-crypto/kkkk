package com.example.ui.screens.worship

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DefaultData
import com.example.data.DhikrItem
import com.example.data.DuaItem
import com.example.data.RuqyahItem
import com.example.data.model.CustomDhikrEntity
import com.example.data.model.PrayerEntity
import com.example.data.model.QuranProgressEntity
import com.example.data.remote.PrayerTimesResult
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun WorshipScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val prayerTimes by viewModel.prayerTimes.collectAsState()
    val todayPrayers by viewModel.todayPrayers.collectAsState()
    val customDhikrs by viewModel.customDhikrs.collectAsState()
    val quranProgress by viewModel.quranProgress.collectAsState()
    val user by viewModel.user.collectAsState()
    val isRuqyahUnlocked by viewModel.isRuqyahUnlocked.collectAsState()

    var selectedSubTab by remember { mutableStateOf(0) }
    val subTabs = listOf("مواقيت الصلاة", "موسوعة الأذكار", "السبحة الذكية", "الورد القرآني", "موسوعة الأدعية", "القسم الروحاني والرقية 🔒")

    var showPinDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(subTabs.indices.toList()) { index ->
                TabPill(
                    text = subTabs[index],
                    isSelected = selectedSubTab == index,
                    onClick = {
                        if (index == 5 && (user?.ruqyahPin?.isNotEmpty() == true) && !isRuqyahUnlocked) {
                            showPinDialog = true
                        } else {
                            selectedSubTab = index
                        }
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedSubTab) {
            0 -> PrayersTabContent(
                prayerTimes = prayerTimes,
                todayPrayers = todayPrayers,
                onTogglePrayer = { name, inMosque -> viewModel.togglePrayer(name, inMosque) }
            )
            1 -> AthkarTabContent()
            2 -> SmartTasbihTabContent(
                customDhikrs = customDhikrs,
                onAddCustomDhikr = { text, count, reward -> viewModel.addCustomDhikr(text, count, reward) }
            )
            3 -> QuranWirdTabContent(
                progress = quranProgress,
                onUpdateJuz = { inc -> viewModel.updateQuranJuz(inc) }
            )
            4 -> DuasTabContent()
            5 -> RuqyahSpiritualChamberTabContent(
                isLocked = (user?.ruqyahPin?.isNotEmpty() == true) && !isRuqyahUnlocked,
                onRequestUnlock = { showPinDialog = true },
                onLock = { viewModel.lockRuqyah() }
            )
        }
    }

    if (showPinDialog) {
        PinAuthDialog(
            correctPin = user?.ruqyahPin ?: "",
            onDismiss = { showPinDialog = false },
            onSuccess = {
                viewModel.unlockRuqyah(it)
                selectedSubTab = 5
                showPinDialog = false
            }
        )
    }
}

@Composable
fun PrayersTabContent(
    prayerTimes: PrayerTimesResult,
    todayPrayers: List<PrayerEntity>,
    onTogglePrayer: (String, Boolean) -> Unit
) {
    val prayers = listOf(
        "الفجر" to prayerTimes.fajr,
        "الظهر" to prayerTimes.dhuhr,
        "العصر" to prayerTimes.asr,
        "المغرب" to prayerTimes.maghrib,
        "العشاء" to prayerTimes.isha
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "مواقيت صلاة محافظة ${prayerTimes.governorate}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "حسب الهيئة المصرية العامة للمساحة",
                                style = MaterialTheme.typography.bodySmall.copy(color = Emerald100)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Gold500.copy(alpha = 0.3f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "الشروق: ${prayerTimes.sunrise}",
                                style = MaterialTheme.typography.labelSmall.copy(color = Gold300, fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Divider(color = Emerald700)

                    Text(
                        text = "الصلاة القادمة: ${prayerTimes.nextPrayerName} (${prayerTimes.remainingTimeFormatted})",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Gold300,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        item {
            SectionHeader(
                title = "سجل متابعة الفروض والمسجد اليوم",
                subtitle = "الصلاة على وقتها أحب الأعمال إلى الله",
                icon = Icons.Default.CheckCircle
            )
        }

        items(prayers) { (name, time) ->
            val prayerEntity = todayPrayers.find { it.prayerName == name }
            val isDone = prayerEntity?.isDone == true
            val inMosque = prayerEntity?.inMosque == true

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDone) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                    else MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Checkbox(
                            checked = isDone,
                            onCheckedChange = { onTogglePrayer(name, false) },
                            colors = CheckboxDefaults.colors(checkedColor = Emerald600)
                        )
                        Column {
                            Text(
                                text = "صلاة $name",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDone) Emerald700 else MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "الأذان: $time",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = inMosque,
                            onClick = { onTogglePrayer(name, !inMosque) },
                            label = {
                                Text(
                                    text = if (inMosque) "في المسجد 🕌" else "المسجد",
                                    fontSize = 11.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Emerald700,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AthkarTabContent() {
    var selectedCategory by remember { mutableStateOf("morning") }
    val categories = listOf(
        "morning" to "أذكار الصباح",
        "evening" to "أذكار المساء",
        "afterPrayer" to "أذكار بعد الصلاة",
        "sleep" to "أذكار النوم"
    )

    val currentList = DefaultData.ATHKAR_LIST.filter { it.category == selectedCategory }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(categories) { (catId, catName) ->
                    TabPill(
                        text = catName,
                        isSelected = selectedCategory == catId,
                        onClick = { selectedCategory = catId }
                    )
                }
            }
        }

        items(currentList) { item ->
            DhikrItemCard(item = item)
        }
    }
}

@Composable
fun DhikrItemCard(item: DhikrItem) {
    val context = LocalContext.current
    var currentCount by remember(item.id) { mutableStateOf(0) }
    val isCompleted = currentCount >= item.repeatCount

    fun vibrate() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(40)
            }
        } catch (_: Exception) {}
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) Emerald900.copy(alpha = 0.1f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (currentCount < item.repeatCount) {
                    currentCount++
                    vibrate()
                }
            }
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Gold500.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.source,
                        style = MaterialTheme.typography.labelSmall.copy(color = Gold700, fontWeight = FontWeight.Bold)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (isCompleted) Emerald600 else MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isCompleted) "اكتمل ✓" else "$currentCount / ${item.repeatCount}",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Text(
                text = item.text,
                style = MaterialTheme.typography.bodyLarge.copy(
                    lineHeight = 26.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            if (item.virtue.isNotBlank()) {
                Text(
                    text = "الفضل: ${item.virtue}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Emerald600)
                )
            }

            CustomProgressBar(
                progress = if (item.repeatCount > 0) currentCount.toFloat() / item.repeatCount.toFloat() else 1f,
                color = Emerald600
            )
        }
    }
}

@Composable
fun SmartTasbihTabContent(
    customDhikrs: List<CustomDhikrEntity>,
    onAddCustomDhikr: (String, Int, String) -> Unit
) {
    val context = LocalContext.current
    var activeDhikrIndex by remember { mutableStateOf(0) }
    var currentCount by remember { mutableStateOf(0) }
    var targetCount by remember { mutableStateOf(33) }
    var totalDhikrToday by remember { mutableStateOf(0) }

    val activeDhikr = customDhikrs.getOrNull(activeDhikrIndex) ?: CustomDhikrEntity(text = "سُبْحَانَ اللَّهِ", targetCount = 33)

    fun vibrate() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(50)
            }
        } catch (_: Exception) {}
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "السبحة الإلكترونية الذكية",
                subtitle = "إجمالي تسبيحاتك اليوم: $totalDhikrToday",
                icon = Icons.Default.Fingerprint
            )
        }

        // Dhikr selection chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(customDhikrs.indices.toList()) { idx ->
                    val d = customDhikrs[idx]
                    TabPill(
                        text = d.text,
                        isSelected = activeDhikrIndex == idx,
                        onClick = {
                            activeDhikrIndex = idx
                            targetCount = d.targetCount
                            currentCount = 0
                        }
                    )
                }
            }
        }

        // Big Tap Target Circle
        item {
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Emerald700,
                                Emerald900
                            )
                        )
                    )
                    .border(6.dp, Gold400, CircleShape)
                    .clickable {
                        currentCount++
                        totalDhikrToday++
                        vibrate()
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "$currentCount",
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "الهدف: $targetCount",
                        style = MaterialTheme.typography.labelMedium.copy(color = Gold300)
                    )
                    Text(
                        text = activeDhikr.text,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        ),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "اضغط للتسبيح 👆",
                        style = MaterialTheme.typography.labelSmall.copy(color = Emerald100)
                    )
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { currentCount = 0 },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصفير العداد")
                }
            }
        }
    }
}

@Composable
fun QuranWirdTabContent(
    progress: QuranProgressEntity?,
    onUpdateJuz: (Int) -> Unit
) {
    val currentJuz = progress?.currentJuz ?: 1
    val completedKhatmas = progress?.completedKhatmas ?: 0

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ختمة الثانوية العامة المباركة",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "قراءة جزء واحد يومياً تضمن لك ختمة شهرية متكاملة",
                                style = MaterialTheme.typography.bodySmall.copy(color = Emerald100)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Gold500.copy(alpha = 0.3f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "$completedKhatmas ختمات مكتملة 🏆",
                                style = MaterialTheme.typography.labelSmall.copy(color = Gold300, fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Divider(color = Emerald700)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "الجزء الحالي",
                                style = MaterialTheme.typography.bodySmall.copy(color = Emerald100)
                            )
                            Text(
                                text = "الجزء $currentJuz من 30",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Gold400
                                )
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onUpdateJuz(-1) },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("السابق")
                            }
                            Button(
                                onClick = { onUpdateJuz(1) },
                                colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("أتممت الجزء ✓", color = Emerald900, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    CustomProgressBar(
                        progress = currentJuz.toFloat() / 30f,
                        color = Gold400,
                        backgroundColor = Emerald800
                    )
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "نصيحة تقسيم الورد اليومي مع المذاكرة:",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Emerald600)
                    )
                    Text("• اقرأ 4 صفحات بعد كل صلاة مفروضة (الفجر، الظهر، العصر، المغرب، العشاء).", style = MaterialTheme.typography.bodySmall)
                    Text("• المجموع = 20 صفحة = جزء كامل يومياً دون أي إحساس بضغط أو ضيق وقت!", style = MaterialTheme.typography.bodySmall)
                    Text("• بركة القرآن ستضاعف سرعة فهمك وحفظك للمواد الصعبة.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun DuasTabContent() {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "موسوعة أدعية التوفيق وتثبيت الحفظ",
                subtitle = "أدعية الأنبياء والمذاكرة وتفريج الكروب",
                icon = Icons.Default.MenuBook
            )
        }

        items(DefaultData.DUAS_COLLECTION) { dua ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = dua.title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Emerald700)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Gold500.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = dua.source,
                                style = MaterialTheme.typography.labelSmall.copy(color = Gold700, fontSize = 10.sp)
                            )
                        }
                    }
                    Text(
                        text = "« ${dua.text} »",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            lineHeight = 24.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun RuqyahSpiritualChamberTabContent(
    isLocked: Boolean,
    onRequestUnlock: () -> Unit,
    onLock: () -> Unit
) {
    if (isLocked) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Emerald800),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Gold400,
                    modifier = Modifier.size(40.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "القسم الروحاني محمي برمز أمان",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "هذا القسم يحتوي على الرقية الشرعية الكاملة، آيات التحصين، وتفجير عقد السحر والحسد.",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onRequestUnlock,
                colors = ButtonDefaults.buttonColors(containerColor = Emerald700),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("إدخال رمز المرور وفتح القسم")
            }
        }
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SectionHeader(
                        title = "الرقية الشرعية وحصن المسلم",
                        subtitle = "تحصين كامل للنفس والجسد والبيت",
                        icon = Icons.Default.Shield
                    )
                    IconButton(onClick = onLock) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "قفل القسم",
                            tint = Emerald600
                        )
                    }
                }
            }

            items(DefaultData.RUQYAH_COLLECTION) { item ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Emerald700)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Emerald800)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${item.repeatCount} مرات",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Gold300, fontWeight = FontWeight.Bold)
                                )
                            }
                        }

                        Text(
                            text = item.text,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                lineHeight = 28.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )

                        Text(
                            text = "طريقة العمل: ${item.instructions}",
                            style = MaterialTheme.typography.bodySmall.copy(color = Gold700, fontWeight = FontWeight.SemiBold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PinAuthDialog(
    correctPin: String,
    onDismiss: () -> Unit,
    onSuccess: (String) -> Unit
) {
    var pinInput by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("رمز أمان القسم الروحاني") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("أدخل رمز المرور المكون من 4 أرقام:")
                OutlinedTextField(
                    value = pinInput,
                    onValueChange = {
                        if (it.length <= 6) {
                            pinInput = it
                            errorMsg = false
                        }
                    },
                    label = { Text("رمز المرور") },
                    isError = errorMsg,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorMsg) {
                    Text("رمز المرور غير صحيح!", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (correctPin.isEmpty() || pinInput == correctPin) {
                        onSuccess(pinInput)
                    } else {
                        errorMsg = true
                    }
                }
            ) {
                Text("تأكيد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
