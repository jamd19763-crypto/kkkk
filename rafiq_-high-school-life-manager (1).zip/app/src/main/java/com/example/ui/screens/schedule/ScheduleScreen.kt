package com.example.ui.screens.schedule

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GoalEntity
import com.example.data.model.ScheduleBlockEntity
import com.example.data.model.SocialMediaLimitEntity
import com.example.data.model.TaskEntity
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.screens.dashboard.AddTaskDialog
import com.example.ui.screens.dashboard.TaskItemRow
import com.example.ui.theme.*

@Composable
fun ScheduleScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scheduleBlocks by viewModel.scheduleBlocks.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val goals by viewModel.goals.collectAsState()
    val socialLimits by viewModel.socialLimits.collectAsState()

    var selectedSubTab by remember { mutableStateOf(0) }
    val subTabs = listOf("جدول اليوم", "قائمة المهام", "الأهداف وتحدي الـ 30", "محدد السوشيال ميديا")

    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showAddGoalDialog by remember { mutableStateOf(false) }
    var showAddBlockDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(subTabs.indices.toList()) { index ->
                TabPill(
                    text = subTabs[index],
                    isSelected = selectedSubTab == index,
                    onClick = { selectedSubTab = index }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedSubTab) {
            0 -> DailyTimelineTabContent(
                blocks = scheduleBlocks,
                onAddBlock = { showAddBlockDialog = true },
                onDeleteBlock = { block -> viewModel.deleteScheduleBlock(block) }
            )
            1 -> TasksTabContent(
                tasks = tasks,
                onAddTask = { showAddTaskDialog = true },
                onToggleTask = { task -> viewModel.toggleTask(task) },
                onDeleteTask = { task -> viewModel.deleteTask(task) }
            )
            2 -> GoalsTabContent(
                goals = goals,
                onAddGoal = { showAddGoalDialog = true },
                onUpdateGoal = { goal, p -> viewModel.updateGoalProgress(goal, p) },
                onDeleteGoal = { goal -> viewModel.deleteGoal(goal) }
            )
            3 -> SocialLimitsTabContent(
                limits = socialLimits,
                onUpdateUsed = { limit, delta -> viewModel.updateSocialLimit(limit, delta) }
            )
        }
    }

    if (showAddTaskDialog) {
        AddTaskDialog(
            onDismiss = { showAddTaskDialog = false },
            onConfirm = { title, cat, prio ->
                viewModel.addTask(title, cat, prio)
                showAddTaskDialog = false
            }
        )
    }

    if (showAddGoalDialog) {
        AddGoalDialog(
            onDismiss = { showAddGoalDialog = false },
            onConfirm = { title, desc, cat ->
                viewModel.addGoal(title, desc, cat)
                showAddGoalDialog = false
            }
        )
    }

    if (showAddBlockDialog) {
        AddBlockDialog(
            onDismiss = { showAddBlockDialog = false },
            onConfirm = { hour, title, cat, color ->
                viewModel.addScheduleBlock(hour, title, cat, color)
                showAddBlockDialog = false
            }
        )
    }
}

@Composable
fun DailyTimelineTabContent(
    blocks: List<ScheduleBlockEntity>,
    onAddBlock: () -> Unit,
    onDeleteBlock: (ScheduleBlockEntity) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "جدول اليوم (تقسيم الـ 24 ساعة)",
                subtitle = "نظم وقتك بالساعة وتجنب الفوضى والتسويف",
                icon = Icons.Default.Schedule,
                actionText = "+ نشاط جديد",
                onActionClick = onAddBlock
            )
        }

        items(blocks) { block ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    when (block.category) {
                                        "مذاكرة" -> Emerald800
                                        "درس" -> AccentPurple.copy(alpha = 0.2f)
                                        "صلاة" -> Gold500.copy(alpha = 0.2f)
                                        "نوم" -> AccentTeal.copy(alpha = 0.2f)
                                        else -> AccentCoral.copy(alpha = 0.2f)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${block.hourStart}:00",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = when (block.category) {
                                        "مذاكرة" -> Gold400
                                        "درس" -> AccentPurple
                                        "صلاة" -> Gold700
                                        "نوم" -> AccentTeal
                                        else -> AccentCoral
                                    }
                                )
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = block.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "التصنيف: ${block.category}",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }

                    IconButton(onClick = { onDeleteBlock(block) }, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TasksTabContent(
    tasks: List<TaskEntity>,
    onAddTask: () -> Unit,
    onToggleTask: (TaskEntity) -> Unit,
    onDeleteTask: (TaskEntity) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("الكل") }
    val categories = listOf("الكل", "مذاكرة", "ديني", "صحي", "شخصي")

    val filteredTasks = if (selectedCategory == "الكل") tasks else tasks.filter { it.category == selectedCategory }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "قائمة المهام والواجبات اليومية",
                subtitle = "${tasks.count { it.isCompleted }} من أصل ${tasks.size} مهمة منجزة",
                icon = Icons.Default.TaskAlt,
                actionText = "+ مهمة جديدة",
                onActionClick = onAddTask
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(categories) { cat ->
                    TabPill(
                        text = cat,
                        isSelected = selectedCategory == cat,
                        onClick = { selectedCategory = cat }
                    )
                }
            }
        }

        items(filteredTasks) { task ->
            TaskItemRow(
                task = task,
                onToggle = { onToggleTask(task) },
                onDelete = { onDeleteTask(task) }
            )
        }
    }
}

@Composable
fun GoalsTabContent(
    goals: List<GoalEntity>,
    onAddGoal: () -> Unit,
    onUpdateGoal: (GoalEntity, Int) -> Unit,
    onDeleteGoal: (GoalEntity) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "أهداف السنة وتحدي الـ 30 يوماً",
                subtitle = "الطريق نحو الـ 99% والكلية التي تحلم بها",
                icon = Icons.Default.EmojiEvents,
                actionText = "+ هدف جديد",
                onActionClick = onAddGoal
            )
        }

        items(goals) { goal ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = goal.title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        IconButton(onClick = { onDeleteGoal(goal) }, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "حذف الهدف",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        }
                    }

                    if (goal.description.isNotBlank()) {
                        Text(
                            text = goal.description,
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نسبة التقدم: ${goal.progressPercentage}%",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = Emerald600)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { onUpdateGoal(goal, (goal.progressPercentage + 10).coerceAtMost(100)) },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("+10%", fontSize = 11.sp)
                            }
                        }
                    }

                    CustomProgressBar(
                        progress = goal.progressPercentage / 100f,
                        color = Gold500
                    )
                }
            }
        }
    }
}

@Composable
fun SocialLimitsTabContent(
    limits: List<SocialMediaLimitEntity>,
    onUpdateUsed: (SocialMediaLimitEntity, Int) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "محدد السوشيال ميديا وقفل التركيز",
                subtitle = "حماية وقتك من إدمان الشاشات والتشتت",
                icon = Icons.Default.PhonelinkLock
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LockClock,
                        contentDescription = null,
                        tint = Gold400,
                        modifier = Modifier.size(32.dp)
                    )
                    Column {
                        Text(
                            text = "وضع التركيز الخارق (Deep Focus Mode)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                        )
                        Text(
                            text = "يتم منع فتح مواقع التواصل تلقائياً أثناء تشغيل مؤقت البومودورو.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Emerald100)
                        )
                    }
                }
            }
        }

        items(limits) { limit ->
            val isExceeded = limit.usedMinutesToday >= limit.maxMinutesPerDay
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = limit.appName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isExceeded) AccentCoral.copy(alpha = 0.2f) else Emerald600.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${limit.usedMinutesToday} / ${limit.maxMinutesPerDay} دقيقة",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isExceeded) AccentCoral else Emerald700,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    CustomProgressBar(
                        progress = (limit.usedMinutesToday.toFloat() / limit.maxMinutesPerDay.toFloat()).coerceIn(0f, 1f),
                        color = if (isExceeded) AccentCoral else Emerald600
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { onUpdateUsed(limit, 5) }) {
                            Text("+5 دقائق استخدام", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddGoalDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, desc: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("دراسي") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة هدف جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الهدف") },
                    placeholder = { Text("مثال: ختم مادة الأحياء قبل شهر مارس...") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("التفاصيل والخطة") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (title.isNotBlank()) onConfirm(title, desc, category) },
                enabled = title.isNotBlank()
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AddBlockDialog(
    onDismiss: () -> Unit,
    onConfirm: (hour: Int, title: String, cat: String, color: String) -> Unit
) {
    var hourStr by remember { mutableStateOf("15") }
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("مذاكرة") }

    val categories = listOf("مذاكرة", "درس", "صلاة", "نوم", "راحة")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة نشاط للجدول اليومي") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = hourStr,
                    onValueChange = { hourStr = it },
                    label = { Text("الساعة (من 5 إلى 23)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم النشاط") },
                    placeholder = { Text("مثال: مذاكرة كيمياء عضوية...") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("التصنيف:", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        TabPill(
                            text = cat,
                            isSelected = category == cat,
                            onClick = { category = cat }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val h = hourStr.toIntOrNull() ?: 12
                    if (title.isNotBlank()) onConfirm(h, title, category, "#1B6A4B")
                },
                enabled = title.isNotBlank()
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
