package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DefaultData
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.remote.PrayerTimesCalculator
import com.example.data.remote.PrayerTimesResult
import com.example.data.repository.LifeBalanceRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: LifeBalanceRepository
    private val todayString: String
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    val user: StateFlow<UserEntity?>
    val subjects: StateFlow<List<SubjectEntity>>
    val allLessons: StateFlow<List<LessonEntity>>
    val tasks: StateFlow<List<TaskEntity>>
    val goals: StateFlow<List<GoalEntity>>
    val customDhikrs: StateFlow<List<CustomDhikrEntity>>
    val quranProgress: StateFlow<QuranProgressEntity?>
    val scheduleBlocks: StateFlow<List<ScheduleBlockEntity>>
    val socialLimits: StateFlow<List<SocialMediaLimitEntity>>
    val sleepRecords: StateFlow<List<SleepRecordEntity>>
    val moodRecords: StateFlow<List<MoodRecordEntity>>
    val aiMessages: StateFlow<List<AiChatMessageEntity>>
    val summaries: StateFlow<List<SummaryEntity>>
    val studySessions: StateFlow<List<StudySessionEntity>>

    val todayPrayers: StateFlow<List<PrayerEntity>>

    private val _prayerTimes = MutableStateFlow(PrayerTimesCalculator.calculate("القاهرة"))
    val prayerTimes: StateFlow<PrayerTimesResult> = _prayerTimes.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _isRuqyahUnlocked = MutableStateFlow(false)
    val isRuqyahUnlocked: StateFlow<Boolean> = _isRuqyahUnlocked.asStateFlow()

    private val _activeTab = MutableStateFlow("dashboard")
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = LifeBalanceRepository(database)

        user = repository.user.stateIn(viewModelScope, SharingStarted.Eagerly, null)
        subjects = repository.subjects.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        allLessons = repository.allLessons.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        tasks = repository.tasks.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        goals = repository.goals.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        customDhikrs = repository.customDhikrs.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        quranProgress = repository.quranProgress.stateIn(viewModelScope, SharingStarted.Eagerly, null)
        scheduleBlocks = repository.scheduleBlocks.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        socialLimits = repository.socialLimits.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        sleepRecords = repository.sleepRecords.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        moodRecords = repository.moodRecords.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        aiMessages = repository.aiMessages.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        summaries = repository.summaries.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        studySessions = repository.studySessions.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

        todayPrayers = repository.getPrayersForDate(todayString)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

        // Refresh prayer times when user governorate changes
        viewModelScope.launch {
            user.collect { u ->
                val gov = u?.governorate ?: "القاهرة"
                _prayerTimes.value = repository.calculatePrayerTimes(gov)
            }
        }
    }

    fun setActiveTab(tab: String) {
        _activeTab.value = tab
    }

    fun unlockRuqyah(pin: String): Boolean {
        val currentPin = user.value?.ruqyahPin ?: ""
        if (currentPin.isEmpty() || currentPin == pin) {
            _isRuqyahUnlocked.value = true
            return true
        }
        return false
    }

    fun lockRuqyah() {
        _isRuqyahUnlocked.value = false
    }

    fun updateProfile(name: String, governorate: String, division: String, age: Int, pin: String) {
        viewModelScope.launch {
            val current = user.value ?: UserEntity()
            val divisionChanged = current.division != division
            val updated = current.copy(
                name = name,
                governorate = governorate,
                division = division,
                age = age,
                ruqyahPin = pin,
                isRuqyahLocked = pin.isNotEmpty()
            )
            repository.updateUser(updated)
            if (divisionChanged) {
                repository.changeDivision(division)
            }
            _prayerTimes.value = repository.calculatePrayerTimes(governorate)
        }
    }

    fun togglePrayer(prayerName: String, inMosque: Boolean = false) {
        viewModelScope.launch {
            repository.togglePrayer(prayerName, todayString, inMosque)
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun addTask(title: String, category: String, priority: String, dueDate: String = todayString) {
        viewModelScope.launch {
            repository.insertTask(
                TaskEntity(
                    title = title,
                    category = category,
                    priority = priority,
                    dueDateString = dueDate
                )
            )
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun addSubject(name: String, targetHours: Double, totalLessons: Int, colorHex: String = "#1B6A4B") {
        viewModelScope.launch {
            val division = user.value?.division ?: "عام"
            repository.insertSubject(
                SubjectEntity(
                    name = name,
                    division = division,
                    colorHex = colorHex,
                    iconName = "book",
                    targetHours = targetHours,
                    totalLessons = totalLessons
                )
            )
        }
    }

    fun updateSubjectProgress(subject: SubjectEntity, hoursAdded: Double, lessonCompleted: Boolean) {
        viewModelScope.launch {
            val newHours = (subject.hoursCompleted + hoursAdded).coerceAtLeast(0.0)
            val newLessons = if (lessonCompleted) (subject.completedLessons + 1).coerceAtMost(subject.totalLessons) else subject.completedLessons
            repository.updateSubject(
                subject.copy(
                    hoursCompleted = newHours,
                    completedLessons = newLessons
                )
            )
        }
    }

    fun deleteSubject(subject: SubjectEntity) {
        viewModelScope.launch {
            repository.deleteSubject(subject)
        }
    }

    fun addLesson(subjectId: Long, subjectName: String, title: String, teacher: String, day: String, start: String, end: String, location: String) {
        viewModelScope.launch {
            repository.insertLesson(
                LessonEntity(
                    subjectId = subjectId,
                    subjectName = subjectName,
                    title = title,
                    teacherName = teacher,
                    dayOfWeek = day,
                    startTime = start,
                    endTime = end,
                    location = location
                )
            )
        }
    }

    fun deleteLesson(lesson: LessonEntity) {
        viewModelScope.launch {
            repository.deleteLesson(lesson)
        }
    }

    fun saveStudySession(subjectId: Long, subjectName: String, durationMinutes: Int, type: String, rating: Int, notes: String, difficulties: String) {
        viewModelScope.launch {
            repository.insertStudySession(
                StudySessionEntity(
                    subjectId = subjectId,
                    subjectName = subjectName,
                    startTime = System.currentTimeMillis(),
                    durationMinutes = durationMinutes,
                    type = type,
                    rating = rating,
                    notes = notes,
                    difficulties = difficulties,
                    dateString = todayString
                )
            )
            // also increment hours in subject
            val subj = subjects.value.find { it.id == subjectId || it.name == subjectName }
            if (subj != null) {
                val addedHours = durationMinutes / 60.0
                repository.updateSubject(subj.copy(hoursCompleted = subj.hoursCompleted + addedHours))
            }
        }
    }

    fun addSummary(subjectName: String, title: String, content: String, keyPoints: String, tags: String) {
        viewModelScope.launch {
            repository.insertSummary(
                SummaryEntity(
                    subjectName = subjectName,
                    title = title,
                    content = content,
                    keyPoints = keyPoints,
                    tags = tags
                )
            )
        }
    }

    fun deleteSummary(summary: SummaryEntity) {
        viewModelScope.launch {
            repository.deleteSummary(summary)
        }
    }

    fun addGoal(title: String, description: String, category: String) {
        viewModelScope.launch {
            repository.insertGoal(
                GoalEntity(
                    title = title,
                    description = description,
                    category = category
                )
            )
        }
    }

    fun updateGoalProgress(goal: GoalEntity, newPercentage: Int) {
        viewModelScope.launch {
            repository.updateGoal(
                goal.copy(
                    progressPercentage = newPercentage,
                    isCompleted = newPercentage >= 100
                )
            )
        }
    }

    fun deleteGoal(goal: GoalEntity) {
        viewModelScope.launch {
            repository.deleteGoal(goal)
        }
    }

    fun addCustomDhikr(text: String, targetCount: Int, reward: String) {
        viewModelScope.launch {
            repository.insertCustomDhikr(
                CustomDhikrEntity(
                    text = text,
                    targetCount = targetCount,
                    reward = reward
                )
            )
        }
    }

    fun deleteCustomDhikr(dhikr: CustomDhikrEntity) {
        viewModelScope.launch {
            repository.deleteCustomDhikr(dhikr)
        }
    }

    fun updateQuranJuz(juzIncrement: Int, surahName: String = "", ayah: Int = 1) {
        viewModelScope.launch {
            val current = quranProgress.value ?: QuranProgressEntity()
            var nextJuz = current.currentJuz + juzIncrement
            var khatmas = current.completedKhatmas
            if (nextJuz > 30) {
                nextJuz = 1
                khatmas += 1
            } else if (nextJuz < 1) {
                nextJuz = 1
            }
            repository.updateQuranProgress(
                current.copy(
                    currentJuz = nextJuz,
                    currentSurah = if (surahName.isNotEmpty()) surahName else current.currentSurah,
                    currentAyah = ayah,
                    completedKhatmas = khatmas,
                    lastReadDateString = todayString
                )
            )
        }
    }

    fun addScheduleBlock(hourStart: Int, title: String, category: String, colorHex: String) {
        viewModelScope.launch {
            repository.insertScheduleBlock(
                ScheduleBlockEntity(
                    hourStart = hourStart,
                    title = title,
                    category = category,
                    colorHex = colorHex
                )
            )
        }
    }

    fun deleteScheduleBlock(block: ScheduleBlockEntity) {
        viewModelScope.launch {
            repository.deleteScheduleBlock(block)
        }
    }

    fun updateSocialLimit(limit: SocialMediaLimitEntity, usedDeltaMinutes: Int) {
        viewModelScope.launch {
            val updated = limit.copy(
                usedMinutesToday = (limit.usedMinutesToday + usedDeltaMinutes).coerceAtLeast(0)
            )
            repository.updateSocialMediaLimit(updated)
        }
    }

    fun saveSleepRecord(sleepTime: String, wakeTime: String, durationHours: Double, quality: Int, notes: String) {
        viewModelScope.launch {
            repository.insertSleepRecord(
                SleepRecordEntity(
                    dateString = todayString,
                    sleepTime = sleepTime,
                    wakeTime = wakeTime,
                    durationHours = durationHours,
                    qualityRating = quality,
                    notes = notes
                )
            )
        }
    }

    fun saveMoodRecord(emoji: String, label: String, note: String) {
        viewModelScope.launch {
            repository.insertMoodRecord(
                MoodRecordEntity(
                    dateString = todayString,
                    moodEmoji = emoji,
                    moodLabel = label,
                    note = note
                )
            )
        }
    }

    fun sendAiPrompt(prompt: String) {
        if (prompt.isBlank() || _isAiLoading.value) return
        viewModelScope.launch {
            _isAiLoading.value = true
            try {
                val division = user.value?.division ?: "علمي علوم"
                val name = user.value?.name ?: "طالبنا العزيز"
                repository.sendAiMessage(prompt, division, name)
            } finally {
                _isAiLoading.value = false
            }
        }
    }

    fun clearAiHistory() {
        viewModelScope.launch {
            repository.clearAiChat()
        }
    }
}
