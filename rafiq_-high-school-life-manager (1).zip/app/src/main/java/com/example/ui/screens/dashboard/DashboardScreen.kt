package com.example.ui.screens.dashboard

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DefaultData
import com.example.data.model.PrayerEntity
import com.example.data.model.TaskEntity
import com.example.data.model.UserEntity
import com.example.data.remote.PrayerTimesResult
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToTab: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val user by viewModel.user.collectAsState()
    val todayPrayers by viewModel.todayPrayers.collectAsState()
    val prayerTimes by viewModel.prayerTimes.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val subjects by viewModel.subjects.collectAsState()
    val quranProgress by viewModel.quranProgress.collectAsState()

    var showAddTaskDialog by remember { mutableStateOf(false) }

    val completedPrayersCount = todayPrayers.count { it.isDone }
    val completedTasksCount = tasks.count { it.isCompleted }
    val totalStudyHours = subjects.sumOf { it.hoursCompleted }
    val dailyProgress = if (tasks.isNotEmpty()) (completedTasksCount.toFloat() / tasks.size.toFloat()) else 0.5f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // 1. Welcome & Status Hero Banner
        item {
            HeroWelcomeCard(
                user = user,
                completedPrayers = completedPrayersCount,
                dailyProgress = dailyProgress
            )
        }

        // 2. Egyptian Live Prayer Times & Tracker Widget
        item {
            PrayerWidgetCard(
                prayerTimes = prayerTimes,
                todayPrayers = todayPrayers,
                onTogglePrayer = { name -> viewModel.togglePrayer(name) },
                onNavigateToWorship = { onNavigateToTab("worship") }
            )
        }

        // 3. Quick Stats Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "الصلوات اليوم",
                    value = "$completedPrayersCount / 5",
                    subtitle = if (completedPrayersCount == 5) "ما شاء الله كاملة!" else "حافظ على الفروض",
                    icon = Icons.Default.Mosque,
                    color = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "ساعات المذاكرة",
                    value = "%.1f س".format(totalStudyHours),
                    subtitle = "إجمالي الشعبة",
                    icon = Icons.Default.MenuBook,
                    color = Gold500,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "ورد القرآن",
                    value = "جزء ${quranProgress?.currentJuz ?: 1}",
                    subtitle = "ختمة الشهر",
                    icon = Icons.Default.AutoStories,
                    color = AccentSky,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 4. Quick Action Shortcuts (Cards)
        item {
            SectionHeader(
                title = "الوصول السريع",
                subtitle = "أهم أدوات يومك",
                icon = Icons.Default.FlashOn
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionItem(
                    title = "المساعد الذكي",
                    icon = Icons.Default.Psychology,
                    color = AccentPurple,
                    onClick = { onNavigateToTab("more") },
                    modifier = Modifier.weight(1f)
                )
                QuickActionItem(
                    title = "بومودورو",
                    icon = Icons.Default.Timer,
                    color = AccentCoral,
                    onClick = { onNavigateToTab("study") },
                    modifier = Modifier.weight(1f)
                )
                QuickActionItem(
                    title = "الرقية والتحصين",
                    icon = Icons.Default.Shield,
                    color = Emerald600,
                    onClick = { onNavigateToTab("worship") },
                    modifier = Modifier.weight(1f)
                )
                QuickActionItem(
                    title = "جدول اليوم",
                    icon = Icons.Default.CalendarMonth,
                    color = Gold700,
                    onClick = { onNavigateToTab("schedule") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 5. Daily Motivation (آية وحكمة اليوم)
        item {
            val randomQuote = remember { DefaultData.DAILY_QUOTES.random() }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = Gold500,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (randomQuote.type == "ayah") "آية اليوم للتثبيت" else "حكمة وتوجيه دراسي",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Gold500
                            )
                        )
                    }
                    Text(
                        text = "« ${randomQuote.text} »",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            lineHeight = 22.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Text(
                        text = randomQuote.reference,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // 6. Urgent Tasks Checklist
        item {
            SectionHeader(
                title = "مهام اليوم العاجلة",
                subtitle = "${tasks.count { it.isCompleted }} من ${tasks.size} مكتملة",
                icon = Icons.Default.CheckCircleOutline,
                actionText = "+ إضافة مهمة",
                onActionClick = { showAddTaskDialog = true }
            )
        }

        if (tasks.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "لا توجد مهام مسجلة اليوم، اضغط على + لإضافة مهمة جديدة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(tasks.take(4)) { task ->
                TaskItemRow(
                    task = task,
                    onToggle = { viewModel.toggleTask(task) },
                    onDelete = { viewModel.deleteTask(task) }
                )
            }
        }
    }

    if (showAddTaskDialog) {
        AddTaskDialog(
            onDismiss = { showAddTaskDialog = false },
            onConfirm = { title, cat, prio ->
                viewModel.addTask(title, cat, prio)
                showAddTaskDialog = false
            }
        )
    }
}

@Composable
fun HeroWelcomeCard(
    user: UserEntity?,
    completedPrayers: Int,
    dailyProgress: Float
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_welcome_card")
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Emerald900,
                            Emerald800,
                            Emerald700
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "يا مرحب، ${user?.name ?: "يا بطل"} 👋",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "${user?.division ?: "علمي علوم"} • ${user?.governorate ?: "القاهرة"}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Emerald100
                            )
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Gold500.copy(alpha = 0.25f))
                            .border(1.dp, Gold400, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "3 ثانوي 🎓",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Gold300
                            )
                        )
                    }
                }

                Divider(color = Emerald700.copy(alpha = 0.5f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "معدل الإنجاز والتوازن اليومي",
                            style = MaterialTheme.typography.bodySmall.copy(color = Emerald100)
                        )
                        Text(
                            text = "${(dailyProgress * 100).toInt()}% مكتمل",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Gold300
                            )
                        )
                    }
                    Text(
                        text = if (completedPrayers >= 4) "🌟 يوم مبارك ومنتج" else "⚡ شد حيلك في الصلوات والمذاكرة",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    )
                }

                CustomProgressBar(
                    progress = dailyProgress,
                    color = Gold400,
                    backgroundColor = Emerald900.copy(alpha = 0.6f),
                    height = 8
                )
            }
        }
    }
}

@Composable
fun PrayerWidgetCard(
    prayerTimes: PrayerTimesResult,
    todayPrayers: List<PrayerEntity>,
    onTogglePrayer: (String) -> Unit,
    onNavigateToWorship: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mosque,
                        contentDescription = null,
                        tint = Emerald600,
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = "مواقيت الصلاة (${prayerTimes.governorate})",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "الصلاة القادمة: ${prayerTimes.nextPrayerName} (${prayerTimes.remainingTimeFormatted})",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Gold700,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }
                IconButton(onClick = onNavigateToWorship) {
                    Icon(
                        imageVector = Icons.Default.ArrowForwardIos,
                        contentDescription = "الذهاب للعبادات",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // 5 Prayers Quick Checkboxes
            val prayersList = listOf(
                "الفجر" to prayerTimes.fajr,
                "الظهر" to prayerTimes.dhuhr,
                "العصر" to prayerTimes.asr,
                "المغرب" to prayerTimes.maghrib,
                "العشاء" to prayerTimes.isha
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                prayersList.forEach { (name, time) ->
                    val isDone = todayPrayers.any { it.prayerName == name && it.isDone }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onTogglePrayer(name) }
                            .padding(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDone) Emerald600 else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isDone) Emerald600 else MaterialTheme.colorScheme.surfaceVariant
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isDone) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            } else {
                                Text(
                                    text = "—",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                        Text(
                            text = time,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = modifier
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 12.dp, horizontal = 6.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
fun TaskItemRow(
    task: TaskEntity,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (task.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            else MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Checkbox(
                checked = task.isCompleted,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(
                    checkedColor = Emerald600,
                    uncheckedColor = MaterialTheme.colorScheme.outline
                )
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (task.isCompleted) FontWeight.Normal else FontWeight.SemiBold,
                        color = if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                when (task.priority) {
                                    "عالية" -> AccentCoral.copy(alpha = 0.15f)
                                    "متوسطة" -> Gold500.copy(alpha = 0.15f)
                                    else -> Emerald500.copy(alpha = 0.15f)
                                }
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = task.priority,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = when (task.priority) {
                                    "عالية" -> AccentCoral
                                    "متوسطة" -> Gold700
                                    else -> Emerald700
                                }
                            )
                        )
                    }
                    Text(
                        text = "• ${task.category}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "حذف المهمة",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun AddTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, category: String, priority: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("مذاكرة") }
    var priority by remember { mutableStateOf("عالية") }

    val categories = listOf("مذاكرة", "ديني", "صحي", "شخصي")
    val priorities = listOf("عالية", "متوسطة", "منخفضة")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "إضافة مهمة جديدة",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان المهمة") },
                    placeholder = { Text("مثال: حل 40 سؤال كيمياء...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_title_input")
                )

                Text("التصنيف:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        TabPill(
                            text = cat,
                            isSelected = category == cat,
                            onClick = { category = cat }
                        )
                    }
                }

                Text("الأولوية:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    priorities.forEach { prio ->
                        TabPill(
                            text = prio,
                            isSelected = priority == prio,
                            onClick = { priority = prio }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) onConfirm(title, category, priority)
                },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Emerald700),
                modifier = Modifier.testTag("confirm_add_task_button")
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
