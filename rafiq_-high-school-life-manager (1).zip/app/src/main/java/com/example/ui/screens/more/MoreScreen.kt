package com.example.ui.screens.more

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DefaultData
import com.example.data.model.AiChatMessageEntity
import com.example.data.model.MoodRecordEntity
import com.example.data.model.SleepRecordEntity
import com.example.data.model.UserEntity
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun MoreScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val user by viewModel.user.collectAsState()
    val aiMessages by viewModel.aiMessages.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val sleepRecords by viewModel.sleepRecords.collectAsState()
    val moodRecords by viewModel.moodRecords.collectAsState()

    var selectedSubTab by remember { mutableStateOf(0) }
    val subTabs = listOf("المساعد الذكي 🤖", "الصحة والنوم والنفسية", "لوحة الشرف والمجتمع", "التقارير والإحصائيات", "الملف والإعدادات")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(subTabs.indices.toList()) { index ->
                TabPill(
                    text = subTabs[index],
                    isSelected = selectedSubTab == index,
                    onClick = { selectedSubTab = index }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedSubTab) {
            0 -> AiAssistantTabContent(
                messages = aiMessages,
                isLoading = isAiLoading,
                onSendMessage = { prompt -> viewModel.sendAiPrompt(prompt) },
                onClearChat = { viewModel.clearAiHistory() }
            )
            1 -> HealthAndWellnessTabContent(
                sleepRecords = sleepRecords,
                moodRecords = moodRecords,
                onSaveSleep = { s, w, d, q, n -> viewModel.saveSleepRecord(s, w, d, q, n) },
                onSaveMood = { emoji, label, note -> viewModel.saveMoodRecord(emoji, label, note) }
            )
            2 -> LeaderboardTabContent()
            3 -> AnalyticsReportsTabContent(viewModel = viewModel)
            4 -> ProfileSettingsTabContent(
                user = user,
                onUpdateProfile = { name, gov, div, age, pin ->
                    viewModel.updateProfile(name, gov, div, age, pin)
                }
            )
        }
    }
}

@Composable
fun AiAssistantTabContent(
    messages: List<AiChatMessageEntity>,
    isLoading: Boolean,
    onSendMessage: (String) -> Unit,
    onClearChat: () -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val promptSuggestions = listOf(
        "شرح درس قانون فاراداي فيزياء",
        "طريقة حل مسائل المعايرة في الكيمياء",
        "جدول مذاكرة مكثف لـ 6 ساعات",
        "دعاء لتثبيت الحفظ وعدم النسيان"
    )

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 85.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Emerald800),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Gold400,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "مساعد التالتة ثانوي الذكي",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "مدعوم بنموذج Gemini الذكي",
                        style = MaterialTheme.typography.bodySmall.copy(color = Emerald600)
                    )
                }
            }

            IconButton(onClick = onClearChat) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "مسح المحادثة",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Prompt Suggestions
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(promptSuggestions) { suggestion ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { onSendMessage(suggestion) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = suggestion,
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { message ->
                val isUser = message.sender == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        shape = RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isUser) 16.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 16.dp
                        ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) Emerald700 else MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = message.message,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    lineHeight = 22.sp,
                                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = Emerald600
                                )
                                Text(
                                    text = "جاري التفكير وصياغة الإجابة...",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input Field
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("اسأل عن أي مسألة أو مفهوم...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_prompt_input"),
                shape = RoundedCornerShape(24.dp)
            )

            IconButton(
                onClick = {
                    if (inputText.isNotBlank() && !isLoading) {
                        onSendMessage(inputText)
                        inputText = ""
                    }
                },
                enabled = inputText.isNotBlank() && !isLoading,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (inputText.isNotBlank() && !isLoading) Emerald700 else MaterialTheme.colorScheme.surfaceVariant)
                    .testTag("send_ai_prompt_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "إرسال",
                    tint = if (inputText.isNotBlank() && !isLoading) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun HealthAndWellnessTabContent(
    sleepRecords: List<SleepRecordEntity>,
    moodRecords: List<MoodRecordEntity>,
    onSaveSleep: (String, String, Double, Int, String) -> Unit,
    onSaveMood: (String, String, String) -> Unit
) {
    // 4-7-8 Breathing Guide State
    var isBreathingActive by remember { mutableStateOf(false) }
    var breathingPhase by remember { mutableStateOf("شهيق (4 ثوان)") }
    var countdown by remember { mutableStateOf(4) }

    val infiniteTransition = rememberInfiniteTransition(label = "breathing")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    LaunchedEffect(isBreathingActive) {
        while (isBreathingActive) {
            breathingPhase = "شهيق عميق من الأنف 🫁"
            for (i in 4 downTo 1) {
                countdown = i
                delay(1000L)
            }
            breathingPhase = "احبس النفس بهدوء 🛑"
            for (i in 7 downTo 1) {
                countdown = i
                delay(1000L)
            }
            breathingPhase = "زفير بطيء من الفم 💨"
            for (i in 8 downTo 1) {
                countdown = i
                delay(1000L)
            }
        }
    }

    val emojis = listOf(
        "😃" to "متحمس وطاقتي عالية",
        "😊" to "راضي ومستقر",
        "😐" to "عادي",
        "😟" to "قلق وتائه",
        "😫" to "مضغوط ومجهد"
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // 1. Breathing Exercise Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "تمرين التنفس 4-7-8 لتفريغ التوتر والقلق",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "يساعدك على تهدئة الجهاز العصبي وزيادة تدفق الأكسجين للمخ خلال دقيقتين",
                        style = MaterialTheme.typography.bodySmall.copy(color = Emerald100),
                        textAlign = TextAlign.Center
                    )

                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .scale(if (isBreathingActive) scale else 1f)
                            .clip(CircleShape)
                            .background(Gold500.copy(alpha = 0.25f))
                            .border(3.dp, Gold400, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (isBreathingActive) "$countdown" else "4-7-8",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White)
                            )
                            if (isBreathingActive) {
                                Text(
                                    text = breathingPhase,
                                    style = MaterialTheme.typography.labelSmall.copy(color = Gold300),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }

                    Button(
                        onClick = { isBreathingActive = !isBreathingActive },
                        colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isBreathingActive) "إيقاف التمرين" else "ابدأ التمرين الآن",
                            color = Emerald900,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 2. Mood Tracker
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "كيف تشعر اليوم؟ (متابعة حالتك النفسية)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        emojis.forEach { (emoji, label) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onSaveMood(emoji, label, "حالة مسجلة") }
                                    .padding(8.dp)
                            ) {
                                Text(text = emoji, fontSize = 28.sp)
                                Text(text = label.take(5), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // 3. Sleep & Health Tips
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "قواعد النوم والتغذية لطالب الثانوية العامة المتفوق:",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Emerald700)
                    )
                    Text("💤 1. النوم 7 ساعات ليلاً (من 11:30 م إلى 6:00 ص) يعادل 10 ساعات في النهار لتثبيت المعلومات في الذاكرة طويلة المدى.", style = MaterialTheme.typography.bodySmall)
                    Text("💧 2. اشرب كوب ماء كل ساعة دراسة؛ الجفاف البسيط يقلل تركيزك بنسبة 20%.", style = MaterialTheme.typography.bodySmall)
                    Text("🥗 3. ركز على المكسرات، البيض، الأسماك، والموز والخضراوات الورقية.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun LeaderboardTabContent() {
    val topStudents = listOf(
        Triple("أحمد محمود (القاهرة)", "1,450 نقطة", "الأول 🥇"),
        Triple("سارة محمد (الإسكندرية)", "1,380 نقطة", "الثاني 🥈"),
        Triple("عمر خالد (المنصورة)", "1,290 نقطة", "الثالث 🥉"),
        Triple("مريم حسن (الجيزة)", "1,210 نقطة", "الرابع 🎖️"),
        Triple("أنت (طالب الثانوية)", "1,150 نقطة", "الخامس 🌟")
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "لوحة الشرف وتحدي الالتزام",
                subtitle = "نقاط الصلوات في المسجد، الأذكار، وساعات المذاكرة",
                icon = Icons.Default.Leaderboard
            )
        }

        items(topStudents) { (name, score, rank) ->
            val isMe = name.contains("أنت")
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isMe) Emerald800 else MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = if (isMe) 3.dp else 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isMe) Gold500 else Emerald900)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = rank,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMe) Emerald900 else Gold400
                                )
                            )
                        }
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }

                    Text(
                        text = score,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isMe) Gold300 else Emerald700
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun AnalyticsReportsTabContent(viewModel: MainViewModel) {
    val subjects by viewModel.subjects.collectAsState()
    val todayPrayers by viewModel.todayPrayers.collectAsState()
    val tasks by viewModel.tasks.collectAsState()

    val totalHours = subjects.sumOf { it.hoursCompleted }
    val targetHours = subjects.sumOf { it.targetHours }
    val overallProgress = if (targetHours > 0) (totalHours / targetHours).toFloat() else 0.4f

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "التقارير والإحصائيات الشاملة",
                subtitle = "مستوى التزامك الدراسي والروحي",
                icon = Icons.Default.Analytics
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "مؤشر التوازن والإنتاجية الكلي",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("إجمالي المنجز من المنهج", style = MaterialTheme.typography.bodySmall)
                        Text("${(overallProgress * 100).toInt()}%", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = Emerald600))
                    }
                    CustomProgressBar(progress = overallProgress, color = Emerald600)

                    Divider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("الالتزام بالفروض اليومية", style = MaterialTheme.typography.bodySmall)
                        Text("${todayPrayers.count { it.isDone }} / 5 صلوات", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = Gold700))
                    }
                    CustomProgressBar(progress = todayPrayers.count { it.isDone } / 5f, color = Gold500)

                    Divider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("إنجاز المهام والواجبات", style = MaterialTheme.typography.bodySmall)
                        Text("${tasks.count { it.isCompleted }} / ${tasks.size} مهمة", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = AccentSky))
                    }
                    CustomProgressBar(
                        progress = if (tasks.isNotEmpty()) tasks.count { it.isCompleted }.toFloat() / tasks.size.toFloat() else 0.5f,
                        color = AccentSky
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileSettingsTabContent(
    user: UserEntity?,
    onUpdateProfile: (String, String, String, Int, String) -> Unit
) {
    var name by remember(user?.name) { mutableStateOf(user?.name ?: "طالب الثانوية") }
    var selectedGov by remember(user?.governorate) { mutableStateOf(user?.governorate ?: "القاهرة") }
    var selectedDivision by remember(user?.division) { mutableStateOf(user?.division ?: "علمي علوم") }
    var ruqyahPin by remember(user?.ruqyahPin) { mutableStateOf(user?.ruqyahPin ?: "") }

    val divisions = listOf("علمي علوم", "علمي رياضة", "أدبي")

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "الملف الشخصي وإعدادات الحساب",
                subtitle = "تخصيص الشعبة والمحافظة وحماية البيانات",
                icon = Icons.Default.Settings
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("اسمك الكريم") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("الشعبة الدراسية:", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        divisions.forEach { div ->
                            TabPill(
                                text = div,
                                isSelected = selectedDivision == div,
                                onClick = { selectedDivision = div }
                            )
                        }
                    }

                    Text("المحافظة (لحساب مواقيت الصلاة الدقيقة):", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(DefaultData.GOVERNORATES) { gov ->
                            TabPill(
                                text = gov,
                                isSelected = selectedGov == gov,
                                onClick = { selectedGov = gov }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = ruqyahPin,
                        onValueChange = { ruqyahPin = it },
                        label = { Text("رمز حماية القسم الروحاني (اختياري)") },
                        placeholder = { Text("مثال: 1234 (اتركه فارغاً لإلغاء القفل)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            onUpdateProfile(name, selectedGov, selectedDivision, 18, ruqyahPin)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald700),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("حفظ التغييرات")
                    }
                }
            }
        }
    }
}
