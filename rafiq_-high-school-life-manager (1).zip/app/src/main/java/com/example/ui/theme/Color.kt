package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald Palette (البركة والنماء)
val Emerald900 = Color(0xFF0B291B)
val Emerald800 = Color(0xFF134E36)
val Emerald700 = Color(0xFF1B6A4B)
val Emerald600 = Color(0xFF23865D)
val Emerald500 = Color(0xFF2EA071)
val Emerald300 = Color(0xFF6EDBA8)
val Emerald100 = Color(0xFFD1F4E3)
val Emerald50 = Color(0xFFF0FAF5)

// Secondary Warm Amber Gold Palette (النجاح والتميز)
val Gold900 = Color(0xFF5C4300)
val Gold700 = Color(0xFFB8860B)
val Gold500 = Color(0xFFD4AF37)
val Gold400 = Color(0xFFE5C158)
val Gold300 = Color(0xFFF3D98B)
val Gold100 = Color(0xFFFFF3D1)
val Gold50 = Color(0xFFFFFDF5)

// Accent Blue & Slate
val AccentSky = Color(0xFF2A9D8F)
val AccentTeal = Color(0xFF264653)
val AccentCoral = Color(0xFFE76F51)
val AccentOrange = Color(0xFFF4A261)
val AccentPurple = Color(0xFF8338EC)

// Neutral & Backgrounds - Dark
val DarkBg = Color(0xFF0F1714)
val DarkSurface = Color(0xFF17231E)
val DarkSurfaceVariant = Color(0xFF1F2F29)
val DarkSurfaceHighlight = Color(0xFF2A3D35)
val DarkTextPrimary = Color(0xFFF1F7F4)
val DarkTextSecondary = Color(0xFFA5B8B0)
val DarkBorder = Color(0xFF2D4239)

// Neutral & Backgrounds - Light
val LightBg = Color(0xFFF6FAF7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAF2ED)
val LightSurfaceHighlight = Color(0xFFDFECE3)
val LightTextPrimary = Color(0xFF13221C)
val LightTextSecondary = Color(0xFF536A60)
val LightBorder = Color(0xFFD4E2D9)
