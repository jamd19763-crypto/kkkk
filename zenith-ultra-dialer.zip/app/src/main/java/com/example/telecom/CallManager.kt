package com.example.telecom

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import com.example.data.model.ActiveCallInfo
import com.example.data.model.CallState
import com.example.data.model.RecordingLayer
import com.example.data.model.TranscriptEntry
import com.example.recording.RecordingManager
import com.example.speech.LiveCaptionEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object CallManager {
    private var activeTelecomCall: Call? = null
    private var applicationContext: Context? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var callTimerJob: Job? = null

    private val _currentCallInfo = MutableStateFlow(ActiveCallInfo())
    val currentCallInfo = _currentCallInfo.asStateFlow()

    fun initialize(context: Context) {
        applicationContext = context.applicationContext
    }

    fun updateTelecomCall(call: Call?) {
        activeTelecomCall = call
        if (call == null) {
            stopCallTimer()
            _currentCallInfo.value = ActiveCallInfo()
            return
        }

        val handle = call.details?.handle
        val phoneNumber = handle?.schemeSpecificPart ?: ""
        val callerName = call.details?.callerDisplayName ?: phoneNumber

        val mappedState = mapTelecomState(call.state)
        _currentCallInfo.update {
            it.copy(
                callId = call.hashCode().toString(),
                phoneNumber = phoneNumber,
                callerName = if (callerName.isNotBlank()) callerName else phoneNumber,
                state = mappedState
            )
        }

        if (mappedState == CallState.ACTIVE && callTimerJob == null) {
            startCallTimer()
        }
    }

    private fun mapTelecomState(telecomState: Int): CallState {
        return when (telecomState) {
            Call.STATE_DIALING -> CallState.DIALING
            Call.STATE_CONNECTING -> CallState.CONNECTING
            Call.STATE_RINGING -> CallState.RINGING
            Call.STATE_ACTIVE -> CallState.ACTIVE
            Call.STATE_HOLDING -> CallState.HOLDING
            Call.STATE_DISCONNECTING -> CallState.DISCONNECTING
            Call.STATE_DISCONNECTED -> CallState.DISCONNECTED
            else -> CallState.IDLE
        }
    }

    fun startOutgoingCall(context: Context, phoneNumber: String, isVideo: Boolean = false) {
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        try {
            val uri = Uri.fromParts("tel", phoneNumber, null)
            val intent = Intent(Intent.ACTION_CALL, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                if (isVideo) {
                    putExtra(TelecomManager.EXTRA_START_CALL_WITH_VIDEO_STATE, android.telecom.VideoProfile.STATE_BIDIRECTIONAL)
                }
            }
            context.startActivity(intent)

            // Preview active call state in UI immediately
            _currentCallInfo.update {
                it.copy(
                    callId = "call_${System.currentTimeMillis()}",
                    phoneNumber = phoneNumber,
                    callerName = phoneNumber,
                    state = CallState.DIALING,
                    callDurationSeconds = 0
                )
            }
        } catch (e: SecurityException) {
            // Fallback to DIAL intent if CALL_PHONE permission is waiting
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(dialIntent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun answer() {
        activeTelecomCall?.answer(0)
        _currentCallInfo.update { it.copy(state = CallState.ACTIVE) }
        startCallTimer()
    }

    fun hangup() {
        if (activeTelecomCall != null) {
            activeTelecomCall?.disconnect()
        }
        stopCallTimer()
        _currentCallInfo.update { it.copy(state = CallState.DISCONNECTED) }
        scope.launch {
            delay(1000)
            _currentCallInfo.value = ActiveCallInfo()
        }
    }

    fun toggleMute() {
        val currentMute = _currentCallInfo.value.isMuted
        val newMute = !currentMute
        val audioManager = applicationContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        audioManager?.isMicrophoneMute = newMute
        _currentCallInfo.update { it.copy(isMuted = newMute) }
    }

    fun toggleSpeaker() {
        val currentSpeaker = _currentCallInfo.value.isSpeakerOn
        val newSpeaker = !currentSpeaker
        val audioManager = applicationContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        audioManager?.isSpeakerphoneOn = newSpeaker
        _currentCallInfo.update { it.copy(isSpeakerOn = newSpeaker) }
    }

    fun toggleHold() {
        val currentHold = _currentCallInfo.value.isHold
        if (currentHold) {
            activeTelecomCall?.unhold()
        } else {
            activeTelecomCall?.hold()
        }
        _currentCallInfo.update { it.copy(isHold = !currentHold) }
    }

    fun sendDtmf(digit: Char) {
        activeTelecomCall?.playDtmfTone(digit)
        scope.launch {
            delay(200)
            activeTelecomCall?.stopDtmfTone()
        }
    }

    fun toggleRecording(context: Context) {
        val isCurrentlyRecording = _currentCallInfo.value.isRecording
        if (isCurrentlyRecording) {
            RecordingManager.stopRecording(context)
            _currentCallInfo.update { it.copy(isRecording = false, recordingDurationSeconds = 0) }
        } else {
            val phone = _currentCallInfo.value.phoneNumber
            val name = _currentCallInfo.value.callerName
            RecordingManager.startRecording(context, phone, name)
            _currentCallInfo.update { it.copy(isRecording = true) }
        }
    }

    fun addLiveTranscript(entry: TranscriptEntry) {
        _currentCallInfo.update {
            it.copy(liveTranscriptList = it.liveTranscriptList + entry)
        }
    }

    fun updateWaveform(amplitudes: List<Float>) {
        _currentCallInfo.update {
            it.copy(audioWaveformAmplitudes = amplitudes)
        }
    }

    // Simulation / Direct Trigger for testing UI states seamlessly
    fun simulateCall(phoneNumber: String, name: String, isIncoming: Boolean) {
        _currentCallInfo.value = ActiveCallInfo(
            callId = "sim_${System.currentTimeMillis()}",
            phoneNumber = phoneNumber,
            callerName = name,
            state = if (isIncoming) CallState.RINGING else CallState.DIALING,
            callDurationSeconds = 0,
            isRecording = false,
            liveTranscriptList = listOf(
                TranscriptEntry("النظام الذكي", "جاري تشغيل محرك تحويل الصوت للنص المباشر بدقة عالية...", System.currentTimeMillis()),
                TranscriptEntry(name, "مرحباً! أتصل بك بخصوص مشروع ColorOS 13 وتسجيل المكالمات.", System.currentTimeMillis() + 1000, true)
            )
        )

        if (!isIncoming) {
            scope.launch {
                delay(2000)
                _currentCallInfo.update { it.copy(state = CallState.ACTIVE) }
                startCallTimer()
            }
        }
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = scope.launch {
            while (isActive) {
                delay(1000)
                _currentCallInfo.update { current ->
                    if (current.state == CallState.ACTIVE) {
                        current.copy(
                            callDurationSeconds = current.callDurationSeconds + 1,
                            recordingDurationSeconds = if (current.isRecording) current.recordingDurationSeconds + 1 else current.recordingDurationSeconds
                        )
                    } else {
                        current
                    }
                }
            }
        }
    }

    private fun stopCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = null
    }
}
