package com.example.telecom

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CallBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            CallService.ACTION_HANGUP -> CallManager.hangup()
            CallService.ACTION_TOGGLE_MUTE -> CallManager.toggleMute()
            CallService.ACTION_TOGGLE_SPEAKER -> CallManager.toggleSpeaker()
            CallService.ACTION_TOGGLE_RECORD -> CallManager.toggleRecording(context)
        }
    }
}
