package com.example.data.model

data class ActiveCallInfo(
    val callId: String = "",
    val phoneNumber: String = "",
    val callerName: String = "",
    val callerPhotoUri: String? = null,
    val state: CallState = CallState.DISCONNECTED,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false,
    val isHold: Boolean = false,
    val isRecording: Boolean = false,
    val recordingDurationSeconds: Long = 0,
    val callDurationSeconds: Long = 0,
    val activeLayer: RecordingLayer = RecordingLayer.MEDIA_PROJECTION,
    val liveTranscriptList: List<TranscriptEntry> = emptyList(),
    val audioWaveformAmplitudes: List<Float> = emptyList()
)

enum class CallState {
    IDLE,
    DIALING,
    CONNECTING,
    RINGING,
    ACTIVE,
    HOLDING,
    DISCONNECTING,
    DISCONNECTED
}

data class TranscriptEntry(
    val speaker: String, // "You" or Caller Name
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isIncomingSpeaker: Boolean = false
)
