package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class RecordingLayer {
    MEDIA_PROJECTION,
    ACCESSIBILITY_OPPO,
    ROOT_REFLECTION,
    MIC_FALLBACK
}

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val phoneNumber: String,
    val callerName: String? = null,
    val filePath: String,
    val fileName: String,
    val durationSeconds: Long = 0,
    val fileSizeBytes: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val audioFormat: String = "MP3", // MP3, WAV, AAC, FLAC
    val sampleRate: Int = 44100, // 44.1 kHz CD Quality
    val bitRateKbps: Int = 128,
    val layerUsed: RecordingLayer = RecordingLayer.MEDIA_PROJECTION,
    val transcript: String? = null,
    val isFavorite: Boolean = false
)
