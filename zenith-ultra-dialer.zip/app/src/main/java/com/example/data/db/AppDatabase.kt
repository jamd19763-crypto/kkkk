package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ContactEntity::class,
        CallLogEntity::class,
        MessageEntity::class,
        RecordingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun callLogDao(): CallLogDao
    abstract fun messageDao(): MessageDao
    abstract fun recordingDao(): RecordingDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "titan_dialer_database.db"
                )
                .fallbackToDestructiveMigration()
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed realistic initial data for testing
                        CoroutineScope(Dispatchers.IO).launch {
                            INSTANCE?.let { database ->
                                seedInitialData(database)
                            }
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedInitialData(db: AppDatabase) {
            val sampleContacts = listOf(
                ContactEntity(
                    name = "سارة أحمد (Oppo Tech)",
                    phoneNumber = "+966501234567",
                    email = "sara.ahmed@example.com",
                    isFavorite = true,
                    company = "ColorOS Team",
                    jobTitle = "مهندسة برمجيات"
                ),
                ContactEntity(
                    name = "م. خالد العمري",
                    phoneNumber = "+966559876543",
                    email = "khaled.omari@telecom.sa",
                    isFavorite = true,
                    company = "الاتصالات السعودية",
                    jobTitle = "مدير الشبكات"
                ),
                ContactEntity(
                    name = "دعم عملاء أوبو (Oppo Support)",
                    phoneNumber = "8008440001",
                    email = "support@oppo.com",
                    isFavorite = true,
                    company = "OPPO KSA",
                    jobTitle = "الدعم الفني VIP"
                ),
                ContactEntity(
                    name = "فاطمة الزهراء",
                    phoneNumber = "+966567890123",
                    email = "fatima@designhub.io",
                    isFavorite = false,
                    company = "Design Studio",
                    jobTitle = "مصممة واجهات UI/UX"
                ),
                ContactEntity(
                    name = "طارق العتيبي",
                    phoneNumber = "+966531122334",
                    email = "tariq@cloudtech.com",
                    isFavorite = false,
                    company = "Cloud Systems",
                    jobTitle = "مطور أنظمة أندرويد"
                )
            )
            db.contactDao().insertAll(sampleContacts)

            val now = System.currentTimeMillis()
            db.callLogDao().insertCallLog(
                CallLogEntity(
                    callerName = "سارة أحمد (Oppo Tech)",
                    phoneNumber = "+966501234567",
                    callType = CallType.INCOMING,
                    timestamp = now - 3600000,
                    durationSeconds = 184,
                    location = "الرياض"
                )
            )
            db.callLogDao().insertCallLog(
                CallLogEntity(
                    callerName = "م. خالد العمري",
                    phoneNumber = "+966559876543",
                    callType = CallType.OUTGOING,
                    timestamp = now - 86400000,
                    durationSeconds = 95,
                    location = "جدة"
                )
            )
            db.callLogDao().insertCallLog(
                CallLogEntity(
                    callerName = "رقم غير مسجل (Smart Call)",
                    phoneNumber = "+966580009988",
                    callType = CallType.MISSED,
                    timestamp = now - 12000000,
                    durationSeconds = 0,
                    location = "دبي"
                )
            )

            // Seed initial messages
            db.messageDao().insertAll(
                listOf(
                    MessageEntity(
                        senderNumber = "+966501234567",
                        recipientNumber = "Me",
                        senderName = "سارة أحمد (Oppo Tech)",
                        body = "أهلاً بك! تم ضبط إعدادات تسجيل المكالمات بنجاح على ColorOS 13",
                        timestamp = now - 1800000,
                        isIncoming = true,
                        isRead = true
                    ),
                    MessageEntity(
                        senderNumber = "Me",
                        recipientNumber = "+966501234567",
                        senderName = "أنا",
                        body = "ممتاز، جودة الصوت 44.1kHz فائقة الوضوح لكلا الطرفين!",
                        timestamp = now - 900000,
                        isIncoming = false,
                        isRead = true
                    )
                )
            )
        }
    }
}
