package com.example.data.repository

import android.content.Context
import com.example.data.db.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class DialerRepository(private val context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val contactDao = db.contactDao()
    private val callLogDao = db.callLogDao()
    private val messageDao = db.messageDao()
    private val recordingDao = db.recordingDao()

    private val _settings = MutableStateFlow(DialerSettings())
    val settings = _settings.asStateFlow()

    // Contacts
    fun getAllContacts(): Flow<List<ContactEntity>> = contactDao.getAllContacts()
    fun getFavoriteContacts(): Flow<List<ContactEntity>> = contactDao.getFavoriteContacts()
    fun searchContacts(query: String): Flow<List<ContactEntity>> = contactDao.searchContacts(query)
    suspend fun findContactByNumber(phone: String): ContactEntity? = contactDao.findByPhoneNumber(phone)
    suspend fun insertContact(contact: ContactEntity): Long = contactDao.insertContact(contact)
    suspend fun updateContact(contact: ContactEntity) = contactDao.updateContact(contact)
    suspend fun deleteContact(id: Long) = contactDao.deleteById(id)
    suspend fun toggleFavorite(id: Long, isFav: Boolean) = contactDao.updateFavorite(id, isFav)

    // Call Logs
    fun getAllCallLogs(): Flow<List<CallLogEntity>> = callLogDao.getAllCallLogs()
    fun searchCallLogs(query: String): Flow<List<CallLogEntity>> = callLogDao.searchCallLogs(query)
    suspend fun insertCallLog(callLog: CallLogEntity): Long = callLogDao.insertCallLog(callLog)
    suspend fun deleteCallLog(id: Long) = callLogDao.deleteById(id)
    suspend fun clearAllCallLogs() = callLogDao.clearAll()

    // Messages
    fun getAllMessages(): Flow<List<MessageEntity>> = messageDao.getAllMessages()
    fun getRecentConversations(): Flow<List<MessageEntity>> = messageDao.getRecentConversations()
    fun getConversation(phone: String): Flow<List<MessageEntity>> = messageDao.getConversation(phone)
    fun searchMessages(query: String): Flow<List<MessageEntity>> = messageDao.searchMessages(query)
    suspend fun insertMessage(msg: MessageEntity): Long = messageDao.insertMessage(msg)
    suspend fun deleteMessage(id: Long) = messageDao.deleteById(id)
    suspend fun deleteConversation(phone: String) = messageDao.deleteConversation(phone)

    // Recordings
    fun getAllRecordings(): Flow<List<RecordingEntity>> = recordingDao.getAllRecordings()
    suspend fun insertRecording(rec: RecordingEntity): Long = recordingDao.insertRecording(rec)
    suspend fun deleteRecording(id: Long) = recordingDao.deleteById(id)
    suspend fun toggleRecordingFavorite(id: Long, isFav: Boolean) = recordingDao.toggleFavorite(id, isFav)

    // Settings management
    fun updateSettings(transform: (DialerSettings) -> DialerSettings) {
        _settings.update(transform)
    }
}
