package com.example.data.db

import androidx.room.*
import com.example.data.model.MessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    fun getAllMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE recipientNumber = :phoneNumber OR senderNumber = :phoneNumber ORDER BY timestamp ASC")
    fun getConversation(phoneNumber: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE id IN (SELECT MAX(id) FROM messages GROUP BY CASE WHEN isIncoming = 1 THEN senderNumber ELSE recipientNumber END) ORDER BY timestamp DESC")
    fun getRecentConversations(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE body LIKE '%' || :query || '%' OR senderName LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchMessages(query: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(messages: List<MessageEntity>)

    @Update
    suspend fun updateMessage(message: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM messages WHERE recipientNumber = :phoneNumber OR senderNumber = :phoneNumber")
    suspend fun deleteConversation(phoneNumber: String)
}
