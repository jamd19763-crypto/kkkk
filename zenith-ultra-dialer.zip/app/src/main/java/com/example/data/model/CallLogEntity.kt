package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CallType {
    INCOMING,
    OUTGOING,
    MISSED,
    REJECTED,
    VOICEMAIL
}

@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val callerName: String? = null,
    val phoneNumber: String,
    val callType: CallType = CallType.OUTGOING,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0,
    val recordingPath: String? = null,
    val simSlot: Int = 1,
    val location: String? = null
)
