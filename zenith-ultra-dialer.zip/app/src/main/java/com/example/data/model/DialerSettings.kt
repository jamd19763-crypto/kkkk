package com.example.data.model

enum class AutoRecordMode {
    ALL_CALLS,
    UNKNOWN_NUMBERS_ONLY,
    INTERNATIONAL_ONLY,
    MANUAL_ONLY
}

enum class AudioFormatOption(val extension: String, val mimeType: String) {
    MP3("mp3", "audio/mpeg"),
    AAC("m4a", "audio/mp4a-latm"),
    WAV("wav", "audio/wav"),
    FLAC("flac", "audio/flac")
}

enum class ThemeMode {
    SYSTEM,
    DARK_AMOLED,
    LIGHT_LUXURY,
    COLOROS_GRADIENT
}

data class DialerSettings(
    val autoRecordMode: AutoRecordMode = AutoRecordMode.ALL_CALLS,
    val selectedFormat: AudioFormatOption = AudioFormatOption.MP3,
    val selectedBitrateKbps: Int = 128, // 64, 128, 256
    val sampleRateHz: Int = 44100, // 44.1 kHz CD Quality
    val storagePath: String = "Recordings/TitanDialer",
    val isGoogleDriveBackupEnabled: Boolean = true,
    val isBiometricLockEnabled: Boolean = false,
    val isDndDuringCallEnabled: Boolean = false,
    val isOngoingCallNotificationEnabled: Boolean = true,
    val activeRecordingLayer: RecordingLayer = RecordingLayer.MEDIA_PROJECTION,
    val themeMode: ThemeMode = ThemeMode.COLOROS_GRADIENT,
    val isLiveCaptionEnabled: Boolean = true,
    val isVoipSipEnabled: Boolean = false,
    val isSmartCallerIdEnabled: Boolean = true,
    val hasAdbPermissionsGranted: Boolean = false,
    val isAccessibilityServiceRunning: Boolean = false
)
