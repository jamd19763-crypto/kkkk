package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MessageStatus {
    SENT,
    DELIVERED,
    READ,
    FAILED,
    PENDING,
    SCHEDULED
}

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val threadId: Long = 0,
    val senderNumber: String,
    val recipientNumber: String,
    val senderName: String? = null,
    val body: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isIncoming: Boolean = false,
    val isRead: Boolean = true,
    val status: MessageStatus = MessageStatus.SENT,
    val attachmentUri: String? = null,
    val attachmentType: String? = null, // "image", "audio", "vcard"
    val scheduledTime: Long? = null
)
