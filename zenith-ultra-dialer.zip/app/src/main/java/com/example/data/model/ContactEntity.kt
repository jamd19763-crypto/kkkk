package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val secondaryNumber: String? = null,
    val email: String? = null,
    val avatarUri: String? = null,
    val isFavorite: Boolean = false,
    val company: String? = null,
    val jobTitle: String? = null,
    val note: String? = null,
    val ringtoneUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
