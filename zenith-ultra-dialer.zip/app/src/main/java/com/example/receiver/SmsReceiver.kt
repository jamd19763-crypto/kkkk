package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.example.data.db.AppDatabase
import com.example.data.model.MessageEntity
import com.example.data.model.MessageStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_DELIVER_ACTION ||
            intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            if (!messages.isNullOrEmpty()) {
                val db = AppDatabase.getInstance(context)
                CoroutineScope(Dispatchers.IO).launch {
                    for (sms in messages) {
                        val sender = sms.originatingAddress ?: "Unknown"
                        val body = sms.messageBody ?: ""
                        val entity = MessageEntity(
                            senderNumber = sender,
                            recipientNumber = "Me",
                            senderName = sender,
                            body = body,
                            timestamp = sms.timestampMillis,
                            isIncoming = true,
                            isRead = false,
                            status = MessageStatus.READ
                        )
                        db.messageDao().insertMessage(entity)
                    }
                }
            }
        }
    }
}
