package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.DialerRepository
import com.example.telecom.CallManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = DialerRepository(application)

    val contacts: StateFlow<List<ContactEntity>> = repository.getAllContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val callLogs: StateFlow<List<CallLogEntity>> = repository.getAllCallLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messages: StateFlow<List<MessageEntity>> = repository.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recordings: StateFlow<List<RecordingEntity>> = repository.getAllRecordings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _settings = MutableStateFlow(DialerSettings())
    val settings: StateFlow<DialerSettings> = _settings.asStateFlow()

    val activeCallInfo: StateFlow<ActiveCallInfo> = CallManager.currentCallInfo

    init {
        // Pre-populate sample contacts & call logs if database is empty for rich demonstration
        viewModelScope.launch {
            repository.getAllContacts().first().let { currentContacts ->
                if (currentContacts.isEmpty()) {
                    populateInitialData()
                }
            }
        }
    }

    private suspend fun populateInitialData() {
        val sampleContacts = listOf(
            ContactEntity(name = "أحمد المنصوري", phoneNumber = "+966501234567", company = "Oppo Tech Director", isFavorite = true),
            ContactEntity(name = "سارة العتيبي", phoneNumber = "+966559876543", company = "ColorOS Systems", isFavorite = true),
            ContactEntity(name = "محمد الخالدي", phoneNumber = "+966543210987", company = "Telecommunication HQ", isFavorite = false),
            ContactEntity(name = "د. خالد السبيعي", phoneNumber = "+966512345678", company = "King Saud University", isFavorite = true),
            ContactEntity(name = "فاطمة الغامدي", phoneNumber = "+966567890123", company = "AI Research Lab", isFavorite = false),
            ContactEntity(name = "خدمة عملاء Oppo VIP", phoneNumber = "8008971234", company = "Oppo Customer Care", isFavorite = true)
        )
        sampleContacts.forEach { repository.insertContact(it) }

        val sampleLogs = listOf(
            CallLogEntity(phoneNumber = "+966501234567", callerName = "أحمد المنصوري", callType = CallType.INCOMING, durationSeconds = 142, timestamp = System.currentTimeMillis() - 3600000),
            CallLogEntity(phoneNumber = "+966559876543", callerName = "سارة العتيبي", callType = CallType.OUTGOING, durationSeconds = 85, timestamp = System.currentTimeMillis() - 7200000),
            CallLogEntity(phoneNumber = "+971509988776", callerName = "مكالمة دولية (دبي)", callType = CallType.MISSED, durationSeconds = 0, timestamp = System.currentTimeMillis() - 86400000),
            CallLogEntity(phoneNumber = "8008971234", callerName = "خدمة عملاء Oppo VIP", callType = CallType.INCOMING, durationSeconds = 320, timestamp = System.currentTimeMillis() - 172800000)
        )
        sampleLogs.forEach { repository.insertCallLog(it) }

        val sampleMessages = listOf(
            MessageEntity(senderNumber = "+966501234567", recipientNumber = "Me", senderName = "أحمد المنصوري", body = "أهلاً بك، هل تم تفعيل تسجيل المكالمات بنجاح على نظام ColorOS 13؟", timestamp = System.currentTimeMillis() - 1800000, isIncoming = true),
            MessageEntity(senderNumber = "Me", recipientNumber = "+966501234567", senderName = "Me", body = "نعم، النظام يعمل بكفاءة مع الطبقات الثلاث وبصيغة ستيريو 44.1kHz.", timestamp = System.currentTimeMillis() - 1200000, isIncoming = false),
            MessageEntity(senderNumber = "+966559876543", recipientNumber = "Me", senderName = "سارة العتيبي", body = "شكراً لك على التحديث السريع!", timestamp = System.currentTimeMillis() - 900000, isIncoming = true)
        )
        sampleMessages.forEach { repository.insertMessage(it) }
    }

    fun addContact(contact: ContactEntity) {
        viewModelScope.launch { repository.insertContact(contact) }
    }

    fun deleteContact(contactId: Long) {
        viewModelScope.launch { repository.deleteContact(contactId) }
    }

    fun toggleContactFavorite(contactId: Long, isFavorite: Boolean) {
        viewModelScope.launch { repository.toggleFavorite(contactId, isFavorite) }
    }

    fun sendMessage(recipient: String, body: String, scheduledTime: Long?) {
        viewModelScope.launch {
            val message = MessageEntity(
                senderNumber = "Me",
                recipientNumber = recipient,
                senderName = "Me",
                body = body,
                timestamp = scheduledTime ?: System.currentTimeMillis(),
                isIncoming = false,
                isRead = true,
                status = if (scheduledTime != null) MessageStatus.SCHEDULED else MessageStatus.DELIVERED
            )
            repository.insertMessage(message)
        }
    }

    fun deleteMessage(messageId: Long) {
        viewModelScope.launch { repository.deleteMessage(messageId) }
    }

    fun deleteRecording(recordingId: Long) {
        viewModelScope.launch { repository.deleteRecording(recordingId) }
    }

    fun updateSettings(transformer: (DialerSettings) -> DialerSettings) {
        _settings.value = transformer(_settings.value)
    }
}
