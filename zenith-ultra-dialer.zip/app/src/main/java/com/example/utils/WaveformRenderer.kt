package com.example.utils

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun LiveWaveformVisualizer(
    amplitudes: List<Float>,
    isRecording: Boolean,
    modifier: Modifier = Modifier,
    height: Dp = 60.dp,
    barColor: Color = Color(0xFF00E5FF),
    accentColor: Color = Color(0xFF7C4DFF)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val centerY = canvasHeight / 2

        val barCount = 36
        val barSpacing = 4.dp.toPx()
        val totalSpacing = barSpacing * (barCount - 1)
        val barWidth = ((canvasWidth - totalSpacing) / barCount).coerceAtLeast(3.dp.toPx())

        val brush = Brush.verticalGradient(
            colors = listOf(
                accentColor,
                barColor,
                accentColor
            ),
            startY = 0f,
            endY = canvasHeight
        )

        for (i in 0 until barCount) {
            val amp = if (amplitudes.isNotEmpty() && i < amplitudes.size) {
                amplitudes[i]
            } else if (isRecording) {
                // Gentle baseline fluctuation
                (0.2f + 0.15f * Math.sin((i + pulseScale * 5).toDouble()).toFloat())
            } else {
                0.1f
            }

            val scale = if (isRecording) amp * pulseScale else amp
            val barHeight = (canvasHeight * scale.coerceIn(0.1f, 1.0f)).coerceAtLeast(6.dp.toPx())
            val x = i * (barWidth + barSpacing)
            val y = centerY - (barHeight / 2)

            drawRoundRect(
                brush = brush,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}
