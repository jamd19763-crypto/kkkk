package com.example.ui.screens

import android.media.MediaPlayer
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RecordingEntity
import com.example.data.model.RecordingLayer
import com.example.ui.theme.CallRed
import com.example.ui.theme.TitanBlue
import com.example.ui.theme.TitanCyan
import com.example.utils.StorageHelper
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordingsVaultScreen(
    recordings: List<RecordingEntity>,
    onDeleteRecording: (Long) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var playingRecordingId by remember { mutableStateOf<Long?>(null) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "خزينة تسجيل المكالمات (${recordings.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val msg = StorageHelper.simulateDriveBackup(recordings.size, 0)
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        }
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = "Backup to Drive", tint = TitanCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        if (recordings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(top = 80.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.MicOff, contentDescription = null, tint = TitanCyan, modifier = Modifier.size(48.dp))
                    Text("لا توجد تسجيلات حتى الآن", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("يتم تسجيل المكالمات تلقائياً بجودة 44.1kHz ستيريو", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(recordings, key = { it.id }) { rec ->
                    val isPlaying = playingRecordingId == rec.id
                    val displayName = if (!rec.callerName.isNullOrBlank()) rec.callerName else rec.phoneNumber

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = displayName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = StorageHelper.formatTimestamp(rec.timestamp),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // Layer Used & Format Badge
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when (rec.layerUsed) {
                                            RecordingLayer.MEDIA_PROJECTION -> TitanCyan.copy(alpha = 0.2f)
                                            RecordingLayer.ACCESSIBILITY_OPPO -> TitanBlue.copy(alpha = 0.2f)
                                            RecordingLayer.ROOT_REFLECTION -> CallRed.copy(alpha = 0.2f)
                                            RecordingLayer.MIC_FALLBACK -> Color.Gray.copy(alpha = 0.2f)
                                        }
                                    ) {
                                        Text(
                                            text = when (rec.layerUsed) {
                                                RecordingLayer.MEDIA_PROJECTION -> "Layer 1: MediaProjection"
                                                RecordingLayer.ACCESSIBILITY_OPPO -> "Layer 2: ColorOS UI"
                                                RecordingLayer.ROOT_REFLECTION -> "Layer 3: Root Voice"
                                                RecordingLayer.MIC_FALLBACK -> "Mic Source"
                                            },
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (rec.layerUsed) {
                                                RecordingLayer.MEDIA_PROJECTION -> TitanCyan
                                                RecordingLayer.ACCESSIBILITY_OPPO -> TitanBlue
                                                RecordingLayer.ROOT_REFLECTION -> CallRed
                                                RecordingLayer.MIC_FALLBACK -> Color.LightGray
                                            },
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = TitanCyan.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "${rec.audioFormat} • 44.1k",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TitanCyan,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "المدة: ${StorageHelper.formatDuration(rec.durationSeconds)} • الحجم: ${StorageHelper.formatFileSize(rec.fileSizeBytes)}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Play / Pause Button
                                    IconButton(
                                        onClick = {
                                            if (isPlaying) {
                                                mediaPlayer?.stop()
                                                mediaPlayer?.release()
                                                mediaPlayer = null
                                                playingRecordingId = null
                                            } else {
                                                mediaPlayer?.release()
                                                try {
                                                    val file = File(rec.filePath)
                                                    if (file.exists()) {
                                                        mediaPlayer = MediaPlayer().apply {
                                                            setDataSource(rec.filePath)
                                                            prepare()
                                                            start()
                                                            setOnCompletionListener {
                                                                playingRecordingId = null
                                                            }
                                                        }
                                                        playingRecordingId = rec.id
                                                    } else {
                                                        Toast.makeText(context, "الملف غير موجود في المسار: ${rec.filePath}", Toast.LENGTH_SHORT).show()
                                                    }
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "فشل تشغيل الملف: ${e.message}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(if (isPlaying) CallRed else TitanCyan)
                                    ) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isPlaying) "Pause" else "Play",
                                            tint = if (isPlaying) Color.White else Color.Black,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    // Delete Button
                                    IconButton(
                                        onClick = { onDeleteRecording(rec.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
