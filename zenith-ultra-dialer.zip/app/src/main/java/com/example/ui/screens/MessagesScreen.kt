package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MessageEntity
import com.example.data.model.MessageStatus
import com.example.ui.theme.GradientEnd
import com.example.ui.theme.TitanBlue
import com.example.ui.theme.TitanCyan
import com.example.utils.StorageHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagesScreen(
    messages: List<MessageEntity>,
    onSendMessage: (recipient: String, body: String, scheduledTime: Long?) -> Unit,
    onDeleteMessage: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedThreadRecipient by remember { mutableStateOf<String?>(null) }
    var showNewMessageDialog by remember { mutableStateOf(false) }

    // Group messages by recipient/sender into conversations
    val conversationMap = remember(messages) {
        messages.groupBy {
            if (it.isIncoming) it.senderNumber else it.recipientNumber
        }
    }

    if (selectedThreadRecipient != null) {
        val threadMessages = messages.filter {
            it.senderNumber == selectedThreadRecipient || it.recipientNumber == selectedThreadRecipient
        }.sortedBy { it.timestamp }

        ChatThreadView(
            recipient = selectedThreadRecipient!!,
            messages = threadMessages,
            onBack = { selectedThreadRecipient = null },
            onSend = { text, scheduledTime ->
                onSendMessage(selectedThreadRecipient!!, text, scheduledTime)
            }
        )
    } else {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showNewMessageDialog = true },
                    containerColor = TitanCyan,
                    contentColor = Color.Black,
                    shape = CircleShape,
                    modifier = Modifier.testTag("new_message_fab")
                ) {
                    Icon(Icons.Default.AddComment, contentDescription = "New Message")
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                // Header with Drive Backup Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الرسائل النصية (SMS / MMS)",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = TitanCyan.copy(alpha = 0.15f),
                        modifier = Modifier.clickable {
                            val msg = StorageHelper.simulateDriveBackup(0, messages.size)
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = "Backup",
                                tint = TitanCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "نسخ للـ Drive",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TitanCyan
                            )
                        }
                    }
                }

                if (conversationMap.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 80.dp),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Text(
                            text = "لا توجد محادثات نصية حالياً",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(conversationMap.entries.toList(), key = { it.key }) { entry ->
                            val recipient = entry.key
                            val lastMsg = entry.value.maxByOrNull { it.timestamp }
                            val contactName = lastMsg?.senderName ?: recipient

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { selectedThreadRecipient = recipient },
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(
                                                brush = Brush.linearGradient(
                                                    listOf(TitanCyan, TitanBlue, GradientEnd)
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = contactName.take(1),
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = contactName,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = if (lastMsg != null) StorageHelper.formatTimeOnly(lastMsg.timestamp) else "",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(2.dp))

                                        Text(
                                            text = lastMsg?.body ?: "",
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (showNewMessageDialog) {
                NewMessageDialog(
                    onDismiss = { showNewMessageDialog = false },
                    onSend = { phone, text ->
                        onSendMessage(phone, text, null)
                        showNewMessageDialog = false
                        selectedThreadRecipient = phone
                    }
                )
            }
        }
    }
}

@Composable
fun ChatThreadView(
    recipient: String,
    messages: List<MessageEntity>,
    onBack: () -> Unit,
    onSend: (text: String, scheduledTime: Long?) -> Unit
) {
    val listState = rememberLazyListState()
    var inputText by remember { mutableStateOf("") }
    var showScheduleDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Chat Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(TitanCyan.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = recipient.take(1),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TitanCyan
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = recipient,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "متصل عبر SMS المشفر",
                        fontSize = 11.sp,
                        color = TitanCyan
                    )
                }
            }
        }

        // Messages Bubble Stream
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isMe = !msg.isIncoming
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isMe) 16.dp else 4.dp,
                            bottomEnd = if (isMe) 4.dp else 16.dp
                        ),
                        color = if (isMe) TitanBlue else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(
                                text = msg.body,
                                fontSize = 14.sp,
                                color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                modifier = Modifier.align(Alignment.End),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = StorageHelper.formatTimeOnly(msg.timestamp),
                                    fontSize = 10.sp,
                                    color = if (isMe) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (isMe) {
                                    Icon(
                                        imageVector = Icons.Default.DoneAll,
                                        contentDescription = "Delivered",
                                        tint = Color.White.copy(alpha = 0.8f),
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Input Row: MMS Image Attachment, Schedule SMS, Text Input, Send
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // MMS Attachment Button
                IconButton(
                    onClick = {
                        Toast.makeText(context, "تم إرفاق وسائط MMS جاهزة للإرسال", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.AttachFile, contentDescription = "Attach MMS", tint = TitanCyan)
                }

                // Schedule SMS Button
                IconButton(
                    onClick = { showScheduleDialog = true }
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = "Schedule SMS", tint = TitanCyan)
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("اكتب رسالة...") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 4
                )

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            onSend(inputText, null)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(TitanCyan)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.Black)
                }
            }
        }

        if (showScheduleDialog) {
            ScheduleSmsDialog(
                onDismiss = { showScheduleDialog = false },
                onSchedule = { scheduledTime ->
                    if (inputText.isNotBlank()) {
                        onSend(inputText, scheduledTime)
                        inputText = ""
                        Toast.makeText(context, "تمت جدولة إرسال الرسالة بنجاح!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "يرجى كتابة نص الرسالة أولاً", Toast.LENGTH_SHORT).show()
                    }
                    showScheduleDialog = false
                }
            )
        }
    }
}

@Composable
fun ScheduleSmsDialog(
    onDismiss: () -> Unit,
    onSchedule: (Long) -> Unit
) {
    var hoursAhead by remember { mutableStateOf(1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("جدولة إرسال الرسالة", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("اختر موعد إرسال الرسالة تلقائياً:")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf(1, 2, 6, 24).forEach { hours ->
                        FilterChip(
                            selected = hoursAhead == hours,
                            onClick = { hoursAhead = hours },
                            label = { Text("بعد $hours ساعة") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val futureMillis = System.currentTimeMillis() + (hoursAhead * 3600 * 1000L)
                    onSchedule(futureMillis)
                },
                colors = ButtonDefaults.buttonColors(containerColor = TitanCyan, contentColor = Color.Black)
            ) {
                Text("تأكيد الجدولة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun NewMessageDialog(
    onDismiss: () -> Unit,
    onSend: (phoneNumber: String, text: String) -> Unit
) {
    var phone by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("رسالة جديدة", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم المستلم") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("نص الرسالة") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (phone.isNotBlank() && text.isNotBlank()) {
                        onSend(phone, text)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TitanCyan, contentColor = Color.Black)
            ) {
                Text("إرسال")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
