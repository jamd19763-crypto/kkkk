package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary & Brand Colors
val TitanCyan = Color(0xFF00E5FF)
val TitanBlue = Color(0xFF2979FF)
val TitanDeepIndigo = Color(0xFF0D1B2A)
val TitanSurfaceDark = Color(0xFF1B263B)
val TitanCardDark = Color(0xFF23324E)

// In-Call and Dialing Colors
val CallGreen = Color(0xFF00E676)
val CallGreenGlow = Color(0xFF69F0AE)
val CallRed = Color(0xFFFF1744)
val CallRedGlow = Color(0xFFFF5252)
val CallAmber = Color(0xFFFFAB00)

// Dynamic Island & Overlay Colors
val DynamicIslandBg = Color(0xFF000000)
val DynamicIslandBorder = Color(0xFF333333)

// Luxury Gradients
val GradientStart = Color(0xFF00E5FF)
val GradientMid = Color(0xFF2979FF)
val GradientEnd = Color(0xFF7C4DFF)

// M3 Theme Colors
val PrimaryDark = TitanCyan
val OnPrimaryDark = Color(0xFF002026)
val SecondaryDark = Color(0xFF82B1FF)
val BackgroundDark = Color(0xFF070B14)
val SurfaceDark = Color(0xFF0F172A)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)

val PrimaryLight = Color(0xFF00687A)
val OnPrimaryLight = Color.White
val SecondaryLight = Color(0xFF005AC1)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE2E8F0)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
