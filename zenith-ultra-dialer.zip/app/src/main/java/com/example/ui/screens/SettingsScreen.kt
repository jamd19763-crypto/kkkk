package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.TitanBlue
import com.example.ui.theme.TitanCyan
import com.example.utils.PermissionHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: DialerSettings,
    onUpdateSettings: ((DialerSettings) -> DialerSettings) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onRequestMediaProjection: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    val adbCommands = """
adb shell pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS
adb shell appops set ${context.packageName} SYSTEM_ALERT_WINDOW allow
adb shell dumpsys deviceidle whitelist +${context.packageName}
adb shell pm grant ${context.packageName} android.permission.CAPTURE_AUDIO_OUTPUT
    """.trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "الإعدادات الشاملة (Titan Dialer)",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
            )
        }

        // Section 1: Call Recording 3-Layer Engine
        item {
            SettingsCategoryHeader(title = "نظام تسجيل المكالمات المتقدم (3 طبقات)", icon = Icons.Default.GraphicEq)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "وضع التسجيل التلقائي:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AutoRecordMode.values().forEach { mode ->
                            val label = when (mode) {
                                AutoRecordMode.ALL_CALLS -> "الكل"
                                AutoRecordMode.UNKNOWN_NUMBERS_ONLY -> "غير المسجلين"
                                AutoRecordMode.INTERNATIONAL_ONLY -> "الدولية"
                                AutoRecordMode.MANUAL_ONLY -> "يدوي"
                            }
                            FilterChip(
                                selected = settings.autoRecordMode == mode,
                                onClick = { onUpdateSettings { it.copy(autoRecordMode = mode) } },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    Text(
                        text = "صيغة الصوت وجودة التسجيل (CD Quality):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AudioFormatOption.values().forEach { fmt ->
                            FilterChip(
                                selected = settings.selectedFormat == fmt,
                                onClick = { onUpdateSettings { it.copy(selectedFormat = fmt) } },
                                label = { Text(fmt.name, fontSize = 11.sp) }
                            )
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(64, 128, 256).forEach { bitrate ->
                            FilterChip(
                                selected = settings.selectedBitrateKbps == bitrate,
                                onClick = { onUpdateSettings { it.copy(selectedBitrateKbps = bitrate) } },
                                label = { Text("$bitrate kbps", fontSize = 11.sp) }
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    // MediaProjection & Accessibility Quick Action Triggers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("الطبقة الأولى (MediaProjection):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("تسجيل صوت الطرفين بجودة رقمية 44.1kHz", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = onRequestMediaProjection,
                            colors = ButtonDefaults.buttonColors(containerColor = TitanCyan, contentColor = Color.Black)
                        ) {
                            Text("منح الإذن", fontSize = 11.sp)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("الطبقة الثانية (ColorOS Accessibility):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("أتمتة زر التسجيل المدمج في واجهة هواتف أوبو", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = onOpenAccessibilitySettings,
                            colors = ButtonDefaults.buttonColors(containerColor = TitanBlue, contentColor = Color.White)
                        ) {
                            Text("تفعيل", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Section 2: Oppo ColorOS 13 & ADB Commands Optimization Guide
        item {
            SettingsCategoryHeader(title = "تجاوز إدارة البطارية في Oppo ColorOS 13 وأوامر ADB", icon = Icons.Default.Terminal)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TitanCyan.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "🚀 أوامر ADB للتشغيل الاحترافي الكامل:",
                        fontWeight = FontWeight.Bold,
                        color = TitanCyan,
                        fontSize = 14.sp
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.8f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = adbCommands,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFF00E676),
                            modifier = Modifier.padding(10.dp)
                        )
                    }

                    Button(
                        onClick = {
                            clipboardManager.setPrimaryClip(ClipData.newPlainText("ADB Commands", adbCommands))
                            Toast.makeText(context, "تم نسخ أوامر ADB إلى الحافظة بنجاح!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TitanCyan, contentColor = Color.Black)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("نسخ جميع أوامر ADB بنقرة واحدة")
                    }

                    Text(
                        text = "📋 خطوات تفعيل ColorOS 13 يدوياً من إعدادات الهاتف:\n" +
                                "1. افتح الإعدادات > البطارية > إعدادات متقدمة > تحسين استخدام البطارية > اختر التطبيق وضعه على 'عدم التحسين' (Don't optimize).\n" +
                                "2. افتح الإعدادات > إدارة التطبيقات > التشغيل التلقائي (Auto-launch) > فعّل Titan Dialer في الخلفية.\n" +
                                "3. قفل التطبيق في قائمة التطبيقات الأخيرة بالضغط على القفل (Lock).",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.85f),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Section 3: General App Settings (Biometric, DND, Notification, Themes)
        item {
            SettingsCategoryHeader(title = "الأمان والمظهر والتنبيهات", icon = Icons.Default.Security)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Biometric Lock
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("قفل التطبيق بالبصمة / PIN:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("حماية سجل المكالمات والتسجيلات", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.isBiometricLockEnabled,
                            onCheckedChange = { checked ->
                                onUpdateSettings { it.copy(isBiometricLockEnabled = checked) }
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    // DND During Call
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("وضع عدم الإزعاج أثناء المكالمة:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("كتم أصوات الإشعارات الأخرى تلقائياً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.isDndDuringCallEnabled,
                            onCheckedChange = { checked ->
                                onUpdateSettings { it.copy(isDndDuringCallEnabled = checked) }
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    // Persistent Notification
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("إشعار دائم مع أزرار التحكم بالمكالمة:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("التحكم بالتسجيل وإنهاء المكالمة من شريط الحالة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.isOngoingCallNotificationEnabled,
                            onCheckedChange = { checked ->
                                onUpdateSettings { it.copy(isOngoingCallNotificationEnabled = checked) }
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    // Theme selector
                    Text("المظهر والثيمات:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ThemeMode.values().forEach { theme ->
                            val label = when (theme) {
                                ThemeMode.COLOROS_GRADIENT -> "تدرج ColorOS"
                                ThemeMode.DARK_AMOLED -> "AMOLED داكن"
                                ThemeMode.LIGHT_LUXURY -> "فاخر فاتح"
                                ThemeMode.SYSTEM -> "تلقائي النظام"
                            }
                            FilterChip(
                                selected = settings.themeMode == theme,
                                onClick = { onUpdateSettings { it.copy(themeMode = theme) } },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsCategoryHeader(title: String, icon: ImageVector) {
    Row(
        modifier = Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = TitanCyan, modifier = Modifier.size(20.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TitanCyan
        )
    }
}
