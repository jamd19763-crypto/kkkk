package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActiveCallInfo
import com.example.data.model.CallState
import com.example.telecom.CallManager
import com.example.ui.theme.*
import com.example.utils.StorageHelper

@Composable
fun DynamicIslandOverlay(
    callInfo: ActiveCallInfo,
    onExpandClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCallActive = callInfo.state == CallState.ACTIVE ||
            callInfo.state == CallState.DIALING ||
            callInfo.state == CallState.RINGING

    AnimatedVisibility(
        visible = isCallActive,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
        modifier = modifier
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "island_glow")
        val glowAlpha by infiniteTransition.animateFloat(
            initialValue = 0.4f,
            targetValue = 0.9f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "glowAlpha"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color.Black.copy(alpha = 0.95f))
                    .border(
                        width = 1.2.dp,
                        brush = Brush.horizontalGradient(
                            listOf(
                                TitanCyan.copy(alpha = glowAlpha),
                                TitanBlue.copy(alpha = glowAlpha),
                                GradientEnd.copy(alpha = glowAlpha)
                            )
                        ),
                        shape = RoundedCornerShape(32.dp)
                    )
                    .clickable { onExpandClick() }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Left Icon: Active Call / Ringing
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (callInfo.state == CallState.RINGING) CallAmber.copy(alpha = 0.3f) else CallGreen.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Active Call",
                        tint = if (callInfo.state == CallState.RINGING) CallAmber else CallGreen,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Middle Info: Caller Name & Timer
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = callInfo.callerName.ifBlank { callInfo.phoneNumber },
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (callInfo.state == CallState.RINGING) "مكالمة واردة..." else StorageHelper.formatDuration(callInfo.callDurationSeconds),
                            color = TitanCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (callInfo.isRecording) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(CallRed)
                                )
                                Text(
                                    text = "REC 44.1k",
                                    color = CallRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                }

                // Right quick action: Hangup / Answer
                if (callInfo.state == CallState.RINGING) {
                    IconButton(
                        onClick = { CallManager.answer() },
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(CallGreen)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Answer",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                IconButton(
                    onClick = { CallManager.hangup() },
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(CallRed)
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "Hangup",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
