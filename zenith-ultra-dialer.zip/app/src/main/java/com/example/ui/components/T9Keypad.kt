package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TitanCyan

data class KeypadButtonData(
    val digit: String,
    val letters: String,
    val longPressValue: String? = null
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun T9Keypad(
    onDigitClick: (String) -> Unit,
    onLongPressDigit: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val keypadGrid = listOf(
        listOf(
            KeypadButtonData("1", "➿", "1"),
            KeypadButtonData("2", "ABC / أ ب ت", "2"),
            KeypadButtonData("3", "DEF / ث ج ح", "3")
        ),
        listOf(
            KeypadButtonData("4", "GHI / خ د ذ", "4"),
            KeypadButtonData("5", "JKL / ر ز س", "5"),
            KeypadButtonData("6", "MNO / ش ص ض", "6")
        ),
        listOf(
            KeypadButtonData("7", "PQRS / ط ظ ع", "7"),
            KeypadButtonData("8", "TUV / غ ف ق", "8"),
            KeypadButtonData("9", "WXYZ / ك ل م", "9")
        ),
        listOf(
            KeypadButtonData("*", "،"),
            KeypadButtonData("0", "+", "+"),
            KeypadButtonData("#", "⌗")
        )
    )

    val haptic = LocalHapticFeedback.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        keypadGrid.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row.forEach { keyData ->
                    KeypadButton(
                        data = keyData,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onDigitClick(keyData.digit)
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            if (keyData.longPressValue != null) {
                                onLongPressDigit(keyData.longPressValue)
                            } else {
                                onDigitClick(keyData.digit)
                            }
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun KeypadButton(
    data: KeypadButtonData,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = data.digit,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (data.letters.isNotEmpty()) {
                Text(
                    text = data.letters,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}
