package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContactEntity
import com.example.telecom.CallManager
import com.example.ui.components.T9Keypad
import com.example.ui.theme.*

@Composable
fun DialerScreen(
    contacts: List<ContactEntity>,
    onNavigateToInCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    var dialedNumber by remember { mutableStateOf("") }
    var isVoipEnabled by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    // Smart Match suggestions based on dialed number
    val suggestions = remember(dialedNumber, contacts) {
        if (dialedNumber.length >= 2) {
            contacts.filter { contact ->
                contact.phoneNumber.contains(dialedNumber) ||
                        contact.name.contains(dialedNumber, ignoreCase = true)
            }.take(5)
        } else {
            emptyList()
        }
    }

    // Smart Caller ID simulation for unknown numbers
    val smartCallerId = remember(dialedNumber) {
        when {
            dialedNumber.startsWith("800") -> "شركة معتمدة / رقم مجاني موثق"
            dialedNumber.startsWith("+966") && dialedNumber.length >= 8 -> "مكالمة ذكية موثوقة - المملكة العربية السعودية"
            dialedNumber.length >= 7 -> "Smart Caller ID: جهة اتصال محتملة"
            else -> null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Header: Voip Toggle & Smart ID
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isVoipEnabled) TitanCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clickable { isVoipEnabled = !isVoipEnabled }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isVoipEnabled) Icons.Default.VpnKey else Icons.Default.Phone,
                            contentDescription = "VoIP / SIP",
                            tint = if (isVoipEnabled) TitanCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (isVoipEnabled) "VoIP / SIP مفعّل" else "شبكة الخلوي (GSM)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isVoipEnabled) TitanCyan else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = TitanBlue.copy(alpha = 0.15f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Smart Call",
                            tint = TitanBlue,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Smart Call Active",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TitanBlue
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Dialed Number Display
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = dialedNumber.ifEmpty { "أدخل الرقم..." },
                    fontSize = if (dialedNumber.length > 12) 26.sp else 34.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (dialedNumber.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )

                if (dialedNumber.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            dialedNumber = dialedNumber.dropLast(1)
                        },
                        modifier = Modifier.size(42.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Backspace,
                            contentDescription = "Backspace",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Smart Caller ID Badge
            AnimatedVisibility(visible = smartCallerId != null && dialedNumber.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CallGreen.copy(alpha = 0.12f),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = smartCallerId ?: "",
                        fontSize = 12.sp,
                        color = CallGreen,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }

            // Smart suggestions list
            AnimatedVisibility(visible = suggestions.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(suggestions) { contact ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                            modifier = Modifier.clickable {
                                dialedNumber = contact.phoneNumber
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(TitanCyan.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = contact.name.take(1),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TitanCyan
                                    )
                                }
                                Column {
                                    Text(
                                        text = contact.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = contact.phoneNumber,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // T9 Keypad
        T9Keypad(
            onDigitClick = { digit -> dialedNumber += digit },
            onLongPressDigit = { value -> dialedNumber += value },
            modifier = Modifier.padding(vertical = 4.dp)
        )

        // Action Buttons: Voice Call, Video Call, Simulation trigger
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Video Call Button
            Surface(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .clickable {
                        if (dialedNumber.isNotBlank()) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            CallManager.startOutgoingCall(context, dialedNumber, isVideo = true)
                            onNavigateToInCall()
                        }
                    },
                shape = CircleShape,
                color = TitanBlue.copy(alpha = 0.25f),
                tonalElevation = 4.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Video Call",
                        tint = TitanCyan,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            // Voice Call Main Glowing Button
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .shadow(16.dp, CircleShape, spotColor = CallGreen)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.linearGradient(
                            listOf(CallGreen, Color(0xFF00C853), Color(0xFF00B0FF))
                        )
                    )
                    .clickable {
                        if (dialedNumber.isNotBlank()) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            CallManager.startOutgoingCall(context, dialedNumber, isVideo = false)
                            onNavigateToInCall()
                        } else {
                            // Dial last called number or simulate
                            dialedNumber = "+966501234567"
                        }
                    }
                    .testTag("dialer_call_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Start Voice Call",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }

            // Quick Call Simulation (for testing on non-SIM emulator)
            Surface(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        val phone = if (dialedNumber.isNotBlank()) dialedNumber else "+966501234567"
                        val name = contacts.find { it.phoneNumber == phone }?.name ?: "سارة أحمد (Oppo Tech)"
                        CallManager.simulateCall(phone, name, isIncoming = false)
                        onNavigateToInCall()
                    },
                shape = CircleShape,
                color = GradientEnd.copy(alpha = 0.25f),
                tonalElevation = 4.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Simulate In-Call UI",
                        tint = GradientEnd,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }
}
