package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.telecom.CallManager
import com.example.ui.components.DynamicIslandOverlay
import com.example.ui.components.FloatingDialButton
import com.example.ui.components.SmartSearchBar
import com.example.ui.theme.*
import com.example.utils.StorageHelper

enum class HomeTab(val title: String, val icon: ImageVector) {
    FAVORITES("المفضلة", Icons.Default.Star),
    RECENTS("الأخيرة", Icons.Default.History),
    CONTACTS("جهات الاتصال", Icons.Default.People),
    MESSAGES("الرسائل", Icons.Default.Chat)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    contacts: List<ContactEntity>,
    callLogs: List<CallLogEntity>,
    messages: List<MessageEntity>,
    recordings: List<RecordingEntity>,
    settings: DialerSettings,
    activeCallInfo: ActiveCallInfo,
    onOpenDialer: () -> Unit,
    onOpenInCallScreen: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenRecordings: () -> Unit,
    onAddContact: (ContactEntity) -> Unit,
    onDeleteContact: (Long) -> Unit,
    onToggleContactFavorite: (Long, Boolean) -> Unit,
    onSendMessage: (String, String, Long?) -> Unit,
    onDeleteMessage: (Long) -> Unit,
    onStartCall: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(HomeTab.RECENTS) }
    var searchQuery by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Filter results across contacts, call logs, and messages
    val filteredContacts = remember(contacts, searchQuery) {
        if (searchQuery.isBlank()) contacts
        else contacts.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.phoneNumber.contains(searchQuery) ||
                    (it.company?.contains(searchQuery, ignoreCase = true) == true)
        }
    }

    val filteredCallLogs = remember(callLogs, searchQuery) {
        if (searchQuery.isBlank()) callLogs
        else callLogs.filter {
            (it.callerName?.contains(searchQuery, ignoreCase = true) == true) ||
                    it.phoneNumber.contains(searchQuery)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // iPhone-style Dynamic Island live banner
                DynamicIslandOverlay(
                    callInfo = activeCallInfo,
                    onExpandClick = onOpenInCallScreen
                )

                // App Title & Quick Top Actions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.linearGradient(
                                        listOf(TitanCyan, TitanBlue, GradientEnd)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneInTalk,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "Titan Dialer",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Recordings Vault Button
                        IconButton(
                            onClick = onOpenRecordings,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Recordings Vault",
                                tint = TitanCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Settings Button
                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Smart Unified Search Bar
                SmartSearchBar(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "بحث في جهات الاتصال، المكالمات، الرسائل..."
                )
            }
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("home_bottom_navigation"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                HomeTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(imageVector = tab.icon, contentDescription = tab.title)
                        },
                        label = {
                            Text(text = tab.title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            indicatorColor = TitanCyan
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingDialButton(onClick = onOpenDialer)
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                HomeTab.FAVORITES -> {
                    val favorites = filteredContacts.filter { it.isFavorite }
                    FavoritesTabContent(
                        favorites = favorites,
                        onCall = onStartCall,
                        onSms = { selectedTab = HomeTab.MESSAGES }
                    )
                }
                HomeTab.RECENTS -> {
                    RecentsTabContent(
                        callLogs = filteredCallLogs,
                        recordings = recordings,
                        onCall = onStartCall
                    )
                }
                HomeTab.CONTACTS -> {
                    ContactsScreen(
                        contacts = filteredContacts,
                        onAddContact = onAddContact,
                        onDeleteContact = onDeleteContact,
                        onToggleFavorite = onToggleContactFavorite,
                        onStartCall = onStartCall,
                        onSendMessage = { phone ->
                            selectedTab = HomeTab.MESSAGES
                        }
                    )
                }
                HomeTab.MESSAGES -> {
                    MessagesScreen(
                        messages = messages,
                        onSendMessage = onSendMessage,
                        onDeleteMessage = onDeleteMessage
                    )
                }
            }
        }
    }
}

@Composable
fun FavoritesTabContent(
    favorites: List<ContactEntity>,
    onCall: (String) -> Unit,
    onSms: (String) -> Unit
) {
    if (favorites.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 80.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.StarOutline, contentDescription = null, tint = TitanCyan, modifier = Modifier.size(48.dp))
                Text("لا توجد جهات اتصال مفضلة حالياً", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("قم بتمييز جهات الاتصال بنجمة لتظهر هنا فوراً", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(favorites, key = { it.id }) { contact ->
                ContactCardItem(
                    contact = contact,
                    onCardClick = { onCall(contact.phoneNumber) },
                    onCallClick = { onCall(contact.phoneNumber) },
                    onSmsClick = { onSms(contact.phoneNumber) },
                    onToggleFavorite = {}
                )
            }
        }
    }
}

@Composable
fun RecentsTabContent(
    callLogs: List<CallLogEntity>,
    recordings: List<RecordingEntity>,
    onCall: (String) -> Unit
) {
    if (callLogs.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 80.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Text("لا توجد مكالمات حديثة", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(callLogs, key = { it.id }) { log ->
                val hasRecording = recordings.any { it.phoneNumber == log.phoneNumber }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onCall(log.phoneNumber) },
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Call Type Icon
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (log.callType) {
                                            CallType.INCOMING -> CallGreen.copy(alpha = 0.2f)
                                            CallType.OUTGOING -> TitanCyan.copy(alpha = 0.2f)
                                            CallType.MISSED -> CallRed.copy(alpha = 0.2f)
                                            CallType.REJECTED -> CallRed.copy(alpha = 0.2f)
                                            CallType.VOICEMAIL -> TitanBlue.copy(alpha = 0.2f)
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (log.callType) {
                                        CallType.INCOMING -> Icons.Default.CallReceived
                                        CallType.OUTGOING -> Icons.Default.CallMade
                                        CallType.MISSED -> Icons.Default.CallMissed
                                        CallType.REJECTED -> Icons.Default.PhoneDisabled
                                        CallType.VOICEMAIL -> Icons.Default.Voicemail
                                    },
                                    contentDescription = log.callType.name,
                                    tint = when (log.callType) {
                                        CallType.INCOMING -> CallGreen
                                        CallType.OUTGOING -> TitanCyan
                                        CallType.MISSED -> CallRed
                                        CallType.REJECTED -> CallRed
                                        CallType.VOICEMAIL -> TitanBlue
                                    },
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = log.callerName ?: log.phoneNumber,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (log.callType == CallType.MISSED) CallRed else MaterialTheme.colorScheme.onSurface
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = StorageHelper.formatTimestamp(log.timestamp),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (log.durationSeconds > 0) {
                                        Text(
                                            text = "• ${StorageHelper.formatDuration(log.durationSeconds)}",
                                            fontSize = 11.sp,
                                            color = TitanCyan
                                        )
                                    }
                                }
                            }
                        }

                        // Has Recording Badge & Quick Call Button
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (hasRecording) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = CallRed.copy(alpha = 0.15f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Mic,
                                            contentDescription = "Recorded",
                                            tint = CallRed,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = "44.1k",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CallRed
                                        )
                                    }
                                }
                            }

                            IconButton(
                                onClick = { onCall(log.phoneNumber) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(TitanCyan.copy(alpha = 0.2f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Call,
                                    contentDescription = "Call",
                                    tint = TitanCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
