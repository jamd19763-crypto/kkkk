package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActiveCallInfo
import com.example.data.model.CallState
import com.example.data.model.TranscriptEntry
import com.example.telecom.CallManager
import com.example.ui.components.T9Keypad
import com.example.ui.theme.*
import com.example.utils.LiveWaveformVisualizer
import com.example.utils.StorageHelper
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InCallScreen(
    callInfo: ActiveCallInfo,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    var isKeypadVisible by remember { mutableStateOf(false) }
    var isLiveCaptionVisible by remember { mutableStateOf(true) }
    val transcriptListState = rememberLazyListState()

    val smartReplies = listOf(
        "سأتصل بك لاحقاً 📞",
        "أنا في الطريق الآن 🚗",
        "أنا في اجتماع مهم 💼",
        "أرسل لي رسالة نصية 💬",
        "شكراً، سأعاود الاتصال بك لاحقاً"
    )

    // Auto-scroll transcripts when new lines arrive
    LaunchedEffect(callInfo.liveTranscriptList.size) {
        if (callInfo.liveTranscriptList.isNotEmpty()) {
            transcriptListState.animateScrollToItem(callInfo.liveTranscriptList.size - 1)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060A12))
    ) {
        // Blurred Glassmorphism Ambient Glow Backdrop
        Box(
            modifier = Modifier
                .fillMaxSize()
                .blur(80.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 40.dp)
                    .clip(CircleShape)
                    .background(TitanCyan.copy(alpha = 0.25f))
            )
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(TitanBlue.copy(alpha = 0.2f))
            )
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .align(Alignment.BottomCenter)
                    .offset(y = (-40).dp)
                    .clip(CircleShape)
                    .background(GradientEnd.copy(alpha = 0.18f))
            )
        }

        // Main In-Call Content Layout
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Back & Live Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Minimize Call",
                        tint = Color.White
                    )
                }

                // HD Audio & Security Badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.6f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TitanCyan.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (callInfo.state == CallState.ACTIVE) CallGreen else CallAmber)
                        )
                        Text(
                            text = "HD Voice • مشفرة 256-bit",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Live Captions Toggle Button
                IconButton(
                    onClick = {
                        isLiveCaptionVisible = !isLiveCaptionVisible
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (isLiveCaptionVisible) TitanCyan.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f))
                ) {
                    Icon(
                        imageVector = Icons.Default.ClosedCaption,
                        contentDescription = "Live Captions",
                        tint = if (isLiveCaptionVisible) TitanCyan else Color.White
                    )
                }
            }

            // Caller Avatar & Profile Info
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Gradient Glowing Avatar
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .shadow(20.dp, CircleShape, spotColor = TitanCyan)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                listOf(TitanCyan, TitanBlue, GradientEnd)
                            )
                        )
                        .border(3.dp, Color.White.copy(alpha = 0.3f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = callInfo.callerName.take(1).ifEmpty { "📞" },
                        fontSize = 42.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }

                Text(
                    text = callInfo.callerName.ifEmpty { callInfo.phoneNumber },
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = callInfo.phoneNumber,
                    fontSize = 15.sp,
                    color = Color.White.copy(alpha = 0.7f)
                )

                // Call State / Timer
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = when (callInfo.state) {
                            CallState.RINGING -> "مكالمة واردة..."
                            CallState.DIALING -> "جاري الاتصال..."
                            CallState.CONNECTING -> "جاري التوصيل..."
                            CallState.ACTIVE -> StorageHelper.formatDuration(callInfo.callDurationSeconds)
                            CallState.HOLDING -> "المكالمة قيد الانتظار"
                            CallState.DISCONNECTED -> "انتهت المكالمة"
                            else -> "متصل"
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (callInfo.state == CallState.ACTIVE) TitanCyan else Color.White,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }

            // Real-Time Waveform & CD Quality Recording Status
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.Black.copy(alpha = 0.45f))
                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Waveform",
                            tint = TitanCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (callInfo.isRecording) "تسجيل ستيريو 44.1kHz • ${StorageHelper.formatDuration(callInfo.recordingDurationSeconds)}" else "طيف الصوت الصادر والوارد",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (callInfo.isRecording) CallRed else TitanCyan
                        )
                    }

                    if (callInfo.isRecording) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CallRed.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "128kbps MP3",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CallRed,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Animated Live Audio Waveform Canvas
                LiveWaveformVisualizer(
                    amplitudes = callInfo.audioWaveformAmplitudes,
                    isRecording = callInfo.isRecording,
                    height = 38.dp,
                    barColor = if (callInfo.isRecording) CallRed else TitanCyan,
                    accentColor = TitanBlue
                )
            }

            // Live Caption (Speech-To-Text Stream)
            AnimatedVisibility(
                visible = isLiveCaptionVisible,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 110.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color.Black.copy(alpha = 0.6f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TitanCyan.copy(alpha = 0.2f))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Live Captions",
                                tint = TitanCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "تحويل الصوت إلى نص لحظياً (Live Caption)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TitanCyan
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        LazyColumn(
                            state = transcriptListState,
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (callInfo.liveTranscriptList.isEmpty()) {
                                item {
                                    Text(
                                        text = "جاري الاستماع وترجمة الكلمات على الشاشة لحظياً...",
                                        fontSize = 11.sp,
                                        color = Color.White.copy(alpha = 0.5f),
                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                    )
                                }
                            } else {
                                items(callInfo.liveTranscriptList) { entry ->
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Text(
                                            text = "${entry.speaker}:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (entry.isIncomingSpeaker) CallAmber else TitanCyan
                                        )
                                        Text(
                                            text = entry.text,
                                            fontSize = 11.sp,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Smart Quick Replies Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(smartReplies) { reply ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.12f),
                        modifier = Modifier.clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            CallManager.addLiveTranscript(
                                TranscriptEntry("أنت (رد سريع)", reply, System.currentTimeMillis())
                            )
                            Toast.makeText(context, "تم إرسال الرد: $reply", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text(
                            text = reply,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // In-Call Action Controls Grid (Mute, Speaker, 3-State Record, Keypad, Hold, Add Call)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    InCallActionButton(
                        icon = if (callInfo.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        label = if (callInfo.isMuted) "مكتوم" else "كتم",
                        isActive = callInfo.isMuted,
                        activeColor = CallRed,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            CallManager.toggleMute()
                        }
                    )

                    InCallActionButton(
                        icon = if (callInfo.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                        label = if (callInfo.isSpeakerOn) "مكبر الصوت" else "السماعة",
                        isActive = callInfo.isSpeakerOn,
                        activeColor = TitanCyan,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            CallManager.toggleSpeaker()
                        }
                    )

                    // 3-State Record Button (44.1kHz Dual Recording)
                    InCallActionButton(
                        icon = if (callInfo.isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                        label = if (callInfo.isRecording) "إيقاف التسجيل" else "تسجيل 44.1k",
                        isActive = callInfo.isRecording,
                        activeColor = CallRed,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            CallManager.toggleRecording(context)
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    InCallActionButton(
                        icon = Icons.Default.Dialpad,
                        label = "لوحة الأرقام",
                        isActive = isKeypadVisible,
                        activeColor = TitanBlue,
                        onClick = { isKeypadVisible = !isKeypadVisible }
                    )

                    InCallActionButton(
                        icon = if (callInfo.isHold) Icons.Default.PlayArrow else Icons.Default.Pause,
                        label = if (callInfo.isHold) "استئناف" else "انتظار",
                        isActive = callInfo.isHold,
                        activeColor = CallAmber,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            CallManager.toggleHold()
                        }
                    )

                    InCallActionButton(
                        icon = Icons.Default.GroupAdd,
                        label = "مؤتمر",
                        isActive = false,
                        onClick = {
                            Toast.makeText(context, "ميزة إضافة مكالمة ومؤتمر جماعي", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // Bottom Actions: Answer (if ringing) or Big End Call Button
            if (callInfo.state == CallState.RINGING) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Answer Button
                    Surface(
                        modifier = Modifier
                            .size(72.dp)
                            .shadow(16.dp, CircleShape, spotColor = CallGreen)
                            .clip(CircleShape)
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                CallManager.answer()
                            },
                        color = CallGreen,
                        shape = CircleShape
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "Answer Call",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    // Hangup Button
                    Surface(
                        modifier = Modifier
                            .size(72.dp)
                            .shadow(16.dp, CircleShape, spotColor = CallRed)
                            .clip(CircleShape)
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                CallManager.hangup()
                                onClose()
                            },
                        color = CallRed,
                        shape = CircleShape
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.CallEnd,
                                contentDescription = "Decline Call",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }
            } else {
                // Active Call: Big Glowing End Call Button
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .shadow(20.dp, CircleShape, spotColor = CallRed)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                listOf(CallRed, Color(0xFFD50000), Color(0xFFFF5252))
                            )
                        )
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            CallManager.hangup()
                            onClose()
                        }
                        .testTag("incall_end_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }
        }

        // Keypad Bottom Sheet / Modal Drawer
        if (isKeypadVisible) {
            ModalBottomSheet(
                onDismissRequest = { isKeypadVisible = false },
                containerColor = Color(0xFF0F172A),
                scrimColor = Color.Black.copy(alpha = 0.7f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "نغمات DTMF للأرقام",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    T9Keypad(
                        onDigitClick = { digit ->
                            if (digit.isNotEmpty()) {
                                CallManager.sendDtmf(digit[0])
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun InCallActionButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    activeColor: Color = TitanCyan,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Surface(
            modifier = Modifier
                .size(62.dp)
                .clip(CircleShape)
                .clickable { onClick() },
            shape = CircleShape,
            color = if (isActive) activeColor else Color.White.copy(alpha = 0.12f),
            tonalElevation = if (isActive) 6.dp else 0.dp
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isActive) Color.Black else Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White.copy(alpha = 0.85f)
        )
    }
}
