package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.CallState
import com.example.data.model.ContactEntity
import com.example.recording.RecordingManager
import com.example.telecom.CallManager
import com.example.ui.screens.*
import com.example.ui.theme.TitanDialerTheme
import com.example.utils.PermissionHelper
import com.example.viewmodel.MainViewModel

enum class ScreenState {
    HOME,
    DIALER,
    IN_CALL,
    RECORDINGS_VAULT,
    SETTINGS
}

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: MainViewModel = viewModel()
            val contacts by viewModel.contacts.collectAsStateWithLifecycle()
            val callLogs by viewModel.callLogs.collectAsStateWithLifecycle()
            val messages by viewModel.messages.collectAsStateWithLifecycle()
            val recordings by viewModel.recordings.collectAsStateWithLifecycle()
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val activeCallInfo by viewModel.activeCallInfo.collectAsStateWithLifecycle()

            var currentScreen by remember { mutableStateOf(ScreenState.HOME) }
            var isBiometricAuthenticated by remember { mutableStateOf(!settings.isBiometricLockEnabled) }

            // MediaProjection Launcher for Layer 1 Call Recording
            val mediaProjectionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                    RecordingManager.projectionResultCode = result.resultCode
                    RecordingManager.projectionResultData = result.data
                    Toast.makeText(this, "تم منح إذن التقاط الصوت الداخلي بنجاح (Layer 1 Active)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "لم يتم منح إذن التقاط الشاشة، سيتم استخدام الميكروفون المباشر", Toast.LENGTH_SHORT).show()
                }
            }

            // Runtime Permissions Request Launcher
            val permissionsLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { perms ->
                val allGranted = perms.values.all { it }
                if (allGranted) {
                    Toast.makeText(this, "تم منح كافة الأذونات المطلوبة لتشغيل الهاتف والتسجيل", Toast.LENGTH_SHORT).show()
                }
            }

            // Request necessary permissions on start
            LaunchedEffect(Unit) {
                val permissions = mutableListOf(
                    android.Manifest.permission.RECORD_AUDIO,
                    android.Manifest.permission.READ_PHONE_STATE,
                    android.Manifest.permission.READ_CONTACTS,
                    android.Manifest.permission.WRITE_CONTACTS,
                    android.Manifest.permission.CALL_PHONE,
                    android.Manifest.permission.READ_CALL_LOG,
                    android.Manifest.permission.WRITE_CALL_LOG,
                    android.Manifest.permission.SEND_SMS,
                    android.Manifest.permission.READ_SMS,
                    android.Manifest.permission.RECEIVE_SMS
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    permissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
                }
                permissionsLauncher.launch(permissions.toTypedArray())

                if (!PermissionHelper.isDefaultDialer(this@MainActivity)) {
                    PermissionHelper.requestDefaultDialer(this@MainActivity, 1001)
                }
            }

            // Automatically transition to In-Call Screen when incoming or active call occurs
            LaunchedEffect(activeCallInfo.state) {
                if (activeCallInfo.state == CallState.RINGING ||
                    activeCallInfo.state == CallState.ACTIVE ||
                    activeCallInfo.state == CallState.DIALING
                ) {
                    currentScreen = ScreenState.IN_CALL
                } else if (activeCallInfo.state == CallState.DISCONNECTED && currentScreen == ScreenState.IN_CALL) {
                    // Small delay before returning home after disconnect
                    kotlinx.coroutines.delay(1200)
                    currentScreen = ScreenState.HOME
                }
            }

            TitanDialerTheme(themeMode = settings.themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn() togetherWith fadeOut()
                        },
                        label = "ScreenNavigation"
                    ) { screen ->
                        when (screen) {
                            ScreenState.HOME -> {
                                HomeScreen(
                                    contacts = contacts,
                                    callLogs = callLogs,
                                    messages = messages,
                                    recordings = recordings,
                                    settings = settings,
                                    activeCallInfo = activeCallInfo,
                                    onOpenDialer = { currentScreen = ScreenState.DIALER },
                                    onOpenInCallScreen = { currentScreen = ScreenState.IN_CALL },
                                    onOpenSettings = { currentScreen = ScreenState.SETTINGS },
                                    onOpenRecordings = { currentScreen = ScreenState.RECORDINGS_VAULT },
                                    onAddContact = { viewModel.addContact(it) },
                                    onDeleteContact = { viewModel.deleteContact(it) },
                                    onToggleContactFavorite = { id, fav -> viewModel.toggleContactFavorite(id, fav) },
                                    onSendMessage = { phone, text, time -> viewModel.sendMessage(phone, text, time) },
                                    onDeleteMessage = { viewModel.deleteMessage(it) },
                                    onStartCall = { phone ->
                                        val contactName = contacts.find { it.phoneNumber == phone }?.name ?: phone
                                        CallManager.startOutgoingCall(this@MainActivity, phone, false)
                                        CallManager.simulateCall(phone, contactName, false)
                                        currentScreen = ScreenState.IN_CALL
                                    }
                                )
                            }
                            ScreenState.DIALER -> {
                                DialerScreen(
                                    contacts = contacts,
                                    onNavigateToInCall = { currentScreen = ScreenState.IN_CALL }
                                )
                            }
                            ScreenState.IN_CALL -> {
                                InCallScreen(
                                    callInfo = activeCallInfo,
                                    onClose = { currentScreen = ScreenState.HOME }
                                )
                            }
                            ScreenState.RECORDINGS_VAULT -> {
                                RecordingsVaultScreen(
                                    recordings = recordings,
                                    onDeleteRecording = { viewModel.deleteRecording(it) },
                                    onBack = { currentScreen = ScreenState.HOME }
                                )
                            }
                            ScreenState.SETTINGS -> {
                                SettingsScreen(
                                    settings = settings,
                                    onUpdateSettings = { viewModel.updateSettings(it) },
                                    onOpenAccessibilitySettings = {
                                        PermissionHelper.openAccessibilitySettings(this@MainActivity)
                                    },
                                    onRequestMediaProjection = {
                                        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
                                        projectionManager?.let {
                                            mediaProjectionLauncher.launch(it.createScreenCaptureIntent())
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
