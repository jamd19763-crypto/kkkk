package com.example.recording

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.example.data.db.AppDatabase
import com.example.data.model.RecordingEntity
import com.example.data.model.RecordingLayer
import com.example.telecom.CallManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.lang.reflect.Field
import java.text.SimpleDateFormat
import java.util.*

object RecordingManager {
    private const val TAG = "RecordingManager"

    var projectionResultCode: Int = Activity.RESULT_CANCELED
    var projectionResultData: Intent? = null

    private val _isRecordingActive = MutableStateFlow(false)
    val isRecordingActive = _isRecordingActive.asStateFlow()

    private val _recentAmplitudes = MutableStateFlow<List<Float>>(emptyList())
    val recentAmplitudes = _recentAmplitudes.asStateFlow()

    private val amplitudeBuffer = LinkedList<Float>()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun updateAmplitude(amplitude: Float) {
        synchronized(amplitudeBuffer) {
            if (amplitudeBuffer.size >= 40) {
                amplitudeBuffer.removeFirst()
            }
            amplitudeBuffer.add(amplitude)
            val list = amplitudeBuffer.toList()
            _recentAmplitudes.value = list
            CallManager.updateWaveform(list)
        }
    }

    fun startRecording(context: Context, phoneNumber: String, callerName: String) {
        val appContext = context.applicationContext
        _isRecordingActive.value = true

        if (projectionResultData != null && projectionResultCode == Activity.RESULT_OK) {
            Log.d(TAG, "Starting Layer 1: MediaProjection + AudioPlaybackCapture")
            val serviceIntent = Intent(appContext, AudioCaptureService::class.java).apply {
                action = AudioCaptureService.ACTION_START_PROJECTION_RECORDING
                putExtra(AudioCaptureService.EXTRA_RESULT_CODE, projectionResultCode)
                putExtra(AudioCaptureService.EXTRA_RESULT_DATA, projectionResultData)
                putExtra(AudioCaptureService.EXTRA_PHONE_NUMBER, phoneNumber)
                putExtra(AudioCaptureService.EXTRA_CALLER_NAME, callerName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(serviceIntent)
            } else {
                appContext.startService(serviceIntent)
            }
            return
        }

        val rootSuccess = attemptRootVoiceCallRecording(appContext, phoneNumber, callerName)
        if (!rootSuccess) {
            Log.d(TAG, "Starting Mic fallback recording")
            val serviceIntent = Intent(appContext, AudioCaptureService::class.java).apply {
                action = AudioCaptureService.ACTION_START_PROJECTION_RECORDING
                putExtra(AudioCaptureService.EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                putExtra(AudioCaptureService.EXTRA_PHONE_NUMBER, phoneNumber)
                putExtra(AudioCaptureService.EXTRA_CALLER_NAME, callerName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(serviceIntent)
            } else {
                appContext.startService(serviceIntent)
            }
        }
    }

    fun stopRecording(context: Context) {
        val appContext = context.applicationContext
        _isRecordingActive.value = false
        val serviceIntent = Intent(appContext, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP_PROJECTION_RECORDING
        }
        appContext.startService(serviceIntent)
    }

    fun attemptRootVoiceCallRecording(context: Context, phoneNumber: String, callerName: String): Boolean {
        return try {
            val isRooted = executeShellCommand("su -c 'chmod 666 /dev/snd/*'")
            if (!isRooted) return false

            val voiceCallSource = getVoiceCallAudioSource()
            val sampleRate = 44100
            val channelConfig = AudioFormat.CHANNEL_IN_STEREO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(4096)

            val audioRecord = AudioRecord(
                voiceCallSource,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            if (audioRecord.state == AudioRecord.STATE_INITIALIZED) {
                audioRecord.startRecording()
                Log.d(TAG, "Layer 3 Success: Root AudioSource.VOICE_CALL initialized!")
                val file = createRecordingFile(context, phoneNumber, "WAV")
                scope.launch {
                    val fos = FileOutputStream(file)
                    val buffer = ShortArray(bufferSize / 2)
                    val byteBuffer = java.nio.ByteBuffer.allocate(bufferSize).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    var totalBytes = 0L
                    val startTime = System.currentTimeMillis()
                    fos.write(ByteArray(44))

                    while (_isRecordingActive.value) {
                        val read = audioRecord.read(buffer, 0, buffer.size)
                        if (read > 0) {
                            byteBuffer.clear()
                            for (i in 0 until read) {
                                byteBuffer.putShort(buffer[i])
                            }
                            fos.write(byteBuffer.array(), 0, read * 2)
                            totalBytes += read * 2
                            updateAmplitude(0.45f)
                        }
                    }
                    writeWavHeader(fos, totalBytes, sampleRate, 2, 16)
                    fos.flush()
                    fos.close()
                    audioRecord.stop()
                    audioRecord.release()

                    val duration = ((System.currentTimeMillis() - startTime) / 1000).coerceAtLeast(1)
                    saveRecordingToDatabase(context, file, phoneNumber, callerName, duration, RecordingLayer.ROOT_REFLECTION)
                }
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Layer 3 root reflection failed: ${e.message}")
            false
        }
    }

    private fun getVoiceCallAudioSource(): Int {
        return try {
            val field: Field = MediaRecorder.AudioSource::class.java.getField("VOICE_CALL")
            field.getInt(null)
        } catch (e: Exception) {
            MediaRecorder.AudioSource.MIC
        }
    }

    private fun executeShellCommand(cmd: String): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val exitCode = process.waitFor()
            exitCode == 0
        } catch (e: Exception) {
            false
        }
    }

    fun createRecordingFile(context: Context, phoneNumber: String, format: String): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val cleanNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
        val fileName = "TitanCall_${cleanNumber}_$timeStamp.${format.lowercase()}"

        val storageDir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
        if (!storageDir.exists()) {
            storageDir.mkdirs()
        }
        return File(storageDir, fileName)
    }

    suspend fun saveRecordingToDatabase(
        context: Context,
        file: File,
        phoneNumber: String,
        callerName: String,
        durationSeconds: Long,
        layer: RecordingLayer
    ) {
        try {
            val db = AppDatabase.getInstance(context)
            val recording = RecordingEntity(
                phoneNumber = phoneNumber,
                callerName = callerName,
                filePath = file.absolutePath,
                fileName = file.name,
                durationSeconds = durationSeconds,
                fileSizeBytes = file.length(),
                timestamp = System.currentTimeMillis(),
                audioFormat = file.extension.uppercase(),
                sampleRate = 44100,
                bitRateKbps = 128,
                layerUsed = layer
            )
            db.recordingDao().insertRecording(recording)

            saveToMediaStore(context, file, phoneNumber)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun saveToMediaStore(context: Context, file: File, phoneNumber: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_RECORDINGS + "/TitanDialer")
                put(MediaStore.Audio.Media.IS_PENDING, 0)
            }
            try {
                context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun writeWavHeader(
        out: FileOutputStream,
        totalAudioLen: Long,
        longSampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        val totalDataLen = totalAudioLen + 36
        val byteRate = (bitsPerSample * longSampleRate * channels / 8).toLong()
        val header = ByteArray(44)

        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = (totalDataLen shr 8 and 0xff).toByte()
        header[6] = (totalDataLen shr 16 and 0xff).toByte()
        header[7] = (totalDataLen shr 24 and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (longSampleRate and 0xff).toByte()
        header[25] = (longSampleRate shr 8 and 0xff).toByte()
        header[26] = (longSampleRate shr 16 and 0xff).toByte()
        header[27] = (longSampleRate shr 24 and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = (byteRate shr 8 and 0xff).toByte()
        header[30] = (byteRate shr 16 and 0xff).toByte()
        header[31] = (byteRate shr 24 and 0xff).toByte()
        header[32] = (channels * bitsPerSample / 8).toByte()
        header[33] = 0
        header[34] = bitsPerSample.toByte()
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xff).toByte()
        header[41] = (totalAudioLen shr 8 and 0xff).toByte()
        header[42] = (totalAudioLen shr 16 and 0xff).toByte()
        header[43] = (totalAudioLen shr 24 and 0xff).toByte()

        try {
            out.write(header, 0, 44)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
