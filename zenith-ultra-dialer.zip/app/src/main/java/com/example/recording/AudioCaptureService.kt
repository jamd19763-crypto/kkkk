package com.example.recording

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.model.RecordingLayer
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START_PROJECTION_RECORDING = "com.example.START_PROJECTION_RECORDING"
        const val ACTION_STOP_PROJECTION_RECORDING = "com.example.STOP_PROJECTION_RECORDING"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
        const val EXTRA_PHONE_NUMBER = "EXTRA_PHONE_NUMBER"
        const val EXTRA_CALLER_NAME = "EXTRA_CALLER_NAME"
        const val CHANNEL_ID = "titan_recording_channel"
        const val NOTIFICATION_ID = 2002

        var isServiceRunning = false
            private set
    }

    private var mediaProjection: MediaProjection? = null
    private var playbackAudioRecord: AudioRecord? = null
    private var micAudioRecord: AudioRecord? = null
    private var recordingJob: Job? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val sampleRate = 44100 // CD Quality 44.1kHz
    private val channelConfig = AudioFormat.CHANNEL_IN_STEREO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(4096)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_PROJECTION_RECORDING -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                val phoneNumber = intent.getStringExtra(EXTRA_PHONE_NUMBER) ?: "Unknown"
                val callerName = intent.getStringExtra(EXTRA_CALLER_NAME) ?: phoneNumber

                startForegroundServiceWithNotification(phoneNumber)

                if (resultData != null && resultCode == Activity.RESULT_OK) {
                    startAudioCapture(resultCode, resultData, phoneNumber, callerName)
                }
            }
            ACTION_STOP_PROJECTION_RECORDING -> {
                stopAudioCapture()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundServiceWithNotification(phoneNumber: String) {
        isServiceRunning = true
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Titan Call Recorder 44.1kHz")
            .setContentText("تسجيل صوتي ثنائي الاتجاه عالي الدقة: $phoneNumber")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            }
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startAudioCapture(resultCode: Int, resultData: Intent, phoneNumber: String, callerName: String) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mediaProjection != null) {
            try {
                // Layer 1: AudioPlaybackCaptureConfiguration to record remote caller audio
                val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection!!)
                    .addMatchingUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()

                val audioPlaybackFormat = AudioFormat.Builder()
                    .setEncoding(audioFormat)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelConfig)
                    .build()

                playbackAudioRecord = AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(config)
                    .setAudioFormat(audioPlaybackFormat)
                    .setBufferSizeInBytes(bufferSize)
                    .build()

                // Capture local user microphone audio
                micAudioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize
                )

                playbackAudioRecord?.startRecording()
                micAudioRecord?.startRecording()

                val outputFile = RecordingManager.createRecordingFile(this, phoneNumber, "MP3")
                startDualMixingLoop(outputFile, phoneNumber, callerName)

            } catch (e: Exception) {
                e.printStackTrace()
                // Fallback to standard MIC recording
                fallbackMicCapture(phoneNumber, callerName)
            }
        } else {
            fallbackMicCapture(phoneNumber, callerName)
        }
    }

    private fun fallbackMicCapture(phoneNumber: String, callerName: String) {
        try {
            micAudioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )
            micAudioRecord?.startRecording()
            val outputFile = RecordingManager.createRecordingFile(this, phoneNumber, "WAV")
            startSingleRecordingLoop(outputFile, phoneNumber, callerName)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startDualMixingLoop(outputFile: File, phoneNumber: String, callerName: String) {
        recordingJob?.cancel()
        recordingJob = serviceScope.launch {
            val fos = FileOutputStream(outputFile)
            val playbackBuffer = ShortArray(bufferSize / 2)
            val micBuffer = ShortArray(bufferSize / 2)
            val mixedBuffer = ShortArray(bufferSize / 2)
            val byteBuffer = ByteArray(bufferSize)

            var totalBytesRecorded = 0L
            val startTime = System.currentTimeMillis()

            try {
                // Write placeholder WAV header (44 bytes)
                fos.write(ByteArray(44))

                while (isActive) {
                    val readPlayback = playbackAudioRecord?.read(playbackBuffer, 0, playbackBuffer.size) ?: 0
                    val readMic = micAudioRecord?.read(micBuffer, 0, micBuffer.size) ?: 0

                    val count = maxOf(readPlayback, readMic)
                    if (count > 0) {
                        var sumAmplitude = 0f
                        for (i in 0 until count) {
                            val sample1 = if (i < readPlayback) playbackBuffer[i].toInt() else 0
                            val sample2 = if (i < readMic) micBuffer[i].toInt() else 0

                            // AudioMixer: Linear saturation mixing without clipping
                            var mixed = sample1 + sample2
                            if (mixed > Short.MAX_VALUE) mixed = Short.MAX_VALUE.toInt()
                            if (mixed < Short.MIN_VALUE) mixed = Short.MIN_VALUE.toInt()
                            mixedBuffer[i] = mixed.toShort()

                            sumAmplitude += Math.abs(mixed.toFloat()) / Short.MAX_VALUE
                        }

                        // Convert short array to PCM byte buffer
                        ByteBuffer.wrap(byteBuffer).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(mixedBuffer, 0, count)
                        val bytesCount = count * 2
                        fos.write(byteBuffer, 0, bytesCount)
                        totalBytesRecorded += bytesCount

                        // Emit visual amplitude for waveform
                        val avgAmp = (sumAmplitude / count).coerceIn(0.05f, 1.0f)
                        RecordingManager.updateAmplitude(avgAmp)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try {
                    // Overwrite header with accurate WAV header
                    RecordingManager.writeWavHeader(fos, totalBytesRecorded, sampleRate, 2, 16)
                    fos.flush()
                    fos.close()

                    val durationSec = ((System.currentTimeMillis() - startTime) / 1000).coerceAtLeast(1)
                    RecordingManager.saveRecordingToDatabase(
                        context = this@AudioCaptureService,
                        file = outputFile,
                        phoneNumber = phoneNumber,
                        callerName = callerName,
                        durationSeconds = durationSec,
                        layer = RecordingLayer.MEDIA_PROJECTION
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun startSingleRecordingLoop(outputFile: File, phoneNumber: String, callerName: String) {
        recordingJob?.cancel()
        recordingJob = serviceScope.launch {
            val fos = FileOutputStream(outputFile)
            val buffer = ShortArray(bufferSize / 2)
            val byteBuffer = ByteArray(bufferSize)
            var totalBytesRecorded = 0L
            val startTime = System.currentTimeMillis()

            try {
                fos.write(ByteArray(44))
                while (isActive) {
                    val read = micAudioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        var sumAmp = 0f
                        for (i in 0 until read) {
                            sumAmp += Math.abs(buffer[i].toFloat()) / Short.MAX_VALUE
                        }
                        ByteBuffer.wrap(byteBuffer).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(buffer, 0, read)
                        val bytesCount = read * 2
                        fos.write(byteBuffer, 0, bytesCount)
                        totalBytesRecorded += bytesCount

                        RecordingManager.updateAmplitude((sumAmp / read).coerceIn(0.05f, 1.0f))
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try {
                    RecordingManager.writeWavHeader(fos, totalBytesRecorded, sampleRate, 2, 16)
                    fos.flush()
                    fos.close()

                    val durationSec = ((System.currentTimeMillis() - startTime) / 1000).coerceAtLeast(1)
                    RecordingManager.saveRecordingToDatabase(
                        context = this@AudioCaptureService,
                        file = outputFile,
                        phoneNumber = phoneNumber,
                        callerName = callerName,
                        durationSeconds = durationSec,
                        layer = RecordingLayer.MIC_FALLBACK
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun stopAudioCapture() {
        isServiceRunning = false
        recordingJob?.cancel()
        try {
            playbackAudioRecord?.stop()
            playbackAudioRecord?.release()
            micAudioRecord?.stop()
            micAudioRecord?.release()
            mediaProjection?.stop()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        playbackAudioRecord = null
        micAudioRecord = null
        mediaProjection = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Titan Call Recording Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopAudioCapture()
        super.onDestroy()
    }
}
