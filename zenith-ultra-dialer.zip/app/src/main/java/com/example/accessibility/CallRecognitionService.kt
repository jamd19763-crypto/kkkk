package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.model.RecordingLayer
import com.example.recording.RecordingManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CallRecognitionService : AccessibilityService() {

    companion object {
        private const val TAG = "CallRecognitionService"
        var isServiceConnected = false
            private set

        private val RECORD_BUTTON_IDENTIFIERS = listOf(
            "record", "recording", "btn_record", "call_record",
            "تسجيل", "بدء التسجيل", "تسجيل المكالمة",
            "录音", "通话录音", "开始录音"
        )
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private var telephonyManager: TelephonyManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceConnected = true
        Log.d(TAG, "Titan Dialer Accessibility Service connected for ColorOS/Oppo integration")

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_CLICKED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        serviceInfo = info

        registerTelephonyListener()
    }

    private fun registerTelephonyListener() {
        telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            telephonyManager?.registerTelephonyCallback(
                mainExecutor,
                object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handlePhoneStateChange(state)
                    }
                }
            )
        } else {
            @Suppress("DEPRECATION")
            telephonyManager?.listen(object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    handlePhoneStateChange(state)
                }
            }, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    private fun handlePhoneStateChange(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                Log.d(TAG, "Telephony state: OFFHOOK (Call Active) -> Triggering ColorOS Auto-Record")
                // Scan UI nodes to click native record button if present in ColorOS InCallUI
                scanAndClickRecordButton()
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                Log.d(TAG, "Telephony state: IDLE -> Call ended")
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: ""

        // Check if event is from InCallUI in Oppo/ColorOS/Android
        if (packageName.contains("incallui") || packageName.contains("dialer") || packageName.contains("coloros")) {
            scanAndClickRecordButton()
        }
    }

    fun scanAndClickRecordButton(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        try {
            return searchAndClickNode(rootNode)
        } catch (e: Exception) {
            Log.e(TAG, "Error clicking accessibility node", e)
        } finally {
            rootNode.recycle()
        }
        return false
    }

    private fun searchAndClickNode(node: AccessibilityNodeInfo): Boolean {
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        val isRecordButton = RECORD_BUTTON_IDENTIFIERS.any { keyword ->
            text.contains(keyword) || desc.contains(keyword) || viewId.contains(keyword)
        }

        if (isRecordButton && node.isClickable) {
            val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Log.d(TAG, "Successfully clicked ColorOS Call Record Button: $clicked (ViewId: $viewId)")
            return clicked
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (searchAndClickNode(child)) {
                child.recycle()
                return true
            }
            child.recycle()
        }
        return false
    }

    override fun onInterrupt() {
        Log.w(TAG, "CallRecognitionService interrupted")
    }

    override fun onDestroy() {
        isServiceConnected = false
        super.onDestroy()
    }
}
