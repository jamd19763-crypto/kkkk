package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ColorOS Signature Brand Palette (Oppo Reno 6 Pro Aesthetic)
val ColorOS_Teal = Color(0xFF00A896)      // Primary Signature Emerald Teal
val ColorOS_Teal_Light = Color(0xFF33BEAB) // Accent Highlight
val ColorOS_Teal_Dark = Color(0xFF006D61)  // Rich Deep Accent

// Dark ColorOS Theme Tokens
val ColorOS_Dark_Bg = Color(0xFF0F1617)       // Deep Obsidian Teal Background
val ColorOS_Dark_Surface = Color(0xFF162022)  // Slate-Teal Card Surface
val ColorOS_Dark_Card = Color(0xFF1F2C2E)     // Elevated List Element Base
val ColorOS_Dark_Text_Primary = Color(0xFFE1EAEA)
val ColorOS_Dark_Text_Secondary = Color(0xFF90A4A5)

// Light ColorOS Theme Tokens
val ColorOS_Light_Bg = Color(0xFFF4F7F7)      // Silky Light Gray-Green
val ColorOS_Light_Surface = Color(0xFFFFFFFF) // Pure White Base Card
val ColorOS_Light_Card = Color(0xFFE9F2F1)    // Secondary Interactive Plate
val ColorOS_Light_Text_Primary = Color(0xFF1E2829)
val ColorOS_Light_Text_Secondary = Color(0xFF6B7E80)

// Standard Utility / Accent Glows
val System_Blue = Color(0xFF2E93E4)
val System_Orange = Color(0xFFFF9800)
val System_Red = Color(0xFFF44336)
val System_Gold = Color(0xFFFFC107)
val System_Purple = Color(0xFF9C27B0)
val System_Green = Color(0xFF4CAF50)
