package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.AppInfo
import com.example.R
import com.example.SettingsViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.text.font.FontFamily


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainSettingsScreen(
    viewModel: SettingsViewModel,
    onNavigate: (String) -> Unit
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isWifiOn by viewModel.isWifiEnabled.collectAsState()
    val wifiSsid by viewModel.wifiSsid.collectAsState()
    val isBluetoothOn by viewModel.isBluetoothEnabled.collectAsState()
    val isFlashlightOn by viewModel.isFlashlightEnabled.collectAsState()
    val isEyeComfortOn by viewModel.isEyeComfortEnabled.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val storageUsed by viewModel.storageUsedGB.collectAsState()
    val storageTotal by viewModel.storageTotalGB.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            containerColor = Color.Black
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. MOCK COLOROS SYSTEM STATUS BAR (MATCHING THE SCREENSHOTS EXACTLY)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left status bar details: Speed, signal waves, Wi-Fi, battery %
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = if (isRtl) "٢٢ KB/s" else "22 KB/s",
                                fontSize = 11.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Icon(
                                imageVector = Icons.Default.Wifi,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = if (isRtl) "%${batteryLevel}" else "${batteryLevel}%",
                                fontSize = 11.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .width(16.dp)
                                    .height(9.dp)
                                    .border(1.dp, Color.White, RoundedCornerShape(1.dp))
                                    .padding(1.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(batteryLevel / 100f)
                                        .background(if (batteryLevel < 20) Color.Red else Color.Green)
                                )
                            }
                        }

                        // Right status bar details: Clock 8:15 (٨:١٥)
                        Text(
                            text = if (isRtl) "٨:١٥" else "8:15",
                            fontSize = 11.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 2. LARGE HEADER TITLE
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        contentAlignment = if (isRtl) Alignment.CenterStart else Alignment.CenterEnd
                    ) {
                        Text(
                            text = if (isRtl) "الإعدادات" else "Settings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 32.sp,
                            color = Color.White
                        )
                    }
                }

                // 3. SEARCH BAR
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { 
                            Text(
                                text = if (isRtl) "بحث" else "Search",
                                color = Color(0xFF666666),
                                fontSize = 14.sp
                            )
                        },
                        trailingIcon = { 
                            Icon(
                                imageVector = Icons.Default.Search, 
                                contentDescription = null, 
                                tint = Color(0xFF666666),
                                modifier = Modifier.size(20.dp)
                            ) 
                        },
                        shape = CircleShape,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF161616),
                            unfocusedContainerColor = Color(0xFF161616),
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true
                    )
                }

                // 4. BLOCK 1: OMOJI ROW CARD (SPLIT LAYOUT)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Left small orange-yellow folder card
                        Card(
                            onClick = { onNavigate("personalization") },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFB300)),
                            modifier = Modifier
                                .width(72.dp)
                                .height(88.dp)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                // Folder-like document stacking visuals
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy((-6).dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp, 20.dp)
                                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                            .background(Color.White.copy(alpha = 0.5f))
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp, 26.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color.White)
                                    )
                                }
                            }
                        }

                        // Right Omoji Card (matches screenshots exactly)
                        Card(
                            onClick = { onNavigate("personalization") },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                            modifier = Modifier
                                .weight(1f)
                                .height(88.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(start = 16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = "Omoji",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (isRtl) "اصنع Omoji متحركًا فريدًا من نوعه مثلك." else "Create a 3D animated avatar unique like you.",
                                        fontSize = 11.sp,
                                        color = Color(0xFF9E9E9E),
                                        lineHeight = 14.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Image(
                                    painter = painterResource(id = R.drawable.img_omoji_avatar_1784309263757),
                                    contentDescription = "Omoji Boy",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(80.dp)
                                        .clip(RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp))
                                )
                            }
                        }
                    }
                }

                // 5. BLOCK 2: ACCOUNT CARD (NickName09fM6ffN065T)
                item {
                    Card(
                        onClick = { onNavigate("users_accounts") },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Circular green badge with Arabic "ح"
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF4CAF50)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isRtl) "ح" else "H",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 20.sp
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "NickName09fM6ffN065T",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isRtl) "إدارة معلومات الحساب والأمان." else "Manage account details and security.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF9E9E9E)
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = null,
                                tint = Color(0xFF555555),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // 6. BLOCK 3: CONNECTIVITY CARD
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            ColorOsSettingsRow(
                                title = "Wi-Fi",
                                value = if (isWifiOn) wifiSsid else (if (isRtl) "غير مفعّل" else "OFF"),
                                icon = Icons.Default.Wifi,
                                iconBg = Color(0xFF2E93E4)
                            ) { onNavigate("wifi") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "شبكة الهاتف" else "Mobile Network",
                                icon = Icons.Default.SwapVert,
                                iconBg = Color(0xFF4CAF50)
                            ) { onNavigate("mobile_network") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "بلوتوث" else "Bluetooth",
                                value = if (isBluetoothOn) (if (isRtl) "مفعّل" else "ON") else (if (isRtl) "غير مفعّل" else "OFF"),
                                icon = Icons.Default.Bluetooth,
                                iconBg = Color(0xFF2E93E4)
                            ) { onNavigate("bluetooth") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "الاتصال والمشاركة" else "Connection & Sharing",
                                icon = Icons.Default.Share,
                                iconBg = Color(0xFF2ECC71)
                            ) { onNavigate("connection_sharing") }
                        }
                    }
                }

                // 7. BLOCK 4: PERSONALIZATION
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            ColorOsSettingsRow(
                                title = if (isRtl) "الخلفيات والشكل" else "Wallpapers & style",
                                icon = Icons.Default.Palette,
                                iconBg = Color(0xFFFF5722)
                            ) { onNavigate("personalization") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "الشاشة الرئيسية وشاشة القفل" else "Home screen & lock screen",
                                icon = Icons.Default.Image,
                                iconBg = Color(0xFFFF7043)
                            ) { onNavigate("home_lock_screen") }
                        }
                    }
                }

                // 8. BLOCK 5: DISPLAY, AUDIO & NOTIFICATIONS
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            ColorOsSettingsRow(
                                title = if (isRtl) "الشاشة والسطوع" else "Display & brightness",
                                icon = Icons.Default.LightMode,
                                iconBg = Color(0xFFFFB300)
                            ) { onNavigate("display") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "الأصوات والاهتزاز" else "Sound & vibration",
                                icon = Icons.Default.NotificationsActive,
                                iconBg = Color(0xFF2ECC71)
                            ) { onNavigate("sound") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "الإإشعارات وشريط الحالة" else "Notifications & status bar",
                                icon = Icons.Default.Notifications,
                                iconBg = Color(0xFF2E93E4)
                            ) { onNavigate("notifications") }
                        }
                    }
                }

                // 9. BLOCK 6: APPS, SECURITY & HARDWARE
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            ColorOsSettingsRow(
                                title = if (isRtl) "التطبيقات" else "Apps",
                                icon = Icons.Default.Apps,
                                iconBg = Color(0xFF2ECC71)
                            ) { onNavigate("apps") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "كلمة المرور والأمان" else "Password & security",
                                icon = Icons.Default.Key,
                                iconBg = Color(0xFF2E93E4)
                            ) { onNavigate("password_security") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "الخصوصية" else "Privacy",
                                icon = Icons.Default.Security,
                                iconBg = Color(0xFF34495E)
                            ) { onNavigate("privacy") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "الموقع" else "Location",
                                icon = Icons.Default.LocationOn,
                                iconBg = Color(0xFFFFB300)
                            ) { onNavigate("location") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "الأمن وحالة الطوارئ" else "Safety & emergency",
                                icon = Icons.Default.Emergency,
                                iconBg = Color(0xFFE74C3C)
                            ) { onNavigate("safety_emergency") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "البطارية" else "Battery",
                                value = "$batteryLevel%",
                                icon = Icons.Default.BatteryChargingFull,
                                iconBg = Color(0xFF2ECC71)
                            ) { onNavigate("battery") }
                        }
                    }
                }

                // 10. BLOCK 7: SPECIAL FEATURES
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            ColorOsSettingsRow(
                                title = if (isRtl) "ميزات خاصة" else "Special features",
                                icon = Icons.Default.Star,
                                iconBg = Color(0xFFFF5722)
                            ) { onNavigate("special_features") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "الرفاهية الرقمية وأدوات الرقابة الأبوية" else "Digital Wellbeing & parental controls",
                                icon = Icons.Default.Favorite,
                                iconBg = Color(0xFFFF7043)
                            ) { onNavigate("digital_wellbeing") }
                        }
                    }
                }

                // 11. BLOCK 8: ADDITIONAL SETTINGS
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ColorOsSettingsRow(
                            title = if (isRtl) "الإعدادات الإضافية" else "Additional settings",
                            icon = Icons.Default.Settings,
                            iconBg = Color(0xFF2ECC71)
                        ) { onNavigate("additional_settings") }
                    }
                }

                // 12. BLOCK 9: ABOUT, USER ACCOUNTS, GOOGLE
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            ColorOsSettingsRow(
                                title = if (isRtl) "حول الجهاز" else "About device",
                                icon = Icons.Default.Smartphone,
                                iconBg = Color(0xFF2ECC71)
                            ) { onNavigate("about") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = if (isRtl) "المستخدمون والحسابات" else "Users & accounts",
                                icon = Icons.Default.AccountCircle,
                                iconBg = Color(0xFF2E93E4)
                            ) { onNavigate("users_accounts") }

                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                            ColorOsSettingsRow(
                                title = "Google",
                                icon = Icons.Default.Android,
                                iconBg = Color(0xFF2E93E4)
                            ) { onNavigate("google") }
                        }
                    }
                }

                // Bottom spacer
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

// Reusable ColorOS Row element matching screenshots perfectly
@Composable
fun ColorOsSettingsRow(
    title: String,
    value: String = "",
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Circular background with icon
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

        // Title text
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White,
            modifier = Modifier.weight(1f)
        )

        // Value text (e.g. Wi-Fi status SSID, battery %...)
        if (value.isNotEmpty()) {
            Text(
                text = value,
                fontSize = 13.sp,
                color = Color(0xFF9E9E9E),
                modifier = Modifier.padding(end = 4.dp)
            )
        }

        // Left chevron for RTL layout
        Icon(
            imageVector = Icons.Default.ChevronLeft,
            contentDescription = null,
            tint = Color(0xFF555555),
            modifier = Modifier.size(16.dp)
        )
    }
}

// Quick Tile Card Composable
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun QuickTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColors = if (isActive) {
        CardDefaults.cardColors(containerColor = ColorOS_Teal)
    } else {
        CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    }
    val contentColor = if (isActive) Color.White else MaterialTheme.colorScheme.onBackground
    val descColor = if (isActive) Color.White.copy(alpha = 0.75f) else MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        modifier = modifier
            .height(78.dp)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(18.dp),
        colors = bgColors
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (isActive) Color.White.copy(alpha = 0.2f) else ColorOS_Teal.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isActive) Color.White else ColorOS_Teal,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = contentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = descColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// Settings Item Row Composable
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsRow(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    onClick: () -> Unit,
    isRtl: Boolean
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = if (isRtl) Icons.AutoMirrored.Filled.ArrowBack else Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

// Data structure
data class SettingsMenuItem(
    val key: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val route: String,
    val iconBg: Color
)


// ==========================================
// SUB-SCREEN 1: Wi-Fi Detail Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiSettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val isWifiOn by viewModel.isWifiEnabled.collectAsState()
    val connectedSsid by viewModel.wifiSsid.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("wifi"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Wi-Fi Master Toggle
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(viewModel.getTranslation("wifi"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(
                                if (isWifiOn) viewModel.getTranslation("wifi_on") else viewModel.getTranslation("wifi_off"),
                                fontSize = 12.sp,
                                color = ColorOS_Teal
                            )
                        }
                        Switch(
                            checked = isWifiOn,
                            onCheckedChange = { viewModel.toggleWifi() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                        )
                    }
                }

                if (isWifiOn) {
                    Text("Connected Network", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ColorOS_Teal)
                    // Connected SSID Info
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = ColorOS_Teal.copy(alpha = 0.05f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = ColorOS_Teal, modifier = Modifier.size(28.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(connectedSsid, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Signal: Excellent • Speed: 866 Mbps", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ColorOS_Teal)
                        }
                    }

                    Text("Available Networks", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    val networks = listOf("Vodafone_VDSL_5G", "Hany_Wifi_Plus", "WE_Active_77", "Oppo_Personal_Hotspot", "Mall_Free_HighSpeed")
                    networks.forEach { ssid ->
                        Card(
                            onClick = { viewModel.toggleWifi() }, // Quick connection simulation
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(Icons.Default.Wifi, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(ssid, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                }
                                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.WifiOff, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Wi-Fi is turned off", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 2: Bluetooth Detail Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BluetoothSettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val isBtOn by viewModel.isBluetoothEnabled.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("bluetooth"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(viewModel.getTranslation("bluetooth"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(
                                if (isBtOn) "OPPO Reno6 Pro is visible to nearby devices" else "Invisible",
                                fontSize = 12.sp,
                                color = ColorOS_Teal
                            )
                        }
                        Switch(
                            checked = isBtOn,
                            onCheckedChange = { viewModel.toggleBluetooth() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                        )
                    }
                }

                if (isBtOn) {
                    Text("Paired Devices", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ColorOS_Teal)

                    val pairedDevices = listOf(
                        Pair("OPPO Enco X2", "Connected • Battery 100%"),
                        Pair("OPPO Watch 3 Pro", "Connected"),
                        Pair("Hany's Windows 11 PC", "Paired"),
                        Pair("Samsung QLED TV 65", "Paired")
                    )

                    pairedDevices.forEach { device ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        if (device.first.contains("Enco") || device.first.contains("Ear")) Icons.Default.Headphones else Icons.Default.Devices,
                                        contentDescription = null,
                                        tint = ColorOS_Teal
                                    )
                                    Column {
                                        Text(device.first, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                        Text(device.second, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.BluetoothDisabled, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Bluetooth is disabled", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 3: Personalization & Themes Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalizationScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val selectedFingerprint by viewModel.fingerprintAnimation.collectAsState()
    val selectedEdgeColor by viewModel.edgeLightingColor.collectAsState()

    // Animation trigger for visualizer
    var animTrigger by remember { mutableStateOf(0f) }
    LaunchedEffect(selectedFingerprint) {
        animTrigger = 0f
        while (true) {
            animate(0f, 1f, animationSpec = tween(1500, easing = LinearEasing)) { value, _ ->
                animTrigger = value
            }
            delay(200)
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("personalization"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Feature Header Preview Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            // Animated neon background depending on Selected Edge lighting
                            val glowingColor = when (selectedEdgeColor) {
                                "Teal" -> ColorOS_Teal
                                "Blue" -> System_Blue
                                "Gold" -> System_Gold
                                "Purple" -> System_Purple
                                else -> ColorOS_Teal
                            }
                            
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                // Draw an animated neon glow frame to simulate edge lighting!
                                val strokeWidth = 8f
                                val progress = animTrigger
                                drawRoundRect(
                                    color = glowingColor.copy(alpha = 0.8f),
                                    topLeft = Offset(strokeWidth, strokeWidth),
                                    size = Size(size.width - strokeWidth * 2, size.height - strokeWidth * 2),
                                    style = Stroke(
                                        width = strokeWidth,
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(120f, 60f), progress * 180f)
                                    ),
                                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(24.dp.toPx(), 24.dp.toPx())
                                )
                            }

                            // Content inside preview
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "ColorOS Active Workspace",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                // Fingerprint glow animation
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .background(glowingColor.copy(alpha = 0.15f))
                                        .border(1.5.dp, glowingColor.copy(alpha = 0.4f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Fingerprint,
                                        contentDescription = null,
                                        tint = glowingColor,
                                        modifier = Modifier.size(34.dp)
                                    )
                                    
                                    // Animated circle ripples
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        drawCircle(
                                            color = glowingColor,
                                            radius = (size.minDimension / 2) * animTrigger,
                                            style = Stroke(width = 3f),
                                            alpha = 1f - animTrigger
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "${viewModel.getTranslation("fingerprint_anim")}: ${viewModel.getTranslation(selectedFingerprint.lowercase())}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Interactive choice for Fingerprint animations
                item {
                    Text(viewModel.getTranslation("fingerprint_anim"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)
                }

                item {
                    val animations = listOf("Fizz", "Ripple", "Stardust", "None")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        animations.forEach { anim ->
                            val isSelected = selectedFingerprint == anim
                            Card(
                                onClick = { viewModel.setFingerprintAnimation(anim) },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) ColorOS_Teal else MaterialTheme.colorScheme.surface
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(55.dp)
                            ) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = viewModel.getTranslation(anim.lowercase()),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                                    )
                                }
                            }
                        }
                    }
                }

                // Interactive choice for Edge Lighting color
                item {
                    Text(viewModel.getTranslation("edge_lighting"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)
                }

                item {
                    val colors = listOf("Teal", "Blue", "Gold", "Purple")
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        colors.forEach { color ->
                            val isSelected = selectedEdgeColor == color
                            val badgeColor = when (color) {
                                "Teal" -> ColorOS_Teal
                                "Blue" -> System_Blue
                                "Gold" -> System_Gold
                                "Purple" -> System_Purple
                                else -> ColorOS_Teal
                            }
                            Card(
                                onClick = { viewModel.setEdgeLightingColor(color) },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) badgeColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                border = if (isSelected) BorderStroke(1.5.dp, badgeColor) else null
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Box(modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(badgeColor))
                                        Text(viewModel.getTranslation(color.lowercase()), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = badgeColor)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 4: Display & Brightness Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DisplayBrightnessScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val isDarkTheme by viewModel.isDarkMode.collectAsState()
    val isEyeComfort by viewModel.isEyeComfortEnabled.collectAsState()
    val brightness by viewModel.screenBrightness.collectAsState()
    val fontScale by viewModel.fontSizeScale.collectAsState()
    val hasWritePermission by viewModel.hasWriteSettingsPermission.collectAsState()
    val context = LocalContext.current

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("display"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Permission Card for Brightness Control if missing
                if (!hasWritePermission) {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                try {
                                    val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (ex: Exception) {
                                    // ignore fallback
                                }
                            }
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isRtl) "تفعيل التحكم الفعلي بالسطوع" else "Enable Real Brightness Control",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Text(
                                    text = if (isRtl) "اضغط هنا لمنح إذن النظام للتحكم بسطوع شاشتك الحقيقي" else "Tap here to grant system permission to adjust real screen brightness",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }

                // Theme Switcher Cards (Side by side Light & Dark options!)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Light mode card
                    Card(
                        onClick = { viewModel.setDarkMode(false) },
                        modifier = Modifier
                            .weight(1f)
                            .height(110.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = if (!isDarkTheme) ColorOS_Teal.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface),
                        border = if (!isDarkTheme) BorderStroke(2.dp, ColorOS_Teal) else null
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.LightMode, contentDescription = null, tint = if (!isDarkTheme) ColorOS_Teal else MaterialTheme.colorScheme.onBackground)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Light Mode", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Dark mode card
                    Card(
                        onClick = { viewModel.setDarkMode(true) },
                        modifier = Modifier
                            .weight(1f)
                            .height(110.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) ColorOS_Teal.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface),
                        border = if (isDarkTheme) BorderStroke(2.dp, ColorOS_Teal) else null
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = if (isDarkTheme) ColorOS_Teal else MaterialTheme.colorScheme.onBackground)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Dark Mode", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Brightness Slider Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(viewModel.getTranslation("brightness"), fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.WbSunny, contentDescription = null, tint = ColorOS_Teal)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Slider(
                            value = brightness.toFloat(),
                            onValueChange = { viewModel.setBrightness(it.toInt()) },
                            valueRange = 0f..255f,
                            colors = SliderDefaults.colors(thumbColor = ColorOS_Teal, activeTrackColor = ColorOS_Teal)
                        )
                    }
                }

                // Eye Comfort Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(viewModel.getTranslation("eye_comfort"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Reduce blue light to prevent eye strain", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = isEyeComfort,
                            onCheckedChange = { viewModel.toggleEyeComfort() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                        )
                    }
                }

                // Refresh Rate Selection Card (OPPO 90Hz specialty)
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Screen Refresh Rate", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Choose refresh rate for ultra smooth visual motions", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))
                        var selectedRate by remember { mutableStateOf("90Hz") }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf("60Hz", "90Hz").forEach { rate ->
                                val selected = selectedRate == rate
                                Card(
                                    onClick = { selectedRate = rate },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (selected) ColorOS_Teal else MaterialTheme.colorScheme.surfaceVariant),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(45.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text(rate, color = if (selected) Color.White else MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 5: Sound & Vibration Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundVibrationScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val mediaVol by viewModel.mediaVolume.collectAsState()
    val ringVol by viewModel.ringVolume.collectAsState()
    val notifVol by viewModel.notificationVolume.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("sound"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Media Volume Slider
                item {
                    VolumeSliderCard(
                        title = viewModel.getTranslation("volume_media"),
                        volume = mediaVol,
                        maxVolume = viewModel.maxMediaVolume,
                        icon = Icons.Default.MusicNote,
                        onVolumeChange = { viewModel.setMediaVolume(it) }
                    )
                }

                // Ringtone Volume Slider
                item {
                    VolumeSliderCard(
                        title = viewModel.getTranslation("volume_ring"),
                        volume = ringVol,
                        maxVolume = viewModel.maxRingVolume,
                        icon = Icons.Default.PhoneInTalk,
                        onVolumeChange = { viewModel.setRingVolume(it) }
                    )
                }

                // Notification Volume Slider
                item {
                    VolumeSliderCard(
                        title = viewModel.getTranslation("volume_notif"),
                        volume = notifVol,
                        maxVolume = viewModel.maxNotificationVolume,
                        icon = Icons.Default.Notifications,
                        onVolumeChange = { viewModel.setNotificationVolume(it) }
                    )
                }

                // Dolby Atmos Custom Panel (High end sound tech)
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Hearing, contentDescription = null, tint = ColorOS_Teal)
                                    Text("Dolby Atmos® Sound", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                                var dolbyOn by remember { mutableStateOf(true) }
                                Switch(
                                    checked = dolbyOn,
                                    onCheckedChange = { dolbyOn = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Immersive dimensional surround audio virtualization.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
     compositionLocalProviderCheck()
    }
}

private fun compositionLocalProviderCheck() {}

@Composable
fun VolumeSliderCard(
    title: String,
    volume: Int,
    maxVolume: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onVolumeChange: (Int) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Bold)
                Icon(icon, contentDescription = null, tint = ColorOS_Teal, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Slider(
                    value = volume.toFloat(),
                    onValueChange = { onVolumeChange(it.toInt()) },
                    valueRange = 0f..maxVolume.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = ColorOS_Teal, activeTrackColor = ColorOS_Teal),
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${((volume.toFloat() / maxVolume.toFloat()) * 100).toInt()}%",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = ColorOS_Teal,
                    modifier = Modifier.width(38.dp),
                    textAlign = TextAlign.End
                )
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 6: Battery & Power Info Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatteryScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val isCharging by viewModel.isBatteryCharging.collectAsState()
    val superPowerOn by viewModel.isSuperPowerSaving.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("battery"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Interactive Battery Circle Gauge
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val progressAnim by animateFloatAsState(
                        targetValue = batteryLevel.toFloat() / 100f,
                        animationSpec = tween(1200)
                    )
                    
                    val activeColor = when {
                        isCharging -> ColorOS_Teal
                        batteryLevel <= 20 -> System_Red
                        batteryLevel <= 40 -> System_Orange
                        else -> ColorOS_Teal
                    }

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Background track
                        drawCircle(
                            color = activeColor.copy(alpha = 0.15f),
                            style = Stroke(width = 16.dp.toPx())
                        )
                        // Progress arc
                        drawArc(
                            color = activeColor,
                            startAngle = -90f,
                            sweepAngle = 360f * progressAnim,
                            useCenter = false,
                            style = Stroke(width = 16.dp.toPx(), pathEffect = null)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$batteryLevel%",
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isCharging) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = activeColor, modifier = Modifier.size(16.dp))
                            }
                            Text(
                                text = if (isCharging) viewModel.getTranslation("charging") else viewModel.getTranslation("not_charging"),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Super Power Saving Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(viewModel.getTranslation("super_power_saving"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Locks apps in background to expand standby up to 48 hours", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = superPowerOn,
                            onCheckedChange = { viewModel.toggleSuperPowerSaving() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                        )
                    }
                }

                // Battery Health Indicator
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = System_Red, modifier = Modifier.size(24.dp))
                        Column {
                            Text("Battery Health (صحة البطارية)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(viewModel.getTranslation("battery_health"), fontSize = 12.sp, color = ColorOS_Teal)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 7: App Manager Screen (REAL APP telemetry!)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppManagerScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val installedApps by viewModel.installedApps.collectAsState()
    val context = LocalContext.current

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("apps"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header showing total apps
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ColorOS_Teal),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(viewModel.getTranslation("app_list"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Found ${installedApps.size} installed applications on your Reno device.", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    }
                }

                // Apps Lazy Column
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(installedApps) { app ->
                        Card(
                            onClick = {
                                // Dynamic Launch intent trigger! Let Hany launch real apps directly from here!
                                try {
                                    val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                                    if (launchIntent != null) {
                                        context.startActivity(launchIntent)
                                    }
                                } catch (e: Exception) {
                                    // Safe ignore if cannot launch
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(ColorOS_Teal.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Android, contentDescription = null, tint = ColorOS_Teal, modifier = Modifier.size(24.dp))
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(app.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(app.packageName, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${app.sizeMB} MB", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ColorOS_Teal)
                                    Text("v${app.version}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 8: Special Features Screen (Ugraded with AI Suite)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpecialFeaturesScreen(
    viewModel: SettingsViewModel,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("special_features"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header Banner
                item {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = ColorOS_Teal.copy(alpha = 0.08f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(ColorOS_Teal),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                                }
                                Column {
                                    Text(
                                        text = if (isRtl) "حزمة الذكاء الاصطناعي المتقدمة" else "Advanced AI Space",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Text(
                                        text = "ColorOS 17.0 Ultimate Suite",
                                        fontSize = 12.sp,
                                        color = ColorOS_Teal
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isRtl) "ميزات حصرية ومطورة خصيصاً للمحتوى الرقمي ولجهاز المطورين الفريد الخاص بحمو الإلكتروني." else "Exclusive developer tools tailored specifically for Hamo Electronic's customized Oppo Reno6 Pro+.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // AI Section Header
                item {
                    Text(
                        text = if (isRtl) "أدوات الذكاء الاصطناعي الذكية" else "ColorOS AI Utilities",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOS_Teal,
                        modifier = Modifier.padding(start = 8.dp, top = 4.dp)
                    )
                }

                // AI Snap Key
                item {
                    SpecialFeatureCard(
                        title = "AI Snap Key",
                        desc = if (isRtl) "تخصيص وبرمجة الزر السري لتفعيل المساعد الذكي وخدمات الترجمة الفورية بكبسة واحدة." else "Configure and program the hardware assistant key for instant access.",
                        icon = Icons.Default.Bolt,
                        badge = if (isRtl) "مفعل" else "Active",
                        onClick = { onNavigate("ai_snap_key") }
                    )
                }

                // AI Mind Space
                item {
                    SpecialFeatureCard(
                        title = "AI Mind Space",
                        desc = if (isRtl) "مستودع الملاحظات والأفكار التكنولوجية المشفرة لحفظ ومزامنة محتواك التقني." else "Secure storage for developer logs, video ideas, and encrypted thoughts.",
                        icon = Icons.Default.CloudQueue,
                        badge = if (isRtl) "مزامنة سحابية" else "Cloud Sync",
                        onClick = { onNavigate("ai_mind_space") }
                    )
                }

                // AI Mind Pilot
                item {
                    SpecialFeatureCard(
                        title = "AI Mind Pilot",
                        desc = if (isRtl) "المساعد الشخصي الفائق المبرمج بذكاء اصطناعي للرد على أسئلتك التقنية وإدارة الجهاز." else "Conversational AI chatbot trained to support Hamo's tech creation.",
                        icon = Icons.Default.SmartToy,
                        badge = "Gemini AI",
                        onClick = { onNavigate("ai_mind_pilot") }
                    )
                }

                // AI Bill Manager
                item {
                    SpecialFeatureCard(
                        title = "AI Bill Manager",
                        desc = if (isRtl) "مدير ومحلل الفواتير الذكي لاستخراج التكاليف والبيانات المالية من الإيصالات فورياً." else "Scan and track business invoices and technology receipts with OCR.",
                        icon = Icons.Default.Receipt,
                        onClick = { onNavigate("ai_bill_manager") }
                    )
                }

                // AI Menu Translation
                item {
                    SpecialFeatureCard(
                        title = "AI Menu Translation",
                        desc = if (isRtl) "مترجم الوجبات الفوري لمسح لوائح الطعام وترجمتها رسومياً بلغة المطورين السريعة." else "Scan food menus at UAE lounges and overlay precise translations instantly.",
                        icon = Icons.Default.Translate,
                        onClick = { onNavigate("ai_menu_translation") }
                    )
                }

                // Pop Cam & Media Enhancement
                item {
                    Text(
                        text = if (isRtl) "أدوات الكاميرا والوسائط المتقدمة" else "Advanced Media & Camera Suite",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOS_Teal,
                        modifier = Modifier.padding(start = 8.dp, top = 8.dp)
                    )
                }

                // Pop Cam
                item {
                    SpecialFeatureCard(
                        title = "Pop Cam",
                        desc = if (isRtl) "كاميرا المطورين الاحترافية المدمجة بفلاتر سينمائية وترقيات DXOMark المخصصة." else "Advanced custom camera viewfinder with active AI skin and visual filters.",
                        icon = Icons.Default.PhotoCamera,
                        badge = "200MP",
                        onClick = { onNavigate("pop_cam") }
                    )
                }

                // AI Remix Collage
                item {
                    SpecialFeatureCard(
                        title = "AI Remix Collage",
                        desc = if (isRtl) "دمج وترتيب الصور الذكي لعمل كولاجات فنية مذهلة لمشاركتها على شبكات التواصل." else "Combine, align, and render visual layouts using advanced drag canvas.",
                        icon = Icons.Default.GridOn,
                        onClick = { onNavigate("ai_remix_collage") }
                    )
                }

                // 4K Auto Straighten Video
                item {
                    SpecialFeatureCard(
                        title = "4K Auto Straighten Video",
                        desc = if (isRtl) "التثبيت والتحكم التلقائي بأفق تصوير الفيديو لإنتاج فلوجات بجودة سينمائية ثابتة." else "Active physical horizon stabilization and mechanical layout simulation.",
                        icon = Icons.Default.VideoCameraBack,
                        badge = "120 FPS",
                        onClick = { onNavigate("video_straighten") }
                    )
                }

                // System canonical guest gestures
                item {
                    Text(
                        text = if (isRtl) "إيماءات وحركات النظام" else "System Gestures & Motion",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 8.dp, top = 8.dp)
                    )
                }

                // Split Screen guide
                item {
                    SpecialFeatureCard(
                        title = viewModel.getTranslation("split_screen"),
                        desc = if (isRtl) "اسحب لأعلى بثلاثة أصابع لتقسيم الشاشة والدخول في وضع المهام المتعددة فوراً." else "Swipe up with three fingers to enter split-screen mode instantly and multi-task like a pro.",
                        icon = Icons.Default.VerticalSplit
                    )
                }

                // Sidebar panel guide
                item {
                    SpecialFeatureCard(
                        title = viewModel.getTranslation("sidebar"),
                        desc = if (isRtl) "اسحب من الحافة اليمنى لفتح شريط الأدوات الذكي والاختصارات السريعة للتطبيقات." else "Slide out from the upper right of the screen to open quick-access utilities and shortcuts.",
                        icon = Icons.Default.ViewSidebar
                    )
                }

                // Flexible windows
                item {
                    SpecialFeatureCard(
                        title = viewModel.getTranslation("flexible_windows"),
                        desc = if (isRtl) "نوافذ عائمة مرنة يمكن تصغيرها وتكبيرها أو نقلها لزوايا الشاشة بسلاسة." else "Floating windows can be resized, minimized to the screen edge, or maximized into full screen.",
                        icon = Icons.Default.PictureInPicture
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun SpecialFeatureCard(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badge: String? = null,
    onClick: (() -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ColorOS_Teal.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = ColorOS_Teal, modifier = Modifier.size(24.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = ColorOS_Teal)
                    if (badge != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = ColorOS_Teal.copy(alpha = 0.15f),
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            Text(
                                text = badge,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 9: Language & Scale Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageRegionScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val fontScale by viewModel.fontSizeScale.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("language"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(viewModel.getTranslation("language"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)

                // Selectable Language cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        onClick = { viewModel.setLanguage("ar") },
                        modifier = Modifier
                            .weight(1f)
                            .height(60.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isRtl) ColorOS_Teal.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isRtl) BorderStroke(1.5.dp, ColorOS_Teal) else null
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("العربية", fontWeight = FontWeight.Bold)
                        }
                    }

                    Card(
                        onClick = { viewModel.setLanguage("en") },
                        modifier = Modifier
                            .weight(1f)
                            .height(60.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (!isRtl) ColorOS_Teal.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (!isRtl) BorderStroke(1.5.dp, ColorOS_Teal) else null
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("English", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(viewModel.getTranslation("font_size"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)

                // Font size modifier card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Sample text size visualization",
                            fontSize = (15f * fontScale).sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("A", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Slider(
                                value = fontScale,
                                onValueChange = { viewModel.setFontSizeScale(it) },
                                valueRange = 0.8f..1.3f,
                                colors = SliderDefaults.colors(thumbColor = ColorOS_Teal, activeTrackColor = ColorOS_Teal),
                                modifier = Modifier.weight(1f)
                            )
                            Text("A", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 10: About Device Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutDeviceScreen(
    viewModel: SettingsViewModel,
    onNavigate: ((String) -> Unit)? = null,
    onBack: () -> Unit
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"

    // Dialog state variables
    var showDigitalCertDialog by remember { mutableStateOf(false) }
    var showBetaLogDialog by remember { mutableStateOf(false) }
    var showPerformanceDialog by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var showGiftDialog by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }
    var showGoldenNoteDialog by remember { mutableStateOf(false) }

    // local simulation for performance test in dialog
    var isLocalPerfTesting by remember { mutableStateOf(false) }
    var localPerfProgress by remember { mutableStateOf(0f) }
    var localPerfScore by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    // local simulation for security diagnosis in dialog
    var isLocalSecScanning by remember { mutableStateOf(false) }
    var localSecProgress by remember { mutableStateOf(0f) }
    var localSecStatus by remember { mutableStateOf("") }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { 
                        Text(
                            text = if (isRtl) "حول الجهاز" else "About Device", 
                            fontWeight = FontWeight.Bold
                        ) 
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showGoldenNoteDialog = true }) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = ColorOS_Teal)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(bottom = 32.dp)
                ) {
                    // 1. ColorOS Top Luxury Metallic Dark Card Banner (Developer Edition)
                    item {
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                                        )
                                    )
                                    .padding(vertical = 28.dp, horizontal = 24.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "ColorOS",
                                            fontSize = 40.sp,
                                            fontWeight = FontWeight.Black,
                                            color = ColorOS_Teal,
                                            letterSpacing = (-1.sp)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(ColorOS_Teal.copy(alpha = 0.2f))
                                                .border(1.dp, ColorOS_Teal, RoundedCornerShape(8.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "v17.0 Ultimate",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = ColorOS_Teal
                                            )
                                        }
                                    }
                                    
                                    Spacer(modifier = Modifier.height(14.dp))
                                    
                                    Text(
                                        text = "OPPO Reno6 Pro+ Plus 5G",
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Developer Edition (UAE Custom Build)",
                                        fontSize = 13.sp,
                                        color = Color.White.copy(alpha = 0.6f)
                                    )
                                    
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Divider(color = Color.White.copy(alpha = 0.1f))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    
                                    Text(
                                        text = "Build: CPH9999_17.0.0.512 (EX01) – معدل للمطورين",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = ColorOS_Teal
                                    )
                                    Text(
                                        text = if (isRtl) "تاريخ الإصدار: ديسمبر 2024 (آخر تحديث أمني: يوليو 2026)" else "Released: December 2024 (Last security: July 2026)",
                                        fontSize = 11.sp,
                                        color = Color.White.copy(alpha = 0.5f)
                                    )
                                }
                            }
                        }
                    }

                    // 2. Device Official Status Indicators (Gift from YouTube & Closed Beta)
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                border = BorderStroke(1.dp, ColorOS_Teal.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CardGiftcard,
                                        contentDescription = null,
                                        tint = ColorOS_Teal,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = "📌 هدية رسمية من قناة يوتيوب – مقدم خصيصاً للمبدع / حمو الإلكتروني",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = Color.Red,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = "📌 غير مخصص للبيع – نسخة اختبارية مغلقة (Closed Beta)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Red
                                    )
                                }
                            }
                        }
                    }

                    // 3. Basic Specifications (⚙️ المواصفات الأساسية المُحسَّنة)
                    item {
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isRtl) "⚙️ المواصفات الأساسية (المُحسَّنة)" else "⚙️ Core Specifications (Enhanced)",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                TextButton(onClick = { showGoldenNoteDialog = true }) {
                                    Text(text = if (isRtl) "الملاحظة الذهبية" else "Golden Note", color = ColorOS_Teal, fontWeight = FontWeight.Bold)
                                }
                            }

                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    SpecItemRow(
                                        icon = Icons.Default.DeveloperMode,
                                        label = if (isRtl) "المعالج" else "Processor",
                                        value = "Qualcomm Snapdragon 8 Gen 4 (3nm) – Octa-core up to 4.2 GHz – نسخة مطورين مرفوعة التردد"
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SpecItemRow(
                                        icon = Icons.Default.Bolt,
                                        label = if (isRtl) "المعالج الرسومي" else "GPU",
                                        value = "Adreno 760 – مخصص للألعاب والذكاء الاصطناعي"
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SpecItemRow(
                                        icon = Icons.Default.Memory,
                                        label = "RAM",
                                        value = "18.00 GB LPDDR5X + 18.00 GB توسيع ذكي (Dynamic RAM Expansion) → إجمالي 36 GB"
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SpecItemRow(
                                        icon = Icons.Default.Storage,
                                        label = if (isRtl) "مساحة التخزين" else "Storage",
                                        value = "1.0 TB UFS 4.1 (قراءة/كتابة فائقة السرعة)"
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SpecItemRow(
                                        icon = Icons.Default.Smartphone,
                                        label = if (isRtl) "الشاشة" else "Display",
                                        value = "6.82 بوصة – AMOLED 2K+ (3200×1440) – 144Hz Adaptive Refresh – HDR10+ – Dimensity Eye Care"
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SpecItemRow(
                                        icon = Icons.Default.BatteryChargingFull,
                                        label = if (isRtl) "البطارية" else "Battery & Charging",
                                        value = "6500 mAh (نموذجية) – شحن سريع 150W SuperVOOC – شحن لاسلكي 50W – عكسى 15W"
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SpecItemRow(
                                        icon = Icons.Default.PhotoCamera,
                                        label = if (isRtl) "الكاميرا الخلفية" else "Rear Camera",
                                        value = "200MP رئيسية (Samsung ISOCELL HP3) + 64MP periscope telephoto (5x optical) + 50MP ultra-wide + 8MP macro + 2MP depth – مستشعرات مطورة بدقة 16-bit"
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SpecItemRow(
                                        icon = Icons.Default.CameraFront,
                                        label = if (isRtl) "الكاميرا الأمامية" else "Front Camera",
                                        value = "60MP (Sony IMX898) – تصوير 4K@120fps – فلاش مزدوج"
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SpecItemRow(
                                        icon = Icons.Default.Android,
                                        label = if (isRtl) "نظام التشغيل" else "OS & Kernel",
                                        value = "Android 17 (API 34) – مُعدَّل بأدوات أمن سيبراني متقدمة (FIPS 140-3 معتمد)"
                                    )
                                }
                            }
                        }
                    }

                    // 4. Cybersecurity & Developer Features (🔐 ميزات الأمان والمطورين)
                    item {
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = if (isRtl) "🔐 ميزات الأمان والمطورين" else "🔐 Security & Developer Features",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )

                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    SecurityFeatureItem(
                                        title = "وضع المطور الفائق (Super Developer Mode)",
                                        status = "مفعّل مسبقاً",
                                        color = ColorOS_Teal
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SecurityFeatureItem(
                                        title = "جدار ناري للأمان السيبراني",
                                        status = "حماية من هجمات الطبقة الثنائية (Kernel-level Protection)",
                                        color = ColorOS_Teal
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SecurityFeatureItem(
                                        title = "شهادة ISO 27001 و NIST",
                                        status = "خاصة بالنسخ الحكومية والمطورين",
                                        color = ColorOS_Teal
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SecurityFeatureItem(
                                        title = "تحديثات يومية OTA",
                                        status = "مباشرة من خوادم يوتيوب المخصصة",
                                        color = ColorOS_Teal
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    SecurityFeatureItem(
                                        title = "إلغاء القيود الجغرافية",
                                        status = "مفتوح لجميع الشبكات العالمية (غير مربوط بمنطقة)",
                                        color = ColorOS_Teal
                                    )
                                }
                            }
                        }
                    }

                    // 5. Interactive ColorOS AI Suite features grid
                    item {
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = if (isRtl) "🧩 ميزات وحزمة الذكاء الاصطناعي (ColorOS AI Suite)" else "🧩 ColorOS AI Suite",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AiFeatureCard(
                                    title = "AI Snap Key",
                                    desc = "زر مخصص لتشغيل الذكاء الاصطناعي",
                                    icon = Icons.Default.Key,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate?.invoke("ai_snap_key") }
                                )
                                AiFeatureCard(
                                    title = "AI Mind Space",
                                    desc = "حفظ وتنظيم المعلومات",
                                    icon = Icons.Default.Cloud,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate?.invoke("ai_mind_space") }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AiFeatureCard(
                                    title = "AI Mind Pilot",
                                    desc = "مساعد ذكي متعدد النماذج",
                                    icon = Icons.Default.Psychology,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate?.invoke("ai_mind_pilot") }
                                )
                                AiFeatureCard(
                                    title = "AI Bill Manager",
                                    desc = "إدارة الفواتير تلقائياً",
                                    icon = Icons.Default.ReceiptLong,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate?.invoke("ai_bill_manager") }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AiFeatureCard(
                                    title = "AI Menu Translation",
                                    desc = "ترجمة المنيو بالصور",
                                    icon = Icons.Default.Translate,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate?.invoke("ai_menu_translation") }
                                )
                                AiFeatureCard(
                                    title = "Pop Cam",
                                    desc = "تصوير إبداعي",
                                    icon = Icons.Default.PhotoCamera,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate?.invoke("pop_cam") }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AiFeatureCard(
                                    title = "AI Remix Collage",
                                    desc = "دمج الصور والفيديوهات",
                                    icon = Icons.Default.AutoAwesome,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate?.invoke("ai_remix_collage") }
                                )
                                AiFeatureCard(
                                    title = "4K Auto Straighten Video",
                                    desc = "تثبيت الفيديو تلقائياً",
                                    icon = Icons.Default.Videocam,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onNavigate?.invoke("video_straighten") }
                                )
                            }
                        }
                    }

                    // 6. Additional Buttons & Options (🧩 أزرار وخيارات إضافية)
                    item {
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = if (isRtl) "🛠️ أدوات وخيارات إضافية" else "🛠️ Custom Developer Extras",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )

                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    AboutItemRow(
                                        title = if (isRtl) "معلومات الشهادة الرقمية" else "Digital Certificate Info",
                                        trailing = "YouTube Creators Lab",
                                        isRtl = isRtl,
                                        onClick = { showDigitalCertDialog = true }
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), modifier = Modifier.padding(horizontal = 16.dp))
                                    AboutItemRow(
                                        title = if (isRtl) "سجل التحديثات التجريبي" else "Beta Update Log",
                                        trailing = "July 2026 Stable",
                                        isRtl = isRtl,
                                        onClick = { showBetaLogDialog = true }
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), modifier = Modifier.padding(horizontal = 16.dp))
                                    AboutItemRow(
                                        title = if (isRtl) "اختبار الأداء المتقدم" else "Advanced Performance Test",
                                        trailing = "AnTuTu 2026",
                                        isRtl = isRtl,
                                        onClick = { showPerformanceDialog = true }
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), modifier = Modifier.padding(horizontal = 16.dp))
                                    AboutItemRow(
                                        title = if (isRtl) "تشخيص الأمان السيبراني" else "Security Diagnosis",
                                        trailing = "Kernel Protection Active",
                                        isRtl = isRtl,
                                        onClick = { showSecurityDialog = true }
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), modifier = Modifier.padding(horizontal = 16.dp))
                                    AboutItemRow(
                                        title = if (isRtl) "هدية المطور" else "Developer Gift",
                                        trailing = "حمو الإلكتروني",
                                        isRtl = isRtl,
                                        onClick = { showGiftDialog = true }
                                    )
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), modifier = Modifier.padding(horizontal = 16.dp))
                                    AboutItemRow(
                                        title = if (isRtl) "اتصال الدعم المباشر" else "Direct Support Contact",
                                        trailing = "Dubai Dev Lab",
                                        isRtl = isRtl,
                                        onClick = { showSupportDialog = true }
                                    )
                                }
                            }
                        }
                    }

                    // 7. Actual Device Real Hardware Info (📱 المواصفات الحقيقية لجهازك)
                    item {
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = if (isRtl) "📱 المواصفات الحقيقية لجهازك" else "📱 Real Device Hardware Info",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )

                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    val batteryTemp by viewModel.batteryTemp.collectAsState()
                                    val batteryVoltage by viewModel.batteryVoltage.collectAsState()

                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (isRtl) "طراز الهاتف الفعلي" else "Actual Phone Model", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(viewModel.realDeviceModel, fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                    }
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (isRtl) "إصدار أندرويد الفعلي" else "Actual Android Version", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("Android ${viewModel.realAndroidVersion} (API ${viewModel.realApiLevel})", fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                    }
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (isRtl) "درجة حرارة البطارية" else "Battery Temperature", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(String.format("%.1f °C", batteryTemp), fontWeight = FontWeight.SemiBold, color = if (batteryTemp > 39) Color.Red else ColorOS_Teal, fontSize = 13.sp)
                                    }
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (isRtl) "جهد البطارية" else "Battery Voltage", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(String.format("%.2f V", batteryVoltage), fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                    }
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (isRtl) "عدد الأنوية الحقيقي" else "Actual CPU Cores", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${viewModel.realProcessorCores} Cores", fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                    }
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (isRtl) "تحديث الأمان الفعلي" else "Actual Security Patch", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(viewModel.realSecurityPatch, fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    // 8. Small footer text
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp, horizontal = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "نسخة مطورين – غير قابلة للبيع – هدية من يوتيوب",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            )
                        }
                    }
                }

                // ==========================================
                // DIALOGS
                // ==========================================

                // Golden Note Dialog
                if (showGoldenNoteDialog) {
                    AlertDialog(
                        onDismissRequest = { showGoldenNoteDialog = false },
                        title = {
                            Text(
                                text = if (isRtl) "📌 الملاحظة الذهبية للتطوير" else "📌 Golden Developer Note",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal
                            )
                        },
                        text = {
                            Text(
                                text = "هذا الإصدار هو النموذج الأولي النهائي من سلسلة Reno المطورة، تم تصنيعه في منشأة أبوظبي للتقنيات المتطورة، ولا يتوفر في أي متجر رسمي. يحتوي على معالج مُرفوع التردد بنسبة 30% عن الإصدار التجاري، مع تحسينات في إدارة الحرارة تسمح بتشغيل الألعاب الثقيلة دون أي ارتفاع في درجة الحرارة. تم اختباره لمدة 6 أشهر في بيئات الضغط العالي، وحصل على أعلى تقييم في مختبرات DXOMark (166 نقطة للكاميرا، و 215 نقطة للأداء العام).",
                                fontSize = 14.sp,
                                lineHeight = 20.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = { showGoldenNoteDialog = false }) {
                                Text(if (isRtl) "إغلاق" else "Close", color = ColorOS_Teal, fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                }

                // Digital Certificate Dialog
                if (showDigitalCertDialog) {
                    AlertDialog(
                        onDismissRequest = { showDigitalCertDialog = false },
                        title = {
                            Text(
                                text = if (isRtl) "الشهادة الرقمية المعتمدة" else "Digital Certificate",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal
                            )
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                DialogField("Authorized Issuer:", "YouTube Creators Lab")
                                DialogField("Recipient Name:", "حمو الإلكتروني / Hamo Electronic")
                                DialogField("Authority Lab:", "ATRC Abu Dhabi Technologies Lab")
                                DialogField("Serial Identifier:", "YT-CREATORS-LAB-RE6P-9999")
                                DialogField("Security Standard:", "FIPS 140-3 Active Compliance")
                                DialogField("Verification Status:", "✅ معتمد وموثق رقمياً بنجاح")
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "تم التحقق من سلامة البناء ونظام التشغيل وتوقيع النواة بواسطة خوادم يوتيوب الرسمية ومجلس أبحاث التكنولوجيا المتطورة بدبي وأبوظبي.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showDigitalCertDialog = false }) {
                                Text(if (isRtl) "موافق" else "OK", color = ColorOS_Teal)
                            }
                        }
                    )
                }

                // Beta Update Log Dialog
                if (showBetaLogDialog) {
                    AlertDialog(
                        onDismissRequest = { showBetaLogDialog = false },
                        title = {
                            Text(
                                text = if (isRtl) "سجل التحديثات التجريبي" else "Beta Update Log",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal
                            )
                        },
                        text = {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.heightIn(max = 300.dp)
                            ) {
                                item {
                                    BetaLogItem(
                                        version = "v17.0.0.512 (2026-07-10)",
                                        desc = "تحسين إدارة السطوع الأقصى لـ 2600 nits وتحديث بروتوكول تبريد السائل وتفادي الحرارة تحت ضغط الألعاب الثقيلة."
                                    )
                                }
                                item {
                                    BetaLogItem(
                                        version = "v17.0.0.488 (2026-06-28)",
                                        desc = "ترقية النواة لتطابق معايير NIST للتشفير الفيدرالي وحظر هجمات كسر الحماية أو الاختراقات المحلية."
                                    )
                                }
                                item {
                                    BetaLogItem(
                                        version = "v17.0.0.420 (2026-05-15)",
                                        desc = "دعم شبكات الجيل الخامس الهجينة في دبي وتفعيل كسر تردد المعالج لـ 4.2 GHz بشكل آمن."
                                    )
                                }
                                item {
                                    BetaLogItem(
                                        version = "v17.0.0.310 (2026-04-02)",
                                        desc = "ترقية خوارزمية تجميع الصور AI Remix Collage ودقة التقريب البصري للكاميرا بدقة 200MP."
                                    )
                                }
                                item {
                                    BetaLogItem(
                                        version = "v17.0.0.100 (2026-01-20)",
                                        desc = "البناء التجريبي الأول لنظام ColorOS 17 Ultimate المستقر وإعداد جدار الحماية للأنوية."
                                    )
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showBetaLogDialog = false }) {
                                Text(if (isRtl) "إغلاق" else "Close", color = ColorOS_Teal)
                            }
                        }
                    )
                }

                // Advanced Performance Test Dialog (AnTuTu)
                if (showPerformanceDialog) {
                    AlertDialog(
                        onDismissRequest = { 
                            if (!isLocalPerfTesting) showPerformanceDialog = false 
                        },
                        title = {
                            Text(
                                text = "AnTuTu Benchmark - extreme v11",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal
                            )
                        },
                        text = {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Text(
                                    text = if (isRtl) "قياس قدرات معالج Snapdragon 8 Gen 4 مكسور السرعة في هاتف المطورين." else "Stress-test the Snapdragon 8 Gen 4 processor.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )

                                if (isLocalPerfTesting) {
                                    CircularProgressIndicator(color = ColorOS_Teal, modifier = Modifier.size(48.dp))
                                    Text(
                                        text = when {
                                            localPerfProgress < 0.25f -> "جاري فحص نواة المعالج Cortex-X5..."
                                            localPerfProgress < 0.5f -> "جاري اختبار محرك الرسوميات Adreno 760 Extreme..."
                                            localPerfProgress < 0.75f -> "جاري قياس سرعة قراءة وكتابة UFS 4.1..."
                                            else -> "جاري ضغط وتقييم الذاكرة العشوائية 36GB..."
                                        } + " ${String.format("%.0f%%", localPerfProgress * 100)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = ColorOS_Teal,
                                        textAlign = TextAlign.Center
                                    )
                                    LinearProgressIndicator(
                                        progress = localPerfProgress,
                                        color = ColorOS_Teal,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(CircleShape)
                                    )
                                } else {
                                    if (localPerfScore > 0) {
                                        Text(
                                            text = if (isRtl) "النتيجة الخارقة المحققة:" else "Extreme Score Reached:",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "3,254,128",
                                            fontSize = 38.sp,
                                            fontWeight = FontWeight.Black,
                                            color = ColorOS_Teal
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color.Green.copy(alpha = 0.15f))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = if (isRtl) "يتفوق على 100% من الأجهزة عالمياً! (+42%)" else "Outperforms 100% of global devices!",
                                                fontSize = 11.sp,
                                                color = Color.Green,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text(
                                            text = "تم قياس الضغط العالي مع الحفاظ على حرارة 34 درجة مئوية بفضل تبريد سائل أبوظبي المتقدم.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = TextAlign.Center
                                        )
                                    } else {
                                        Button(
                                            onClick = {
                                                isLocalPerfTesting = true
                                                localPerfProgress = 0f
                                                scope.launch {
                                                    while (localPerfProgress < 1.0f) {
                                                        delay(100)
                                                        localPerfProgress += 0.04f
                                                    }
                                                    localPerfProgress = 1.0f
                                                    localPerfScore = 3254128
                                                    isLocalPerfTesting = false
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = ColorOS_Teal),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(if (isRtl) "بدء اختبار الأداء الفائق" else "Start Performance Test")
                                        }
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                onClick = { showPerformanceDialog = false },
                                enabled = !isLocalPerfTesting
                            ) {
                                Text(if (isRtl) "إغلاق" else "Close", color = ColorOS_Teal)
                            }
                        }
                    )
                }

                // Security Diagnosis Dialog
                if (showSecurityDialog) {
                    AlertDialog(
                        onDismissRequest = { 
                            if (!isLocalSecScanning) showSecurityDialog = false 
                        },
                        title = {
                            Text(
                                text = if (isRtl) "تشخيص الأمان السيبراني" else "Kernel Cybersecurity Shield",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal
                            )
                        },
                        text = {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                if (isLocalSecScanning) {
                                    CircularProgressIndicator(color = ColorOS_Teal, modifier = Modifier.size(48.dp))
                                    Text(
                                        text = localSecStatus + " ${String.format("%.0f%%", localSecProgress * 100)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = ColorOS_Teal,
                                        textAlign = TextAlign.Center
                                    )
                                    LinearProgressIndicator(
                                        progress = localSecProgress,
                                        color = ColorOS_Teal,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(CircleShape)
                                    )
                                } else {
                                    if (localSecStatus.contains("نجاح")) {
                                        Text(
                                            text = "تم اجتياز جميع اختبارات الاختراق بنجاح!",
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Green,
                                            fontSize = 15.sp
                                        )
                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            PassItem("✅ عزل الذاكرة الحيوية (Hardware Isolation)")
                                            PassItem("✅ حماية جدار الحماية للأنوية (Kernel Defense)")
                                            PassItem("✅ تشفير البيانات العسكري (Military Data Enc)")
                                            PassItem("✅ شهادة ISO 27001 النشطة")
                                            PassItem("✅ شهادة NIST FIPS 140-3 المعتمدة")
                                        }
                                    } else {
                                        Text(
                                            text = "فحص متقدم لأمان النواة وثغرات الأجهزة الحيوية وتشفير البيانات.",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = TextAlign.Center
                                        )
                                        Button(
                                            onClick = {
                                                isLocalSecScanning = true
                                                localSecProgress = 0f
                                                scope.launch {
                                                    val stages = listOf(
                                                        "جاري فحص سلامة النواة...",
                                                        "جاري فحص التشفير والمفاتيح...",
                                                        "جاري فحص عزل الذاكرة العشوائية...",
                                                        "جاري اختبار جدار الحماية ضد الثغرات..."
                                                    )
                                                    var stageIdx = 0
                                                    while (localSecProgress < 1.0f) {
                                                        delay(120)
                                                        localSecProgress += 0.05f
                                                        stageIdx = (localSecProgress * stages.size).toInt().coerceIn(0, stages.size - 1)
                                                        localSecStatus = stages[stageIdx]
                                                    }
                                                    localSecProgress = 1.0f
                                                    localSecStatus = "تم اجتياز الفحص بنجاح!"
                                                    isLocalSecScanning = false
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onSurface),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(if (isRtl) "بدء الفحص والتشخيص" else "Start Diagnosis Scan")
                                        }
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                onClick = { showSecurityDialog = false },
                                enabled = !isLocalSecScanning
                            ) {
                                Text(if (isRtl) "إغلاق" else "Close", color = ColorOS_Teal)
                            }
                        }
                    )
                }

                // Developer Gift Dialog
                if (showGiftDialog) {
                    AlertDialog(
                        onDismissRequest = { showGiftDialog = false },
                        title = {
                            Text(
                                text = "🎁 هدية المطور | Developer Gift",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal
                            )
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "هذا الجهاز مُهدى إلى حمو الإلكتروني تقديراً لإبداعه في المحتوى التقني",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ColorOS_Teal,
                                    lineHeight = 22.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "نسخة ذهبية حصرية مطورة خصيصاً بمواصفات خارقة من معامل YouTube Creators Lab بالتنسيق مع منشأة أبوظبي للتقنيات المتطورة، تقديرًا لجهوده المستمرة في تقديم مراجعات تكنولوجية رائدة ونزيهة لمتابعيه في الشرق الأوسط والعالم.",
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showGiftDialog = false }) {
                                Text(if (isRtl) "شكراً" else "Thank You", color = ColorOS_Teal, fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                }

                // Direct Support Contact Dialog
                if (showSupportDialog) {
                    AlertDialog(
                        onDismissRequest = { showSupportDialog = false },
                        title = {
                            Text(
                                text = if (isRtl) "الاتصال المباشر بالمطورين" else "Emirati Developer Support",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal
                            )
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = null, tint = ColorOS_Teal)
                                    Text(
                                        text = "+971 800-DEV-UAE",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = ColorOS_Teal
                                    )
                                }
                                Text(
                                    text = if (isRtl) "الخط الساخن الحصري المفتوح على مدار الساعة لخدمة حمو الإلكتروني وتلبية التخصيصات والبرمجيات الخاصة بالنظام الإماراتي ومجلس الأبحاث المتطورة بدبي وأبوظبي." else "Exclusive 24/7 hotline dedicated for Hamo Electronic to command custom kernel patches and developer support directly from Dubai labs.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 16.sp
                                )
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showSupportDialog = false }) {
                                Text(if (isRtl) "حسناً" else "OK", color = ColorOS_Teal)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AboutItemRow(title: String, trailing: String = "", isRtl: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (trailing.isNotEmpty()) {
                    Text(
                        text = trailing,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(
                    imageVector = if (isRtl) Icons.AutoMirrored.Filled.ArrowBack else Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun SpecRow(label: String, value: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ColorOS_Teal)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun PassItem(text: String) {
    Text(
        text = text,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        color = Color.Green,
        modifier = Modifier.padding(vertical = 2.dp)
    )
}

@Composable
fun DialogField(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ColorOS_Teal)
    }
}

@Composable
fun BetaLogItem(version: String, desc: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(text = version, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ColorOS_Teal)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 16.sp)
    }
}

@Composable
fun SpecItemRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(ColorOS_Teal.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ColorOS_Teal,
                modifier = Modifier.size(18.dp)
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 16.sp)
        }
    }
}

@Composable
fun SecurityFeatureItem(title: String, status: String, color: Color) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(2.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(text = status, fontSize = 12.sp, color = color, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun AiFeatureCard(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)),
        modifier = modifier.height(110.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = ColorOS_Teal)
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = ColorOS_Teal,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = desc,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ====================================================================
// NEW PREMIUM INTERACTIVE SCREENS FOR HAMO ELECTRONIC'S SPECIAL SUITE
// ====================================================================

// 1. AI SNAP KEY SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSnapKeyScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val snapAction by viewModel.aiSnapKeyAction.collectAsState()
    var showLaserEffect by remember { mutableStateOf(false) }
    
    val infiniteTransition = rememberInfiniteTransition()
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("AI Snap Key", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Device Mockup Card
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Box(
                            modifier = Modifier
                                .width(110.dp)
                                .height(180.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color.DarkGray)
                                .border(2.dp, Color.LightGray, RoundedCornerShape(18.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(4.dp)
                                    .background(Color.Black)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(Color.DarkGray)
                                        .align(Alignment.TopCenter)
                                        .padding(top = 4.dp)
                                )

                                if (showLaserEffect) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .rotate(rotation)
                                            .background(
                                                Brush.radialGradient(
                                                    colors = listOf(ColorOS_Teal.copy(alpha = 0.6f), Color.Transparent)
                                                )
                                            )
                                    )
                                    Text(
                                        text = "AI LENS ON",
                                        color = ColorOS_Teal,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.align(Alignment.Center)
                                    )
                                }
                            }

                            // Glowing active hardware side button
                            Box(
                                modifier = Modifier
                                    .size(6.dp, 24.dp)
                                    .align(Alignment.CenterEnd)
                                    .background(if (showLaserEffect) Color.Red else ColorOS_Teal)
                                    .clickable { showLaserEffect = !showLaserEffect }
                            )
                        }
                    }
                }

                Text(
                    text = if (isRtl) "انقر على الزر الأحمر الجانبي في الهاتف الافتراضي لتنشيط تأثير الليزر والعدسة الذكية!" else "Click the glowing side key in the mockup to trigger custom AI Laser waves!",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                Text(
                    text = if (isRtl) "تخصيص الإجراء السريع للمفتاح" else "Choose Snap Key Quick Action",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = ColorOS_Teal,
                    modifier = Modifier.align(Alignment.Start)
                )

                val actions = listOf(
                    "launch_pilot" to (if (isRtl) "تشغيل المساعد الذكي AI Mind Pilot" else "Launch AI Mind Pilot"),
                    "open_mindspace" to (if (isRtl) "فتح مفكرة الأفكار المشفرة AI Mind Space" else "Open AI Mind Space Logs"),
                    "translate" to (if (isRtl) "ترجمة الشاشة الفورية بالعدسة الذكية" else "Instant Lens Translation"),
                    "cyber" to (if (isRtl) "فحص الحماية وتنشيط جدار الحماية الناري" else "Trigger Dual Cyber Firewall")
                )

                actions.forEach { (key, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.setAiSnapKeyAction(key) }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = snapAction == key,
                            onClick = { viewModel.setAiSnapKeyAction(key) },
                            colors = RadioButtonDefaults.colors(selectedColor = ColorOS_Teal)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

// 2. AI MIND SPACE SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiMindSpaceScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val notes by viewModel.mindSpaceNotes.collectAsState()

    var noteTitle by remember { mutableStateOf("") }
    var noteContent by remember { mutableStateOf("") }
    var selectedTag by remember { mutableStateOf("Tech") }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("AI Mind Space", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Add note form
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = if (isRtl) "إضافة ملاحظة مشفرة جديدة" else "Secure New Encrypted Note",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal,
                                fontSize = 14.sp
                            )
                            
                            OutlinedTextField(
                                value = noteTitle,
                                onValueChange = { noteTitle = it },
                                label = { Text(if (isRtl) "العنوان" else "Title") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ColorOS_Teal)
                            )
                            
                            OutlinedTextField(
                                value = noteContent,
                                onValueChange = { noteContent = it },
                                label = { Text(if (isRtl) "المحتوى" else "Content") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2,
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ColorOS_Teal)
                            )

                            // Tag Selection row
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("YouTube", "Tech", "أمن", "مطور").forEach { tag ->
                                    val isSelected = selectedTag == tag
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) ColorOS_Teal else ColorOS_Teal.copy(alpha = 0.1f),
                                        modifier = Modifier.clickable { selectedTag = tag }
                                    ) {
                                        Text(
                                            text = tag,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else ColorOS_Teal,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    if (noteTitle.isNotBlank() && noteContent.isNotBlank()) {
                                        viewModel.addMindNote(noteTitle, noteContent, selectedTag)
                                        noteTitle = ""
                                        noteContent = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ColorOS_Teal),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isRtl) "حفظ ومزامنة فورية" else "Secure & Sync")
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (isRtl) "الملاحظات المشفرة المخزنة" else "Encrypted Developer Logs",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                // Render logs list
                if (notes.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text(if (isRtl) "لا توجد ملاحظات مخزنة حالياً." else "No records found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    items(notes.size) { index ->
                        val note = notes[index]
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = ColorOS_Teal.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = note.tag,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = ColorOS_Teal,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                    IconButton(onClick = { viewModel.deleteMindNote(note.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red.copy(alpha = 0.8f))
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(note.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ColorOS_Teal)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(note.content, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(note.date, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

// 3. AI MIND PILOT SCREEN (Chatbot with customized responses)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiMindPilotScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val messages by viewModel.chatMessages.collectAsState()
    val isGenerating by viewModel.isGeneratingResponse.collectAsState()
    var textInput by remember { mutableStateOf("") }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier.size(10.getDp()).clip(CircleShape).background(Color.Green)
                            )
                            Text("AI Mind Pilot", fontWeight = FontWeight.Bold)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Pre-defined clickable prompt chips at the top
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val promptChips = listOf(
                        if (isRtl) "قوة المعالج 🚀" else "CPU Power 🚀",
                        if (isRtl) "مساحة الرام 💾" else "RAM Size 💾",
                        if (isRtl) "جدار الحماية 🛡️" else "Firewall 🛡️"
                    )
                    promptChips.forEach { prompt ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ColorOS_Teal.copy(alpha = 0.1f),
                            border = BorderStroke(1.dp, ColorOS_Teal.copy(alpha = 0.2f)),
                            modifier = Modifier.clickable {
                                textInput = prompt
                            }
                        ) {
                            Text(
                                text = prompt,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ColorOS_Teal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                // Chat Messages Space
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages.size) { index ->
                        val msg = messages[index]
                        val isUser = msg.isUser
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Card(
                                shape = RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isUser) 16.dp else 2.dp,
                                    bottomEnd = if (isUser) 2.dp else 16.dp
                                ),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isUser) ColorOS_Teal else MaterialTheme.colorScheme.surface
                                ),
                                modifier = Modifier.widthIn(max = 280.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = msg.text,
                                        fontSize = 14.sp,
                                        color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                                        lineHeight = 19.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = msg.timestamp,
                                        fontSize = 9.sp,
                                        color = if (isUser) Color.White.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier.align(Alignment.End)
                                    )
                                }
                            }
                        }
                    }

                    if (isGenerating) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(8.dp),
                                horizontalArrangement = Arrangement.Start
                            ) {
                                Text(
                                    text = if (isRtl) "جاري مراجعة النواة وصياغة الرد..." else "Analyzing kernel data...",
                                    fontSize = 12.sp,
                                    color = ColorOS_Teal,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // Input Space with Fill Style
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text(if (isRtl) "اسأل مساعد المطورين هنا..." else "Command AI Mind Pilot...") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ColorOS_Teal),
                        shape = RoundedCornerShape(24.dp)
                    )
                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessageToPilot(textInput)
                                textInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(ColorOS_Teal)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                    }
                }
            }
        }
    }
}

// 4. AI BILL MANAGER SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiBillManagerScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val isScanning by viewModel.isScanningBill.collectAsState()
    val bills by viewModel.scannedBills.collectAsState()

    val infiniteTransition = rememberInfiniteTransition()
    val laserOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 180f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("AI Bill Manager", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Viewfinder Mockup
                item {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            // Viewfinder lines
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(24.dp)
                                    .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            ) {
                                // Flashing laser line
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(2.dp)
                                        .padding(horizontal = 10.dp)
                                        .offset(y = laserOffset.getDp())
                                        .background(Color.Red)
                                        .border(2.dp, Color.Red)
                                )
                                
                                Text(
                                    text = if (isScanning) "SCANNING RECEIPT..." else "READY FOR DOCUMENT SCAN",
                                    color = if (isScanning) Color.Red else ColorOS_Teal,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .padding(8.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (isRtl) "اختر إيصال تقني لمحاكاة مسحه ضوئياً:" else "Select an invoice to scan:",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                // Scan Action triggers
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.scanBill("شراء Snapdragon Developer Pack") },
                            colors = ButtonDefaults.buttonColors(containerColor = ColorOS_Teal),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isRtl) "فاتورة المعالج 🧾" else "Scan Processor 🧾")
                        }
                        Button(
                            onClick = { viewModel.scanBill("مشتريات استوديو يوتيوب دبي") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onSurface),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isRtl) "استوديو دبي 🎙️" else "Scan Studio 🎙️")
                        }
                    }
                }

                item {
                    Text(
                        text = if (isRtl) "سجل الفواتير والمصروفات الذكية (محللة بالكامل)" else "Scanned Receipts History (AED)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOS_Teal
                    )
                }

                // History records
                items(bills.size) { index ->
                    val bill = bills[index]
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(ColorOS_Teal.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Receipt, contentDescription = null, tint = ColorOS_Teal)
                                }
                                Text(bill.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(bill.details, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

// 5. AI MENU TRANSLATION SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiMenuTranslationScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val isTranslating by viewModel.isTranslatingMenu.collectAsState()
    val translationResult by viewModel.menuTranslationResult.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("AI Menu Translation", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Intro Guide
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (isRtl) "مترجم قوائم الطعام الذكي بالإمارات" else "UAE Restaurant Smart Lens",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isRtl) "قم بتجربة مسح وترجمة قوائم المطاعم الفاخرة في دبي وأبوظبي فوراً بدقة عالية." else "Experience rapid lens overlays for high-end dining lists in Dubai.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        onClick = { viewModel.translateMenu("dubai_yacht_club") },
                        modifier = Modifier
                            .weight(1f)
                            .height(80.getDp()),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                if (isRtl) "نادي اليخوت بمرسى دبي 🛥️" else "Dubai Yacht Club 🛥️",
                                textAlign = TextAlign.Center,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Card(
                        onClick = { viewModel.translateMenu("airport_lounge") },
                        modifier = Modifier
                            .weight(1f)
                            .height(80.getDp()),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                if (isRtl) "صالة كبار الشخصيات بأبوظبي ✈️" else "Abu Dhabi Lounge ✈️",
                                textAlign = TextAlign.Center,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Translation Display Area
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.DarkGray),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                        if (isTranslating) {
                            CircularProgressIndicator(
                                color = ColorOS_Teal,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else {
                            if (translationResult.isNotBlank()) {
                                LazyColumn(modifier = Modifier.fillMaxSize()) {
                                    item {
                                        Text(
                                            text = translationResult,
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            lineHeight = 22.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    text = if (isRtl) "الرجاء تحديد لائحة طعام أعلاه لتجربة الترجمة الذكية الفورية!" else "Select a menu from above to overlay live translations!",
                                    color = Color.LightGray,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 6. POP CAM SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PopCamScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val activeFilter by viewModel.popCamFilter.collectAsState()
    val smoothLevel by viewModel.aiSmoothLevel.collectAsState()
    var isCapturing by remember { mutableStateOf(false) }
    var captureSuccessMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Pop Cam (200MP)", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Viewfinder simulation
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Flashing White on capturing
                        if (isCapturing) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.White)
                            )
                        } else {
                            // Render colored filter tint
                            val filterTint = when (activeFilter) {
                                "Cyberpunk" -> Color.Magenta.copy(alpha = 0.15f)
                                "Sunset" -> Color.Red.copy(alpha = 0.15f)
                                "Emerald" -> ColorOS_Teal.copy(alpha = 0.15f)
                                else -> Color.Transparent
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(filterTint),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "RAW 16-BIT ACTIVE",
                                        color = Color.White.copy(alpha = 0.5f),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        "SAMSUNG ISOCELL HP3 - 200MP",
                                        color = ColorOS_Teal,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Success notification overlay
                        if (captureSuccessMessage.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.Black.copy(alpha = 0.8f),
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(16.dp)
                            ) {
                                Text(
                                    text = captureSuccessMessage,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }

                // Filter selectors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Cyberpunk", "Sunset", "Emerald", "Raw_16Bit").forEach { filter ->
                        val isSelected = activeFilter == filter
                        Card(
                            onClick = { viewModel.setPopCamFilter(filter) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) ColorOS_Teal else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Box(modifier = Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text = filter,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // Smoothing Level slider
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (isRtl) "مستوى نعومة البشرة بالذكاء الاصطناعي: ${String.format("%.0f%%", smoothLevel * 100)}" else "AI Skin Smoothness: ${String.format("%.0f%%", smoothLevel * 100)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = smoothLevel,
                        onValueChange = { viewModel.setAiSmoothLevel(it) },
                        colors = SliderDefaults.colors(thumbColor = ColorOS_Teal, activeTrackColor = ColorOS_Teal)
                    )
                }

                // Shutter trigger button
                IconButton(
                    onClick = {
                        scope.launch {
                            isCapturing = true
                            delay(150)
                            isCapturing = false
                            captureSuccessMessage = if (isRtl) "تم حفظ صورة 200MP بمجلد الحفظ الإماراتي بنجاح!" else "200MP RAW saved to Abu Dhabi Secure Storage!"
                            delay(2000)
                            captureSuccessMessage = ""
                        }
                    },
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(ColorOS_Teal)
                        .border(3.dp, Color.White, CircleShape)
                ) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = Color.White)
                }
            }
        }
    }
}

// 7. AI REMIX COLLAGE SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiRemixCollageScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var isCollaging by remember { mutableStateOf(false) }
    var collageGeneratedCode by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("AI Remix Collage", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isRtl) "محرك دمج وتنسيق الصور بالذكاء الاصطناعي" else "AI Layout Collage Maker",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(4.getDp()))
                        Text(
                            text = if (isRtl) "انقر على زر إعادة الخلط لمشاهدة تأثير ترتيب الصور الفني المذهل." else "Press Remix to watch automated image alignment algorithms in real time.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }

                // Simulated Workspace Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.DarkGray),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCollaging) {
                        CircularProgressIndicator(color = ColorOS_Teal)
                    } else {
                        if (collageGeneratedCode > 0) {
                            // Beautiful grids depending on random remix
                            Row(modifier = Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(modifier = Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(ColorOS_Teal.copy(alpha = 0.4f)), contentAlignment = Alignment.Center) { Text("UAE Tech", color = Color.White, fontSize = 11.sp) }
                                    Box(modifier = Modifier.weight(1.5f).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.Gray), contentAlignment = Alignment.Center) { Text("Reno 6 Pro+", color = Color.White, fontSize = 11.sp) }
                                }
                                Column(modifier = Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(modifier = Modifier.weight(1.8f).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.LightGray), contentAlignment = Alignment.Center) { Text("Dubai Marina", color = Color.DarkGray, fontSize = 11.sp) }
                                    Box(modifier = Modifier.weight(0.8f).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(ColorOS_Teal), contentAlignment = Alignment.Center) { Text("Developer", color = Color.White, fontSize = 11.sp) }
                                }
                            }
                        } else {
                            Text(
                                text = if (isRtl) "مساحة العمل فارغة. انقر على خلط الصور أدناه!" else "Canvas empty. Click Remix to populate layouts!",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        scope.launch {
                            isCollaging = true
                            delay(1200)
                            isCollaging = false
                            collageGeneratedCode = (1..5).random()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ColorOS_Teal),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.GridOn, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.getDp()))
                    Text(if (isRtl) "إعادة خلط وتنسيق الصور بالذكاء الاصطناعي" else "Generate Smart Collage Remix")
                }
            }
        }
    }
}

// 8. VIDEO STRAIGHTEN SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoStraightenScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val isStraightActive by viewModel.isVideoStraighteningActive.collectAsState()
    val stabilityScore by viewModel.videoStabilityScore.collectAsState()

    val infiniteTransition = rememberInfiniteTransition()
    val driftOffset by infiniteTransition.animateFloat(
        initialValue = -15f,
        targetValue = 15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("4K Auto Straighten Video", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (isRtl) "تثبيت الأفق وموازنة الفيديو الآلية" else "Active Gyroscopic Horizon Lock",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isRtl) "يقوم بتثبيت وموازنة حواف تصوير الفيديو بدقة 4K@120fps بشكل ديناميكي لمقاومة الاهتزاز." else "Dynamically straightens and aligns camera outputs during heavy actions.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }

                // Horizon view player simulator
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Horizontal leveling bar tilting depending on state
                        val tiltAngle = if (isStraightActive) 0f else driftOffset
                        
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .align(Alignment.Center)
                                .rotate(tiltAngle)
                                .background(if (isStraightActive) Color.Green else Color.Red)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(if (isStraightActive) Color.Green else Color.Red)
                                    .align(Alignment.Center)
                            )
                        }

                        // Telemetry data overlay
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "STABILITY INDEX: ${String.format("%.0f%%", stabilityScore * 100)}",
                                color = if (isStraightActive) Color.Green else Color.Red,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "HORIZON CALIBRATION: ${if (isStraightActive) "LOCKED 0.0°" else "DRIFT DETECTED"}",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Switch lock
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Default.VideoCameraBack, contentDescription = null, tint = ColorOS_Teal)
                            Text(
                                text = if (isRtl) "قفل وموازنة الأفق تلقائياً" else "Auto Horizon Stabilization Lock",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Switch(
                            checked = isStraightActive,
                            onCheckedChange = { viewModel.toggleVideoStraightening() },
                            colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 9: Mobile Network Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MobileNetworkScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var isMobileDataOn by remember { mutableStateOf(true) }
    var isDataRoamingOn by remember { mutableStateOf(false) }
    var selectedNetworkType by remember { mutableStateOf("5G Auto") }
    
    var isDiagnosing by remember { mutableStateOf(false) }
    var diagnosisProgress by remember { mutableStateOf(0f) }
    var diagnosisResult by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "شبكة الهاتف" else "Mobile Network", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = if (isRtl) "معلومات البطاقة والمشغل" else "SIM Card & Carrier",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(ColorOS_Teal.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("1", color = ColorOS_Teal, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("WE UAE", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(if (isRtl) "مكالمات ورسائل وإنترنت" else "Calls, SMS & Data", color = Color.Gray, fontSize = 11.sp)
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(ColorOS_Teal)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(if (isRtl) "نشط" else "ACTIVE", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(if (isRtl) "بيانات الهاتف" else "Mobile Data", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(if (isRtl) "الوصول إلى الإنترنت عبر شبكة الجوال" else "Access internet via mobile network", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isMobileDataOn,
                                onCheckedChange = { isMobileDataOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(if (isRtl) "تجوال البيانات" else "Data Roaming", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(if (isRtl) "الاتصال بالبيانات أثناء التجوال" else "Connect to data services when roaming", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isDataRoamingOn,
                                onCheckedChange = { isDataRoamingOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (isRtl) "نوع الشبكة المفضل" else "Preferred Network Type", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        listOf("5G Auto", "4G/3G/2G Auto", "3G/2G Auto").forEach { network ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedNetworkType = network }
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(network, color = if (selectedNetworkType == network) ColorOS_Teal else Color.White, fontSize = 13.sp)
                                RadioButton(
                                    selected = selectedNetworkType == network,
                                    onClick = { selectedNetworkType = network },
                                    colors = RadioButtonDefaults.colors(selectedColor = ColorOS_Teal, unselectedColor = Color.Gray)
                                )
                            }
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = if (isRtl) "أداة تشخيص شبكة الجوال" else "Carrier Network Diagnostics",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isRtl) "قم بفحص سرعة واستقرار شبكة الجوال في منطقتك حالياً." else "Test mobile connection latency and bandwidth in real time.",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )

                        if (isDiagnosing) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                LinearProgressIndicator(
                                    progress = diagnosisProgress,
                                    modifier = Modifier.fillMaxWidth(),
                                    color = ColorOS_Teal,
                                    trackColor = Color(0xFF262626)
                                )
                                Text(
                                    text = if (isRtl) "جاري القياس والاختبار... ${String.format("%.0f%%", diagnosisProgress * 100)}" else "Testing connection parameters... ${String.format("%.0f%%", diagnosisProgress * 100)}",
                                    fontSize = 11.sp,
                                    color = ColorOS_Teal
                                )
                            }
                        }

                        diagnosisResult?.let { result ->
                            Text(
                                text = result,
                                fontSize = 13.sp,
                                color = Color.Green,
                                lineHeight = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .background(Color.Green.copy(alpha = 0.05f))
                                    .border(1.dp, Color.Green.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                                    .fillMaxWidth()
                            )
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    isDiagnosing = true
                                    diagnosisProgress = 0f
                                    diagnosisResult = null
                                    while (diagnosisProgress < 1f) {
                                        delay(150)
                                        diagnosisProgress += 0.05f
                                    }
                                    isDiagnosing = false
                                    diagnosisResult = if (isRtl) {
                                        "✅ اكتمال الفحص:\nالاستجابة (Ping): ١٢ مللي ثانية\nالسرعة الفعلية: ٤٨٥ ميجابت/ثانية\nجودة الإشارة: ممتاز (5G)"
                                    } else {
                                        "✅ Diagnostic Complete:\nLatency (Ping): 12 ms\nReal Speed: 485 Mbps\nSignal Quality: Excellent (5G)"
                                    }
                                }
                            },
                            enabled = !isDiagnosing,
                            colors = ButtonDefaults.buttonColors(containerColor = ColorOS_Teal),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isRtl) "بدء فحص الشبكة" else "Run Network Diagnostics", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 10: Connection & Sharing Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectionSharingScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var isHotspotOn by remember { mutableStateOf(false) }
    var hotspotSsid by remember { mutableStateOf("OPPO Reno6 Pro 5G") }
    var isBluetoothTetheringOn by remember { mutableStateOf(false) }
    var isVpnConnected by remember { mutableStateOf(false) }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "الاتصال والمشاركة" else "Connection & Sharing", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(if (isRtl) "نقطة اتصال شخصية" else "Personal Hotspot", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(if (isRtl) "مشاركة إنترنت الهاتف عبر Wi-Fi" else "Share mobile network via Wi-Fi", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isHotspotOn,
                                onCheckedChange = { isHotspotOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                        if (isHotspotOn) {
                            Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (isRtl) "اسم نقطة الاتصال" else "Hotspot Name", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = hotspotSsid,
                                    onValueChange = { hotspotSsid = it },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedContainerColor = Color.Black,
                                        unfocusedContainerColor = Color.Black,
                                        focusedBorderColor = ColorOS_Teal
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(if (isRtl) "مشاركة عبر بلوتوث" else "Bluetooth Tethering", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(if (isRtl) "مشاركة الإنترنت عبر البلوتوث" else "Share internet connection via Bluetooth", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isBluetoothTetheringOn,
                                onCheckedChange = { isBluetoothTetheringOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (isRtl) "خدمات الشبكة الافتراضية VPN" else "Virtual Private Network (VPN)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("UAE Secure Dev Gateway", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(if (isVpnConnected) (if (isRtl) "متصل بالبوابة" else "CONNECTED") else (if (isRtl) "مفصول" else "DISCONNECTED"), color = if (isVpnConnected) Color.Green else Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isVpnConnected,
                                onCheckedChange = { isVpnConnected = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 11: Home & Lock Screen Settings
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeLockScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var selectedGrid by remember { mutableStateOf("5x6") }
    var selectedSpeed by remember { mutableStateOf("Fast") }
    var isDoubleTapToWakeOn by remember { mutableStateOf(true) }
    var isAlwaysOnDisplayOn by remember { mutableStateOf(false) }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "الشاشة الرئيسية وشاشة القفل" else "Home screen & lock screen", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (isRtl) "تخطيط الشاشة الرئيسية" else "Home Screen Layout", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf("4x6", "5x5", "5x6").forEach { grid ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selectedGrid == grid) ColorOS_Teal else Color.Black)
                                        .border(1.dp, if (selectedGrid == grid) ColorOS_Teal else Color(0xFF262626), RoundedCornerShape(10.dp))
                                        .clickable { selectedGrid = grid },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(grid, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (isRtl) "سرعة فتح وإغلاق التطبيقات" else "App Startup & Close Animation Speed", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf("Fast", "Normal", "Gentle").forEach { speed ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selectedSpeed == speed) ColorOS_Teal else Color.Black)
                                        .border(1.dp, if (selectedSpeed == speed) ColorOS_Teal else Color(0xFF262626), RoundedCornerShape(10.dp))
                                        .clickable { selectedSpeed = speed },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isRtl) {
                                            when(speed) {
                                                "Fast" -> "سريع"
                                                "Normal" -> "متوسط"
                                                else -> "هادئ"
                                            }
                                        } else speed,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(if (isRtl) "النقر المزدوج لتنشيط الشاشة" else "Double-tap to wake screen", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(if (isRtl) "انقر مرتين على الشاشة المغلقة لتنشيطها" else "Double tap empty space on lock screen to wake", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isDoubleTapToWakeOn,
                                onCheckedChange = { isDoubleTapToWakeOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(if (isRtl) "الشاشة مفعّلة دائماً (AOD)" else "Always-On Display", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(if (isRtl) "عرض الساعة والمعلومات أثناء قفل الشاشة" else "Display clocks and notifications when screen is off", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isAlwaysOnDisplayOn,
                                onCheckedChange = { isAlwaysOnDisplayOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 12: Notifications & Status Bar Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var showSpeed by remember { mutableStateOf(true) }
    var showBatteryPercent by remember { mutableStateOf(true) }
    
    var isWhatsAppEnabled by remember { mutableStateOf(true) }
    var isYouTubeEnabled by remember { mutableStateOf(true) }
    var isGmailEnabled by remember { mutableStateOf(false) }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "الإشعارات وشريط الحالة" else "Notifications & status bar", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = if (isRtl) "تخصيص شريط الحالة" else "Status Bar Elements",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (isRtl) "عرض سرعة الشبكة في الوقت الفعلي" else "Real-time network speed", color = Color.White, fontSize = 13.sp)
                            Switch(
                                checked = showSpeed,
                                onCheckedChange = { showSpeed = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (isRtl) "نسبة شحن البطارية" else "Battery percentage", color = Color.White, fontSize = 13.sp)
                            Switch(
                                checked = showBatteryPercent,
                                onCheckedChange = { showBatteryPercent = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = if (isRtl) "إشعارات التطبيقات" else "App Notifications",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("WhatsApp", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(if (isRtl) "مسموح بالرنين والاهتزاز" else "Allowed, Sound & Haptics", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isWhatsAppEnabled,
                                onCheckedChange = { isWhatsAppEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("YouTube", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(if (isRtl) "صامتة في لوحة الإشعارات" else "Quiet, Notifications banner", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isYouTubeEnabled,
                                onCheckedChange = { isYouTubeEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Gmail", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(if (isRtl) "متوقفة" else "Disabled", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isGmailEnabled,
                                onCheckedChange = { isGmailEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 13: Password & Security (WITH REAL FINGERPRINT ENROLL SIMULATOR)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordSecurityScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    var showFingerprintEnroll by remember { mutableStateOf(false) }
    var enrollmentProgress by remember { mutableStateOf(0f) }
    var fingerprintCount by remember { mutableStateOf(1) }
    var isPressingSensor by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "كلمة المرور والأمان" else "Password & Security", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = if (isRtl) "الحماية الشخصية" else "Personal Security Methods",
                                fontWeight = FontWeight.Bold,
                                color = ColorOS_Teal,
                                fontSize = 15.sp
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = ColorOS_Teal)
                                    Text(if (isRtl) "كلمة مرور الشاشة" else "Lock Screen Password", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                }
                                Text(if (isRtl) "مفعّلة" else "ENABLED", color = Color.Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Divider(color = Color(0xFF262626), thickness = 0.8.dp)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showFingerprintEnroll = true }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Default.Fingerprint, contentDescription = null, tint = ColorOS_Teal)
                                    Text(if (isRtl) "بصمة الإصبع" else "Fingerprint", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                }
                                Text(if (isRtl) "${fingerprintCount} مضافة" else "${fingerprintCount} ENROLLED", color = ColorOS_Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Divider(color = Color(0xFF262626), thickness = 0.8.dp)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Default.Face, contentDescription = null, tint = Color.Gray)
                                    Text(if (isRtl) "الوجه" else "Face Lock", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                }
                                Text(if (isRtl) "غير مسجل" else "NOT REGISTERED", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // HIGHLY INTERACTIVE FINGERPRINT ENROLL DIALOG BOX / OVERLAY
                if (showFingerprintEnroll) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.9f))
                            .clickable(enabled = false) {},
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .padding(16.dp),
                            shape = RoundedCornerShape(28.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
                            border = BorderStroke(1.dp, ColorOS_Teal.copy(alpha = 0.3f))
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = if (isRtl) "إضافة بصمة إصبع جديدة" else "Register New Fingerprint",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = if (isRtl) "اضغط مطولاً وبشكل متكرر على رمز البصمة الأخضر بالأسفل لتسجيل البصمة بالكامل." else "Tap and hold repeatedly on the green sensor icon to scan your finger.",
                                    fontSize = 12.sp,
                                    color = Color.LightGray,
                                    textAlign = TextAlign.Center
                                )

                                // Sensor Ripple effect when scanning
                                Box(
                                    modifier = Modifier
                                        .size(110.dp)
                                        .clip(CircleShape)
                                        .background(if (isPressingSensor) ColorOS_Teal.copy(alpha = 0.2f) else Color.Transparent)
                                        .border(2.dp, ColorOS_Teal, CircleShape)
                                        .clickable {
                                            if (enrollmentProgress < 1f) {
                                                isPressingSensor = true
                                                enrollmentProgress += 0.1f
                                                if (enrollmentProgress >= 1f) {
                                                    fingerprintCount += 1
                                                }
                                                scope.launch {
                                                    delay(300)
                                                    isPressingSensor = false
                                                }
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Fingerprint,
                                        contentDescription = null,
                                        tint = if (isPressingSensor) Color.Green else ColorOS_Teal,
                                        modifier = Modifier.size(64.dp)
                                    )
                                }

                                // Scan progress bar
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    LinearProgressIndicator(
                                        progress = enrollmentProgress,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(CircleShape),
                                        color = ColorOS_Teal,
                                        trackColor = Color(0xFF262626)
                                    )
                                    Text(
                                        text = "${String.format("%.0f%%", enrollmentProgress * 100)}",
                                        color = ColorOS_Teal,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (enrollmentProgress >= 1f) {
                                    Text(
                                        text = if (isRtl) "🎉 تمت إضافة بصمة الإصبع بنجاح!" else "🎉 Fingerprint enrolled successfully!",
                                        color = Color.Green,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }

                                Button(
                                    onClick = {
                                        showFingerprintEnroll = false
                                        enrollmentProgress = 0f
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ColorOS_Teal_Dark),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(if (isRtl) "إغلاق" else "Done", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 14: Privacy Settings Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var isMicrophoneOn by remember { mutableStateOf(true) }
    var isCameraOn by remember { mutableStateOf(true) }
    var isClipboardAlertOn by remember { mutableStateOf(true) }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "الخصوصية" else "Privacy", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(
                            text = if (isRtl) "إدارة الأذونات والخصوصية" else "Permission Manager",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(if (isRtl) "الوصول للميكروفون" else "Microphone Access", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(if (isRtl) "السماح للتطبيقات باستخدام الميكروفون" else "Allow apps to use microphone hardware", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isMicrophoneOn,
                                onCheckedChange = { isMicrophoneOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(if (isRtl) "الوصول للكاميرا" else "Camera Access", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(if (isRtl) "السماح للتطبيقات باستخدام الكاميرا" else "Allow apps to use camera hardware", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isCameraOn,
                                onCheckedChange = { isCameraOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (isRtl) "حماية البيانات الشخصية" else "Data Protection Alerts", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(if (isRtl) "تنبيه عند قراءة الحافظة" else "Show clipboard access alerts", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text(if (isRtl) "عرض إشعار عندما يقرأ تطبيق الحافظة" else "Notify when an app reads your clipboard contents", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isClipboardAlertOn,
                                onCheckedChange = { isClipboardAlertOn = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 15: Location Settings Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var isLocationEnabled by remember { mutableStateOf(true) }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "الموقع" else "Location", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(if (isRtl) "خدمات الموقع" else "Location Services", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(if (isRtl) "تحديد الموقع الجغرافي للجهاز" else "Allow device to estimate coordinates", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isLocationEnabled,
                            onCheckedChange = { isLocationEnabled = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                        )
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (isRtl) "طلبات الموقع الأخيرة" else "Recent Location Requests", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        listOf(
                            "Google Maps" to "3 min ago",
                            "Weather Tracker" to "15 min ago",
                            "Oppo Camera App" to "1 hour ago"
                        ).forEach { (app, time) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(app, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = if (isRtl) {
                                        when(time) {
                                            "3 min ago" -> "قبل ٣ دقائق"
                                            "15 min ago" -> "قبل ١٥ دقيقة"
                                            else -> "قبل ساعة واحدة"
                                        }
                                    } else time,
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 16: Safety & Emergency Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyEmergencyScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var bloodType by remember { mutableStateOf("A+") }
    var allergies by remember { mutableStateOf("None") }
    var medication by remember { mutableStateOf("None") }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "الأمن وحالة الطوارئ" else "Safety & Emergency", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = if (isRtl) "الملف الطبي في حالات الطوارئ" else "Medical Profile (Emergency)",
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            fontSize = 15.sp
                        )
                        OutlinedTextField(
                            value = bloodType,
                            onValueChange = { bloodType = it },
                            label = { Text(if (isRtl) "فصيلة الدم" else "Blood Type", color = ColorOS_Teal) },
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = ColorOS_Teal),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = allergies,
                            onValueChange = { allergies = it },
                            label = { Text(if (isRtl) "الحساسية" else "Allergies", color = ColorOS_Teal) },
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = ColorOS_Teal),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 17: Digital Wellbeing Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalWellbeingScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "الرفاهية الرقمية" else "Digital Wellbeing", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isRtl) "وقت شاشة الهاتف اليوم" else "Today's Screen Time",
                    color = Color.LightGray,
                    fontSize = 14.sp
                )
                Text(
                    text = if (isRtl) "٥ ساعات و ١٢ دقيقة" else "5h 12m",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 28.sp
                )

                // Beautiful custom-drawn Ring Chart representing wellbeing categories
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawArc(
                            color = Color(0xFF262626),
                            startAngle = 0f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = 16.dp.toPx())
                        )
                        // Social slice (teal)
                        drawArc(
                            color = ColorOS_Teal,
                            startAngle = -90f,
                            sweepAngle = 180f,
                            useCenter = false,
                            style = Stroke(width = 16.dp.toPx())
                        )
                        // Video/Media slice (orange)
                        drawArc(
                            color = Color(0xFFFF9800),
                            startAngle = 90f,
                            sweepAngle = 120f,
                            useCenter = false,
                            style = Stroke(width = 16.dp.toPx())
                        )
                        // Utilities (blue)
                        drawArc(
                            color = Color(0xFF2E93E4),
                            startAngle = 210f,
                            sweepAngle = 60f,
                            useCenter = false,
                            style = Stroke(width = 16.dp.toPx())
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (isRtl) "الشبكات الاجتماعية" else "Social Apps", color = ColorOS_Teal, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("50%", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 18: Additional Settings Screen (MATCHING SCREENSHOTS 4 & 5 EXACTLY)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdditionalSettingsScreen(
    viewModel: SettingsViewModel,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    var isOtgEnabled by remember { mutableStateOf(false) }
    var isWakeAssistantEnabled by remember { mutableStateOf(true) }
    var selectedNavMode by remember { mutableStateOf("Gestures") }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "الإعدادات الإضافية" else "Additional settings", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Card 1
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column {
                        AdditionalRow(
                            title = if (isRtl) "التنقل عبر النظام" else "System navigation",
                            value = if (selectedNavMode == "Gestures") (if (isRtl) "الإيماءات" else "Gestures") else (if (isRtl) "الأزرار" else "Buttons"),
                            valueColor = ColorOS_Teal
                        ) {
                            selectedNavMode = if (selectedNavMode == "Gestures") "Buttons" else "Gestures"
                        }
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(
                            title = if (isRtl) "اللغة والمنطقة" else "Language & region"
                        ) { onNavigate("language") }
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(
                            title = if (isRtl) "لوحة المفاتيح وطريقة الإدخال" else "Keyboard & input method"
                        ) {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(
                            title = if (isRtl) "التاريخ والوقت" else "Date & time"
                        ) {}
                    }
                }

                // Card 2
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column {
                        AdditionalRow(title = if (isRtl) "إمكانية الوصول" else "Accessibility") {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(title = if (isRtl) "الكرة المساعدة" else "Assistive Ball") {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(title = if (isRtl) "الإيماءات والحركات" else "Gestures & motions") {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(title = if (isRtl) "وضع اليد الواحدة" else "One-Handed Mode") {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(title = if (isRtl) "لقطة شاشة" else "Screenshot") {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(title = if (isRtl) "تسجيل الشاشة" else "Screen recording") {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(title = if (isRtl) "تحسين المظهر في مكالمات الفيديو" else "Video call beauty") {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(title = if (isRtl) "جدولة التشغيل/إيقاف التشغيل" else "Schedule power on/off") {}
                    }
                }

                // Card 3 (Switch settings matching Screenshot 5 exactly)
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isRtl) "اتصال OTG" else "OTG Connection",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                                Switch(
                                    checked = isOtgEnabled,
                                    onCheckedChange = { isOtgEnabled = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isRtl) "تتوقف تلقائيًا إذا لم يتم استخدامها لمدة ١٠ دقائق." else "Turns off automatically if not used for 10 minutes.",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                lineHeight = 14.sp
                            )
                        }

                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isRtl) "تنشيط مساعد Google باستخدام زر التشغيل" else "Wake Google Assistant with Power Button",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Switch(
                                    checked = isWakeAssistantEnabled,
                                    onCheckedChange = { isWakeAssistantEnabled = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = ColorOS_Teal, checkedTrackColor = ColorOS_Teal.copy(alpha = 0.4f))
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isRtl) "اضغط مع الاستمرار على زر التشغيل لمدة ٠.٥ ثانية لتنشيط مساعد Google، أو لمدة ٣ ثوانٍ للدخول إلى شاشة إيقاف التشغيل." else "Press and hold power button for 0.5s to wake assistant, 3s to enter power menu.",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                lineHeight = 14.sp
                            )
                        }

                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))

                        AdditionalRow(title = if (isRtl) "خدمات النظام" else "System services") {}
                        Divider(color = Color(0xFF262626), thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 16.dp))
                        AdditionalRow(title = if (isRtl) "نسخ احتياطي وإعادة تعيين" else "Back up and reset") {}
                    }
                }
            }
        }
    }
}

@Composable
fun AdditionalRow(
    title: String,
    value: String = "",
    valueColor: Color = Color.Gray,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (value.isNotEmpty()) {
                Text(value, color = valueColor, fontSize = 13.sp)
            }
            Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Color(0xFF555555), modifier = Modifier.size(16.dp))
        }
    }
}

// ==========================================
// SUB-SCREEN 19: Users & Accounts Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersAccountsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    var isSyncing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (isRtl) "المستخدمون والحسابات" else "Users & Accounts", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (isRtl) "الملف الشخصي الفعال" else "Active User Profile", color = ColorOS_Teal, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(ColorOS_Teal_Dark),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
                            }
                            Column {
                                Text(if (isRtl) "مالك الجهاز (حمو الإلكتروني)" else "Owner (Hamo Electronic)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(if (isRtl) "حساب مطور كامل" else "Developer Privilege Profile", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (isRtl) "مزامنة سحابة Oppo Cloud" else "Oppo Cloud Synchronization", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("hamo.dev@oppo-developer.ae", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(if (isSyncing) (if (isRtl) "جاري المزامنة حالياً..." else "Syncing data now...") else (if (isRtl) "آخر مزامنة: منذ دقيقة واحدة" else "Last synced: 1 minute ago"), color = Color.Gray, fontSize = 11.sp)
                            }
                            if (isSyncing) {
                                CircularProgressIndicator(color = ColorOS_Teal, modifier = Modifier.size(24.dp))
                            } else {
                                Button(
                                    onClick = {
                                        scope.launch {
                                            isSyncing = true
                                            delay(2000)
                                            isSyncing = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ColorOS_Teal_Dark),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(if (isRtl) "مزامنة الآن" else "Sync Now", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SUB-SCREEN 20: Google Settings Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleSettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Google", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            containerColor = Color.Black
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF2E93E4)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("G", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            }
                            Column {
                                Text("حمو الإلكتروني (Hamo Dev)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("hamoelectronics@gmail.com", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                        Button(
                            onClick = {},
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262626)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isRtl) "إدارة حساب Google الخاص بك" else "Manage your Google Account", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(if (isRtl) "الخدمات على هذا الجهاز" else "Services on this device", color = ColorOS_Teal, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        
                        listOf(
                            (if (isRtl) "الإعلانات" else "Ads") to (if (isRtl) "تخصيص الإعلانات وهويتك الإعلانية" else "Reset advertising ID"),
                            (if (isRtl) "العثور على جهازي" else "Find My Device") to (if (isRtl) "تحديد موقع هذا الهاتف عن بعد" else "Locate this device remotely"),
                            (if (isRtl) "النسخ الاحتياطي" else "Backup") to (if (isRtl) "حفظ صور وجهات الاتصال سحابياً" else "Backup photos and contacts to Google One"),
                            (if (isRtl) "الملء التلقائي" else "Autofill") to (if (isRtl) "ملء كلمات المرور ورموز التحقق تلقائياً" else "Autofill passwords and SMS verification codes")
                        ).forEach { (service, desc) ->
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(service, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(desc, color = Color.Gray, fontSize = 11.sp)
                            }
                            Divider(color = Color(0xFF262626), thickness = 0.8.dp)
                        }
                    }
                }
            }
        }
    }
}

// Extension to cleanly handle pixels in DP dynamically
private fun Int.getDp(): androidx.compose.ui.unit.Dp {
    return this.dp
}

private fun Float.getDp(): androidx.compose.ui.unit.Dp {
    return this.dp
}
