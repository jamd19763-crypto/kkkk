package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ColorOS_Teal,
    onPrimary = ColorOS_Light_Surface,
    primaryContainer = ColorOS_Teal_Dark,
    secondary = ColorOS_Teal_Light,
    background = Color.Black,
    surface = Color(0xFF121212),
    surfaceVariant = Color(0xFF1C1C1E),
    onBackground = Color.White,
    onSurface = Color.White,
    onSurfaceVariant = Color(0xFF9E9E9E)
)

private val LightColorScheme = lightColorScheme(
    primary = ColorOS_Teal,
    onPrimary = ColorOS_Light_Surface,
    primaryContainer = ColorOS_Teal_Light,
    secondary = ColorOS_Teal_Dark,
    background = ColorOS_Light_Bg,
    surface = ColorOS_Light_Surface,
    surfaceVariant = ColorOS_Light_Card,
    onBackground = ColorOS_Light_Text_Primary,
    onSurface = ColorOS_Light_Text_Primary,
    onSurfaceVariant = ColorOS_Light_Text_Secondary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
