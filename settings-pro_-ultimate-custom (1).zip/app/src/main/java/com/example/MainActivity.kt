package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            MyApplicationTheme(darkTheme = isDarkMode) {
                val navController = rememberNavController()
                
                NavHost(
                    navController = navController,
                    startDestination = "main"
                ) {
                    composable("main") {
                        MainSettingsScreen(viewModel = viewModel) { route ->
                            navController.navigate(route)
                        }
                    }
                    composable("wifi") {
                        WifiSettingsScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("bluetooth") {
                        BluetoothSettingsScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("personalization") {
                        PersonalizationScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("display") {
                        DisplayBrightnessScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("sound") {
                        SoundVibrationScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("battery") {
                        BatteryScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("apps") {
                        AppManagerScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("special_features") {
                        SpecialFeaturesScreen(viewModel = viewModel, onNavigate = { route ->
                            navController.navigate(route)
                        }) {
                            navController.popBackStack()
                        }
                    }
                    composable("language") {
                        LanguageRegionScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("about") {
                        AboutDeviceScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("ai_snap_key") {
                        AiSnapKeyScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("ai_mind_space") {
                        AiMindSpaceScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("ai_mind_pilot") {
                        AiMindPilotScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("ai_bill_manager") {
                        AiBillManagerScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("ai_menu_translation") {
                        AiMenuTranslationScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("pop_cam") {
                        PopCamScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("ai_remix_collage") {
                        AiRemixCollageScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("video_straighten") {
                        VideoStraightenScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("mobile_network") {
                        MobileNetworkScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("connection_sharing") {
                        ConnectionSharingScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("home_lock_screen") {
                        HomeLockScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("notifications") {
                        NotificationsScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("password_security") {
                        PasswordSecurityScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("privacy") {
                        PrivacyScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("location") {
                        LocationScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("safety_emergency") {
                        SafetyEmergencyScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("digital_wellbeing") {
                        DigitalWellbeingScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("additional_settings") {
                        AdditionalSettingsScreen(viewModel = viewModel, onNavigate = { route ->
                            navController.navigate(route)
                        }) {
                            navController.popBackStack()
                        }
                    }
                    composable("users_accounts") {
                        UsersAccountsScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("google") {
                        GoogleSettingsScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkWriteSettingsPermission()
        viewModel.updateRealWifiStatus()
        viewModel.updateRealBluetoothStatus()
    }
}
