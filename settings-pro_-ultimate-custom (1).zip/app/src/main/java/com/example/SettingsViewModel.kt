package com.example

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.net.Uri
import android.bluetooth.BluetoothAdapter
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext

    // App Preferences / States
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _currentLanguage = MutableStateFlow("ar") // "ar" or "en"
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _fontSizeScale = MutableStateFlow(1.0f) // 0.8f, 1.0f, 1.2f
    val fontSizeScale: StateFlow<Float> = _fontSizeScale.asStateFlow()

    // Real System Toggles / Toggles state
    private val _isWifiEnabled = MutableStateFlow(false)
    val isWifiEnabled: StateFlow<Boolean> = _isWifiEnabled.asStateFlow()

    private val _isBluetoothEnabled = MutableStateFlow(false)
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val _isFlashlightEnabled = MutableStateFlow(false)
    val isFlashlightEnabled: StateFlow<Boolean> = _isFlashlightEnabled.asStateFlow()

    private val _isEyeComfortEnabled = MutableStateFlow(false)
    val isEyeComfortEnabled: StateFlow<Boolean> = _isEyeComfortEnabled.asStateFlow()

    private val _isSuperPowerSaving = MutableStateFlow(false)
    val isSuperPowerSaving: StateFlow<Boolean> = _isSuperPowerSaving.asStateFlow()

    // Personalization Customizations
    private val _fingerprintAnimation = MutableStateFlow("Fizz") // "Fizz", "Ripple", "Stardust", "None"
    val fingerprintAnimation: StateFlow<String> = _fingerprintAnimation.asStateFlow()

    private val _edgeLightingColor = MutableStateFlow("Teal") // "Teal", "Blue", "Gold", "Purple"
    val edgeLightingColor: StateFlow<String> = _edgeLightingColor.asStateFlow()

    // Real System Telemetry
    private val _batteryLevel = MutableStateFlow(85)
    val batteryLevel: StateFlow<Int> = _batteryLevel.asStateFlow()

    private val _isBatteryCharging = MutableStateFlow(false)
    val isBatteryCharging: StateFlow<Boolean> = _isBatteryCharging.asStateFlow()

    private val _storageTotalGB = MutableStateFlow(256)
    val storageTotalGB: StateFlow<Int> = _storageTotalGB.asStateFlow()

    private val _storageUsedGB = MutableStateFlow(45)
    val storageUsedGB: StateFlow<Int> = _storageUsedGB.asStateFlow()

    private val _ramTotalGB = MutableStateFlow(12)
    val ramTotalGB: StateFlow<Int> = _ramTotalGB.asStateFlow()

    private val _ramExpansionGB = MutableStateFlow(4) // +4GB, +8GB, +12GB
    val ramExpansionGB: StateFlow<Int> = _ramExpansionGB.asStateFlow()

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    private val _batteryTemp = MutableStateFlow(36.5f)
    val batteryTemp: StateFlow<Float> = _batteryTemp.asStateFlow()

    private val _batteryVoltage = MutableStateFlow(4.1f)
    val batteryVoltage: StateFlow<Float> = _batteryVoltage.asStateFlow()

    val realDeviceModel = "${Build.BRAND} ${Build.MODEL}"
    val realAndroidVersion = Build.VERSION.RELEASE
    val realApiLevel = Build.VERSION.SDK_INT
    val realProcessorCores = Runtime.getRuntime().availableProcessors()
    val realSecurityPatch = Build.VERSION.SECURITY_PATCH ?: "2026-06-01"

    // System Volume State
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val _mediaVolume = MutableStateFlow(0)
    val mediaVolume: StateFlow<Int> = _mediaVolume.asStateFlow()
    val maxMediaVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

    private val _ringVolume = MutableStateFlow(0)
    val ringVolume: StateFlow<Int> = _ringVolume.asStateFlow()
    val maxRingVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_RING)

    private val _notificationVolume = MutableStateFlow(0)
    val notificationVolume: StateFlow<Int> = _notificationVolume.asStateFlow()
    val maxNotificationVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION)

    // Screen Brightness (0 to 255)
    private val _screenBrightness = MutableStateFlow(128)
    val screenBrightness: StateFlow<Int> = _screenBrightness.asStateFlow()

    // Wi-Fi details
    private val _wifiSsid = MutableStateFlow("OPPO_5G_Home")
    val wifiSsid: StateFlow<String> = _wifiSsid.asStateFlow()

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _hasWriteSettingsPermission = MutableStateFlow(false)
    val hasWriteSettingsPermission: StateFlow<Boolean> = _hasWriteSettingsPermission.asStateFlow()

    // --- ADVANCED DEVELOPER & AI STATE CHANNELS ---
    private val _aiSnapKeyAction = MutableStateFlow("launch_pilot")
    val aiSnapKeyAction: StateFlow<String> = _aiSnapKeyAction.asStateFlow()

    private val _mindSpaceNotes = MutableStateFlow<List<MindNote>>(
        listOf(
            MindNote(1, "أفكار فيديو رينو 6 برو بلص الإماراتي", "تجهيز مقارنة الأداء العام بين معالج Snapdragon 8 Gen 4 والنسخ التجارية. التركيز على ميزة كسر سرعة النواة لـ 4.2 جيجاهرتز وثبات الحرارة بفضل تبريد أبوظبي المتطور.", "YouTube", "2026-07-17"),
            MindNote(2, "سجل الجدار الناري السيبراني", "الجدار الناري السيبراني نشط وحاصل على شهادة FIPS 140-3. تم حظر 3 محاولات فحص منافذ غير مصرح بها بنجاح في الخلفية.", "أمن", "2026-07-16"),
            MindNote(3, "ملاحظات منشأة أبوظبي للتكنولوجيا", "هذا النموذج التكنولوجي الفريد مخصص ومعد خصيصاً للمبدع حمو الإلكتروني تقديراً لإبداعه المتميز وصنع خصيصا له بطلب من يوتيوب.", "مطور", "2026-07-15")
        )
    )
    val mindSpaceNotes: StateFlow<List<MindNote>> = _mindSpaceNotes.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(1, "أهلاً بك يا حمو الإلكتروني في واجهة المساعد الذكي AI Mind Pilot الخاص بجهازك المطور OPPO Reno6 Pro+ Plus 5G (Developer Edition). كيف يمكنني مساعدتك اليوم؟", false, "09:09")
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isGeneratingResponse = MutableStateFlow(false)
    val isGeneratingResponse: StateFlow<Boolean> = _isGeneratingResponse.asStateFlow()

    private val _isScanningBill = MutableStateFlow(false)
    val isScanningBill: StateFlow<Boolean> = _isScanningBill.asStateFlow()

    private val _scannedBills = MutableStateFlow<List<ScannedBill>>(
        listOf(
            ScannedBill("فاتورة توريد تكنولوجي", "تاريخ: 2026-07-10 • الجهة: ATRC Abu Dhabi • القيمة: 15,400 د.إ • المكون: Snapdragon 8 Gen 4 custom board • الحالة: مدفوعة بالكامل"),
            ScannedBill("ترخيص راديو وموجات دبي", "تاريخ: 2026-06-15 • الجهة: TRA UAE • القيمة: 4,500 د.إ • الغرض: رادار وموجات الجيل الخامس التجريبية • الحالة: معتمد")
        )
    )
    val scannedBills: StateFlow<List<ScannedBill>> = _scannedBills.asStateFlow()

    private val _isTranslatingMenu = MutableStateFlow(false)
    val isTranslatingMenu: StateFlow<Boolean> = _isTranslatingMenu.asStateFlow()

    private val _menuTranslationResult = MutableStateFlow("")
    val menuTranslationResult: StateFlow<String> = _menuTranslationResult.asStateFlow()

    private val _popCamFilter = MutableStateFlow("Cyberpunk")
    val popCamFilter: StateFlow<String> = _popCamFilter.asStateFlow()

    private val _aiSmoothLevel = MutableStateFlow(0.5f)
    val aiSmoothLevel: StateFlow<Float> = _aiSmoothLevel.asStateFlow()

    private val _isVideoStraighteningActive = MutableStateFlow(false)
    val isVideoStraighteningActive: StateFlow<Boolean> = _isVideoStraighteningActive.asStateFlow()

    private val _videoStabilityScore = MutableStateFlow(0.95f)
    val videoStabilityScore: StateFlow<Float> = _videoStabilityScore.asStateFlow()

    // Interactive diagnostics and testing
    private val _isPerformanceTesting = MutableStateFlow(false)
    val isPerformanceTesting: StateFlow<Boolean> = _isPerformanceTesting.asStateFlow()

    private val _performanceTestProgress = MutableStateFlow(0f)
    val performanceTestProgress: StateFlow<Float> = _performanceTestProgress.asStateFlow()

    private val _performanceScore = MutableStateFlow(0)
    val performanceScore: StateFlow<Int> = _performanceScore.asStateFlow()

    private val _isSecurityDiagnosing = MutableStateFlow(false)
    val isSecurityDiagnosing: StateFlow<Boolean> = _isSecurityDiagnosing.asStateFlow()

    private val _securityDiagnosisStatus = MutableStateFlow("مستعد للتشخيص...")
    val securityDiagnosisStatus: StateFlow<String> = _securityDiagnosisStatus.asStateFlow()

    // Initializer
    init {
        // Load initial values
        checkWriteSettingsPermission()
        loadSystemVolumes()
        loadSystemStorage()
        loadSystemBrightness()
        monitorBattery()
        loadInstalledApps()
        loadInitialHardware()
        registerSystemListeners()
        updateRealWifiStatus()
        updateRealBluetoothStatus()
    }

    fun checkWriteSettingsPermission() {
        _hasWriteSettingsPermission.value = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.System.canWrite(context)
        } else {
            true
        }
    }

    fun setDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
    }

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
    }

    fun setFontSizeScale(scale: Float) {
        _fontSizeScale.value = scale
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setRamExpansion(gb: Int) {
        _ramExpansionGB.value = gb
    }

    fun setFingerprintAnimation(anim: String) {
        _fingerprintAnimation.value = anim
    }

    fun setEdgeLightingColor(color: String) {
        _edgeLightingColor.value = color
    }

    // Toggle Wi-Fi (Real toggle via Settings Intent for modern Android compatibility)
    fun toggleWifi() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Intent(Settings.Panel.ACTION_WIFI)
            } else {
                Intent(Settings.ACTION_WIFI_SETTINGS)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (ex: Exception) {
                // prediction fallback toggle
                val nextState = !_isWifiEnabled.value
                _isWifiEnabled.value = nextState
                _wifiSsid.value = if (nextState) "OPPO_5G_Home" else "Disconnected"
            }
        }
    }

    // Toggle Bluetooth (opens Bluetooth settings for real configuration)
    fun toggleBluetooth() {
        try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            _isBluetoothEnabled.value = !_isBluetoothEnabled.value
        }
    }

    fun updateRealWifiStatus() {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (wifiManager != null) {
                val isEnabled = wifiManager.isWifiEnabled
                _isWifiEnabled.value = isEnabled
                if (isEnabled) {
                    val info = wifiManager.connectionInfo
                    val ssid = info?.ssid?.replace("\"", "") ?: "OPPO_5G_Home"
                    _wifiSsid.value = if (ssid == "<unknown ssid>" || ssid.isEmpty()) "OPPO_5G_Home" else ssid
                } else {
                    _wifiSsid.value = "Disconnected"
                }
            }
        } catch (e: Exception) {
            // fallback
        }
    }

    fun updateRealBluetoothStatus() {
        try {
            val btAdapter = BluetoothAdapter.getDefaultAdapter()
            if (btAdapter != null) {
                _isBluetoothEnabled.value = btAdapter.isEnabled
            }
        } catch (e: Exception) {
            // fallback
        }
    }

    private fun registerSystemListeners() {
        try {
            // 1. Listen for system volume changes
            val volumeFilter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
            val volumeReceiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    if (intent != null && intent.action == "android.media.VOLUME_CHANGED_ACTION") {
                        loadSystemVolumes()
                    }
                }
            }
            context.registerReceiver(volumeReceiver, volumeFilter)

            // 2. Listen for Wi-Fi state changes
            val wifiFilter = IntentFilter().apply {
                addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
                addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            }
            val wifiReceiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    updateRealWifiStatus()
                }
            }
            context.registerReceiver(wifiReceiver, wifiFilter)

            // 3. Listen for Bluetooth state changes
            val btFilter = IntentFilter("android.bluetooth.adapter.action.STATE_CHANGED")
            val btReceiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    updateRealBluetoothStatus()
                }
            }
            context.registerReceiver(btReceiver, btFilter)
        } catch (e: Exception) {
            // ignore registration errors if any
        }
    }

    // Toggle Eye Comfort (adjusts tint in-app, can represent real system switch)
    fun toggleEyeComfort() {
        _isEyeComfortEnabled.value = !_isEyeComfortEnabled.value
    }

    // Toggle Super Power Saving
    fun toggleSuperPowerSaving() {
        _isSuperPowerSaving.value = !_isSuperPowerSaving.value
    }

    // Toggle Flashlight/Torch (Real Torch control using CameraManager!)
    fun toggleFlashlight() {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        if (cameraManager != null) {
            try {
                val cameraId = cameraManager.cameraIdList.firstOrNull()
                if (cameraId != null) {
                    val nextState = !_isFlashlightEnabled.value
                    cameraManager.setTorchMode(cameraId, nextState)
                    _isFlashlightEnabled.value = nextState
                } else {
                    _isFlashlightEnabled.value = !_isFlashlightEnabled.value
                }
            } catch (e: Exception) {
                // Fallback to simulation if flashlight fails or permissions missing
                _isFlashlightEnabled.value = !_isFlashlightEnabled.value
            }
        } else {
            _isFlashlightEnabled.value = !_isFlashlightEnabled.value
        }
    }

    // Load actual system storage sizes
    private fun loadSystemStorage() {
        try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val availableBlocks = stat.availableBlocksLong
            
            val totalBytes = totalBlocks * blockSize
            val freeBytes = availableBlocks * blockSize
            
            val totalGB = (totalBytes / (1024 * 1024 * 1024)).toInt()
            val freeGB = (freeBytes / (1024 * 1024 * 1024)).toInt()
            
            // Reno6 Pro standard is 256GB, so if our filesystem size is less (e.g. partition size), 
            // we will scale or display it beautifully, but real statistics is preferred!
            _storageTotalGB.value = if (totalGB < 32) 256 else totalGB
            _storageUsedGB.value = if (totalGB < 32) (256 - freeGB).coerceAtLeast(42) else (totalGB - freeGB)
        } catch (e: Exception) {
            _storageTotalGB.value = 256
            _storageUsedGB.value = 54
        }
    }

    private fun loadInitialHardware() {
        // Reno 6 Pro+ Developer Edition has 18GB RAM and 18GB Expansion
        _ramTotalGB.value = 18
        _ramExpansionGB.value = 18
    }

    // Load and update active system volumes
    fun setMediaVolume(volume: Int) {
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0)
            _mediaVolume.value = volume
        } catch (e: Exception) {
            _mediaVolume.value = volume
        }
    }

    fun setRingVolume(volume: Int) {
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_RING, volume, 0)
            _ringVolume.value = volume
        } catch (e: Exception) {
            _ringVolume.value = volume
        }
    }

    fun setNotificationVolume(volume: Int) {
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, volume, 0)
            _notificationVolume.value = volume
        } catch (e: Exception) {
            _notificationVolume.value = volume
        }
    }

    private fun loadSystemVolumes() {
        try {
            _mediaVolume.value = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            _ringVolume.value = audioManager.getStreamVolume(AudioManager.STREAM_RING)
            _notificationVolume.value = audioManager.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
        } catch (e: Exception) {
            _mediaVolume.value = (maxMediaVolume * 0.6).toInt()
            _ringVolume.value = (maxRingVolume * 0.7).toInt()
            _notificationVolume.value = (maxNotificationVolume * 0.5).toInt()
        }
    }

    // Brightness setting
    fun setBrightness(brightness: Int) {
        _screenBrightness.value = brightness
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.System.canWrite(context)) {
                    Settings.System.putInt(
                        context.contentResolver,
                        Settings.System.SCREEN_BRIGHTNESS,
                        brightness
                    )
                }
            }
        } catch (e: Exception) {
            // Safe fallback
        }
    }

    private fun loadSystemBrightness() {
        try {
            _screenBrightness.value = Settings.System.getInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS
            )
        } catch (e: Exception) {
            _screenBrightness.value = 140
        }
    }

    // Monitor battery percentage in real-time
    private fun monitorBattery() {
        val batteryFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent != null) {
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                    if (level != -1 && scale != -1) {
                        _batteryLevel.value = ((level.toFloat() / scale.toFloat()) * 100).toInt()
                    }
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    _isBatteryCharging.value = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == BatteryManager.BATTERY_STATUS_FULL

                    val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
                    if (temp != -1) {
                        _batteryTemp.value = temp / 10f
                    }
                    val voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
                    if (voltage != -1) {
                        _batteryVoltage.value = if (voltage > 1000) voltage / 1000f else voltage.toFloat()
                    }
                }
            }
        }
        context.registerReceiver(receiver, batteryFilter)
    }

    // Fetch real installed apps list
    private fun loadInstalledApps() {
        viewModelScope.launch {
            try {
                val pm = context.packageManager
                val appsList = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                val mappedApps = appsList.filter {
                    // Filter system apps to show user apps mostly, but can show a clean list of both
                    (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName.contains("google")
                }.map {
                    AppInfo(
                        name = it.loadLabel(pm).toString(),
                        packageName = it.packageName,
                        iconDrawableRes = null,
                        version = try {
                            pm.getPackageInfo(it.packageName, 0).versionName ?: "1.0"
                        } catch (e: Exception) {
                            "1.0"
                        },
                        sizeMB = ((File(it.sourceDir).length() / (1024 * 1024)).coerceAtLeast(1) + (10..120).random()).toInt() // App package size + data size approximation
                    )
                }.sortedBy { it.name }

                _installedApps.value = mappedApps
            } catch (e: Exception) {
                // Fallback mock list if we fail to read packages
                _installedApps.value = listOf(
                    AppInfo("WhatsApp", "com.whatsapp", null, "2.23.10", 82),
                    AppInfo("Facebook", "com.facebook.katana", null, "412.0", 124),
                    AppInfo("YouTube", "com.google.android.youtube", null, "18.20", 154),
                    AppInfo("Instagram", "com.instagram.android", null, "285.0", 94),
                    AppInfo("Messenger", "com.facebook.orca", null, "405.0", 78),
                    AppInfo("TikTok", "com.zhiliaoapp.musically", null, "29.4", 132),
                    AppInfo("Telegram", "org.telegram.messenger", null, "9.6", 67),
                    AppInfo("Spotify", "com.spotify.music", null, "8.8.2", 55)
                )
            }
        }
    }

    // Local Arabic/English Translation Helper (Egyptian dialect aligned system translations)
    fun getTranslation(key: String): String {
        val translationsAr = mapOf(
            "settings" to "الإعدادات",
            "search_hint" to "البحث في الإعدادات...",
            "oppo_id" to "NickName09fM6ffN065T",
            "oppo_id_desc" to "إدارة معلومات الحساب والأمان.",
            "one_hand_mode" to "وضع اليد الواحدة",
            "one_hand_mode_desc" to "وضع اليد الواحدة الجديد تمامًا",
            "air_gestures" to "الإيماءات والتشغيل",
            "air_gestures_desc" to "التحكم عن بعد بالإيماءات وتخصيصات الحركات",
            "personalization" to "الخلفيات والشكل",
            "personalization_desc" to "تخصيص الواجهة، الإضاءة الجانبية، الأيقونات والخطوط",
            "wifi" to "Wi-Fi",
            "wifi_on" to "مفعّل",
            "wifi_off" to "متوقف",
            "wifi_status" to "Hidden Network",
            "bluetooth" to "بلوتوث",
            "bluetooth_desc" to "غير مفعّل",
            "mobile_network" to "شبكة الهاتف",
            "mobile_network_desc" to "اتصال البيانات والشبكة والبطاقة SIM",
            "connection_sharing" to "الاتصال والمشاركة",
            "connection_sharing_desc" to "نقطة الاتصال الشخصية والمشاركة عبر Bluetooth والمنافذ والـ VPN",
            "home_lock_screen" to "الشاشة الرئيسية وشاشة القفل",
            "home_lock_screen_desc" to "تخطيط الأيقونات، الأنماط، Always-On Display",
            "display" to "الشاشة والسطوع",
            "display_desc" to "الوضع الداكن، راحة العين، معدل التحديث والسطوع التلقائي",
            "sound" to "الأصوات والاهتزاز",
            "sound_desc" to "النغمات، مستويات الصوت، Dolby Atmos والاهتزاز اللمسي",
            "notif_status_bar" to "الإشعارات وشريط الحالة",
            "notif_status_bar_desc" to "إدارة الإشعارات، نسبة شحن البطارية وسرعة الشبكة",
            "apps" to "التطبيقات",
            "apps_desc" to "إدارة التطبيقات والأذونات والتطبيقات الافتراضية",
            "password_security" to "كلمة المرور والأمان",
            "password_security_desc" to "بصمة الإصبع، قفل الوجه ورمز قفل الشاشة",
            "privacy" to "الخصوصية",
            "privacy_desc" to "خزنة الملفات، قفل التطبيقات، أذونات الوصول والخصوصية",
            "location" to "الموقع",
            "location_desc" to "أذونات الموقع الجغرافي وخدمات GPS",
            "safety_emergency" to "الأمن وحالة الطوارئ",
            "safety_emergency_desc" to "معلومات الطوارئ الطبية والاتصال SOS وتحذيرات الزلازل",
            "battery" to "البطارية",
            "battery_desc" to "وضع توفير الطاقة الفائق، استهلاك الطاقة، صحة البطارية",
            "special_features" to "ميزات خاصة",
            "special_features_desc" to "الشريط الجانبي، تقسيم الشاشة، النوافذ المرنة",
            "digital_wellbeing" to "الرفاهية الرقمية وأدوات الرقابة الأبوية",
            "digital_wellbeing_desc" to "وقت تشغيل الشاشة، وقت النوم، مؤقتات التطبيقات والقيود",
            "additional_settings" to "الإعدادات الإضافية",
            "additional_settings_desc" to "اللغة والمنطقة، الوقت والتاريخ، كابل OTG وتحديثات النظام",
            "about" to "حول الجهاز",
            "about_desc" to "ColorOS 13.0 • OPPO Reno6",
            "users_accounts" to "المستخدمون والحسابات",
            "users_accounts_desc" to "إدارة الحسابات، المزامنة التلقائية والنسخ الاحتياطي",
            "google" to "Google",
            "google_desc" to "خدمات وتفضيلات وتخصيصات Google",
            "system_settings" to "إعدادات النظام",
            "system_settings_desc" to "اللغة والمنطقة، الوقت والتاريخ، لوحة المفاتيح",
            "dark_mode" to "الوضع الداكن",
            "eye_comfort" to "درع حماية العين",
            "brightness" to "سطوع الشاشة",
            "volume_media" to "حجم صوت الوسائط",
            "volume_ring" to "صوت نغمة الرنين",
            "volume_notif" to "صوت الإشعارات",
            "super_power_saving" to "توفير الطاقة الفائق",
            "battery_health" to "حالة البطارية ممتاز (100%)",
            "app_list" to "قائمة التطبيقات المثبتة",
            "device_name" to "اسم الجهاز",
            "model" to "الطراز",
            "processor" to "المعالج",
            "processor_val" to "Qualcomm® Snapdragon™ 720G Octa-core",
            "ram" to "الذاكرة العشوائية (RAM)",
            "ram_expansion" to "توسيع الذاكرة العشوائية",
            "storage" to "مساحة التخزين",
            "coloros_version" to "إصدار ColorOS",
            "android_version" to "إصدار Android",
            "regulatory" to "المعلومات التنظيمية",
            "back" to "رجوع",
            "fizz" to "فوران الوهج",
            "ripple" to "تموج زجاجي",
            "stardust" to "غبار النجوم",
            "none" to "بدون حركة",
            "fingerprint_anim" to "تأثير بصمة الإصبع",
            "edge_lighting" to "إضاءة حواف الشاشة",
            "teal" to "أخضر تركواز",
            "blue" to "أزرق هادئ",
            "gold" to "ذهبي فخم",
            "purple" to "بنفسجي ساحر",
            "split_screen" to "تقسيم الشاشة الذكي",
            "sidebar" to "الشريط الجانبي الذكي",
            "flexible_windows" to "النوافذ المرنة الأنيقة",
            "language" to "لغة التطبيق",
            "font_size" to "حجم الخط",
            "save" to "حفظ",
            "charging" to "جاري الشحن الآن",
            "not_charging" to "يعمل على البطارية"
        )

        val translationsEn = mapOf(
            "settings" to "Settings",
            "search_hint" to "Search settings...",
            "oppo_id" to "NickName09fM6ffN065T",
            "oppo_id_desc" to "Manage account information and security.",
            "one_hand_mode" to "One-Handed Mode",
            "one_hand_mode_desc" to "The brand new one-handed mode",
            "air_gestures" to "Gestures & Operation",
            "air_gestures_desc" to "Remote gesture controls and motion settings",
            "personalization" to "Wallpapers & style",
            "personalization_desc" to "AOD, theme, icons, edge lighting",
            "wifi" to "Wi-Fi",
            "wifi_on" to "Enabled",
            "wifi_off" to "Disabled",
            "wifi_status" to "Hidden Network",
            "bluetooth" to "Bluetooth",
            "bluetooth_desc" to "Disabled",
            "mobile_network" to "Mobile Network",
            "mobile_network_desc" to "Cellular data, network status, SIM cards",
            "connection_sharing" to "Connection & sharing",
            "connection_sharing_desc" to "Personal hotspot, VPN & Bluetooth sharing",
            "home_lock_screen" to "Home screen & Lock screen",
            "home_lock_screen_desc" to "Icon layout, Always-On Display",
            "display" to "Display & brightness",
            "display_desc" to "Dark mode, Eye comfort, 90Hz refresh",
            "sound" to "Sound & vibration",
            "sound_desc" to "Dolby Atmos, Ringtones, Haptics",
            "notif_status_bar" to "Notifications & status bar",
            "notif_status_bar_desc" to "Status bar speed, notification icons",
            "apps" to "Apps",
            "apps_desc" to "App management, default apps",
            "password_security" to "Password & security",
            "password_security_desc" to "Lockscreen passcode, face & fingerprint",
            "privacy" to "Privacy",
            "privacy_desc" to "Permission manager, private safe",
            "location" to "Location",
            "location_desc" to "Location access and GPS settings",
            "safety_emergency" to "Safety & emergency",
            "safety_emergency_desc" to "Emergency SOS, medical info",
            "battery" to "Battery",
            "battery_desc" to "Super power saving, health status",
            "special_features" to "Special features",
            "special_features_desc" to "Split screen, flexible windows, sidebar",
            "digital_wellbeing" to "Digital Wellbeing & parental controls",
            "digital_wellbeing_desc" to "Screen time, daily timers, parental control",
            "additional_settings" to "Additional settings",
            "additional_settings_desc" to "Language & region, date, OTG",
            "about" to "About device",
            "about_desc" to "ColorOS 13.0 • OPPO Reno6",
            "users_accounts" to "Users & accounts",
            "users_accounts_desc" to "Account sync, backup, multi-user",
            "google" to "Google",
            "google_desc" to "Google services & preferences",
            "system_settings" to "System settings",
            "system_settings_desc" to "Language, date, time, OTG",
            "dark_mode" to "Dark mode",
            "eye_comfort" to "Eye comfort",
            "brightness" to "Screen brightness",
            "volume_media" to "Media volume",
            "volume_ring" to "Ringtone volume",
            "volume_notif" to "Notification volume",
            "super_power_saving" to "Super power saving",
            "battery_health" to "Battery Health Excellent (100%)",
            "app_list" to "Installed Applications",
            "device_name" to "Device name",
            "model" to "Model",
            "processor" to "Processor",
            "processor_val" to "Qualcomm® Snapdragon™ 720G Octa-core",
            "ram" to "RAM",
            "ram_expansion" to "RAM Expansion",
            "storage" to "Storage",
            "coloros_version" to "ColorOS version",
            "android_version" to "Android version",
            "regulatory" to "Regulatory info",
            "back" to "Back",
            "fizz" to "Fizz Glow",
            "ripple" to "Glass Ripple",
            "stardust" to "Stardust Wave",
            "none" to "No Animation",
            "fingerprint_anim" to "Fingerprint Animation",
            "edge_lighting" to "Edge Lighting Effect",
            "teal" to "Emerald Teal",
            "blue" to "Aero Blue",
            "gold" to "Luxury Gold",
            "purple" to "Mystic Purple",
            "split_screen" to "Smart Split Screen",
            "sidebar" to "Smart Sidebar Panel",
            "flexible_windows" to "Responsive Flexible Windows",
            "language" to "App Language",
            "font_size" to "Font Size Scale",
            "save" to "Save",
            "charging" to "Charging now",
            "not_charging" to "Discharging"
        )

        return if (_currentLanguage.value == "ar") {
            translationsAr[key] ?: key
        } else {
            translationsEn[key] ?: key
        }
    }

    // --- INTERACTIVE METHODS FOR CUSTOM SPECS & AI FEATURES ---

    fun setAiSnapKeyAction(action: String) {
        _aiSnapKeyAction.value = action
    }

    fun addMindNote(title: String, content: String, tag: String) {
        if (title.isBlank() || content.isBlank()) return
        val currentList = _mindSpaceNotes.value.toMutableList()
        val newId = (currentList.maxOfOrNull { it.id } ?: 0) + 1
        currentList.add(0, MindNote(newId, title, content, tag, "2026-07-17"))
        _mindSpaceNotes.value = currentList
    }

    fun deleteMindNote(id: Int) {
        val currentList = _mindSpaceNotes.value.filter { it.id != id }
        _mindSpaceNotes.value = currentList
    }

    fun sendMessageToPilot(text: String) {
        if (text.isBlank()) return
        val list = _chatMessages.value.toMutableList()
        val userMsgId = list.size + 1
        list.add(ChatMessage(userMsgId, text, true, "09:12"))
        _chatMessages.value = list

        _isGeneratingResponse.value = true
        viewModelScope.launch {
            delay(1200) // realistic AI response delay
            val replyText = when {
                text.contains("معالج") || text.contains("سرعة") || text.contains("Snapdragon") || text.contains("بروسيسور") || text.contains("البروسيسور") -> {
                    "أهلاً يا حمو! معالجك Snapdragon 8 Gen 4 هو أقوى معالج متاح للمطورين بتردد مرفوع ومكسور السرعة يبلغ 4.2 جيجاهرتز ونواة تبريد خاصة تم تصميمها واختبارها في منشأة أبوظبي للتقنيات المتقدمة. إنه يقدم أداءً أعلى بنسبة 30% من أي هاتف تجاري آخر مع حماية تامة ضد الحرارة."
                }
                text.contains("رام") || text.contains("الرام") || text.contains("RAM") || text.contains("مساحة") || text.contains("تخزين") || text.contains("مساحه") -> {
                    "جهازك المخصص OPPO Reno6 Pro+ Plus 5G يحتوي على 18 جيجابايت رام LPDDR5X حقيقية بالإضافة لـ 18 جيجابايت توسيع ذكي (Dynamic RAM Expansion) ليصبح الإجمالي 36 جيجابايت رام مع مساحة تخزين فائقة السرعة 1.0 تيرابايت UFS 4.1."
                }
                text.contains("أمن") || text.contains("حماية") || text.contains("اختراق") || text.contains("حظر") || text.contains("جدار") || text.contains("حمايه") -> {
                    "جدار الحماية السيبراني ذو الطبقة الثنائية (Kernel-level) نشط تماماً وحاصل على اعتماد شهادات FIPS 140-3 و ISO 27001. يقوم بمراقبة وحظر أي هجمات أو محاولات تتبع وتسلل تلقائياً وبسرعة فائقة لحماية خصوصيتك 100%."
                }
                text.contains("تحديث") || text.contains("تحديثات") || text.contains("سجل") || text.contains("بث") || text.contains("يوتيوب") || text.contains("يوتيوبر") -> {
                    "تحديثات OTA تصلك مباشرة ومجاناً من خوادم قناة يوتيوب المخصصة YouTube Creators Lab بمدينة أبوظبي. الإصدار الحالي هو ColorOS 17.0 Ultimate Custom Build المبني على Android 17 Developer Preview v3."
                }
                text.contains("دعم") || text.contains("اتصال") || text.contains("رقم") || text.contains("فريق") -> {
                    "يمكنك الاتصال السري المشفر مباشرة بفريق المطورين الإماراتي في أبوظبي لمتابعة التخصيص أو الإبلاغ عن ميزات تريد إضافتها في التحديث الأمني القادم لجولتك."
                }
                text.contains("أبوظبي") || text.contains("الامارات") || text.contains("الإمارات") || text.contains("ابوظبي") -> {
                    "هذا الهاتف تم تصنيعه وتطويره بشكل سري وحصري في منشأة أبوظبي للتقنيات المتطورة بالتعاون مع معامل تكنولوجيا الهواتف في دبي، وهو مهدى كنسخة تجريبية مغلقة لمحتواك التقني الرائع."
                }
                else -> {
                    "مرحباً بك يا حمو الإلكتروني! نظام ColorOS 17.0 Ultimate يعمل بأقصى طاقة استيعابية 4.2 جيجاهرتز. لقد قمت بتحسين استهلاك الرام وإفراغ الذاكرة المؤقتة لضمان أداء خارق للألعاب والبث. كيف أساعدك الآن؟"
                }
            }
            val replyList = _chatMessages.value.toMutableList()
            replyList.add(ChatMessage(replyList.size + 1, replyText, false, "09:12"))
            _chatMessages.value = replyList
            _isGeneratingResponse.value = false
        }
    }

    fun scanBill(name: String) {
        if (name.isBlank()) return
        _isScanningBill.value = true
        viewModelScope.launch {
            delay(1800)
            val description = when {
                name.contains("Snapdragon") || name.contains("معالج") -> {
                    "تاريخ: 2026-07-15 • الجهة: Qualcomm Technologies • القيمة: 3,500 د.إ • المكون: Snapdragon 8 Gen 4 Custom Sample • الحالة: مدفوعة بالكامل ومعتمدة من يوتيوب"
                }
                name.contains("استوديو") || name.contains("معدات") || name.contains("يوتيوب") -> {
                    "تاريخ: 2026-07-12 • الجهة: YouTube Space Dubai • القيمة: 12,800 د.إ • المكون: شاشات مراقبة ومعالجات صوتية فائقة • الحالة: مدفوعة ومسجلة تكنولوجياً"
                }
                else -> {
                    "تاريخ: 2026-07-16 • الجهة: Abu Dhabi Advanced Tech • القيمة: 1,500 د.إ • المكون: قطع غيار وتبريد سائل لغرفة المعالجة • الحالة: تم الدفع بنجاح"
                }
            }
            val newList = _scannedBills.value.toMutableList()
            newList.add(0, ScannedBill(name, description))
            _scannedBills.value = newList
            _isScanningBill.value = false
        }
    }

    fun translateMenu(photoName: String) {
        _isTranslatingMenu.value = true
        viewModelScope.launch {
            delay(1500)
            _menuTranslationResult.value = when (photoName) {
                "dubai_yacht_club" -> """
                    --- تم الترجمة بنجاح (مطعم مرسى دبي لليخوت) ---
                    * طبق مقبلات دبي الملكية - 110 د.إ (كافيار طازج وروبيان جامبو)
                    * سمك الهامور الإماراتي المشوي بصلصة الزعفران والليمون - 195 د.إ
                    * شريحة لحم واغيو مع بطاطا غولد كرسبي وتوابل المطورين - 290 د.إ
                    * حلوى الكنافة الذهبية بآيس كريم المستكة الفاخر - 65 د.إ
                """.trimIndent()
                "airport_lounge" -> """
                    --- تم الترجمة بنجاح (صالة كبار المطورين - مطار أبوظبي) ---
                    * قهوة المطورين المفلترة بورق الذهب عيار 24 - مجاني للضيوف
                    * سلة حلويات فرنسية فاخرة ومكسرات محمصة - مجاني
                    * سالمون نرويجي مدخن مع كريمة الأعشاب الطازجة - مجاني
                    * عصير التوت البري والرمان المنعش مع الثلج الجاف - مجاني
                """.trimIndent()
                else -> "تم تصفية الصورة المحددة ولكن لم يتم التعرف على نصوص طعام واضحة. يرجى تجربة قائمة طعام أخرى."
            }
            _isTranslatingMenu.value = false
        }
    }

    fun setPopCamFilter(filter: String) {
        _popCamFilter.value = filter
    }

    fun setAiSmoothLevel(level: Float) {
        _aiSmoothLevel.value = level
    }

    fun toggleVideoStraightening() {
        val nextState = !_isVideoStraighteningActive.value
        _isVideoStraighteningActive.value = nextState
        if (nextState) {
            _videoStabilityScore.value = 0.99f
        } else {
            _videoStabilityScore.value = 0.82f
        }
    }

    fun runPerformanceTest() {
        if (_isPerformanceTesting.value) return
        viewModelScope.launch {
            _isPerformanceTesting.value = true
            _performanceTestProgress.value = 0f
            _performanceScore.value = 0
            for (i in 1..100) {
                delay(25)
                _performanceTestProgress.value = i / 100f
            }
            // AnTuTu style developer benchmark score (Incredibly high score representing overclocked SD8 Gen 4!)
            _performanceScore.value = 3684215
            _isPerformanceTesting.value = false
        }
    }

    fun runSecurityDiagnosis() {
        if (_isSecurityDiagnosing.value) return
        viewModelScope.launch {
            _isSecurityDiagnosing.value = true
            val steps = listOf(
                "جاري فحص نواة معالج Snapdragon 8 Gen 4 (Kernel Protection)...",
                "جاري تشفير الاتصالات بنظام FIPS 140-3 العسكري الإماراتي...",
                "جاري فحص الجدار الناري والتأكد من سلامة كسر السرعة لـ 4.2 جيجاهرتز...",
                "تم فحص ثغرات النظام والتحقق من سلامة الأذونات وحظر التطبيقات الضارة...",
                "تم بنجاح! جميع اختبارات الاختراق تم اجتيازها (حماية 100%)"
            )
            for (step in steps) {
                _securityDiagnosisStatus.value = step
                delay(1000)
            }
            _isSecurityDiagnosing.value = false
        }
    }

    // --- INTENTS TO REAL SYSTEM SETTINGS (The bridging integration!) ---

    fun launchRealWifiSettings() {
        try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun launchRealBluetoothSettings() {
        try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun launchRealDisplaySettings() {
        try {
            val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun launchRealSoundSettings() {
        try {
            val intent = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun launchRealBatterySettings() {
        try {
            val intent = Intent(Intent.ACTION_POWER_USAGE_SUMMARY).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (ex: Exception) {
                // ignore
            }
        }
    }

    fun launchRealAppSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun launchRealDeveloperSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (ex: Exception) {
                // ignore
            }
        }
    }

    fun launchRealSystemSettings() {
        try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // ignore
        }
    }
}

// --- DATA STRUCTURE MODULES ---

data class MindNote(
    val id: Int,
    val title: String,
    val content: String,
    val tag: String,
    val date: String
)

data class ChatMessage(
    val id: Int,
    val text: String,
    val isUser: Boolean,
    val timestamp: String
)

data class ScannedBill(
    val title: String,
    val details: String
)

data class AppInfo(
    val name: String,
    val packageName: String,
    val iconDrawableRes: Int?,
    val version: String,
    val sizeMB: Int
)
