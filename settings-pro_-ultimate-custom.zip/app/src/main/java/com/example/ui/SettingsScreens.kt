package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.AppInfo
import com.example.R
import com.example.SettingsViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainSettingsScreen(
    viewModel: SettingsViewModel,
    onNavigate: (String) -> Unit
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isWifiOn by viewModel.isWifiEnabled.collectAsState()
    val isBluetoothOn by viewModel.isBluetoothEnabled.collectAsState()
    val isFlashlightOn by viewModel.isFlashlightEnabled.collectAsState()
    val isEyeComfortOn by viewModel.isEyeComfortEnabled.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val storageUsed by viewModel.storageUsedGB.collectAsState()
    val storageTotal by viewModel.storageTotalGB.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                LargeTopAppBar(
                    title = {
                        Text(
                            text = viewModel.getTranslation("settings"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Search Bar
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { Text(viewModel.getTranslation("search_hint")) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ColorOS_Teal) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(Icons.Default.Close, contentDescription = null)
                                }
                            }
                        },
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = ColorOS_Teal,
                            unfocusedBorderColor = Color.Transparent
                        )
                    )
                }

                // Oppo ID Card
                item {
                    Card(
                        onClick = { onNavigate("language") }, // Quick jump to language/account settings
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = ColorOS_Teal.copy(alpha = 0.08f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, ColorOS_Teal, CircleShape)
                            ) {
                                // Dynamic generated photo loaded locally
                                Image(
                                    painter = painterResource(id = R.drawable.oppo_id_avatar),
                                    contentDescription = "User Portrait",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = viewModel.getTranslation("oppo_id"),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = viewModel.getTranslation("oppo_id_desc"),
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = if (isRtl) Icons.AutoMirrored.Filled.ArrowBack else Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = ColorOS_Teal
                            )
                        }
                    }
                }

                // Quick Settings Panel (Interactive Status ribbon)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickTile(
                            title = viewModel.getTranslation("wifi"),
                            subtitle = if (isWifiOn) viewModel.getTranslation("wifi_on") else viewModel.getTranslation("wifi_off"),
                            icon = Icons.Default.Wifi,
                            isActive = isWifiOn,
                            onClick = { viewModel.toggleWifi() },
                            onLongClick = { onNavigate("wifi") },
                            modifier = Modifier.weight(1f)
                        )
                        QuickTile(
                            title = viewModel.getTranslation("bluetooth"),
                            subtitle = if (isBluetoothOn) viewModel.getTranslation("wifi_on") else viewModel.getTranslation("wifi_off"),
                            icon = Icons.Default.Bluetooth,
                            isActive = isBluetoothOn,
                            onClick = { viewModel.toggleBluetooth() },
                            onLongClick = { onNavigate("bluetooth") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickTile(
                            title = "Flashlight",
                            subtitle = if (isFlashlightOn) "ON" else "OFF",
                            icon = Icons.Default.FlashlightOn,
                            isActive = isFlashlightOn,
                            onClick = { viewModel.toggleFlashlight() },
                            onLongClick = {},
                            modifier = Modifier.weight(1f)
                        )
                        QuickTile(
                            title = viewModel.getTranslation("eye_comfort"),
                            subtitle = if (isEyeComfortOn) "ON" else "OFF",
                            icon = Icons.Default.RemoveRedEye,
                            isActive = isEyeComfortOn,
                            onClick = { viewModel.toggleEyeComfort() },
                            onLongClick = { onNavigate("display") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Main Navigation List
                item {
                    Text(
                        text = "System Settings & Hardware",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOS_Teal,
                        modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 4.dp)
                    )
                }

                // Dynamic Settings Options Grouped
                val settingsItems = listOf(
                    SettingsMenuItem(
                        key = "personalization",
                        icon = Icons.Default.Palette,
                        route = "personalization",
                        iconBg = System_Purple
                    ),
                    SettingsMenuItem(
                        key = "display",
                        icon = Icons.Default.LightMode,
                        route = "display",
                        iconBg = System_Blue
                    ),
                    SettingsMenuItem(
                        key = "sound",
                        icon = Icons.Default.VolumeUp,
                        route = "sound",
                        iconBg = System_Orange
                    ),
                    SettingsMenuItem(
                        key = "battery",
                        icon = Icons.Default.BatteryChargingFull,
                        route = "battery",
                        iconBg = System_Green
                    ),
                    SettingsMenuItem(
                        key = "apps",
                        icon = Icons.Default.Apps,
                        route = "apps",
                        iconBg = System_Blue
                    ),
                    SettingsMenuItem(
                        key = "special_features",
                        icon = Icons.Default.AutoAwesome,
                        route = "special_features",
                        iconBg = ColorOS_Teal
                    ),
                    SettingsMenuItem(
                        key = "language",
                        icon = Icons.Default.Language,
                        route = "language",
                        iconBg = System_Gold
                    ),
                    SettingsMenuItem(
                        key = "about",
                        icon = Icons.Default.Info,
                        route = "about",
                        iconBg = ColorOS_Teal_Dark
                    )
                )

                // Filter list by search query
                val filteredItems = if (searchQuery.isBlank()) {
                    settingsItems
                } else {
                    settingsItems.filter {
                        viewModel.getTranslation(it.key).contains(searchQuery, ignoreCase = true) ||
                                viewModel.getTranslation("${it.key}_desc").contains(searchQuery, ignoreCase = true)
                    }
                }

                items(filteredItems) { item ->
                    SettingsRow(
                        title = viewModel.getTranslation(item.key),
                        description = viewModel.getTranslation("${item.key}_desc"),
                        icon = item.icon,
                        iconBg = item.iconBg,
                        onClick = { onNavigate(item.route) },
                        isRtl = isRtl
                    )
                }

                // Bottom spacer
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

// Quick Tile Card Composable
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun QuickTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColors = if (isActive) {
        CardDefaults.cardColors(containerColor = ColorOS_Teal)
    } else {
        CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    }
    val contentColor = if (isActive) Color.White else MaterialTheme.colorScheme.onBackground
    val descColor = if (isActive) Color.White.copy(alpha = 0.75f) else MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        modifier = modifier
            .height(78.dp)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(18.dp),
        colors = bgColors
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (isActive) Color.White.copy(alpha = 0.2f) else ColorOS_Teal.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isActive) Color.White else ColorOS_Teal,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = contentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = descColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// Settings Item Row Composable
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsRow(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    onClick: () -> Unit,
    isRtl: Boolean
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = if (isRtl) Icons.AutoMirrored.Filled.ArrowBack else Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

// Data structure
data class SettingsMenuItem(
    val key: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val route: String,
    val iconBg: Color
)


// ==========================================
// SUB-SCREEN 1: Wi-Fi Detail Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiSettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val isWifiOn by viewModel.isWifiEnabled.collectAsState()
    val connectedSsid by viewModel.wifiSsid.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("wifi"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Wi-Fi Master Toggle
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(viewModel.getTranslation("wifi"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(
                                if (isWifiOn) viewModel.getTranslation("wifi_on") else viewModel.getTranslation("wifi_off"),
                                fontSize = 12.sp,
                                color = ColorOS_Teal
                            )
                        }
                        Switch(
                            checked = isWifiOn,
                            onCheckedChange = { viewModel.toggleWifi() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                        )
                    }
                }

                if (isWifiOn) {
                    Text("Connected Network", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ColorOS_Teal)
                    // Connected SSID Info
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = ColorOS_Teal.copy(alpha = 0.05f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = ColorOS_Teal, modifier = Modifier.size(28.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(connectedSsid, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Signal: Excellent • Speed: 866 Mbps", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ColorOS_Teal)
                        }
                    }

                    Text("Available Networks", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    val networks = listOf("Vodafone_VDSL_5G", "Hany_Wifi_Plus", "WE_Active_77", "Oppo_Personal_Hotspot", "Mall_Free_HighSpeed")
                    networks.forEach { ssid ->
                        Card(
                            onClick = { viewModel.toggleWifi() }, // Quick connection simulation
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(Icons.Default.Wifi, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(ssid, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                }
                                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.WifiOff, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Wi-Fi is turned off", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 2: Bluetooth Detail Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BluetoothSettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    val isBtOn by viewModel.isBluetoothEnabled.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("bluetooth"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(viewModel.getTranslation("bluetooth"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(
                                if (isBtOn) "OPPO Reno6 Pro is visible to nearby devices" else "Invisible",
                                fontSize = 12.sp,
                                color = ColorOS_Teal
                            )
                        }
                        Switch(
                            checked = isBtOn,
                            onCheckedChange = { viewModel.toggleBluetooth() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                        )
                    }
                }

                if (isBtOn) {
                    Text("Paired Devices", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ColorOS_Teal)

                    val pairedDevices = listOf(
                        Pair("OPPO Enco X2", "Connected • Battery 100%"),
                        Pair("OPPO Watch 3 Pro", "Connected"),
                        Pair("Hany's Windows 11 PC", "Paired"),
                        Pair("Samsung QLED TV 65", "Paired")
                    )

                    pairedDevices.forEach { device ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        if (device.first.contains("Enco") || device.first.contains("Ear")) Icons.Default.Headphones else Icons.Default.Devices,
                                        contentDescription = null,
                                        tint = ColorOS_Teal
                                    )
                                    Column {
                                        Text(device.first, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                        Text(device.second, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.BluetoothDisabled, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Bluetooth is disabled", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 3: Personalization & Themes Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalizationScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val selectedFingerprint by viewModel.fingerprintAnimation.collectAsState()
    val selectedEdgeColor by viewModel.edgeLightingColor.collectAsState()

    // Animation trigger for visualizer
    var animTrigger by remember { mutableStateOf(0f) }
    LaunchedEffect(selectedFingerprint) {
        animTrigger = 0f
        while (true) {
            animate(0f, 1f, animationSpec = tween(1500, easing = LinearEasing)) { value, _ ->
                animTrigger = value
            }
            delay(200)
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("personalization"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Feature Header Preview Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            // Animated neon background depending on Selected Edge lighting
                            val glowingColor = when (selectedEdgeColor) {
                                "Teal" -> ColorOS_Teal
                                "Blue" -> System_Blue
                                "Gold" -> System_Gold
                                "Purple" -> System_Purple
                                else -> ColorOS_Teal
                            }
                            
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                // Draw an animated neon glow frame to simulate edge lighting!
                                val strokeWidth = 8f
                                val progress = animTrigger
                                drawRoundRect(
                                    color = glowingColor.copy(alpha = 0.8f),
                                    topLeft = Offset(strokeWidth, strokeWidth),
                                    size = Size(size.width - strokeWidth * 2, size.height - strokeWidth * 2),
                                    style = Stroke(
                                        width = strokeWidth,
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(120f, 60f), progress * 180f)
                                    ),
                                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(24.dp.toPx(), 24.dp.toPx())
                                )
                            }

                            // Content inside preview
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "ColorOS Active Workspace",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                // Fingerprint glow animation
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .background(glowingColor.copy(alpha = 0.15f))
                                        .border(1.5.dp, glowingColor.copy(alpha = 0.4f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Fingerprint,
                                        contentDescription = null,
                                        tint = glowingColor,
                                        modifier = Modifier.size(34.dp)
                                    )
                                    
                                    // Animated circle ripples
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        drawCircle(
                                            color = glowingColor,
                                            radius = (size.minDimension / 2) * animTrigger,
                                            style = Stroke(width = 3f),
                                            alpha = 1f - animTrigger
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "${viewModel.getTranslation("fingerprint_anim")}: ${viewModel.getTranslation(selectedFingerprint.lowercase())}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Interactive choice for Fingerprint animations
                item {
                    Text(viewModel.getTranslation("fingerprint_anim"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)
                }

                item {
                    val animations = listOf("Fizz", "Ripple", "Stardust", "None")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        animations.forEach { anim ->
                            val isSelected = selectedFingerprint == anim
                            Card(
                                onClick = { viewModel.setFingerprintAnimation(anim) },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) ColorOS_Teal else MaterialTheme.colorScheme.surface
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(55.dp)
                            ) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = viewModel.getTranslation(anim.lowercase()),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                                    )
                                }
                            }
                        }
                    }
                }

                // Interactive choice for Edge Lighting color
                item {
                    Text(viewModel.getTranslation("edge_lighting"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)
                }

                item {
                    val colors = listOf("Teal", "Blue", "Gold", "Purple")
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        colors.forEach { color ->
                            val isSelected = selectedEdgeColor == color
                            val badgeColor = when (color) {
                                "Teal" -> ColorOS_Teal
                                "Blue" -> System_Blue
                                "Gold" -> System_Gold
                                "Purple" -> System_Purple
                                else -> ColorOS_Teal
                            }
                            Card(
                                onClick = { viewModel.setEdgeLightingColor(color) },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) badgeColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                border = if (isSelected) BorderStroke(1.5.dp, badgeColor) else null
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Box(modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(badgeColor))
                                        Text(viewModel.getTranslation(color.lowercase()), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = badgeColor)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 4: Display & Brightness Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DisplayBrightnessScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val isDarkTheme by viewModel.isDarkMode.collectAsState()
    val isEyeComfort by viewModel.isEyeComfortEnabled.collectAsState()
    val brightness by viewModel.screenBrightness.collectAsState()
    val fontScale by viewModel.fontSizeScale.collectAsState()
    val hasWritePermission by viewModel.hasWriteSettingsPermission.collectAsState()
    val context = LocalContext.current

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("display"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Permission Card for Brightness Control if missing
                if (!hasWritePermission) {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                try {
                                    val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (ex: Exception) {
                                    // ignore fallback
                                }
                            }
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isRtl) "تفعيل التحكم الفعلي بالسطوع" else "Enable Real Brightness Control",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Text(
                                    text = if (isRtl) "اضغط هنا لمنح إذن النظام للتحكم بسطوع شاشتك الحقيقي" else "Tap here to grant system permission to adjust real screen brightness",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }

                // Theme Switcher Cards (Side by side Light & Dark options!)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Light mode card
                    Card(
                        onClick = { viewModel.setDarkMode(false) },
                        modifier = Modifier
                            .weight(1f)
                            .height(110.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = if (!isDarkTheme) ColorOS_Teal.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface),
                        border = if (!isDarkTheme) BorderStroke(2.dp, ColorOS_Teal) else null
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.LightMode, contentDescription = null, tint = if (!isDarkTheme) ColorOS_Teal else MaterialTheme.colorScheme.onBackground)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Light Mode", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Dark mode card
                    Card(
                        onClick = { viewModel.setDarkMode(true) },
                        modifier = Modifier
                            .weight(1f)
                            .height(110.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) ColorOS_Teal.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface),
                        border = if (isDarkTheme) BorderStroke(2.dp, ColorOS_Teal) else null
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = if (isDarkTheme) ColorOS_Teal else MaterialTheme.colorScheme.onBackground)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Dark Mode", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Brightness Slider Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(viewModel.getTranslation("brightness"), fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.WbSunny, contentDescription = null, tint = ColorOS_Teal)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Slider(
                            value = brightness.toFloat(),
                            onValueChange = { viewModel.setBrightness(it.toInt()) },
                            valueRange = 0f..255f,
                            colors = SliderDefaults.colors(thumbColor = ColorOS_Teal, activeTrackColor = ColorOS_Teal)
                        )
                    }
                }

                // Eye Comfort Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(viewModel.getTranslation("eye_comfort"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Reduce blue light to prevent eye strain", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = isEyeComfort,
                            onCheckedChange = { viewModel.toggleEyeComfort() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                        )
                    }
                }

                // Refresh Rate Selection Card (OPPO 90Hz specialty)
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Screen Refresh Rate", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Choose refresh rate for ultra smooth visual motions", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))
                        var selectedRate by remember { mutableStateOf("90Hz") }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf("60Hz", "90Hz").forEach { rate ->
                                val selected = selectedRate == rate
                                Card(
                                    onClick = { selectedRate = rate },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (selected) ColorOS_Teal else MaterialTheme.colorScheme.surfaceVariant),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(45.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text(rate, color = if (selected) Color.White else MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 5: Sound & Vibration Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundVibrationScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val mediaVol by viewModel.mediaVolume.collectAsState()
    val ringVol by viewModel.ringVolume.collectAsState()
    val notifVol by viewModel.notificationVolume.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("sound"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Media Volume Slider
                item {
                    VolumeSliderCard(
                        title = viewModel.getTranslation("volume_media"),
                        volume = mediaVol,
                        maxVolume = viewModel.maxMediaVolume,
                        icon = Icons.Default.MusicNote,
                        onVolumeChange = { viewModel.setMediaVolume(it) }
                    )
                }

                // Ringtone Volume Slider
                item {
                    VolumeSliderCard(
                        title = viewModel.getTranslation("volume_ring"),
                        volume = ringVol,
                        maxVolume = viewModel.maxRingVolume,
                        icon = Icons.Default.PhoneInTalk,
                        onVolumeChange = { viewModel.setRingVolume(it) }
                    )
                }

                // Notification Volume Slider
                item {
                    VolumeSliderCard(
                        title = viewModel.getTranslation("volume_notif"),
                        volume = notifVol,
                        maxVolume = viewModel.maxNotificationVolume,
                        icon = Icons.Default.Notifications,
                        onVolumeChange = { viewModel.setNotificationVolume(it) }
                    )
                }

                // Dolby Atmos Custom Panel (High end sound tech)
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Hearing, contentDescription = null, tint = ColorOS_Teal)
                                    Text("Dolby Atmos® Sound", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                                var dolbyOn by remember { mutableStateOf(true) }
                                Switch(
                                    checked = dolbyOn,
                                    onCheckedChange = { dolbyOn = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Immersive dimensional surround audio virtualization.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
     compositionLocalProviderCheck()
    }
}

private fun compositionLocalProviderCheck() {}

@Composable
fun VolumeSliderCard(
    title: String,
    volume: Int,
    maxVolume: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onVolumeChange: (Int) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Bold)
                Icon(icon, contentDescription = null, tint = ColorOS_Teal, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Slider(
                    value = volume.toFloat(),
                    onValueChange = { onVolumeChange(it.toInt()) },
                    valueRange = 0f..maxVolume.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = ColorOS_Teal, activeTrackColor = ColorOS_Teal),
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${((volume.toFloat() / maxVolume.toFloat()) * 100).toInt()}%",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = ColorOS_Teal,
                    modifier = Modifier.width(38.dp),
                    textAlign = TextAlign.End
                )
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 6: Battery & Power Info Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatteryScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val isCharging by viewModel.isBatteryCharging.collectAsState()
    val superPowerOn by viewModel.isSuperPowerSaving.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("battery"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Interactive Battery Circle Gauge
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val progressAnim by animateFloatAsState(
                        targetValue = batteryLevel.toFloat() / 100f,
                        animationSpec = tween(1200)
                    )
                    
                    val activeColor = when {
                        isCharging -> ColorOS_Teal
                        batteryLevel <= 20 -> System_Red
                        batteryLevel <= 40 -> System_Orange
                        else -> ColorOS_Teal
                    }

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Background track
                        drawCircle(
                            color = activeColor.copy(alpha = 0.15f),
                            style = Stroke(width = 16.dp.toPx())
                        )
                        // Progress arc
                        drawArc(
                            color = activeColor,
                            startAngle = -90f,
                            sweepAngle = 360f * progressAnim,
                            useCenter = false,
                            style = Stroke(width = 16.dp.toPx(), pathEffect = null)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$batteryLevel%",
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isCharging) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = activeColor, modifier = Modifier.size(16.dp))
                            }
                            Text(
                                text = if (isCharging) viewModel.getTranslation("charging") else viewModel.getTranslation("not_charging"),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Super Power Saving Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(viewModel.getTranslation("super_power_saving"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Locks apps in background to expand standby up to 48 hours", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = superPowerOn,
                            onCheckedChange = { viewModel.toggleSuperPowerSaving() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = ColorOS_Teal)
                        )
                    }
                }

                // Battery Health Indicator
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = System_Red, modifier = Modifier.size(24.dp))
                        Column {
                            Text("Battery Health (صحة البطارية)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(viewModel.getTranslation("battery_health"), fontSize = 12.sp, color = ColorOS_Teal)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 7: App Manager Screen (REAL APP telemetry!)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppManagerScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val installedApps by viewModel.installedApps.collectAsState()
    val context = LocalContext.current

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("apps"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header showing total apps
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ColorOS_Teal),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(viewModel.getTranslation("app_list"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Found ${installedApps.size} installed applications on your Reno device.", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    }
                }

                // Apps Lazy Column
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(installedApps) { app ->
                        Card(
                            onClick = {
                                // Dynamic Launch intent trigger! Let Hany launch real apps directly from here!
                                try {
                                    val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                                    if (launchIntent != null) {
                                        context.startActivity(launchIntent)
                                    }
                                } catch (e: Exception) {
                                    // Safe ignore if cannot launch
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(ColorOS_Teal.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Android, contentDescription = null, tint = ColorOS_Teal, modifier = Modifier.size(24.dp))
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(app.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(app.packageName, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${app.sizeMB} MB", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ColorOS_Teal)
                                    Text("v${app.version}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 8: Special Features Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpecialFeaturesScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("special_features"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Split Screen guide
                item {
                    SpecialFeatureCard(
                        title = viewModel.getTranslation("split_screen"),
                        desc = "Swipe up with three fingers to enter split-screen mode instantly and multi-task like a pro.",
                        icon = Icons.Default.VerticalSplit
                    )
                }

                // Sidebar panel guide
                item {
                    SpecialFeatureCard(
                        title = viewModel.getTranslation("sidebar"),
                        desc = "Slide out from the upper right of the screen to open quick-access utilities and shortcuts.",
                        icon = Icons.Default.ViewSidebar
                    )
                }

                // Flexible windows
                item {
                    SpecialFeatureCard(
                        title = viewModel.getTranslation("flexible_windows"),
                        desc = "Floating windows can be resized, minimized to the screen edge, or maximized into full screen.",
                        icon = Icons.Default.PictureInPicture
                    )
                }
            }
        }
    }
}

@Composable
fun SpecialFeatureCard(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ColorOS_Teal.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = ColorOS_Teal, modifier = Modifier.size(24.dp))
            }
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = ColorOS_Teal)
                Spacer(modifier = Modifier.height(4.dp))
                Text(desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 9: Language & Scale Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageRegionScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val fontScale by viewModel.fontSizeScale.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("language"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(viewModel.getTranslation("language"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)

                // Selectable Language cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        onClick = { viewModel.setLanguage("ar") },
                        modifier = Modifier
                            .weight(1f)
                            .height(60.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isRtl) ColorOS_Teal.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isRtl) BorderStroke(1.5.dp, ColorOS_Teal) else null
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("العربية", fontWeight = FontWeight.Bold)
                        }
                    }

                    Card(
                        onClick = { viewModel.setLanguage("en") },
                        modifier = Modifier
                            .weight(1f)
                            .height(60.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (!isRtl) ColorOS_Teal.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (!isRtl) BorderStroke(1.5.dp, ColorOS_Teal) else null
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("English", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(viewModel.getTranslation("font_size"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ColorOS_Teal)

                // Font size modifier card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Sample text size visualization",
                            fontSize = (15f * fontScale).sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("A", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Slider(
                                value = fontScale,
                                onValueChange = { viewModel.setFontSizeScale(it) },
                                valueRange = 0.8f..1.3f,
                                colors = SliderDefaults.colors(thumbColor = ColorOS_Teal, activeTrackColor = ColorOS_Teal),
                                modifier = Modifier.weight(1f)
                            )
                            Text("A", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SUB-SCREEN 10: About Device Screen
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutDeviceScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isRtl = currentLanguage == "ar"
    
    val storageUsed by viewModel.storageUsedGB.collectAsState()
    val storageTotal by viewModel.storageTotalGB.collectAsState()
    val ramTotal by viewModel.ramTotalGB.collectAsState()
    val ramExpansion by viewModel.ramExpansionGB.collectAsState()

    val batteryTemp by viewModel.batteryTemp.collectAsState()
    val batteryVoltage by viewModel.batteryVoltage.collectAsState()

    CompositionLocalProvider(
        LocalLayoutDirection provides (if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(viewModel.getTranslation("about"), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Beautiful Header image generated
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.coloros_banner),
                            contentDescription = "ColorOS fluid design banner",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, ColorOS_Dark_Bg.copy(alpha = 0.85f))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp)
                        ) {
                            Text(
                                "OPPO Reno6 Pro 5G",
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                                color = Color.White
                            )
                            Text(
                                "ColorOS 13 | Android 13",
                                fontSize = 13.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                // Grid specifications
                item {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Storage Card showing dynamic real-world sizes
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(viewModel.getTranslation("storage"), fontWeight = FontWeight.Bold)
                                    Text("$storageUsed GB / $storageTotal GB", fontWeight = FontWeight.Bold, color = ColorOS_Teal)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                LinearProgressIndicator(
                                    progress = storageUsed.toFloat() / storageTotal.toFloat(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(CircleShape),
                                    color = ColorOS_Teal,
                                    trackColor = ColorOS_Teal.copy(alpha = 0.15f)
                                )
                            }
                        }

                        // Specs details row
                        SpecRow(label = viewModel.getTranslation("device_name"), value = "OPPO Reno6 Pro 5G")
                        SpecRow(label = viewModel.getTranslation("model"), value = "CPH2247")
                        SpecRow(
                            label = viewModel.getTranslation("processor"),
                            value = viewModel.getTranslation("processor_val")
                        )
                        SpecRow(
                            label = viewModel.getTranslation("ram"),
                            value = "$ramTotal.00 GB (+ $ramExpansion.00 GB virtual expandable)"
                        )
                        SpecRow(label = viewModel.getTranslation("coloros_version"), value = "v13.0 Official")
                        SpecRow(label = viewModel.getTranslation("android_version"), value = "Android 13 (Latest SDK)")
                        SpecRow(label = viewModel.getTranslation("regulatory"), value = "CE / FCC certification passed")
                    }
                }

                // Real System Diagnostics Card
                item {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isRtl) "تشخيص العتاد الحقيقي للجهاز" else "Real Device Hardware Diagnostics",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = ColorOS_Teal,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (isRtl) "جهازك الفعلي" else "Actual Phone Model", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(viewModel.realDeviceModel, fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                }
                                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (isRtl) "إصدار أندرويد الفعلي" else "Actual Android Version", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Android ${viewModel.realAndroidVersion} (API ${viewModel.realApiLevel})", fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                }
                                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (isRtl) "درجة حرارة البطارية" else "Battery Temperature", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(String.format("%.1f °C", batteryTemp), fontWeight = FontWeight.SemiBold, color = if (batteryTemp > 39) Color.Red else ColorOS_Teal, fontSize = 13.sp)
                                }
                                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (isRtl) "جهد البطارية" else "Battery Voltage", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(String.format("%.2f V", batteryVoltage), fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                }
                                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (isRtl) "عدد الأنوية الحقيقي" else "Actual CPU Cores", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("${viewModel.realProcessorCores} Cores", fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                }
                                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (isRtl) "تحديث الأمان الفعلي" else "Actual Security Patch", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(viewModel.realSecurityPatch, fontWeight = FontWeight.SemiBold, color = ColorOS_Teal, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun SpecRow(label: String, value: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ColorOS_Teal)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
