package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = ColorOS_Teal,
    onPrimary = ColorOS_Light_Surface,
    primaryContainer = ColorOS_Teal_Dark,
    secondary = ColorOS_Teal_Light,
    background = ColorOS_Dark_Bg,
    surface = ColorOS_Dark_Surface,
    surfaceVariant = ColorOS_Dark_Card,
    onBackground = ColorOS_Dark_Text_Primary,
    onSurface = ColorOS_Dark_Text_Primary,
    onSurfaceVariant = ColorOS_Dark_Text_Secondary
)

private val LightColorScheme = lightColorScheme(
    primary = ColorOS_Teal,
    onPrimary = ColorOS_Light_Surface,
    primaryContainer = ColorOS_Teal_Light,
    secondary = ColorOS_Teal_Dark,
    background = ColorOS_Light_Bg,
    surface = ColorOS_Light_Surface,
    surfaceVariant = ColorOS_Light_Card,
    onBackground = ColorOS_Light_Text_Primary,
    onSurface = ColorOS_Light_Text_Primary,
    onSurfaceVariant = ColorOS_Light_Text_Secondary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
