package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            MyApplicationTheme(darkTheme = isDarkMode) {
                val navController = rememberNavController()
                
                NavHost(
                    navController = navController,
                    startDestination = "main"
                ) {
                    composable("main") {
                        MainSettingsScreen(viewModel = viewModel) { route ->
                            navController.navigate(route)
                        }
                    }
                    composable("wifi") {
                        WifiSettingsScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("bluetooth") {
                        BluetoothSettingsScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("personalization") {
                        PersonalizationScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("display") {
                        DisplayBrightnessScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("sound") {
                        SoundVibrationScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("battery") {
                        BatteryScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("apps") {
                        AppManagerScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("special_features") {
                        SpecialFeaturesScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("language") {
                        LanguageRegionScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                    composable("about") {
                        AboutDeviceScreen(viewModel = viewModel) {
                            navController.popBackStack()
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkWriteSettingsPermission()
        viewModel.updateRealWifiStatus()
        viewModel.updateRealBluetoothStatus()
    }
}
