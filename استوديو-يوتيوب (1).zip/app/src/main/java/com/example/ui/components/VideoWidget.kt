package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.example.VideoItem
import com.example.ui.theme.*

@Composable
fun VideoThumbnail(
    video: VideoItem,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
    ) {
        if (video.thumbnailResId != null) {
            Image(
                painter = painterResource(id = video.thumbnailResId),
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = video.thumbnailGradientColors.map { Color(it) }
                        )
                    )
            )
            
            // Draw some decorative matrix/security patterns on thumbnail
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height
                
                // Subtle code scanning grid
                val strokeWidth = 1.dp.toPx()
                for (i in 0..10) {
                    val y = height * (i / 10f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.04f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = strokeWidth
                    )
                }
                
                // Draw a tech glowing circle
                drawCircle(
                    color = if (video.isShort) YtRed.copy(alpha = 0.15f) else YtBlue.copy(alpha = 0.15f),
                    radius = width * 0.25f,
                    center = Offset(width * 0.7f, height * 0.5f)
                )
            }
        }
        
        // Interactive icons depending on the theme
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            // Top-left brand icon (e.g., security lock / shield / warning)
            val icon = when {
                video.title.contains("واي فاي") -> Icons.Default.WifiLock
                video.title.contains("تجسس") -> Icons.Default.VisibilityOff
                video.title.contains("تشفر") -> Icons.Default.Lock
                else -> Icons.Default.Shield
            }
            
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (video.isShort) YtRed.copy(alpha = 0.8f) else YtBlue.copy(alpha = 0.8f),
                modifier = Modifier
                    .size(24.dp)
                    .align(Alignment.TopStart)
            )
            
            // Banner labels
            Text(
                text = if (video.title.contains("2026")) "2026" else "SEC",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .background(
                        color = Color.Black.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            )
            
            // Shorts marker
            if (video.isShort) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier
                        .size(16.dp)
                        .align(Alignment.Center)
                )
            }
            
            // Duration Badge (Bottom-left/right depending on RTL. Since we force RTL, let's put it on bottom-left)
            if (!video.isShort) {
                Text(
                    text = video.duration,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .background(
                            color = Color.Black.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun VideoItemRow(
    video: VideoItem,
    onClick: () -> Unit = {}
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = YtCardBackground
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Right-side info or left-side thumbnail?
            // In standard Arabic Studio RTL, thumbnail is on the left and text on the right (wait, no!
            // In the pictures, looking at the Content screen:
            // - The video title & stats are on the left.
            // - The video thumbnail is on the right.
            // Yes! That is standard RTL layout. The layout goes from right to left, so the thumbnail comes FIRST on the right, and title/stats are on the left.
            // Let's implement this perfectly by utilizing standard RTL Row:
            // First item in Row (right-side) is the Thumbnail, second item (left-side) is the text content.
            
            // Title & stats container (expands to take remaining space)
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = video.title,
                        color = YtTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        modifier = Modifier.weight(1f).padding(end = 6.dp),
                        style = LocalTextStyle.current.copy(lineHeight = 17.sp)
                    )
                    
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = YtTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = video.uploadTime,
                    color = YtTextSecondary,
                    fontSize = 11.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Stats Row: views, likes, comments
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = null,
                            tint = YtTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = video.views,
                            color = YtTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ThumbUpOffAlt,
                            contentDescription = null,
                            tint = YtTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = video.likes,
                            color = YtTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Comment,
                            contentDescription = null,
                            tint = YtTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = video.comments,
                            color = YtTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
            
            // Video Thumbnail (Rightmost in Row in RTL)
            VideoThumbnail(
                video = video,
                modifier = Modifier
                    .width(110.dp)
                    .height(65.dp)
            )
        }
    }
}

@Composable
fun ShortItemCard(
    video: VideoItem,
    onClick: () -> Unit = {}
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = YtCardBackground
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .width(130.dp)
            .height(220.dp)
            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Thumbnail takes 70% of height
            Box(
                modifier = Modifier
                    .weight(0.7f)
                    .fillMaxWidth()
            ) {
                VideoThumbnail(
                    video = video,
                    modifier = Modifier.fillMaxSize()
                )
            }
            
            // Text and stats
            Column(
                modifier = Modifier
                    .weight(0.3f)
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = video.title,
                    color = YtTextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    style = LocalTextStyle.current.copy(lineHeight = 14.sp)
                )
                
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = null,
                            tint = YtTextSecondary,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = video.views,
                            color = YtTextSecondary,
                            fontSize = 9.sp
                        )
                    }
                    
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = null,
                        tint = YtTextSecondary,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}
