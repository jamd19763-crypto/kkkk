package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MockData
import com.example.ui.theme.*

@Composable
fun PaymentActivityScreen(
    onBack: () -> Unit = {}
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(YtDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Toolbar with Back Arrow
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
              ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    text = "نشاط الدفعات",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        
        // Currency Information Banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = YtCardBackground.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = YtBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "تختلف العملة المستخدمة في عملية الدفع عن العملة التلقائية في استوديو YouTube.",
                        color = YtTextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f),
                        style = LocalTextStyle.current.copy(lineHeight = 16.sp)
                    )
                }
            }
        }
        
        // Current earnings / payout progress card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = YtCardBackground
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "ستصلك الدفعات بعد تحقيق أكثر من ج.م. ${MockData.minPayout}",
                        color = YtTextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    
                    Text(
                        text = "ج.م. ${MockData.currentBalance}",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black
                    )
                    
                    // Progress Bar
                    val progressRatio = (MockData.currentBalanceDouble / MockData.minPayoutDouble).toFloat()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(YtTextSecondary.copy(alpha = 0.15f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progressRatio)
                                .clip(RoundedCornerShape(5.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(Color(0xFF00F2FE), Color(0xFF4FACFE))
                                    )
                                )
                        )
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "0%",
                            color = YtTextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "ج.م. ${MockData.currentBalance} من ج.م. ${MockData.minPayout}",
                            color = YtTextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    
                    Divider(color = YtTextSecondary.copy(alpha = 0.1f))
                    
                    Text(
                        text = "فترة تحقيق الأرباح الحالية: من 2026/06/01 حتى 2026/07/13",
                        color = YtBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        
        // Received Payments Section
        item {
            Text(
                text = "الدفعات التي وصلتك مؤخرًا",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
            
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = YtCardBackground
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ج.م. 5,181.69",
                        color = YtGreen,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Column(
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "دفعة شهر مايو",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "وصلت في 2026/05/21",
                            color = YtTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
        
        // Requested Payment History Section (June, July + 12 items)
        item {
            Text(
                text = "جدول الدفعات المخطط لها / التاريخية",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
            )
        }
        
        // Display June & July 2026 payouts first
        items(MockData.specificPayouts) { payout ->
            PayoutHistoryItem(payout = payout)
        }
        
        // Display 12 other historical payouts
        items(MockData.other12Payouts) { payout ->
            PayoutHistoryItem(payout = payout, isOld = true)
        }
        
        // References / Resources Section
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "المراجع والمساعدة",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(YtCardBackground, RoundedCornerShape(16.dp))
                    .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    .padding(vertical = 4.dp)
            ) {
                ReferenceRowItem(title = "كيف يتم احتساب الدفعات التقديرية؟")
                Divider(color = YtTextSecondary.copy(alpha = 0.1f), modifier = Modifier.padding(horizontal = 16.dp))
                ReferenceRowItem(title = "ما التاريخ المتوقع لتلقي الدفعات؟")
                Divider(color = YtTextSecondary.copy(alpha = 0.1f), modifier = Modifier.padding(horizontal = 16.dp))
                ReferenceRowItem(title = "شروط تلقي الأرباح عبر البنوك المصرية")
            }
        }
    }
}

@Composable
fun PayoutHistoryItem(
    payout: com.example.PayoutItem,
    isOld: Boolean = false
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = YtCardBackground.copy(alpha = if (isOld) 0.6f else 1f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = payout.amount,
                color = if (isOld) YtTextPrimary.copy(alpha = 0.7f) else YtBlue,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = payout.title,
                    color = if (isOld) YtTextPrimary.copy(alpha = 0.8f) else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "تاريخ الاستحقاق المقرّر: ${payout.date}",
                    color = YtTextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun ReferenceRowItem(title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {}
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Launch,
            contentDescription = null,
            tint = YtTextSecondary,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = title,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
