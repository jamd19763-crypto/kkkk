package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MockData
import com.example.VideoItem
import com.example.ui.theme.*

@Composable
fun VideoDetailScreen(
    videoId: String,
    onBack: () -> Unit
) {
    // Find video in either videos or shorts
    val isShortVideo = videoId.startsWith("s")
    val initialVideo = if (isShortVideo) {
        MockData.shorts.find { it.id == videoId }
    } else {
        MockData.videos.find { it.id == videoId }
    }

    if (initialVideo == null) {
        Box(
            modifier = Modifier.fillMaxSize().background(YtDarkBackground),
            contentAlignment = Alignment.Center
        ) {
            Text("لم يتم العثور على الفيديو", color = Color.White)
        }
        return
    }

    // Form inputs state
    var titleText by remember { mutableStateOf(initialVideo.title) }
    var descriptionText by remember { mutableStateOf(initialVideo.description) }
    var viewsText by remember { mutableStateOf(initialVideo.views) }
    var likesText by remember { mutableStateOf(initialVideo.likes) }
    var commentsText by remember { mutableStateOf(initialVideo.comments) }
    var durationText by remember { mutableStateOf(initialVideo.duration) }
    var uploadTimeText by remember { mutableStateOf(initialVideo.uploadTime) }
    var visibilityOption by remember { mutableStateOf(initialVideo.visibility) }

    val visibilityList = listOf("علني", "غير مدرج", "خاص")
    var isVisibilityDropdownExpanded by remember { mutableStateOf(false) }

    // Display confirmation snackbar/toast or state
    val scrollState = rememberScrollState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = YtDarkBackground,
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left action: Save Button
                    TextButton(
                        onClick = {
                            // Update values in MockData lists
                            val updated = initialVideo.copy(
                                title = titleText,
                                description = descriptionText,
                                views = viewsText,
                                likes = likesText,
                                comments = commentsText,
                                duration = durationText,
                                uploadTime = uploadTimeText,
                                visibility = visibilityOption
                            )
                            if (isShortVideo) {
                                val idx = MockData.shorts.indexOfFirst { it.id == videoId }
                                if (idx != -1) MockData.shorts[idx] = updated
                            } else {
                                val idx = MockData.videos.indexOfFirst { it.id == videoId }
                                if (idx != -1) MockData.videos[idx] = updated
                            }
                            onBack()
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF3EA6FF))
                    ) {
                        Text(
                            text = "حفظ",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "تعديل تفاصيل الفيديو",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Right action: Close/Back Button
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إلغاء",
                            tint = Color.White
                        )
                    }
                }
                HorizontalDivider(color = YtBorderColor, thickness = 1.dp)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Video Thumbnail card with Pencil edit overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, YtBorderColor, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (initialVideo.thumbnailResId != null) {
                    Image(
                        painter = painterResource(id = initialVideo.thumbnailResId),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF2C0A0A))
                    )
                }

                // Dark overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.4f))
                )

                // Edit Thumbnail Icon overlay (simulates YouTube Studio pencil button)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "تعديل الصورة المصغرة",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = "تغيير الصورة المصغرة",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Title TextField
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "العنوان (مطلوب)",
                    color = YtTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = YtRed,
                        unfocusedBorderColor = YtBorderColor,
                        focusedLabelColor = YtRed,
                        cursorColor = YtRed
                    ),
                    shape = RoundedCornerShape(8.dp),
                    maxLines = 3
                )
            }

            // Description TextField
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "الوصف",
                    color = YtTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                OutlinedTextField(
                    value = descriptionText,
                    onValueChange = { descriptionText = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = YtRed,
                        unfocusedBorderColor = YtBorderColor,
                        focusedLabelColor = YtRed,
                        cursorColor = YtRed
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
            }

            // Settings Section
            Card(
                colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, YtBorderColor, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "إعدادات العرض والخصوصية",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Visibility Dropdown trigger
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isVisibilityDropdownExpanded = true }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = when (visibilityOption) {
                                    "علني" -> Icons.Default.Public
                                    "غير مدرج" -> Icons.Default.Link
                                    else -> Icons.Default.Lock
                                },
                                contentDescription = null,
                                tint = YtTextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = "مستوى العرض",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = visibilityOption,
                                    color = YtTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = YtTextSecondary
                        )
                    }

                    // Dropdown menu
                    Box(modifier = Modifier.fillMaxWidth().wrapContentSize(Alignment.TopStart)) {
                        DropdownMenu(
                            expanded = isVisibilityDropdownExpanded,
                            onDismissRequest = { isVisibilityDropdownExpanded = false },
                            modifier = Modifier.background(YtCardBackground)
                        ) {
                            visibilityList.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option, color = Color.White) },
                                    onClick = {
                                        visibilityOption = option
                                        isVisibilityDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Stats Simulation Section (Perfect for local testing!)
            Card(
                colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, YtBorderColor, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "محاكاة الإحصاءات والأرقام (عدلها للمتعة!)",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Row of text inputs for stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = viewsText,
                            onValueChange = { viewsText = it },
                            label = { Text("المشاهدات", fontSize = 11.sp) },
                            textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = YtRed,
                                unfocusedBorderColor = YtBorderColor,
                                focusedLabelColor = YtRed,
                                cursorColor = YtRed
                            ),
                            shape = RoundedCornerShape(6.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = likesText,
                            onValueChange = { likesText = it },
                            label = { Text("الإعجابات", fontSize = 11.sp) },
                            textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = YtRed,
                                unfocusedBorderColor = YtBorderColor,
                                focusedLabelColor = YtRed,
                                cursorColor = YtRed
                            ),
                            shape = RoundedCornerShape(6.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = commentsText,
                            onValueChange = { commentsText = it },
                            label = { Text("التعليقات", fontSize = 11.sp) },
                            textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = YtRed,
                                unfocusedBorderColor = YtBorderColor,
                                focusedLabelColor = YtRed,
                                cursorColor = YtRed
                            ),
                            shape = RoundedCornerShape(6.dp),
                            singleLine = true
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = durationText,
                            onValueChange = { durationText = it },
                            label = { Text("مدة الفيديو", fontSize = 11.sp) },
                            textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = YtRed,
                                unfocusedBorderColor = YtBorderColor,
                                focusedLabelColor = YtRed,
                                cursorColor = YtRed
                            ),
                            shape = RoundedCornerShape(6.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = uploadTimeText,
                            onValueChange = { uploadTimeText = it },
                            label = { Text("تاريخ الرفع", fontSize = 11.sp) },
                            textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = YtRed,
                                unfocusedBorderColor = YtBorderColor,
                                focusedLabelColor = YtRed,
                                cursorColor = YtRed
                            ),
                            shape = RoundedCornerShape(6.dp),
                            singleLine = true
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
