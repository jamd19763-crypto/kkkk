package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MockData
import com.example.ui.theme.*

@Composable
fun EarnScreen(
    onNavigateToPaymentActivity: () -> Unit = {}
) {
    var selectedMethodTitle by remember { mutableStateOf<String?>(null) }
    var selectedMethodDesc by remember { mutableStateOf<String?>(null) }
    var showPaymentsDialog by remember { mutableStateOf(false) }
    var showAdditionalWaysDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(YtDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Toolbar Title
        item {
            Text(
                text = "تحقيق الربح",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }
        
        // Progress toward next payment card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = YtCardBackground
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "مستوى تقدّمك نحو الحصول على دفعتك التالية",
                        color = YtTextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    
                    Text(
                        text = "ج.م. ${MockData.currentBalance}",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black
                    )
                    
                    // Elegant Progress Bar
                    val progressRatio = (MockData.currentBalanceDouble / MockData.minPayoutDouble).toFloat().coerceIn(0f, 1f)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(YtTextSecondary.copy(alpha = 0.15f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progressRatio)
                                .clip(RoundedCornerShape(5.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(Color(0xFF00F2FE), Color(0xFF4FACFE))
                                    )
                                )
                        )
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الحد الأدنى للدفع: ج.م. ${MockData.minPayout}",
                            color = YtTextSecondary,
                            fontSize = 12.sp
                        )
                        
                        Text(
                            text = "${(progressRatio * 100).toInt()}%",
                            color = Color(0xFF4FACFE),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        
        // Ways to Earn Header
        item {
            Text(
                text = "وسائل تحقيق الربح",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)
            )
        }
        
        // List of Ways to Earn
        item {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                EarnMethodItem(
                    title = "إعلانات صفحة المشاهدة",
                    icon = Icons.Default.Movie,
                    iconColor = YtOrange,
                    onClick = {
                        selectedMethodTitle = "إعلانات صفحة المشاهدة"
                        selectedMethodDesc = "احصل على حصة من أرباح الإعلانات التي تظهر على صفحات مشاهدة الفيديوهات الخاصة بك من خلال المتصفحين والمشاهدين."
                    }
                )
                EarnMethodItem(
                    title = "إعلانات خلاصة Shorts",
                    icon = Icons.Default.FlashOn,
                    iconColor = YtGold,
                    onClick = {
                        selectedMethodTitle = "إعلانات خلاصة Shorts"
                        selectedMethodDesc = "اربح الأموال من خلال عرض الإعلانات التفاعلية بين الفيديوهات في خلاصة Shorts الشهيرة ذات الانتشار الواسع."
                    }
                )
                EarnMethodItem(
                    title = "العضويات",
                    icon = Icons.Default.Stars,
                    iconColor = YtGreen,
                    onClick = {
                        selectedMethodTitle = "العضويات"
                        selectedMethodDesc = "أنشئ نادي معجبين بقناتك بأسعار مخصصة مقابل ميزات حصرية مثل الشارات المخصصة والرموز التعبيرية والردود الحصرية."
                    }
                )
                EarnMethodItem(
                    title = "Supers",
                    icon = Icons.Default.Favorite,
                    iconColor = YtRed,
                    onClick = {
                        selectedMethodTitle = "Supers"
                        selectedMethodDesc = "دع الجماهير يعبرون عن حبهم ويدعمونك ماديًا من خلال شراء رسائل سوبر تشات (Super Chat) وملصقات عجيبة أثناء البث ومقاطع العرض الأول."
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Button(
                onClick = { showAdditionalWaysDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = YtTextSecondary.copy(alpha = 0.1f),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(100.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "طرق إضافية لتحقيق الربح",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        
        // Creator tools & resources
        item {
            Text(
                text = "أدوات ومصادر لصنّاع المحتوى",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
            )
        }
        
        // Tools list
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(YtCardBackground, RoundedCornerShape(16.dp))
                    .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    .padding(vertical = 4.dp)
            ) {
                ToolRowItem(
                    title = "نشاط الدفعات",
                    subtitle = "سجل الإيرادات والتحصيلات التاريخية",
                    icon = Icons.Default.Payments,
                    iconColor = YtBlue,
                    onClick = { showPaymentsDialog = true }
                )
                
                Divider(color = YtTextSecondary.copy(alpha = 0.1f), modifier = Modifier.padding(horizontal = 16.dp))
                
                ToolRowItem(
                    title = "فريق دعم صنّاع المحتوى",
                    subtitle = "تواصل مباشرة مع الدعم الفني",
                    icon = Icons.Default.ContactSupport,
                    iconColor = YtGreen,
                    onClick = {
                        selectedMethodTitle = "فريق دعم صنّاع المحتوى"
                        selectedMethodDesc = "فريق الدعم الفني متوفر 24 ساعة للرد على جميع استفساراتك وحل المشاكل التقنية التي قد تواجهها في قناتك."
                    }
                )
                
                Divider(color = YtTextSecondary.copy(alpha = 0.1f), modifier = Modifier.padding(horizontal = 16.dp))
                
                ToolRowItem(
                    title = "أداة مطابقة حقوق الطبع والنشر",
                    subtitle = "حماية المحتوى والتحقق من السرقة",
                    icon = Icons.Default.Copyright,
                    iconColor = YtGold,
                    onClick = {
                        selectedMethodTitle = "أداة مطابقة حقوق الطبع والنشر"
                        selectedMethodDesc = "تبحث هذه الأداة تلقائيًا عن الفيديوهات المطابقة لمحتواك على قنوات أخرى وتتيح لك خيارات طلب إزالتها لحفظ حقوقك."
                    }
                )
            }
        }
    }

    // 1. Earn Method Detail Dialog
    if (selectedMethodTitle != null && selectedMethodDesc != null) {
        AlertDialog(
            onDismissRequest = {
                selectedMethodTitle = null
                selectedMethodDesc = null
            },
            containerColor = YtCardBackground,
            title = {
                Text(
                    text = selectedMethodTitle!!,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End
                )
            },
            text = {
                Text(
                    text = selectedMethodDesc!!,
                    color = YtTextPrimary,
                    fontSize = 14.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedMethodTitle = null
                        selectedMethodDesc = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = YtBlue)
                ) {
                    Text("فهمت", color = Color.White)
                }
            }
        )
    }

    // 2. Payments Activity History Dialog
    if (showPaymentsDialog) {
        val mockPayments = listOf(
            Triple("12 يوليو 2026", "ج.م. 3,500.00", "تم إرسال الدفعة بنجاح"),
            Triple("12 يونيو 2026", "ج.م. 4,120.00", "تم إرسال الدفعة بنجاح"),
            Triple("12 مايو 2026", "ج.م. 3,890.00", "تم إرسال الدفعة بنجاح"),
            Triple("12 أبريل 2026", "ج.م. 2,980.00", "تم إرسال الدفعة بنجاح"),
            Triple("12 مارس 2026", "ج.م. 5,040.00", "تم إرسال الدفعة بنجاح")
        )
        AlertDialog(
            onDismissRequest = { showPaymentsDialog = false },
            containerColor = YtCardBackground,
            title = {
                Text(
                    text = "سجل دفعات الأرباح",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    mockPayments.forEach { (date, amount, status) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(YtDarkBackground, RoundedCornerShape(10.dp))
                                .border(1.dp, YtBorderColor, RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(text = amount, color = YtGreen, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text(text = status, color = YtTextSecondary, fontSize = 11.sp)
                            }
                            Text(text = date, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showPaymentsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = YtBlue)
                ) {
                    Text("إغلاق", color = Color.White)
                }
            }
        )
    }

    // 3. Additional Ways Dialog
    if (showAdditionalWaysDialog) {
        AlertDialog(
            onDismissRequest = { showAdditionalWaysDialog = false },
            containerColor = YtCardBackground,
            title = {
                Text(
                    text = "ميزات إضافية قادمة",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End
                )
            },
            text = {
                Text(
                    text = "يتم حالياً تطوير ميزات ترويج السلع الخاصة بك (Shopping)، وحملات التمويل الجماعي من المعجبين لإضافتها لبرنامج شركاء YouTube قريباً.",
                    color = YtTextPrimary,
                    fontSize = 14.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End
                )
            },
            confirmButton = {
                Button(
                    onClick = { showAdditionalWaysDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = YtBlue)
                ) {
                    Text("ممتاز", color = Color.White)
                }
            }
        )
    }
}

@Composable
fun EarnMethodItem(
    title: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit = {}
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = YtCardBackground
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = null,
                tint = YtTextSecondary,
                modifier = Modifier.size(18.dp)
            )
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(iconColor.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ToolRowItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.ChevronLeft,
            contentDescription = null,
            tint = YtTextSecondary,
            modifier = Modifier.size(18.dp)
        )
        
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = YtTextSecondary,
                    fontSize = 11.sp
                )
            }
            
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(iconColor.copy(alpha = 0.12f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
