package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.example.MockData
import com.example.ui.theme.*

@Composable
fun AnalyticsScreen() {
    var selectedCategory by remember { mutableStateOf(0) }
    val categories = listOf("نظرة عامة", "المحتوى", "الجمهور", "الإيرادات")
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(YtDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Toolbar Title
        item {
            Text(
                text = "الإحصاءات",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }
        
        // Category Row
        item {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(categories.size) { index ->
                    val isSelected = selectedCategory == index
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { selectedCategory = index }
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = categories[index],
                            color = if (isSelected) Color.White else YtTextSecondary,
                            fontSize = 15.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .height(3.dp)
                                    .width(40.dp)
                                    .background(Color.White, RoundedCornerShape(1.5.dp))
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
        
        // Tab Content Router
        when (selectedCategory) {
            0 -> { // Overview (نظرة عامة)
                // Views Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "المشاهدات", color = YtTextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Text(text = MockData.viewsCount, color = YtTextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = YtGreen, modifier = Modifier.size(20.dp))
                            }
                            Text(text = "كالمعتاد تقريبًا", color = YtGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(24.dp))
                            ReusableAnalyticsChart(
                                points = listOf(0.35f, 0.7f, 0.68f, 0.55f, 0.45f, 0.4f, 0.52f, 0.48f, 0.38f, 0.44f, 0.5f),
                                chartColor = YtBlue,
                                modifier = Modifier.fillMaxWidth().height(160.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "16 يونيو", color = YtTextSecondary, fontSize = 11.sp)
                                Text(text = "13 يوليو", color = YtTextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
                
                // Weekly Summary
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E152A)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, Color(0xFF7B2CBF).copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(48.dp).background(Color(0xFF5A189A), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.EventNote, contentDescription = null, tint = Color(0xFFE0AAFF), modifier = Modifier.size(28.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "ملخصّك الأسبوعي أصبح متوفّرًا", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = "انقر لمشاهدة تحليل سريع لأدائك المميز في الأسبوع الماضي.", color = Color(0xFFD8BBFF), fontSize = 12.sp)
                            }
                            Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = null, tint = Color(0xFFD8BBFF), modifier = Modifier.size(24.dp))
                        }
                    }
                }
                
                // Top Content Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "أهم محتوى", color = YtTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(text = "المشاهدات . آخر 28 يومًا", color = YtTextSecondary, fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
                            MockData.videos.take(3).forEachIndexed { index, video ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "${index + 1}", color = YtTextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(16.dp))
                                    Box(modifier = Modifier.size(width = 54.dp, height = 32.dp).clip(RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                                        if (video.thumbnailResId != null) {
                                            Image(painter = painterResource(id = video.thumbnailResId), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                        } else {
                                            Box(modifier = Modifier.fillMaxSize().background(Brush.linearGradient(colors = listOf(Color(video.thumbnailGradientColors[0]), Color(video.thumbnailGradientColors[1]))))) {
                                                Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Color.White.copy(alpha = 0.5f), modifier = Modifier.size(12.dp).align(Alignment.Center))
                                            }
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = video.title, color = YtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text(text = "${video.views} مشاهدة", color = YtTextSecondary, fontSize = 11.sp)
                                    }
                                }
                                if (index < 2) {
                                    Divider(color = YtTextSecondary.copy(alpha = 0.1f))
                                }
                            }
                        }
                    }
                }
            }
            
            1 -> { // Content (المحتوى)
                // Watch Time Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "وقت المشاهدة (بالساعات)", color = YtTextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Text(text = MockData.watchTime, color = YtTextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Icon(imageVector = Icons.Default.TrendingUp, contentDescription = null, tint = YtGreen, modifier = Modifier.size(24.dp))
                            }
                            Text(text = "مرتفع بنسبة 8% مقارنة بالأسبوع الماضي", color = YtGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(24.dp))
                            ReusableAnalyticsChart(
                                points = listOf(0.2f, 0.4f, 0.35f, 0.6f, 0.5f, 0.55f, 0.7f, 0.65f, 0.8f, 0.75f, 0.9f),
                                chartColor = YtOrange,
                                modifier = Modifier.fillMaxWidth().height(160.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "16 يونيو", color = YtTextSecondary, fontSize = 11.sp)
                                Text(text = "13 يوليو", color = YtTextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
                
                // Average View Duration
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(48.dp).background(YtOrange.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = YtOrange, modifier = Modifier.size(24.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "متوسط مدة المشاهدة", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = "3:42 دقيقة (أعلى بنسبة 12% من المعتاد)", color = YtGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                
                // Detailed Videos Statistics
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "أداء الفيديوهات الفردية", color = YtTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
                            MockData.videos.forEachIndexed { index, video ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(modifier = Modifier.size(width = 54.dp, height = 32.dp).clip(RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                                        if (video.thumbnailResId != null) {
                                            Image(painter = painterResource(id = video.thumbnailResId), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                        } else {
                                            Box(modifier = Modifier.fillMaxSize().background(Brush.linearGradient(colors = listOf(Color(video.thumbnailGradientColors[0]), Color(video.thumbnailGradientColors[1])))))
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = video.title, color = YtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Text(text = "👍 ${video.likes}", color = YtTextSecondary, fontSize = 11.sp)
                                            Text(text = "💬 ${video.comments}", color = YtTextSecondary, fontSize = 11.sp)
                                        }
                                    }
                                }
                                if (index < MockData.videos.size - 1) {
                                    Divider(color = YtTextSecondary.copy(alpha = 0.1f))
                                }
                            }
                        }
                    }
                }
            }
            
            2 -> { // Audience (الجمهور)
                // Subscribers gain
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "المشتركون الجدد", color = YtTextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Text(text = MockData.subscribersChange, color = YtTextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Icon(imageVector = Icons.Default.GroupAdd, contentDescription = null, tint = YtBlue, modifier = Modifier.size(24.dp))
                            }
                            Text(text = "معدّل نموّ مستمر لجمهور القناة", color = YtBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(24.dp))
                            ReusableAnalyticsChart(
                                points = listOf(0.1f, 0.15f, 0.3f, 0.25f, 0.45f, 0.4f, 0.6f, 0.55f, 0.75f, 0.85f, 0.95f),
                                chartColor = YtBlue,
                                modifier = Modifier.fillMaxWidth().height(160.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "16 يونيو", color = YtTextSecondary, fontSize = 11.sp)
                                Text(text = "13 يوليو", color = YtTextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
                
                // Age & Gender
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "السن والجنس للمشاهدين", color = YtTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
                            MetricProgressBarRow(label = "18-24 سنة", valueStr = "42%", percentage = 0.42f, color = YtBlue)
                            MetricProgressBarRow(label = "25-34 سنة", valueStr = "48%", percentage = 0.48f, color = YtOrange)
                            MetricProgressBarRow(label = "أخرى", valueStr = "10%", percentage = 0.10f, color = YtTextSecondary)
                        }
                    }
                }
                
                // Top Geographies
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "أهم المناطق الجغرافية", color = YtTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
                            MetricProgressBarRow(label = "مصر", valueStr = "65%", percentage = 0.65f, color = YtRed)
                            MetricProgressBarRow(label = "العراق", valueStr = "12%", percentage = 0.12f, color = YtBlue)
                            MetricProgressBarRow(label = "السعودية", valueStr = "8%", percentage = 0.08f, color = YtGreen)
                            MetricProgressBarRow(label = "المغرب", valueStr = "5%", percentage = 0.05f, color = YtGold)
                        }
                    }
                }
            }
            
            3 -> { // Revenue (الإيرادات)
                // Estimated Revenue
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "الأرباح المقدّرة", color = YtTextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Text(text = MockData.estimatedRevenue, color = YtTextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Icon(imageVector = Icons.Default.MonetizationOn, contentDescription = null, tint = YtGreen, modifier = Modifier.size(24.dp))
                            }
                            Text(text = "العائد لكل ألف مشاهدة مستقر", color = YtGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(24.dp))
                            ReusableAnalyticsChart(
                                points = listOf(0.4f, 0.35f, 0.5f, 0.48f, 0.65f, 0.58f, 0.7f, 0.68f, 0.82f, 0.78f, 0.85f),
                                chartColor = YtGreen,
                                modifier = Modifier.fillMaxWidth().height(160.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "16 يونيو", color = YtTextSecondary, fontSize = 11.sp)
                                Text(text = "13 يوليو", color = YtTextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
                
                // RPM Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(48.dp).background(YtGreen.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.TrendingUp, contentDescription = null, tint = YtGreen, modifier = Modifier.size(24.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "الأرباح لكل ألف مشاهدة (RPM)", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = "US$ 0.40 ثابت ومستقر", color = YtTextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
                
                // Source of Revenue Breakdown
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YtCardBackground),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "مصادر تحقيق الربح", color = YtTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
                            MetricProgressBarRow(label = "إعلانات صفحة المشاهدة", valueStr = "72%", percentage = 0.72f, color = YtGreen)
                            MetricProgressBarRow(label = "إعلانات خلاصة Shorts", valueStr = "18%", percentage = 0.18f, color = YtOrange)
                            MetricProgressBarRow(label = "ميزات أخرى والداعمين", valueStr = "10%", percentage = 0.10f, color = YtBlue)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricProgressBarRow(
    label: String,
    valueStr: String,
    percentage: Float,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Value on the left
        Text(
            text = valueStr,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(48.dp)
        )

        // Progress Bar (taking up weight)
        Box(
            modifier = Modifier
                .weight(1f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(YtTextSecondary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(percentage)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
            )
        }

        // Label on the right
        Text(
            text = label,
            color = YtTextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.width(130.dp)
        )
    }
}

@Composable
fun ReusableAnalyticsChart(
    points: List<Float>,
    chartColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        
        // Guidelines (Grid Lines)
        val gridLines = 4
        for (i in 0 until gridLines) {
            val y = height * (i / (gridLines - 1).toFloat())
            drawLine(
                color = YtTextSecondary.copy(alpha = 0.08f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.dp.toPx()
            )
        }
        
        if (points.isEmpty()) return@Canvas
        
        val offsets = points.mapIndexed { index, normalizedVal ->
            val x = if (points.size > 1) {
                width * (index / (points.size - 1).toFloat())
            } else {
                width / 2f
            }
            val y = height * 0.15f + (height * 0.7f * (1f - normalizedVal))
            Offset(x, y)
        }
        
        val strokePath = Path().apply {
            moveTo(offsets.first().x, offsets.first().y)
            for (i in 1 until offsets.size) {
                val pPrev = offsets[i - 1]
                val pCurr = offsets[i]
                val cpX = (pPrev.x + pCurr.x) / 2
                cubicTo(
                    x1 = cpX, y1 = pPrev.y,
                    x2 = cpX, y2 = pCurr.y,
                    x3 = pCurr.x, y3 = pCurr.y
                )
            }
        }
        
        val fillPath = Path().apply {
            addPath(strokePath)
            lineTo(width, height)
            lineTo(0f, height)
            close()
        }
        
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(chartColor.copy(alpha = 0.25f), Color.Transparent)
            )
        )
        
        drawPath(
            path = strokePath,
            color = chartColor,
            style = Stroke(width = 3.dp.toPx())
        )
        
        drawCircle(
            color = chartColor,
            radius = 5.dp.toPx(),
            center = offsets.last()
        )
        drawCircle(
            color = Color.White,
            radius = 2.5.dp.toPx(),
            center = offsets.last()
        )
    }
}
