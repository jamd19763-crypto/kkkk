package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MockData
import com.example.ui.components.ShortItemCard
import com.example.ui.components.VideoItemRow
import com.example.ui.theme.*

fun parseViews(viewsStr: String): Double {
    val cleaned = viewsStr.replace(" مشاهدة", "").replace("مشاهدة", "").trim()
    return when {
        cleaned.contains("ألف") -> {
            val numStr = cleaned.replace("ألف", "").trim()
            (numStr.toDoubleOrNull() ?: 1.0) * 1000
        }
        cleaned.contains("آلاف") -> {
            val numStr = cleaned.replace("آلاف", "").trim()
            (numStr.toDoubleOrNull() ?: 1.0) * 1000
        }
        cleaned.contains("مليون") -> {
            val numStr = cleaned.replace("مليون", "").trim()
            (numStr.toDoubleOrNull() ?: 1.0) * 1000000
        }
        else -> cleaned.toDoubleOrNull() ?: 0.0
    }
}

@Composable
fun ContentScreen(
    onVideoClick: (String) -> Unit = {}
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Videos, 1: Shorts, 2: Playlists, 3: Live
    val tabsList = listOf("الفيديوهات", "Shorts", "البث المباشر", "قوائم التشغيل")
    
    var isSearching by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var sortByViews by remember { mutableStateOf(false) } // false: Latest, true: Most Viewed
    
    // Filtering and sorting logic
    val filteredVideos = remember(searchQuery, sortByViews, MockData.videos.size) {
        val list = if (searchQuery.isBlank()) {
            MockData.videos
        } else {
            MockData.videos.filter { it.title.contains(searchQuery, ignoreCase = true) }
        }
        if (sortByViews) {
            list.sortedByDescending { parseViews(it.views) }
        } else {
            list // Keep default order (which is latest first)
        }
    }
    
    val filteredShorts = remember(searchQuery, sortByViews, MockData.shorts.size) {
        val list = if (searchQuery.isBlank()) {
            MockData.shorts
        } else {
            MockData.shorts.filter { it.title.contains(searchQuery, ignoreCase = true) }
        }
        if (sortByViews) {
            list.sortedByDescending { parseViews(it.views) }
        } else {
            list
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(YtDarkBackground)
    ) {
        // Top Toolbar (Handles active Search elegantly)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSearching) {
                // Search Bar Field with Close Trigger
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث في الفيديوهات...", color = YtTextSecondary, fontSize = 14.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = YtBlue,
                        unfocusedBorderColor = YtBorderColor
                    ),
                    trailingIcon = {
                        IconButton(onClick = {
                            searchQuery = ""
                            isSearching = false
                        }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                )
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "المحتوى",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(onClick = { isSearching = true }) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    IconButton(onClick = { sortByViews = !sortByViews }) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "تصفية",
                            tint = if (sortByViews) YtBlue else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
        
        // Tab Selection Row (Horizontal Chips)
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tabsList.size) { index ->
                val isSelected = selectedTab == index
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedTab = index },
                    label = {
                        Text(
                            text = tabsList[index],
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Color.Transparent,
                        selectedContainerColor = YtRed,
                        labelColor = YtTextSecondary,
                        selectedLabelColor = Color.White
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = YtTextSecondary.copy(alpha = 0.3f),
                        selectedBorderColor = Color.Transparent,
                        borderWidth = 1.dp
                    ),
                    shape = RoundedCornerShape(100.dp)
                )
            }
        }
        
        // Sorting and count row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.clickable { sortByViews = !sortByViews }
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Sort,
                    contentDescription = "ترتيب",
                    tint = YtTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = if (sortByViews) "الأكثر مشاهدة" else "الأحدث",
                    color = YtBlue,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Text(
                text = when (selectedTab) {
                    0 -> "إجمالي الفيديوهات (${filteredVideos.size})"
                    1 -> "إجمالي المقاطع (${filteredShorts.size})"
                    else -> "فارغ"
                },
                color = YtTextSecondary,
                fontSize = 12.sp
            )
        }
        
        // List of items
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            when (selectedTab) {
                0 -> { // Videos List
                    if (filteredVideos.isEmpty()) {
                        EmptyContentState(message = "لا توجد فيديوهات تطابق البحث")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 32.dp)
                        ) {
                            items(filteredVideos, key = { it.id }) { video ->
                                VideoItemRow(video = video, onClick = { onVideoClick(video.id) })
                            }
                        }
                    }
                }
                
                1 -> { // Shorts Grid
                    if (filteredShorts.isEmpty()) {
                        EmptyContentState(message = "لا توجد مقاطع Shorts تطابق البحث")
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 32.dp)
                        ) {
                            items(filteredShorts, key = { it.id }) { short ->
                                ShortItemCard(video = short, onClick = { onVideoClick(short.id) })
                            }
                        }
                    }
                }
                
                else -> { // Empty State for Live / Playlists
                    EmptyContentState(message = "لا توجد عناصر لعرضها حاليًا")
                }
            }
        }
    }
}

@Composable
fun EmptyContentState(message: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = Icons.Default.PlaylistPlay,
            contentDescription = null,
            tint = YtTextSecondary,
            modifier = Modifier.size(64.dp)
        )
        Text(
            text = message,
            color = YtTextSecondary,
            fontSize = 14.sp
        )
    }
}
