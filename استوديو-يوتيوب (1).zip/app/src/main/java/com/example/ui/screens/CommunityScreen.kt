package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.CommentItem
import com.example.MockData
import com.example.ui.theme.*

@Composable
fun CommunityScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(YtDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Toolbar Title
        item {
            Text(
                text = "التعليقات",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }
        
        // Comments Love highlight card (التعليقات التي تستحق الحب والتقدير)
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = YtCardBackground
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(1.dp, YtBorderColor, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = YtTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "التعليقات التي تستحق",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = YtRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Small avatar stack or avatar
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE91E63)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("م", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        
                        Text(
                            text = "أرسلت إليك قناة \"@محمودجمال-\" وزادت 24 قناة أخرى الحب والتقدير.",
                            color = YtTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f),
                            style = LocalTextStyle.current.copy(lineHeight = 18.sp)
                        )
                    }
                    
                    Button(
                        onClick = {},
                        colors = ButtonDefaults.buttonColors(
                            containerColor = YtTextSecondary.copy(alpha = 0.15f),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(100.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "عرض التعليقات",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        
        // List of actual comments
        items(MockData.comments) { comment ->
            CommentRowItem(comment = comment)
        }
    }
}

@Composable
fun CommentRowItem(comment: CommentItem) {
    var isLiked by remember { mutableStateOf(false) }
    var isDisliked by remember { mutableStateOf(false) }
    var hasHeart by remember { mutableStateOf(false) }
    var isReplying by remember { mutableStateOf(false) }
    var replyText by remember { mutableStateOf("") }
    
    Card(
        colors = CardDefaults.cardColors(
            containerColor = YtDarkBackground
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Video reference section (The horizontal grey bar or preview at the top)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(YtCardBackground, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = comment.videoTitle,
                    color = YtTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                
                Box(
                    modifier = Modifier
                        .size(width = 36.dp, height = 22.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF2C0A0A))
                )
            }
            
            // Comment details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Leftmost/Rightmost action or details
                IconButton(
                    onClick = {},
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "خيارات",
                        tint = YtTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
                
                // Content of comment
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Header: Handle + Date
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = comment.timeAgo,
                            color = YtTextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = comment.authorHandle,
                            color = YtTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    
                    // Comment text
                    Text(
                        text = comment.text,
                        color = Color.White,
                        fontSize = 13.sp,
                        style = LocalTextStyle.current.copy(lineHeight = 18.sp)
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    // Interaction row (Like, Dislike, Heart, Reply)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Thumbs up (Like)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.clickable {
                                isLiked = !isLiked
                                if (isLiked) isDisliked = false
                            }
                        ) {
                            Icon(
                                imageVector = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                                contentDescription = "أعجبني",
                                tint = if (isLiked) YtBlue else YtTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            if (comment.likesCount > 0 || isLiked) {
                                Text(
                                    text = "${comment.likesCount + if (isLiked) 1 else 0}",
                                    color = YtTextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        
                        // Thumbs down (Dislike)
                        Icon(
                            imageVector = if (isDisliked) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                            contentDescription = "لم يعجبني",
                            tint = if (isDisliked) YtRed else YtTextSecondary,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable {
                                    isDisliked = !isDisliked
                                    if (isDisliked) isLiked = false
                                }
                        )
                        
                        // Heart from Hamo (Love)
                        Box(
                            modifier = Modifier
                                .clickable { hasHeart = !hasHeart }
                                .padding(2.dp),
                            contentAlignment = Alignment.BottomEnd
                        ) {
                            Icon(
                                imageVector = if (hasHeart) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "حب",
                                tint = if (hasHeart) YtRed else YtTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            // Display tiny channel avatar badge if loved, representing the channel's heart!
                            if (hasHeart) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .border(0.5.dp, Color.White, CircleShape)
                                        .align(Alignment.BottomEnd)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.img_hamo_avatar_1784117854952),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        }
                        
                        // Reply Icon
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.clickable { isReplying = !isReplying }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ChatBubbleOutline,
                                contentDescription = "رد",
                                tint = if (isReplying) YtRed else YtTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "رد",
                                color = if (isReplying) YtRed else YtTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
                
                // Right side: Avatar
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(comment.avatarColor)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = comment.avatarLetter,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            // Inline Reply Input
            if (isReplying) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 48.dp, top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        placeholder = { Text("إضافة رد علني باسم حمو...", fontSize = 12.sp, color = YtTextSecondary) },
                        textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = YtRed,
                            unfocusedBorderColor = YtBorderColor,
                            focusedLabelColor = YtRed,
                            cursorColor = YtRed
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Cancel
                        IconButton(onClick = {
                            isReplying = false
                            replyText = ""
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "إلغاء", tint = YtTextSecondary, modifier = Modifier.size(16.dp))
                        }
                        
                        // Send
                        IconButton(
                            onClick = {
                                if (replyText.isNotBlank()) {
                                    val index = MockData.comments.indexOfFirst { it.id == comment.id }
                                    if (index != -1) {
                                        val currentComment = MockData.comments[index]
                                        val newReply = com.example.ReplyItem(
                                            authorName = "حمو الإلكتروني",
                                            authorHandle = "@hamo-electronic",
                                            timeAgo = "الآن",
                                            text = replyText,
                                            avatarResId = R.drawable.img_hamo_avatar_1784117854952
                                        )
                                        MockData.comments[index] = currentComment.copy(
                                            replies = currentComment.replies + newReply
                                        )
                                    }
                                    replyText = ""
                                    isReplying = false
                                }
                            },
                            enabled = replyText.isNotBlank()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "إرسال",
                                tint = if (replyText.isNotBlank()) YtRed else YtTextSecondary.copy(alpha = 0.5f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Replies List
            if (comment.replies.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 36.dp, top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    comment.replies.forEach { reply ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            // Left side (Options/More in RTL) or space
                            Spacer(modifier = Modifier.width(16.dp))
                            
                            // Text column
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = reply.timeAgo,
                                        color = YtTextSecondary,
                                        fontSize = 10.sp
                                    )
                                    
                                    // Highlight if it's the creator
                                    val isCreator = reply.authorHandle == "@hamo-electronic"
                                    if (isCreator) {
                                        Row(
                                            modifier = Modifier
                                                .background(Color(0xFF3EA6FF).copy(alpha = 0.15f), RoundedCornerShape(100.dp))
                                                .border(0.5.dp, Color(0xFF3EA6FF).copy(alpha = 0.4f), RoundedCornerShape(100.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = reply.authorName,
                                                color = Color(0xFF3EA6FF),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    } else {
                                        Text(
                                            text = reply.authorHandle,
                                            color = YtTextPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                
                                Text(
                                    text = reply.text,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    style = LocalTextStyle.current.copy(lineHeight = 16.sp)
                                )
                            }
                            
                            // Right side: Avatar
                            if (reply.avatarResId != null) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .border(0.5.dp, Color(0xFF00B4D8), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        painter = painterResource(id = reply.avatarResId),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(YtRed),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = reply.authorName.take(1),
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
