package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val YtRed = Color(0xFFFF0033)
val YtDarkBackground = Color(0xFF0F0F0F)
val YtCardBackground = Color(0xFF1E1E1E)
val YtChipBackground = Color(0xFF272727)
val YtBorderColor = Color(0x0DFFFFFF) // White with 5% opacity
val YtTextPrimary = Color(0xFFFFFFFF)
val YtTextSecondary = Color(0xFFAAAAAA)
val YtGreen = Color(0xFF22C55E) // Crisp Green
val YtBlue = Color(0xFF3EA6FF)
val YtGold = Color(0xFFFFD700)
val YtPurple = Color(0xFFBB86FC)
val YtOrange = Color(0xFFFF8C00)
