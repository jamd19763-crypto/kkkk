package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.MockData
import com.example.ui.components.VideoItemRow
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    onNavigateToTab: (Int) -> Unit = {},
    onVideoClick: (String) -> Unit = {}
) {
    var showEditMetricsDialog by remember { mutableStateOf(false) }
    var showCreateVideoDialog by remember { mutableStateOf(false) }
    var showNotificationsDialog by remember { mutableStateOf(false) }

    // Form states for Editing Channel Details
    var editName1 by remember { mutableStateOf(MockData.channelNameLine1) }
    var editName2 by remember { mutableStateOf(MockData.channelNameLine2) }
    var editSubs by remember { mutableStateOf(MockData.totalSubscribers) }
    var editViews by remember { mutableStateOf(MockData.viewsCount) }
    var editWatchTime by remember { mutableStateOf(MockData.watchTime) }
    var editSubsChange by remember { mutableStateOf(MockData.subscribersChange) }
    var editRevenue by remember { mutableStateOf(MockData.estimatedRevenue) }
    var editBalance by remember { mutableStateOf(MockData.currentBalance) }

    // Form states for Creating Video/Short
    var createTitle by remember { mutableStateOf("") }
    var createDuration by remember { mutableStateOf("8:20") }
    var createDescription by remember { mutableStateOf("") }
    var createIsShort by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(YtDarkBackground)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // App header (YouTube Studio Header) - Matches screenshot exactly!
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Right side in RTL (first child): Authentic YouTube Studio Logo
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Red play shape background with white play arrow inside
                        Box(
                            modifier = Modifier
                                .width(28.dp)
                                .height(20.dp)
                                .background(Color(0xFFE50914), RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                        Text(
                            text = "Studio",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    
                    // Left side in RTL (second child): Create icon, Bell, and Small Avatar
                    // In RTL, we order them so Small Avatar is leftmost on screen (last child)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // 1. Plus Create Icon (rightmost of this group) - CLICKABLE
                        IconButton(
                            onClick = { showCreateVideoDialog = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddCircleOutline,
                                contentDescription = "إنشاء",
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        
                        // 2. Bell Notification Icon - CLICKABLE
                        IconButton(
                            onClick = { showNotificationsDialog = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsNone,
                                contentDescription = "إشعارات",
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        
                        // 3. Small Profile Avatar - CLICKABLE
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .border(1.dp, Color(0xFF00B4D8), CircleShape)
                                .clickable { showEditMetricsDialog = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_hamo_avatar_1784117854952),
                                contentDescription = "قناتي",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
            
            // Channel Profile Section (Matches screenshot exactly!) - CLICKABLE
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { showEditMetricsDialog = true }
                        .padding(top = 16.dp, bottom = 24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left in RTL (second child): Channel Name and Subscriber Metrics (Right-aligned text)
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.Start // Start in RTL means Right-aligned
                    ) {
                        Text(
                            text = MockData.channelNameLine1,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            style = LocalTextStyle.current.copy(lineHeight = 24.sp)
                        )
                        Text(
                            text = MockData.channelNameLine2,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            style = LocalTextStyle.current.copy(lineHeight = 24.sp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = MockData.totalSubscribers,
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "إجمالي عدد المشتركين",
                            color = YtTextSecondary,
                            fontSize = 13.sp
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    // Right in RTL (first child): Large Circle Avatar with glowing border
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .border(2.dp, Color(0xFF00B4D8), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hamo_avatar_1784117854952),
                            contentDescription = "حمو الإلكتروني",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
            
            // Stats Overview Title (Sleek minimalist spacing matching screenshot)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // In RTL, "آخر 28 يومًا" appears on the left, "إحصاءات حول القناة" on the right.
                    Text(
                        text = "آخر 28 يومًا",
                        color = YtTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "إحصاءات حول القناة",
                        color = YtTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            // Stats grid - 2x2 grid matching YouTube Studio screenshot - CLICKABLE stats
            item {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Top Row: المشاهدات (Right in RTL) and وقت المشاهدة (Left in RTL)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // First child (Right in RTL)
                        StatCard(
                            title = "المشاهدات",
                            value = MockData.viewsCount,
                            hasCheck = true,
                            onClick = { showEditMetricsDialog = true },
                            modifier = Modifier.weight(1f)
                        )
                        
                        // Second child (Left in RTL)
                        StatCard(
                            title = "وقت المشاهدة (بالساعات)",
                            value = MockData.watchTime,
                            hasCheck = true,
                            onClick = { showEditMetricsDialog = true },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    
                    // Bottom Row: المشتركون (Right in RTL) and الإيرادات المقدّرة (Left in RTL)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // First child (Right in RTL)
                        StatCard(
                            title = "المشتركون",
                            value = MockData.subscribersChange,
                            arrowDown = true,
                            onClick = { showEditMetricsDialog = true },
                            modifier = Modifier.weight(1f)
                        )
                        
                        // Second child (Left in RTL)
                        StatCard(
                            title = "الإيرادات المقدّرة",
                            value = MockData.estimatedRevenue,
                            onClick = { showEditMetricsDialog = true },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            
            // Latest Upload Title
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 28.dp, bottom = 12.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "المحتوى الأخير الذي تمّ نشره",
                        color = YtTextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            // Display recent two videos from MockData
            items(MockData.videos.take(2)) { video ->
                VideoItemRow(video = video, onClick = { onVideoClick(video.id) })
            }
        }

        // --- Dialogs ---

        // 1. Edit Channel Info & Metrics Dialog
        if (showEditMetricsDialog) {
            AlertDialog(
                onDismissRequest = { showEditMetricsDialog = false },
                containerColor = YtCardBackground,
                title = {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "تعديل بيانات القناة والإحصاءات",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        // Line 1
                        OutlinedTextField(
                            value = editName1,
                            onValueChange = { editName1 = it },
                            label = { Text("اسم القناة (سطر 1)", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        // Line 2
                        OutlinedTextField(
                            value = editName2,
                            onValueChange = { editName2 = it },
                            label = { Text("اسم القناة (سطر 2)", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        // Subscriber count
                        OutlinedTextField(
                            value = editSubs,
                            onValueChange = { editSubs = it },
                            label = { Text("إجمالي المشتركين", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        // Views count
                        OutlinedTextField(
                            value = editViews,
                            onValueChange = { editViews = it },
                            label = { Text("المشاهدات (آخر 28 يومًا)", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        // Watch Time
                        OutlinedTextField(
                            value = editWatchTime,
                            onValueChange = { editWatchTime = it },
                            label = { Text("وقت المشاهدة بالساعات", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        // Subscribers change
                        OutlinedTextField(
                            value = editSubsChange,
                            onValueChange = { editSubsChange = it },
                            label = { Text("تغير المشتركين (+1.3 ألف)", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        // Estimated Revenue
                        OutlinedTextField(
                            value = editRevenue,
                            onValueChange = { editRevenue = it },
                            label = { Text("الإيرادات المقدّرة", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        // Balance
                        OutlinedTextField(
                            value = editBalance,
                            onValueChange = { editBalance = it },
                            label = { Text("الرصيد الحالي (ج.م.)", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            MockData.channelNameLine1 = editName1
                            MockData.channelNameLine2 = editName2
                            MockData.totalSubscribers = editSubs
                            MockData.viewsCount = editViews
                            MockData.watchTime = editWatchTime
                            MockData.subscribersChange = editSubsChange
                            MockData.estimatedRevenue = editRevenue
                            MockData.currentBalance = editBalance
                            
                            val parsedDouble = editBalance.replace(",", "").toDoubleOrNull()
                            if (parsedDouble != null) {
                                MockData.currentBalanceDouble = parsedDouble
                            }
                            showEditMetricsDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = YtBlue)
                    ) {
                        Text("حفظ", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditMetricsDialog = false }) {
                        Text("إلغاء", color = YtTextSecondary)
                    }
                }
            )
        }

        // 2. Create Video/Short Dialog
        if (showCreateVideoDialog) {
            AlertDialog(
                onDismissRequest = { showCreateVideoDialog = false },
                containerColor = YtCardBackground,
                title = {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "رفع محتوى جديد (فيديو / Short)",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = createTitle,
                            onValueChange = { createTitle = it },
                            label = { Text("عنوان الفيديو", color = YtTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = createDuration,
                            onValueChange = { createDuration = it },
                            label = { Text("المدة (مثال: 5:12 أو 0:59)", color = YtTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = createDescription,
                            onValueChange = { createDescription = it },
                            label = { Text("الوصف", color = YtTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = YtBlue,
                                unfocusedBorderColor = YtBorderColor
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = createIsShort,
                                onCheckedChange = { createIsShort = it },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = YtBlue,
                                    checkmarkColor = Color.White
                                )
                            )
                            Text(
                                text = "هل هذا فيديو قصير (Short)؟",
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (createTitle.isNotBlank()) {
                                val randomId = "v_custom_" + System.currentTimeMillis()
                                val newVideo = com.example.VideoItem(
                                    id = randomId,
                                    title = createTitle,
                                    duration = createDuration,
                                    uploadTime = "الآن",
                                    views = "0 مشاهدة",
                                    likes = "0",
                                    comments = "0",
                                    thumbnailGradientColors = listOf(0xFF2C0A0AL, 0xFF4A0E17L),
                                    thumbnailResId = null,
                                    isShort = createIsShort,
                                    description = if (createDescription.isBlank()) "لم يتم كتابة وصف للمحتوى الجديد." else createDescription
                                )
                                if (createIsShort) {
                                    MockData.shorts.add(0, newVideo)
                                } else {
                                    MockData.videos.add(0, newVideo)
                                }
                                // Reset fields
                                createTitle = ""
                                createDescription = ""
                                showCreateVideoDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = YtBlue),
                        enabled = createTitle.isNotBlank()
                    ) {
                        Text("رفع الآن", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateVideoDialog = false }) {
                        Text("إلغاء", color = YtTextSecondary)
                    }
                }
            )
        }

        // 3. Notifications Dialog
        if (showNotificationsDialog) {
            val mockNotifications = listOf(
                "ألف مبروك! تخطت قناتك 19 ألف مشترك وتستمر في الصعود بنجاح باهر 🚀",
                "تلقيت تعليقًا جديدًا من عبدالرحمن المليحي: 'اخويا حمو ملك المجال يعم ❤️'",
                "تم تحديث أرباحك المقدرة بنجاح لشهر يوليو 2026 بقيمة US$ 22.67.",
                "فيديو جديد جاهز للرفع: تأكد من ضبط الإعدادات والصورة المصغرة."
            )
            AlertDialog(
                onDismissRequest = { showNotificationsDialog = false },
                containerColor = YtCardBackground,
                title = {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "الإشعارات الواردة",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        mockNotifications.forEach { notification ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = YtDarkBackground),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, YtBorderColor, RoundedCornerShape(8.dp))
                            ) {
                                Text(
                                    text = notification,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showNotificationsDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = YtBlue)
                    ) {
                        Text("حسنًا", color = Color.White)
                    }
                }
            )
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    hasCheck: Boolean = false,
    arrowDown: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = YtCardBackground
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .border(1.dp, YtBorderColor, RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                color = YtTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                maxLines = 1
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = value,
                    color = YtTextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                
                if (hasCheck) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = YtGreen,
                        modifier = Modifier.size(20.dp)
                    )
                } else if (arrowDown) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}
