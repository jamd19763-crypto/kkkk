package com.example

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

data class VideoItem(
    val id: String,
    val title: String,
    val duration: String,
    val uploadTime: String,
    val views: String,
    val likes: String,
    val comments: String,
    val thumbnailGradientColors: List<Long>,
    val isShort: Boolean = false,
    val thumbnailResId: Int? = null,
    val visibility: String = "علني",
    val description: String = "في هذا الفيديو، نقدم شرحاً تقنياً وافياً وحصرياً على قناة حمو الإلكتروني. يتناول الشرح مواضيع الأمن السيبراني والتوعية الأمنية وحماية الأجهزة الشخصية من الاختراقات والتجسس باستخدام أحدث الأساليب والحلول التقنية لعام 2026."
)

data class ReplyItem(
    val authorName: String,
    val authorHandle: String,
    val timeAgo: String,
    val text: String,
    val avatarResId: Int? = null
)

data class CommentItem(
    val id: String,
    val authorName: String,
    val authorHandle: String,
    val avatarLetter: String,
    val avatarColor: Long,
    val timeAgo: String,
    val text: String,
    val videoTitle: String,
    var likesCount: Int = 0,
    val replies: List<ReplyItem> = emptyList()
)

data class PayoutItem(
    val title: String,
    val date: String,
    val amount: String
)

object MockData {
    var channelNameLine1 by mutableStateOf("حمو الإلكتروني | Hamo")
    var channelNameLine2 by mutableStateOf("Electronic")
    var totalSubscribers by mutableStateOf("19,281")
    var estimatedRevenue by mutableStateOf("US$ 22.67")
    var viewsCount by mutableStateOf("56.9 ألف")
    var watchTime by mutableStateOf("1.5 ألف")
    var subscribersChange by mutableStateOf("1.3+ ألف")
    
    var currentBalance by mutableStateOf("14,685.26")
    var currentBalanceDouble by mutableStateOf(14685.26)
    val minPayout = "5,000.00"
    val minPayoutDouble = 5000.00
    
    val videos = mutableStateListOf(
        VideoItem(
            id = "v1",
            title = "اختراق الهاتف 2026 | اصبح مستحيل بعد هذا الفيديو والتطبيق!",
            duration = "8:09",
            uploadTime = "أوّل 15 يوم و11 ساعة",
            views = "1.1 ألف",
            likes = "47",
            comments = "17",
            thumbnailGradientColors = listOf(0xFF2C0A0A, 0xFF5E0B0B),
            thumbnailResId = R.drawable.img_thumb_hacking_impossible_1784077501835,
            description = "شرح كامل وحصري لكيفية تأمين هاتفك وحمايته بنسبة 100% من الاختراقات والتطبيقات الملغمة لعام 2026. سنتعرف على أهم إعدادات الحماية والتطبيقات الأمنية التي تجعل اختراق هاتفك أمراً مستحيلاً."
        ),
        VideoItem(
            id = "v2",
            title = "اختراق الهواتف برابط ملغم بدون ضغط عليه و الحماية منه",
            duration = "6:51",
            uploadTime = "أوّل 27 يوم و7 ساعة",
            views = "4.5 ألف",
            likes = "152",
            comments = "27",
            thumbnailGradientColors = listOf(0xFF0F1E36, 0xFF003366),
            thumbnailResId = R.drawable.img_thumb_poisoned_link_1784077488432,
            description = "تحذير وتوعية أمنية حول الثغرات الأمنية التي تمكن المخترقين من الوصول للهاتف عبر الروابط الملغمة بمجرد استلامها دون الضغط عليها. وكيفية تأمين وحماية هاتفك والواتساب وتطبيقات المحادثة."
        ),
        VideoItem(
            id = "v3",
            title = "اختراق الهاتف والتجسس عليه اصبح مستحيل بعد هذا الفيديو",
            duration = "7:01",
            uploadTime = "أوّل 34 يوم و20 ساعة",
            views = "2.8 ألف",
            likes = "124",
            comments = "26",
            thumbnailGradientColors = listOf(0xFF1B0F2B, 0xFF3D0C5A),
            thumbnailResId = R.drawable.img_thumb_spy_impossible_1784077475017,
            description = "شرح عملي لكشف برامج التجسس والمراقبة المخفية على هاتفك وإزالتها نهائياً لتأمين خصوصيتك وحماية معلوماتك وصورك الشخصية."
        ),
        VideoItem(
            id = "v4",
            title = "سحب صور هاتفك القديم الذي شاشته معطلة برسالة عادية عبر الماسنجر",
            duration = "6:50",
            uploadTime = "قبل 10 أشهر",
            views = "23 ألف",
            likes = "737",
            comments = "58",
            thumbnailGradientColors = listOf(0xFF1F2B1F, 0xFF0E5C0E),
            thumbnailResId = R.drawable.img_thumb_broken_screen_1784077462539,
            description = "طريقة مبتكرة وحصرية لاستعادة وسحب الصور والملفات الهامة من هاتفك القديم الذي تعرض لكسر الشاشة، وذلك عبر إرسال رسالة تحكم من حساب ماسنجر آخر."
        ),
        VideoItem(
            id = "v5",
            title = "اختراق شبكات الواي فاي بالذكاء الاصطناعي 2026 | توعية امنية واخلاقية",
            duration = "6:48",
            uploadTime = "قبل شهر واحد",
            views = "7 آلاف",
            likes = "269",
            comments = "56",
            thumbnailGradientColors = listOf(0xFF332200, 0xFF664400),
            thumbnailResId = R.drawable.img_thumb_wifi_ai_1784077445303,
            description = "شرح توعوي لكيفية استخدام خوارزميات الذكاء الاصطناعي في فحص ثغرات شبكات الواي فاي، وطرق حماية الراوتر وتشفير كلمة المرور لتجنب أي اختراق خارجي لشبكتك المنزلية."
        )
    )
    
    val shorts = mutableStateListOf(
        VideoItem(
            id = "s1",
            title = "إزاي تشفر الكود بتاعك من التعديل والاختراق 🔒",
            duration = "0:59",
            uploadTime = "قبل أسبوعين",
            views = "1.1 ألف",
            likes = "46",
            comments = "5",
            thumbnailGradientColors = listOf(0xFF4A0E17, 0xFF801525),
            isShort = true,
            description = "طريقة سريعة ومبسطة لتشفير الكود المصدري للتطبيقات وحمايتها من الهندسة العكسية والتعديل."
        ),
        VideoItem(
            id = "s2",
            title = "إخفي أي لينك في صورتك 🖼️",
            duration = "0:45",
            uploadTime = "قبل 3 أسابيع",
            views = "2.8 ألف",
            likes = "118",
            comments = "12",
            thumbnailGradientColors = listOf(0xFF0D3B3A, 0xFF146C69),
            isShort = true,
            description = "فن إخفاء البيانات والروابط داخل الصور الرقمية وكيفية استخدام هذه الطريقة لحماية ملفاتك."
        ),
        VideoItem(
            id = "s3",
            title = "إختراق الهواتف برسالة عادية ملغمة 💬",
            duration = "0:58",
            uploadTime = "قبل شهر واحد",
            views = "27 ألف",
            likes = "812",
            comments = "45",
            thumbnailGradientColors = listOf(0xFF321A47, 0xFF5D2E83),
            isShort = true,
            description = "كيف تعمل الرسائل النصية الملغمة وكيف يمكن لنظام التشغيل حظرها تلقائياً لحمايتك."
        )
    )
    
    val comments = mutableStateListOf(
        CommentItem(
            id = "c1",
            authorName = "عبدالرحمن المليحي-م1ي",
            authorHandle = "@abdulrahman-m1y",
            avatarLetter = "ع",
            avatarColor = 0xFF2196F3,
            timeAgo = "قبل 8 دقائق",
            text = "اخويا حمو ملك المجال يعم ❤️ لو سمحت عاوزين أداة صيد كروت شحن بعد اذنك",
            videoTitle = "سحب صور هاتفك القديم الذي شاشته معطلة برسالة عادية عبر الماسنجر",
            replies = listOf(
                ReplyItem(
                    authorName = "حمو الإلكتروني",
                    authorHandle = "@hamo-electronic",
                    timeAgo = "قبل دقيقتين",
                    text = "حبيبي يا غالي منورني دايماً ❤️ جاري العمل على تجهيز الأداة وهتنزل في الفيديو الجاي إن شاء الله، خليك متابع!",
                    avatarResId = R.drawable.img_hamo_avatar_1784117854952
                )
            )
        ),
        CommentItem(
            id = "c2",
            authorName = "عمرو عبدالرحمن-ط6ر",
            authorHandle = "@amr-t6r",
            avatarLetter = "ع",
            avatarColor = 0xFF4CAF50,
            timeAgo = "قبل يوم واحد",
            text = "عايزين الأداة ي حمو",
            videoTitle = "اختراق شبكات الواي فاي بالذكاء الاصطناعي 2026 | توعية امنية واخلاقية"
        ),
        CommentItem(
            id = "c3",
            authorName = "Yusef Al-Turkish",
            authorHandle = "@YusefAl-Turkish",
            avatarLetter = "Y",
            avatarColor = 0xFFFF9800,
            timeAgo = "قبل يوم واحد",
            text = "ي حمو عاوزين الأداة طيب",
            videoTitle = "سحب صور هاتفك القديم الذي شاشته معطلة برسالة عادية عبر الماسنجر"
        ),
        CommentItem(
            id = "c4",
            authorName = "محمود جمال",
            authorHandle = "@mahmoud-jamal",
            avatarLetter = "م",
            avatarColor = 0xFFE91E63,
            timeAgo = "قبل يومين",
            text = "استمر يا بطل شرح ممتاز جداً ومفيد وقناتك في تطور مستمر بالتوفيق!",
            videoTitle = "اختراق الهاتف 2026 | اصبح مستحيل بعد هذا الفيديو والتطبيق!"
        )
    )
    
    val specificPayouts = listOf(
        PayoutItem("دفعة شهر يونيو (2026)", "2026/06/21", "54,378 ج.م"),
        PayoutItem("دفعة شهر يوليو (2026)", "2026/07/21", "38,935 ج.م")
    )
    
    val other12Payouts = listOf(
        PayoutItem("الدفعة الأولى", "2025/05/21", "20,000 ج.م"),
        PayoutItem("الدفعة الثانية", "2025/06/21", "33,000 ج.م"),
        PayoutItem("الدفعة الثالث", "2025/07/21", "46,000 ج.م"),
        PayoutItem("الالدفعة الرابعة", "2025/08/21", "59,000 ج.م"),
        PayoutItem("الدفعة الخامسة", "2025/09/21", "72,000 ج.م"),
        PayoutItem("الدفعة السادسة", "2025/10/21", "85,000 ج.م"),
        PayoutItem("الدفعة السابعة", "2025/11/21", "98,000 ج.م"),
        PayoutItem("الدفعة الثامنة", "2025/12/21", "111,000 ج.م"),
        PayoutItem("الدفعة التاسعة", "2026/01/21", "124,000 ج.م"),
        PayoutItem("الدفعة العاشرة", "2026/02/21", "137,000 ج.م"),
        PayoutItem("الدفعة الحادية عشرة", "2026/03/21", "150,000 ج.م"),
        PayoutItem("الدفعة الثانية عشرة", "2026/04/21", "163,000 ج.م")
    ).reversed()
}
