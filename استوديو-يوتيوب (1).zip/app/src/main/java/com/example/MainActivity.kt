package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.YtDarkBackground
import com.example.ui.theme.YtRed
import com.example.ui.theme.YtTextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Ensure right-to-left layout for full Arabic RTL simulation
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var selectedTab by remember { mutableStateOf(0) }
                    var isViewingPaymentActivity by remember { mutableStateOf(false) }
                    var editingVideoId by remember { mutableStateOf<String?>(null) }
                    
                    // Handle system backpress when viewing detailed payout activity or editing a video
                    BackHandler(enabled = isViewingPaymentActivity || editingVideoId != null) {
                        if (editingVideoId != null) {
                            editingVideoId = null
                        } else {
                            isViewingPaymentActivity = false
                        }
                    }
                    
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = YtDarkBackground
                    ) {
                        if (editingVideoId != null) {
                            VideoDetailScreen(
                                videoId = editingVideoId!!,
                                onBack = { editingVideoId = null }
                            )
                        } else if (isViewingPaymentActivity) {
                            PaymentActivityScreen(
                                onBack = { isViewingPaymentActivity = false }
                            )
                        } else {
                            Scaffold(
                                modifier = Modifier.fillMaxSize(),
                                bottomBar = {
                                    androidx.compose.foundation.layout.Column {
                                        HorizontalDivider(color = com.example.ui.theme.YtBorderColor, thickness = 1.dp)
                                        NavigationBar(
                                            containerColor = YtDarkBackground,
                                            tonalElevation = 0.dp
                                        ) {
                                            val navItems = listOf(
                                                NavItem("لوحة البيانات", Icons.Default.Dashboard, Icons.Outlined.Dashboard, 0),
                                                NavItem("المحتوى", Icons.Default.PlayCircle, Icons.Outlined.PlayCircle, 1),
                                                NavItem("الإحصاءات", Icons.Default.BarChart, Icons.Default.BarChart, 2),
                                                NavItem("المنتدى", Icons.Default.ChatBubble, Icons.Outlined.ChatBubbleOutline, 3),
                                                NavItem("تحقيق الربح", Icons.Default.AttachMoney, Icons.Default.AttachMoney, 4)
                                            )
                                            
                                            navItems.forEach { item ->
                                                val isSelected = selectedTab == item.index
                                                NavigationBarItem(
                                                    selected = isSelected,
                                                    onClick = { selectedTab = item.index },
                                                    icon = {
                                                        Icon(
                                                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                                            contentDescription = item.title,
                                                            modifier = Modifier.size(22.dp)
                                                        )
                                                    },
                                                    label = {
                                                        Text(
                                                            text = item.title,
                                                            fontSize = 11.sp
                                                        )
                                                    },
                                                    colors = NavigationBarItemDefaults.colors(
                                                        selectedIconColor = Color.White,
                                                        selectedTextColor = Color.White,
                                                        unselectedIconColor = YtTextSecondary,
                                                        unselectedTextColor = YtTextSecondary,
                                                        indicatorColor = Color.Transparent
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            ) { innerPadding ->
                                Box(modifier = Modifier.padding(innerPadding)) {
                                    when (selectedTab) {
                                        0 -> DashboardScreen(
                                            onNavigateToTab = { index -> selectedTab = index },
                                            onVideoClick = { id -> editingVideoId = id }
                                        )
                                        1 -> ContentScreen(
                                            onVideoClick = { id -> editingVideoId = id }
                                        )
                                        2 -> AnalyticsScreen()
                                        3 -> CommunityScreen()
                                        4 -> EarnScreen(
                                            onNavigateToPaymentActivity = { isViewingPaymentActivity = true }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

data class NavItem(
    val title: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val index: Int
)
