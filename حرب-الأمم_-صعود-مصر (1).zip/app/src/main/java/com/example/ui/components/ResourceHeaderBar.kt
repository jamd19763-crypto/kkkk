package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameResources
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun ResourceHeaderBar(
    resources: GameResources,
    viewModel: WarGameViewModel,
    gameSpeed: Float,
    isPaused: Boolean,
    isMuted: Boolean,
    notificationMessage: String?,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceDark)
            .border(width = 1.dp, color = SurfaceCardBorder)
            .padding(vertical = 6.dp, horizontal = 8.dp)
    ) {
        // Notification Alert Banner
        AnimatedVisibility(
            visible = notificationMessage != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            notificationMessage?.let { msg ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(EgyptGoldDark.copy(alpha = 0.25f))
                        .border(1.dp, EgyptGold, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "📢 $msg",
                        color = EgyptGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Top Controls: Game Title + Speed & Audio Toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "🦅",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(end = 6.dp)
                )
                Column {
                    Text(
                        text = "صعود مصر: حرب الأمم",
                        color = EgyptGold,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "القيادة العسكرية العليا",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            // Controls: Speed, Pause, Mute, Reset
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Game Speed 1x / 2x
                Box(
                    modifier = Modifier
                        .testTag("speed_toggle_button")
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (gameSpeed == 2f) EgyptGoldDark else SurfaceCard)
                        .clickable { viewModel.setGameSpeed(if (gameSpeed == 1f) 2f else 1f) }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${gameSpeed.toInt()}X",
                        color = if (gameSpeed == 2f) Color.White else EgyptGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Pause / Play
                IconButton(
                    onClick = { viewModel.togglePause() },
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .testTag("pause_play_button")
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = "Pause Play",
                        tint = if (isPaused) RadarGreen else EgyptGold,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Audio Mute Toggle
                IconButton(
                    onClick = { viewModel.toggleMute() },
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .testTag("mute_audio_button")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Mute Toggle",
                        tint = if (isMuted) TextMuted else EgyptGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Resource Ticker Cards (Scrollable horizontally)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ResourcePill(icon = "🪙", label = "ذهب", value = resources.gold, color = EgyptGold)
            ResourcePill(icon = "🛢️", label = "نفط", value = resources.oil, color = Color(0xFFFFA726))
            ResourcePill(icon = "⛓️", label = "حديد", value = resources.iron, color = Color(0xFF90A4AE))
            ResourcePill(icon = "🌾", label = "غذاء", value = resources.food, color = RadarGreen)
            ResourcePill(icon = "🪖", label = "تجنيد", value = resources.manpower, color = Color(0xFF42A5F5))
            ResourcePill(icon = "🔬", label = "أبحاث", value = resources.researchPoints, color = Color(0xFFAB47BC))
        }
    }
}

@Composable
private fun ResourcePill(
    icon: String,
    label: String,
    value: Long,
    color: Color
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = icon, fontSize = 12.sp)
            Column {
                Text(
                    text = label,
                    fontSize = 9.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = formatNumber(value),
                    fontSize = 11.sp,
                    color = color,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

fun formatNumber(number: Long): String {
    return when {
        number >= 1_000_000_000 -> String.format(java.util.Locale.US, "%.1fB", number / 1_000_000_000.0)
        number >= 1_000_000 -> String.format(java.util.Locale.US, "%.1fM", number / 1_000_000.0)
        number >= 1_000 -> String.format(java.util.Locale.US, "%.1fK", number / 1_000.0)
        else -> number.toString()
    }
}
