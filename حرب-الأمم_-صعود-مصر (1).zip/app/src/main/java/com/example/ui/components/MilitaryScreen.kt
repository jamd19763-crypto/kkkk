package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.MilitaryUnitType
import com.example.ui.theme.AlertRed
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun MilitaryScreen(
    viewModel: WarGameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState = viewModel.uiState.value
    val totalAttack = viewModel.calculateTotalPlayerPower()
    val totalDefense = viewModel.calculateTotalPlayerDefense()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
            .padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp)
    ) {
        // Military High Command Summary Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Crest
                    Image(
                        painter = painterResource(id = R.drawable.ic_egypt_crest),
                        contentDescription = "Egyptian Armed Forces Crest",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, EgyptGold, CircleShape)
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "القيادة العامة للقوات المسلحة المصرية",
                            color = EgyptGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "تطوير التسليح وتجنيد الألوية والفيالق العسكرية",
                            color = TextMuted,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column {
                                Text(text = "القوة الهجومية", fontSize = 10.sp, color = TextMuted)
                                Text(
                                    text = formatNumber(totalAttack),
                                    fontSize = 13.sp,
                                    color = AlertRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text(text = "القوة الدفاعية", fontSize = 10.sp, color = TextMuted)
                                Text(
                                    text = formatNumber(totalDefense),
                                    fontSize = 13.sp,
                                    color = TacticalBlue,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text(text = "إجمالي الوحدات", fontSize = 10.sp, color = TextMuted)
                                val totalUnits = uiState.militaryUnits.values.sum()
                                Text(
                                    text = "$totalUnits",
                                    fontSize = 13.sp,
                                    color = RadarGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section Title
        item {
            Text(
                text = "ترسانة الوحدات العسكرية والقتالية",
                color = EgyptGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // List of all 9 Military Unit Types
        items(MilitaryUnitType.values(), key = { it.id }) { unitType ->
            val count = uiState.militaryUnits[unitType] ?: 0
            MilitaryUnitCard(
                unit = unitType,
                currentCount = count,
                onRecruit = { qty -> viewModel.recruitUnits(unitType, qty) }
            )
        }
    }
}

@Composable
private fun MilitaryUnitCard(
    unit: MilitaryUnitType,
    currentCount: Int,
    onRecruit: (Int) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Title & Count
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = unit.iconEmoji, fontSize = 22.sp)
                    Column {
                        Text(
                            text = unit.nameAr,
                            color = EgyptGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = unit.descAr,
                            color = TextMuted,
                            fontSize = 10.sp,
                            maxLines = 2
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(EgyptGoldDark.copy(alpha = 0.2f))
                        .border(1.dp, EgyptGold, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "العدد: $currentCount",
                        color = EgyptGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Stats breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = "هجوم: +${unit.attackPower}", fontSize = 10.sp, color = AlertRed, fontWeight = FontWeight.Bold)
                Text(text = "•", fontSize = 10.sp, color = TextMuted)
                Text(text = "دفاع: +${unit.defensePower}", fontSize = 10.sp, color = TacticalBlue, fontWeight = FontWeight.Bold)
                Text(text = "•", fontSize = 10.sp, color = TextMuted)
                Text(text = "المدى: ${unit.operationalRangeKm} كم", fontSize = 10.sp, color = TextMuted)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Cost tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "التكلفة للوحدة:", fontSize = 10.sp, color = TextMuted)
                Text(text = "🪙 ${formatNumber(unit.costGold)}", fontSize = 10.sp, color = EgyptGold)
                Text(text = "🛢️ ${formatNumber(unit.costOil)}", fontSize = 10.sp, color = Color(0xFFFFA726))
                Text(text = "⛓️ ${formatNumber(unit.costIron)}", fontSize = 10.sp, color = Color(0xFF90A4AE))
                Text(text = "🪖 ${unit.costManpower}", fontSize = 10.sp, color = Color(0xFF42A5F5))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Recruit Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { onRecruit(1) },
                    colors = ButtonDefaults.buttonColors(containerColor = EgyptGold),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("recruit_1_${unit.id}")
                ) {
                    Text(text = "تجنيد +1", color = SurfaceDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onRecruit(5) },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("recruit_5_${unit.id}")
                ) {
                    Text(text = "+5", color = EgyptGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onRecruit(10) },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceCardBorder)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("recruit_10_${unit.id}")
                ) {
                    Text(text = "+10", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
