package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CombatLog
import com.example.model.CombatLogType
import com.example.ui.theme.AlertRed
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun MarketScreen(
    viewModel: WarGameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState = viewModel.uiState.value

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
            .padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "⚖️ البورصة والسوق التجاري الاستراتيجي",
                        color = EgyptGold,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "بيع فوائض الموارد أو شراء النفط والحديد والغذاء لتمويل تسليح الجيش المصري",
                        color = TextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        // Trading Cards
        item {
            TradeCommodityCard(
                name = "براميل النفط الخام",
                icon = "🛢️",
                unit = "برميل",
                buyAmount = 2000,
                buyCostGold = 4000,
                sellAmount = 2000,
                sellGainGold = 2500,
                currentStock = uiState.resources.oil,
                onBuy = { viewModel.buyResource("oil", 2000, 4000) },
                onSell = { viewModel.sellResource("oil", 2000, 2500) }
            )
        }

        item {
            TradeCommodityCard(
                name = "أطنان الحديد والصلب العسكري",
                icon = "⛓️",
                unit = "طن",
                buyAmount = 2500,
                buyCostGold = 5000,
                sellAmount = 2500,
                sellGainGold = 3200,
                currentStock = uiState.resources.iron,
                onBuy = { viewModel.buyResource("iron", 2500, 5000) },
                onSell = { viewModel.sellResource("iron", 2500, 3200) }
            )
        }

        item {
            TradeCommodityCard(
                name = "شحنات القمح والغذاء الإستراتيجي",
                icon = "🌾",
                unit = "شحنة",
                buyAmount = 3000,
                buyCostGold = 3500,
                sellAmount = 3000,
                sellGainGold = 2200,
                currentStock = uiState.resources.food,
                onBuy = { viewModel.buyResource("food", 3000, 3500) },
                onSell = { viewModel.sellResource("food", 3000, 2200) }
            )
        }

        item {
            TradeCommodityCard(
                name = "حملات التعبئة والتجنيد العام",
                icon = "🪖",
                unit = "مقاتل",
                buyAmount = 5000,
                buyCostGold = 6000,
                sellAmount = 0,
                sellGainGold = 0,
                currentStock = uiState.resources.manpower,
                onBuy = { viewModel.buyResource("manpower", 5000, 6000) },
                onSell = {}
            )
        }

        // Operational War Logs Section
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "📜 برقيات وسجل العمليات العسكرية المباشرة",
                color = EgyptGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(uiState.combatLogs, key = { it.id }) { log ->
            CombatLogItem(log = log)
        }
    }
}

@Composable
private fun TradeCommodityCard(
    name: String,
    icon: String,
    unit: String,
    buyAmount: Long,
    buyCostGold: Long,
    sellAmount: Long,
    sellGainGold: Long,
    currentStock: Long,
    onBuy: () -> Unit,
    onSell: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = icon, fontSize = 22.sp)
                    Column {
                        Text(text = name, color = EgyptGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(text = "المخزون الحالي: ${formatNumber(currentStock)} $unit", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onBuy,
                    colors = ButtonDefaults.buttonColors(containerColor = EgyptGold),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f).height(34.dp)
                ) {
                    Text(text = "شراء +$buyAmount (-$buyCostGold 🪙)", color = SurfaceDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                if (sellAmount > 0) {
                    Button(
                        onClick = onSell,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(RadarGreen)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f).height(34.dp)
                    ) {
                        Text(text = "بيع -$sellAmount (+$sellGainGold 🪙)", color = RadarGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun CombatLogItem(log: CombatLog) {
    val (color, prefix) = when (log.type) {
        CombatLogType.VICTORY -> RadarGreen to "🏆 [نصر]"
        CombatLogType.CONQUEST -> EgyptGold to "👑 [فتح وسيادة]"
        CombatLogType.DEFEAT -> AlertRed to "⚠️ [تراجع]"
        CombatLogType.AIR_STRIKE -> TacticalBlue to "🚀 [ضربة جوية]"
        CombatLogType.DIPLOMACY -> RadarGreen to "🤝 [دبلوماسية]"
        CombatLogType.ALLIANCE -> EgyptGold to "⭐ [تحالف]"
        CombatLogType.ENEMY_WAR -> TextMuted to "⚔️ [حرب عالمية]"
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = prefix, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(text = log.messageAr, color = TextPrimary, fontSize = 11.sp)
            }
            Text(text = log.timestampFormatted, color = TextMuted, fontSize = 9.sp)
        }
    }
}
