package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.DailyMission
import com.example.model.DailyStreak
import com.example.ui.theme.CommandBlack
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun DailyMissionsDialog(
    dailyMissions: List<DailyMission>,
    dailyStreak: DailyStreak,
    onClaimMission: (String) -> Unit,
    onClaimStreak: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = SurfaceDark,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .border(2.dp, EgyptGold, RoundedCornerShape(16.dp))
                .testTag("daily_missions_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(text = "🎖️", fontSize = 20.sp)
                            Text(
                                text = "المهام اليومية & سجل الشرف",
                                color = EgyptGold,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "تحديث يومي للمهام مع مكافآت الذهب ونقاط المجد والبحوث",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(SurfaceCard)
                            .clickable(onClick = onDismiss)
                            .padding(6.dp)
                    ) {
                        Text(text = "✕", color = Color.White, fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 7-Day Login Streak Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF131B22))
                        .border(1.dp, EgyptGold.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(text = "🔥", fontSize = 18.sp)
                                Text(
                                    text = "حضور الأبطال (سلسلة 7 أيام)",
                                    color = Color(0xFFFFB74D),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (!dailyStreak.hasClaimedToday) {
                                Button(
                                    onClick = onClaimStreak,
                                    modifier = Modifier
                                        .height(32.dp)
                                        .testTag("claim_streak_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = EgyptGoldDark),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                ) {
                                    Text(text = "استلام مكافأة اليوم", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF2E7D32).copy(alpha = 0.3f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(text = "تم الاستلام اليوم ✓", color = Color(0xFF81C784), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 7 Day Boxes
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (day in 1..7) {
                                val isPast = day < dailyStreak.currentDay
                                val isCurrent = day == dailyStreak.currentDay
                                val isClaimed = isPast || (isCurrent && dailyStreak.hasClaimedToday)

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 2.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            when {
                                                isClaimed -> Color(0xFF1B5E20).copy(alpha = 0.6f)
                                                isCurrent -> EgyptGoldDark.copy(alpha = 0.5f)
                                                else -> Color(0xFF1E242B)
                                            }
                                        )
                                        .border(
                                            1.dp,
                                            if (isCurrent) EgyptGold else Color(0xFF37474F),
                                            RoundedCornerShape(6.dp)
                                        )
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "يوم $day",
                                            fontSize = 9.sp,
                                            color = if (isCurrent) EgyptGold else TextMuted
                                        )
                                        Text(
                                            text = if (isClaimed) "✓" else "🎁",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "مهام العمليات اليومية:",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Missions List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(dailyMissions) { mission ->
                        DailyMissionItemCard(
                            mission = mission,
                            onClaim = { onClaimMission(mission.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DailyMissionItemCard(
    mission: DailyMission,
    onClaim: () -> Unit
) {
    val progress = if (mission.targetCount > 0) (mission.currentCount.toFloat() / mission.targetCount).coerceIn(0f, 1f) else 0f

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceCard)
            .border(1.dp, if (mission.isCompleted && !mission.isClaimed) EgyptGold else SurfaceCardBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(text = mission.iconEmoji, fontSize = 24.sp)
                Column {
                    Text(
                        text = mission.titleAr,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = mission.descAr,
                        color = TextMuted,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .width(90.dp)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (mission.isCompleted) Color(0xFF4CAF50) else EgyptGold,
                            trackColor = Color(0xFF263238)
                        )
                        Text(
                            text = "${mission.currentCount}/${mission.targetCount}",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // Rewards tags
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "🪙 +${mission.rewardGold}", color = EgyptGold, fontSize = 9.sp)
                        Text(text = "🏆 +${mission.rewardGlory}", color = Color(0xFFFFB74D), fontSize = 9.sp)
                        Text(text = "🔬 +${mission.rewardTechPoints}", color = Color(0xFF90CAF9), fontSize = 9.sp)
                    }
                }
            }

            // Claim action button
            when {
                mission.isClaimed -> {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF2E7D32).copy(alpha = 0.3f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = "تم الاستلام ✓", color = Color(0xFF81C784), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                mission.isCompleted -> {
                    Button(
                        onClick = onClaim,
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("claim_mission_${mission.id}"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                    ) {
                        Text(text = "استلام 🎁", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
                else -> {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF263238))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = "قيد التنفيذ", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}
