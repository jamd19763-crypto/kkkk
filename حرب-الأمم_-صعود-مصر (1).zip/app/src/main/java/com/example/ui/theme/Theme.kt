package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EgyptGold,
    onPrimary = CommandBlack,
    primaryContainer = EgyptGoldDark,
    onPrimaryContainer = Color.White,
    secondary = MilitaryRed,
    onSecondary = Color.White,
    secondaryContainer = MilitaryRedDark,
    onSecondaryContainer = Color.White,
    tertiary = RadarGreen,
    onTertiary = CommandBlack,
    background = CommandBlack,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceCardBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent military theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
