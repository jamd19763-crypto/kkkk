package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.MilitaryRankTier
import com.example.model.PlayerRankInfo
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted

@Composable
fun RankedLeagueDialog(
    playerRank: PlayerRankInfo,
    currentTier: MilitaryRankTier,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = SurfaceDark,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .border(2.dp, Color(currentTier.colorHex), RoundedCornerShape(16.dp))
                .testTag("ranked_league_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(text = "🏆", fontSize = 20.sp)
                            Text(
                                text = "دوري الجنرالات والتصنيف العالمي",
                                color = EgyptGold,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "الموسم ${playerRank.seasonNumber} • متبقي ${playerRank.seasonDaysRemaining} يوم على نهاية الموسم",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(SurfaceCard)
                            .clickable(onClick = onDismiss)
                            .padding(6.dp)
                    ) {
                        Text(text = "✕", color = Color.White, fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Current Tier Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF131B22))
                        .border(1.5.dp, Color(currentTier.colorHex), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(text = currentTier.badgeEmoji, fontSize = 38.sp)
                            Column {
                                Text(
                                    text = currentTier.titleAr,
                                    color = Color(currentTier.colorHex),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "نقاط التصنيف (RP): ${playerRank.rankPoints} نقطة",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "الانتصارات: ${playerRank.wins} / المعارك: ${playerRank.battles}",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        // Win Rate Badge
                        val winRate = if (playerRank.battles > 0) ((playerRank.wins.toFloat() / playerRank.battles) * 100).toInt() else 100
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF2E7D32).copy(alpha = 0.35f))
                                .border(1.dp, Color(0xFF4CAF50), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = "معدل الفوز: $winRate%", color = Color(0xFF81C784), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "سلّم رتب المعارك (من البرونزي إلى الأسطورة المصرية):",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // List of tiers
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(MilitaryRankTier.values().toList().reversed()) { tier ->
                        val isCurrent = tier == currentTier
                        val isReached = playerRank.rankPoints >= tier.minPoints

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isCurrent) EgyptGoldDark.copy(alpha = 0.3f) else SurfaceCard)
                                .border(
                                    1.dp,
                                    if (isCurrent) EgyptGold else SurfaceCardBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(text = tier.badgeEmoji, fontSize = 20.sp)
                                    Column {
                                        Text(
                                            text = tier.titleAr,
                                            color = if (isReached) Color(tier.colorHex) else TextMuted,
                                            fontSize = 11.sp,
                                            fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Normal
                                        )
                                        Text(
                                            text = "مطلوب: ${tier.minPoints}+ RP",
                                            color = TextMuted,
                                            fontSize = 9.sp
                                        )
                                    }
                                }

                                if (isCurrent) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(EgyptGold)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "رتبتك الحالية", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else if (isReached) {
                                    Text(text = "تم الاجتياز ✓", color = Color(0xFF81C784), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
