package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MilitaryGeneral
import com.example.ui.theme.AlertRed
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun AcademyScreen(
    viewModel: WarGameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
            .padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp)
    ) {
        // Academy Header Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "🎖️ الأكاديمية العسكرية العليا (هيئة الأركان)",
                                color = EgyptGold,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "تعيين وتكليف القادة والجنرالات الاستراتيجيين لقيادة المعارك الكبرى",
                                color = TextMuted,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        // Glory Points Display
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(EgyptGoldDark.copy(alpha = 0.3f))
                                .border(1.dp, EgyptGold, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(text = "⭐ نقاط المجد:", color = EgyptGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(text = "${uiState.gloryPoints}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }
        }

        // List of Generals
        items(uiState.generals, key = { it.id }) { general ->
            GeneralCard(
                general = general,
                canRecruit = uiState.gloryPoints >= general.costGlory,
                onRecruit = { viewModel.recruitGeneral(general) },
                onAssign = { viewModel.assignGeneral(general) }
            )
        }
    }
}

@Composable
private fun GeneralCard(
    general: MilitaryGeneral,
    canRecruit: Boolean,
    onRecruit: () -> Unit,
    onAssign: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.2.dp,
                if (general.isAssigned) EgyptGold else if (general.isRecruited) RadarGreen else SurfaceCardBorder,
                RoundedCornerShape(10.dp)
            )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(SurfaceDark)
                            .border(1.2.dp, EgyptGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = general.avatarEmoji, fontSize = 22.sp)
                    }

                    Column {
                        Text(
                            text = general.nameAr,
                            color = if (general.isAssigned) EgyptGold else TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = general.titleAr,
                            color = TacticalBlue,
                            fontSize = 11.sp
                        )
                    }
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (general.isAssigned) EgyptGoldDark.copy(alpha = 0.4f)
                            else if (general.isRecruited) RadarGreen.copy(alpha = 0.2f)
                            else SurfaceDark
                        )
                        .border(
                            1.dp,
                            if (general.isAssigned) EgyptGold
                            else if (general.isRecruited) RadarGreen
                            else SurfaceCardBorder,
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (general.isAssigned) "⭐ القائد العام المكلف"
                        else if (general.isRecruited) "جاهز في الاحتياط 🎖️"
                        else "غير مُعيّن 🔒",
                        color = if (general.isAssigned) EgyptGold
                        else if (general.isRecruited) RadarGreen
                        else TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = general.specialtyDescAr, color = TextMuted, fontSize = 11.sp)

            Spacer(modifier = Modifier.height(8.dp))

            // Bonus Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "⚔️ تعزيز الهجوم: +${general.attackBonusPercent}%",
                    color = AlertRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "🛡️ تعزيز الدفاع: +${general.defenseBonusPercent}%",
                    color = TacticalBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (!general.isRecruited) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "التكلفة:", color = TextMuted, fontSize = 11.sp)
                        Text(text = "⭐ ${general.costGlory} نقطة مجد", color = EgyptGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onRecruit,
                        enabled = canRecruit,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EgyptGold,
                            disabledContainerColor = SurfaceCardBorder
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("recruit_general_${general.id}")
                    ) {
                        Text(
                            text = "تعيين الجنرال 🎖️",
                            color = if (canRecruit) SurfaceDark else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (!general.isAssigned) {
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = onAssign,
                        colors = ButtonDefaults.buttonColors(containerColor = EgyptGoldDark),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("assign_general_${general.id}")
                    ) {
                        Text(
                            text = "تكليف بالقيادة العامة ⭐",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
