package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun CinematicIntroOverlay(
    onEnterGame: () -> Unit
) {
    // Animations for lightning, logo zoom, fire particles, and dramatic voiceover
    val logoScale = remember { Animatable(0.3f) }
    val logoAlpha = remember { Animatable(0f) }
    val lightningFlash = remember { Animatable(0f) }
    val subtitleAlpha = remember { Animatable(0f) }
    val buttonAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Dramatic sequence
        delay(200)
        lightningFlash.animateTo(1f, animationSpec = tween(120))
        lightningFlash.animateTo(0f, animationSpec = tween(250))
        delay(150)
        lightningFlash.animateTo(0.8f, animationSpec = tween(90))
        lightningFlash.animateTo(0f, animationSpec = tween(300))

        // Logo expands out of flames and dust
        logoAlpha.animateTo(1f, animationSpec = tween(900, easing = FastOutSlowInEasing))
        logoScale.animateTo(1.15f, animationSpec = tween(1200, easing = FastOutSlowInEasing))
        logoScale.animateTo(1.0f, animationSpec = tween(400))

        // Subtitle appears
        subtitleAlpha.animateTo(1f, animationSpec = tween(700))
        delay(400)
        buttonAlpha.animateTo(1f, animationSpec = tween(600))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B0E))
            .testTag("cinematic_intro_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Dynamic battlefield dust and lightning effect on canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Vignette dark gradient
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF1E1005).copy(alpha = 0.5f), Color(0xFF040608)),
                    center = Offset(width / 2f, height / 2f),
                    radius = width * 0.75f
                )
            )

            // Lightning flash overlay
            if (lightningFlash.value > 0.05f) {
                drawRect(
                    color = Color(0xFFE0F7FA).copy(alpha = lightningFlash.value * 0.85f)
                )
                // Lightning bolt paths
                val boltPath = Path().apply {
                    moveTo(width * 0.45f, 0f)
                    lineTo(width * 0.48f, height * 0.25f)
                    lineTo(width * 0.42f, height * 0.45f)
                    lineTo(width * 0.52f, height * 0.65f)
                    lineTo(width * 0.50f, height)
                }
                drawPath(boltPath, color = Color.White, style = Stroke(width = 4f))
            }
        }

        // Center Hero Elements: Crest, Egyptian Flag, Epic Title
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .scale(logoScale.value)
                .alpha(logoAlpha.value),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Golden Eagle Crest Badge with glowing ring
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(EgyptGoldDark.copy(alpha = 0.7f), Color(0xFF111417))
                        )
                    )
                    .border(3.dp, EgyptGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_egypt_crest),
                    contentDescription = "شعار النسر المصري الملكي",
                    modifier = Modifier.size(90.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Epic Grand Title
            Text(
                text = "حرب الأمم: صعود مصر",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = EgyptGold,
                textAlign = TextAlign.Center,
                letterSpacing = 1.sp
            )

            Text(
                text = "RISE OF THE EGYPTIAN EMPIRE • GRAND STRATEGY RTS",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF90A4AE),
                letterSpacing = 2.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Dramatic Slogan Box
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF161C24).copy(alpha = 0.85f))
                    .border(1.dp, Color(0xFF37474F), RoundedCornerShape(8.dp))
                    .padding(horizontal = 18.dp, vertical = 8.dp)
                    .alpha(subtitleAlpha.value)
            ) {
                Text(
                    text = "«من قلب القاهرة... تبدأ الإمبراطورية التي لا تغرب عنها الشمس» 🇪🇬",
                    color = Color(0xFFFFD54F),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Enter Command Button
            Button(
                onClick = onEnterGame,
                modifier = Modifier
                    .height(52.dp)
                    .fillMaxWidth(0.5f)
                    .alpha(buttonAlpha.value)
                    .testTag("enter_war_theater_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EgyptGoldDark
                ),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(2.dp, EgyptGold)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = "⚔️", fontSize = 18.sp)
                    Text(
                        text = "دخول غرفة العمليات الحربية",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
