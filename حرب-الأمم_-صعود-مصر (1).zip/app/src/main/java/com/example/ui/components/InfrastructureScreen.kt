package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.InfrastructureType
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun InfrastructureScreen(
    viewModel: WarGameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState = viewModel.uiState.value

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
            .padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🏛️ البنية التحتية والمشاريع القومية المصرية",
                        color = EgyptGold,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "بناء وتوسيع القواعد والمصانع والقنوات لتمويل المجهود الحربي والسيادة العالمية",
                        color = TextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        items(InfrastructureType.values(), key = { it.id }) { infraType ->
            val currentLevel = uiState.infrastructureLevels[infraType.id] ?: 0
            InfrastructureCard(
                infra = infraType,
                level = currentLevel,
                onUpgrade = { viewModel.upgradeInfrastructure(infraType) }
            )
        }
    }
}

@Composable
private fun InfrastructureCard(
    infra: InfrastructureType,
    level: Int,
    onUpgrade: () -> Unit
) {
    val nextLevel = level + 1
    val isMax = level >= 10
    val costGold = infra.baseCostGold * nextLevel
    val costIron = infra.baseCostIron * nextLevel

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SurfaceCardBorder, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = infra.iconEmoji, fontSize = 24.sp)
                    Column {
                        Text(
                            text = infra.nameAr,
                            color = EgyptGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = infra.benefitDescAr,
                            color = RadarGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isMax) RadarGreen.copy(alpha = 0.2f) else EgyptGoldDark.copy(alpha = 0.2f))
                        .border(1.dp, if (isMax) RadarGreen else EgyptGold, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isMax) "الحد الأقصى" else "مستوى $level/10",
                        color = if (isMax) RadarGreen else EgyptGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = infra.descAr, color = TextMuted, fontSize = 10.sp)

            Spacer(modifier = Modifier.height(8.dp))

            // Level Progress Bar
            LinearProgressIndicator(
                progress = { level / 10f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = EgyptGold,
                trackColor = SurfaceDark
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (!isMax) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = "التكلفة:", fontSize = 10.sp, color = TextMuted)
                        Text(text = "🪙 ${formatNumber(costGold)}", fontSize = 10.sp, color = EgyptGold)
                        Text(text = "⛓️ ${formatNumber(costIron)}", fontSize = 10.sp, color = TextPrimary)
                    }

                    Button(
                        onClick = onUpgrade,
                        colors = ButtonDefaults.buttonColors(containerColor = EgyptGold),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("upgrade_infra_${infra.id}")
                    ) {
                        Text(
                            text = "ترقية إلى لفل $nextLevel ⬆️",
                            color = SurfaceDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
