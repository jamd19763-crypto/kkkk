package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Country
import com.example.model.CountryStatus
import com.example.model.MilitaryUnitType
import com.example.ui.theme.AlertRed
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.MilitaryRed
import com.example.ui.theme.MilitaryRedDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CountryDetailSheet(
    country: Country,
    viewModel: WarGameViewModel,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val uiState = viewModel.uiState.value
    val playerPower = viewModel.calculateTotalPlayerPower()
    val hasNukes = (uiState.militaryUnits[MilitaryUnitType.NUCLEAR_ICBM] ?: 0) > 0
    val isNukeTech = uiState.techItems.find { it.id == "tech_nuclear" }?.isUnlocked == true

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header with Flag, Name & Close button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = country.flag, fontSize = 36.sp)
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = country.nameAr,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (country.isEgypt) EgyptGold else TextPrimary
                            )
                            if (country.isEgypt) {
                                Text(text = " 🦅", fontSize = 16.sp)
                            }
                        }
                        Text(
                            text = "${country.nameEn} • ${country.continent.nameAr}",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .testTag("close_country_sheet")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Status Badge
            val (statusBg, statusBorder, statusText) = when (country.status) {
                CountryStatus.PLAYER_EGYPT -> Triple(EgyptGoldDark.copy(alpha = 0.2f), EgyptGold, "مصر (الوطن الأم - القيادة المركزية)")
                CountryStatus.CONQUERED -> Triple(EgyptGoldDark.copy(alpha = 0.2f), EgyptGoldDark, "أرض خاضعة للسيادة المصرية (محتلة)")
                CountryStatus.ALLIED -> Triple(RadarGreen.copy(alpha = 0.2f), RadarGreen, "دولة حليفة عسكرياً")
                CountryStatus.HOSTILE -> Triple(MilitaryRed.copy(alpha = 0.2f), AlertRed, "دولة معادية للسيادة المصرية")
                CountryStatus.NEUTRAL -> Triple(TacticalBlue.copy(alpha = 0.2f), TacticalBlue, "دولة محايدة")
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(statusBg)
                    .border(1.dp, statusBorder, RoundedCornerShape(8.dp))
                    .padding(vertical = 8.dp, horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = statusText,
                    color = statusBorder,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Strategic Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "القوة العسكرية",
                    value = formatNumber(country.power),
                    icon = "⚔️",
                    color = AlertRed,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "الدفاع والتحصين",
                    value = formatNumber(country.defense),
                    icon = "🛡️",
                    color = TacticalBlue,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "السكان",
                    value = "${country.population} مليون",
                    icon = "👥",
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "الناتج الاقتصادي",
                    value = "$${country.gdpBillion}B",
                    icon = "💰",
                    color = EgyptGold,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tactical Actions (Only enabled if not Egypt and not already Conquered)
            if (!country.isEgypt && country.status != CountryStatus.CONQUERED) {
                Text(
                    text = "العمليات العسكرية والتكتيكية",
                    color = EgyptGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Action: Ground Military Invasion
                Button(
                    onClick = {
                        onDismiss()
                        viewModel.startBattle(country, isAirStrike = false, isNuclear = false)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MilitaryRedDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("launch_ground_invasion_button")
                ) {
                    Text(
                        text = "⚔️ شن غزو واجتياح عسكري شامل",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action: Precision Air / Missile Strike
                Button(
                    onClick = {
                        onDismiss()
                        viewModel.startBattle(country, isAirStrike = true, isNuclear = false)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("launch_airstrike_button")
                ) {
                    Text(
                        text = "🚀 ضربة جوية وصاروخية تكتيكية",
                        color = EgyptGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Action: Nuclear ICBM Strike (If unlocked)
                if (isNukeTech && hasNukes) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            onDismiss()
                            viewModel.startBattle(country, isAirStrike = false, isNuclear = true)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("launch_nuclear_strike_button")
                    ) {
                        Text(
                            text = "☢️ إطلاق صاروخ نووي باليستي استراتيجي",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Diplomacy Section
                Text(
                    text = "المسار الدبلوماسي والمعاهدات",
                    color = TextMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.declareDiplomacy(country, CountryStatus.ALLIED) },
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(RadarGreen)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "🤝 حلف عسكري", color = RadarGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.declareDiplomacy(country, CountryStatus.NEUTRAL) },
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(TacticalBlue)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "🕊️ معاهدة هدنة", color = TacticalBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.declareDiplomacy(country, CountryStatus.HOSTILE) },
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(MilitaryRed)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "⚔️ إعلان عداء", color = AlertRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else if (country.status == CountryStatus.CONQUERED) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceCard)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "✅ تم دمج هذه الدولة بالكامل ضمن السيادة المصرية وتدر دخلاً ثانياً بالذهب والنفط والموارد!",
                        color = EgyptGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceCard)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🇪🇬 جمهورية مصر العربية: المقر الاستراتيجي للقيادة العامة للقوات المسلحة.",
                        color = EgyptGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    icon: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.border(1.dp, SurfaceCardBorder, RoundedCornerShape(8.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = icon, fontSize = 18.sp)
            Column {
                Text(text = title, fontSize = 10.sp, color = TextMuted)
                Text(text = value, fontSize = 13.sp, color = color, fontWeight = FontWeight.Bold)
            }
        }
    }
}
