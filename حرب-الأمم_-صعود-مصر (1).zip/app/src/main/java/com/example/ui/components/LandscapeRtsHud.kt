package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Country
import com.example.model.CountryStatus
import com.example.model.GameResources
import com.example.model.MilitaryUnitType
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CommandBlack
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.MilitaryRed
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun LandscapeRtsTopBar(
    resources: GameResources,
    gameSpeed: Float,
    isPaused: Boolean,
    isMuted: Boolean,
    onToggleSpeed: () -> Unit,
    onTogglePause: () -> Unit,
    onToggleMute: () -> Unit,
    currentStageTitle: String,
    conqueredCount: Int = 0,
    totalCount: Int = 0,
    rankBadge: String = "🥇",
    rankTitle: String = "ذهبي",
    onOpenMissions: () -> Unit = {},
    onOpenRanked: () -> Unit = {},
    onOpenCustomization: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onReplayCinematic: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xF50D131B),
                        Color(0xE6080C12)
                    )
                )
            )
            .border(width = 1.2.dp, color = EgyptGold.copy(alpha = 0.7f), shape = RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Egypt Eagle Title, Campaign Stage & Superpower Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = "🦅", fontSize = 20.sp)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "مصر: القوة العظمى العالمية 🇪🇬",
                            color = EgyptGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF2E7D32).copy(alpha = 0.35f))
                                .border(0.8.dp, Color(0xFF4CAF50), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = if (totalCount > 0) "🌍 السيادة: $conqueredCount/$totalCount" else "⚡ القوة الأولى",
                                color = Color(0xFF81C784),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = currentStageTitle,
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Center: 4 Big Resource Indicators
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                RtsResourceItem(icon = "🪙", label = "ذهب", value = resources.gold, color = EgyptGold)
                RtsResourceItem(icon = "🛢️", label = "نفط", value = resources.oil, color = Color(0xFFFFA726))
                RtsResourceItem(icon = "⚙️", label = "حديد", value = resources.iron, color = Color(0xFF90CAF9))
                RtsResourceItem(icon = "👥", label = "تجنيد", value = resources.manpower, color = Color(0xFF81C784))
            }

            // Right: Legend Mode Actions & Speed, Pause, Mute Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Daily Missions Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(EgyptGoldDark.copy(alpha = 0.6f))
                        .border(1.dp, EgyptGold, RoundedCornerShape(6.dp))
                        .clickable(onClick = onOpenMissions)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = "🎖️", fontSize = 12.sp)
                        Text(text = "المهام", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Ranked Badge Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(SurfaceCard)
                        .border(1.dp, EgyptGold, RoundedCornerShape(6.dp))
                        .clickable(onClick = onOpenRanked)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = rankBadge, fontSize = 12.sp)
                        Text(text = rankTitle.split(" ").firstOrNull() ?: rankTitle, color = EgyptGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Customization Skins Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, RoundedCornerShape(6.dp))
                        .clickable(onClick = onOpenCustomization)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🎨 التمويه", color = Color(0xFF80D8FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                // Replay Cinematic Intro Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, RoundedCornerShape(6.dp))
                        .clickable(onClick = onReplayCinematic)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🎬 سينمائي", color = Color(0xFFFFD54F), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                // Speed Toggle
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (gameSpeed == 2f) EgyptGoldDark else SurfaceCard)
                        .border(1.dp, if (gameSpeed == 2f) EgyptGold else SurfaceCardBorder, RoundedCornerShape(6.dp))
                        .clickable(onClick = onToggleSpeed)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${gameSpeed.toInt()}X ⏩",
                        color = if (gameSpeed == 2f) Color.White else EgyptGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Settings
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, CircleShape)
                ) {
                    Text(text = "⚙️", fontSize = 12.sp)
                }

                // Pause
                IconButton(
                    onClick = onTogglePause,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = "Pause",
                        tint = if (isPaused) RadarGreen else EgyptGold,
                        modifier = Modifier.size(14.dp)
                    )
                }

                // Mute
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceCardBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Mute",
                        tint = if (isMuted) TextMuted else EgyptGold,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RtsResourceItem(icon: String, label: String, value: Long, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(text = icon, fontSize = 16.sp)
        Column {
            Text(
                text = formatNumber(value),
                color = color,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = label,
                color = TextMuted,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
fun LandscapeRtsBottomBar(
    selectedUnit: MilitaryUnitType,
    onSelectUnit: (MilitaryUnitType) -> Unit,
    selectedCountry: Country?,
    onDeployUnit: () -> Unit,
    onOpenMilitary: () -> Unit,
    onOpenAcademy: () -> Unit,
    onOpenCabinet: () -> Unit,
    onOpenWorldWarPicker: () -> Unit,
    onOpenUpgrades: () -> Unit,
    onOpenMarket: () -> Unit,
    onOpenCampaign: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xE6080C12),
                        Color(0xF50D131B)
                    )
                )
            )
            .border(width = 1.2.dp, color = EgyptGold.copy(alpha = 0.7f), shape = RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Unit Dispatcher Buttons: Infantry, Tank, Plane, Warship
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(text = "الوحدات:", color = EgyptGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                val primaryUnits = listOf(
                    MilitaryUnitType.INFANTRY,
                    MilitaryUnitType.TANKS,
                    MilitaryUnitType.FIGHTER_JET,
                    MilitaryUnitType.WARSHIP
                )

                primaryUnits.forEach { unit ->
                    val isSelected = selectedUnit == unit
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) EgyptGoldDark.copy(alpha = 0.45f) else SurfaceCard)
                            .border(1.2.dp, if (isSelected) EgyptGold else SurfaceCardBorder, RoundedCornerShape(8.dp))
                            .clickable { onSelectUnit(unit) }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(text = unit.iconEmoji, fontSize = 16.sp)
                            Text(
                                text = unit.nameAr.split(" ").firstOrNull() ?: unit.nameAr,
                                color = if (isSelected) EgyptGold else TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Quick Deploy Button if target selected
                if (selectedCountry != null && !selectedCountry.isEgypt && selectedCountry.status != CountryStatus.CONQUERED) {
                    Button(
                        onClick = onDeployUnit,
                        colors = ButtonDefaults.buttonColors(containerColor = MilitaryRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("deploy_unit_landscape")
                    ) {
                        Text(
                            text = "🚀 هجوم بالـ ${selectedUnit.iconEmoji} على ${selectedCountry.nameAr}",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Right side: Grand War Controls (Military, World Conquest, Upgrades, Market, Campaign)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = onOpenMilitary,
                    colors = ButtonDefaults.buttonColors(containerColor = EgyptGoldDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "🪖 الجيش", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenAcademy,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "🎖️ الأكاديمية", color = EgyptGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenCabinet,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "🏛️ الحكومة", color = EgyptGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenWorldWarPicker,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "⚔️ غزو أي دولة", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenUpgrades,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "🏛️ البناء والتطوير", color = EgyptGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenMarket,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceCardBorder)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "⚖️ السوق", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenCampaign,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceCardBorder)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "📜 المراحل", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LandscapeFloatingCountryPanel(
    country: Country,
    currentHp: Long,
    maxHp: Long,
    consecutiveTaps: Int,
    onTapAttack: () -> Unit,
    onFullInvasion: () -> Unit,
    onDemandCapitulation: () -> Unit,
    onAirStrike: () -> Unit,
    onNuclearStrike: () -> Unit,
    onOpenDetails: () -> Unit,
    onClose: () -> Unit,
    placedUnitsCount: Int = 0,
    onRecruitUnitOnTerritory: ((MilitaryUnitType) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val hpRatio = if (maxHp > 0) (currentHp.toFloat() / maxHp.toFloat()).coerceIn(0f, 1f) else 0f
    val tapsCount = consecutiveTaps % 5

    Box(
        modifier = modifier
            .width(300.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceDark.copy(alpha = 0.96f))
            .border(1.2.dp, EgyptGold, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Title & Flag
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = country.flag, fontSize = 28.sp)
                    Column {
                        Text(
                            text = country.nameAr,
                            color = EgyptGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${country.continent.nameAr} • ${country.status.labelAr}",
                            color = when (country.status) {
                                CountryStatus.PLAYER_EGYPT -> EgyptGold
                                CountryStatus.CONQUERED -> EgyptGoldDark
                                CountryStatus.ALLIED -> RadarGreen
                                CountryStatus.HOSTILE -> MilitaryRed
                                CountryStatus.NEUTRAL -> TacticalBlue
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                IconButton(onClick = onClose, modifier = Modifier.size(26.dp)) {
                    Text(
                        text = "✕",
                        color = TextMuted,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (!country.isEgypt && country.status != CountryStatus.CONQUERED) {
                // Defense Health Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "صمود العدو:", fontSize = 10.sp, color = TextMuted)
                    Text(text = "${formatNumber(currentHp)} / ${formatNumber(maxHp)}", fontSize = 10.sp, color = AlertRed, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(3.dp))
                LinearProgressIndicator(
                    progress = { hpRatio },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = AlertRed,
                    trackColor = SurfaceCard
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Tap-To-Damage Interactive Button (5 Taps = Critical Strike!)
                Button(
                    onClick = onTapAttack,
                    colors = ButtonDefaults.buttonColors(containerColor = if (tapsCount == 4) EgyptGold else MilitaryRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .testTag("tap_strike_button")
                ) {
                    Text(
                        text = if (tapsCount == 4) "🔥 ضربة قاضية حاسمة! (اضغط للتدمير)" else "⚡ ضربة مدفعية بالضغط ($tapsCount/5)",
                        color = if (tapsCount == 4) CommandBlack else Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(5.dp))

                // Row: Full Invasion & Demand Instant Annexation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onFullInvasion,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                    ) {
                        Text(
                            text = "⚔️ غزو شامل",
                            color = EgyptGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onDemandCapitulation,
                        colors = ButtonDefaults.buttonColors(containerColor = EgyptGoldDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                    ) {
                        Text(
                            text = "👑 ضم فوري",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(5.dp))

                // Row: Tactical Air Strike & Ballistic Nuclear Strike
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onAirStrike,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF64B5F6))),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                    ) {
                        Text(
                            text = "🚀 ضربة جوية",
                            color = Color(0xFF90CAF9),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onNuclearStrike,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFFFB74D))),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                    ) {
                        Text(
                            text = "☢️ قصف نووي",
                            color = Color(0xFFFFB74D),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(5.dp))

                // Open Full Dossier & Diplomacy
                Button(
                    onClick = onOpenDetails,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                ) {
                    Text(
                        text = "📄 الملف والمعاهدات الدبلوماسية",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(EgyptGoldDark.copy(alpha = 0.25f))
                            .border(1.dp, EgyptGold, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (country.isEgypt) "🇪🇬 جمهورية مصر العربية - القيادة العامة" else "👑 أرض محررة خاضعة لسيادة مصر العظمى!",
                            color = EgyptGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Stationed military unit stack indicator (Limit 5)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceCard)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "الحاميات المرابطة:", fontSize = 10.sp, color = TextMuted)
                        Text(text = "$placedUnitsCount / 5 وحدات", fontSize = 10.sp, color = EgyptGold, fontWeight = FontWeight.Bold)
                    }

                    // Recruitment system: Spawn units on this region (Infantry, Tank, Aircraft)
                    Text(text = "🎯 تجنيد وتمركز على الخريطة:", fontSize = 10.sp, color = EgyptGold, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Button(
                            onClick = { onRecruitUnitOnTerritory?.invoke(MilitaryUnitType.INFANTRY) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF81C784))),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                        ) {
                            Text(text = "🪖 مشاة", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onRecruitUnitOnTerritory?.invoke(MilitaryUnitType.TANKS) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                        ) {
                            Text(text = "🛡️ دبابة", fontSize = 9.sp, color = EgyptGold, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onRecruitUnitOnTerritory?.invoke(MilitaryUnitType.FIGHTER_JET) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF64B5F6))),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                        ) {
                            Text(text = "✈️ طائرة", fontSize = 9.sp, color = Color(0xFF90CAF9), fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onOpenDetails,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(32.dp)
                    ) {
                        Text(
                            text = "📄 تفاصيل المقاطعة والموارد",
                            color = EgyptGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}


