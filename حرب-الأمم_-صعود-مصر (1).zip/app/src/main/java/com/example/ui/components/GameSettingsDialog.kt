package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.GameSettings
import com.example.model.GraphicsQuality
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted

@Composable
fun GameSettingsDialog(
    settings: GameSettings,
    isMuted: Boolean,
    onToggleMute: () -> Unit,
    onToggleVibration: () -> Unit,
    onSelectQuality: (GraphicsQuality) -> Unit,
    onResetGame: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = SurfaceDark,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .border(2.dp, EgyptGold, RoundedCornerShape(16.dp))
                .testTag("game_settings_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "⚙️", fontSize = 20.sp)
                        Text(
                            text = "إعدادات اللعبة والأداء التكتيكي",
                            color = EgyptGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(SurfaceCard)
                            .clickable(onClick = onDismiss)
                            .padding(6.dp)
                    ) {
                        Text(text = "✕", color = Color.White, fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Graphics Quality Selector
                Text(
                    text = "جودة الرسوميات ومعدل الإطارات (FPS):",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    GraphicsQuality.values().forEach { quality ->
                        val isSelected = quality == settings.graphicsQuality
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) EgyptGoldDark else SurfaceCard)
                                .border(
                                    1.dp,
                                    if (isSelected) EgyptGold else SurfaceCardBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { onSelectQuality(quality) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (quality) {
                                    GraphicsQuality.LOW -> "منخفضة"
                                    GraphicsQuality.MEDIUM -> "متوسطة"
                                    GraphicsQuality.HIGH -> "عالية (60)"
                                    GraphicsQuality.ULTRA -> "سينمائي"
                                },
                                color = if (isSelected) Color.White else TextMuted,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Toggles Row: Audio and Haptics
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceCard)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = if (isMuted) "🔇" else "🔊", fontSize = 18.sp)
                        Text(text = "المؤثرات الصوتية والتعليق العسكري", color = Color.White, fontSize = 12.sp)
                    }
                    Switch(
                        checked = !isMuted,
                        onCheckedChange = { onToggleMute() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = EgyptGold,
                            checkedTrackColor = EgyptGoldDark
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceCard)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = "📳", fontSize = 18.sp)
                        Text(text = "الاهتزاز التكتيكي للضربات والانفجارات", color = Color.White, fontSize = 12.sp)
                    }
                    Switch(
                        checked = settings.vibrationEnabled,
                        onCheckedChange = { onToggleVibration() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = EgyptGold,
                            checkedTrackColor = EgyptGoldDark
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Reset campaign button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFB71C1C).copy(alpha = 0.2f))
                        .border(1.dp, Color(0xFFE53935), RoundedCornerShape(8.dp))
                        .clickable { onResetGame() }
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "⚠️ إعادة تعيين وبدء حملة جديدة من الصفر",
                        color = Color(0xFFFF8A80),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
