package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.model.TechBranch
import com.example.model.TechItem
import com.example.ui.theme.AlertRed
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun TechTreeScreen(
    viewModel: WarGameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedBranch by remember { mutableStateOf<TechBranch?>(null) }

    val filteredTech = if (selectedBranch == null) {
        uiState.techItems
    } else {
        uiState.techItems.filter { it.branch == selectedBranch }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
            .padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🔬 مجمع البحوث والتكنولوجيا والتطوير العسكري",
                        color = EgyptGold,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "شجرة التقدم العلمي عبر 3 مسارات: الحرب والتسليح، الاقتصاد والتصنيع، والدبلوماسية والسيادة",
                        color = TextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "رصيد الأبحاث الحالي: ${formatNumber(uiState.resources.researchPoints)} 🔬",
                        color = RadarGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Branch Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val branches = listOf(
                    null to "الكل 🌐",
                    TechBranch.WARFARE to "⚔️ الحرب والتسليح",
                    TechBranch.ECONOMY to "⚙️ الاقتصاد والصناعة",
                    TechBranch.DIPLOMACY to "🌐 الدبلوماسية والسيادة"
                )

                branches.forEach { (branch, label) ->
                    val isSelected = selectedBranch == branch
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) EgyptGoldDark.copy(alpha = 0.45f) else SurfaceCard)
                            .border(1.dp, if (isSelected) EgyptGold else SurfaceCardBorder, RoundedCornerShape(8.dp))
                            .clickable { selectedBranch = branch }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) EgyptGold else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        items(filteredTech, key = { it.id }) { tech ->
            TechItemCard(
                tech = tech,
                onUnlock = { viewModel.unlockTechnology(tech) }
            )
        }
    }
}

@Composable
private fun TechItemCard(
    tech: TechItem,
    onUnlock: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (tech.isUnlocked) RadarGreen else SurfaceCardBorder,
                RoundedCornerShape(10.dp)
            )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = tech.iconEmoji, fontSize = 22.sp)
                    Column {
                        Text(
                            text = tech.titleAr,
                            color = if (tech.isUnlocked) EgyptGold else TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = tech.categoryAr,
                            color = TacticalBlue,
                            fontSize = 10.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (tech.isUnlocked) RadarGreen.copy(alpha = 0.2f) else SurfaceDark)
                        .border(1.dp, if (tech.isUnlocked) RadarGreen else SurfaceCardBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (tech.isUnlocked) "مُكتمل ومُفعّل ✅" else "مُغلق 🔒",
                        color = if (tech.isUnlocked) RadarGreen else TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = tech.descAr, color = TextMuted, fontSize = 11.sp)

            Spacer(modifier = Modifier.height(8.dp))

            // Bonus Indicators
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (tech.attackBonusPercent > 0) {
                    Text(text = "قوة الهجوم: +${tech.attackBonusPercent}%", color = AlertRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                if (tech.defenseBonusPercent > 0) {
                    Text(text = "قوة الدفاع: +${tech.defenseBonusPercent}%", color = TacticalBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                if (tech.incomeBonusPercent > 0) {
                    Text(text = "دخل الموارد: +${tech.incomeBonusPercent}%", color = EgyptGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (!tech.isUnlocked) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "المطلوب:", fontSize = 10.sp, color = TextMuted)
                        Text(text = "🔬 ${tech.costResearch}", fontSize = 10.sp, color = RadarGreen)
                        Text(text = "🪙 ${formatNumber(tech.costGold)}", fontSize = 10.sp, color = EgyptGold)
                    }

                    Button(
                        onClick = onUnlock,
                        colors = ButtonDefaults.buttonColors(containerColor = EgyptGold),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("unlock_tech_${tech.id}")
                    ) {
                        Text(text = "بدء البحث العلمي 🔬", color = SurfaceDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
