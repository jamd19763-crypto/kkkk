package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Continent
import com.example.model.Country
import com.example.model.CountryStatus
import com.example.ui.theme.AlertRed
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.MilitaryRed
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun WorldWarPickerModal(
    viewModel: WarGameViewModel,
    onDismiss: () -> Unit
) {
    val uiState = viewModel.uiState.value
    var searchQuery by remember { mutableStateOf("") }
    var selectedContinent by remember { mutableStateOf<Continent?>(null) }
    var onlyUnconquered by remember { mutableStateOf(false) }

    val allCountries = uiState.countries
    val conqueredCount = allCountries.count { it.status == CountryStatus.CONQUERED }
    val totalCount = allCountries.count { !it.isEgypt }

    val filteredCountries = allCountries.filter { country ->
        val matchesContinent = selectedContinent == null || country.continent == selectedContinent
        val matchesSearch = searchQuery.isBlank() ||
                country.nameAr.contains(searchQuery.trim(), ignoreCase = true) ||
                country.nameEn.contains(searchQuery.trim(), ignoreCase = true)
        val matchesUnconquered = !onlyUnconquered || (!country.isEgypt && country.status != CountryStatus.CONQUERED)
        matchesContinent && matchesSearch && matchesUnconquered
    }.sortedWith(compareByDescending<Country> { it.isEgypt }
        .thenBy { it.status == CountryStatus.CONQUERED }
        .thenByDescending { it.power })

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxSize(0.95f)
                .clip(RoundedCornerShape(14.dp))
                .background(SurfaceDark)
                .border(1.5.dp, EgyptGold, RoundedCornerShape(14.dp))
                .padding(12.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "🌍", fontSize = 24.sp)
                        Column {
                            Text(
                                text = "غزو دول العالم: القيادة العسكرية العليا 🇪🇬",
                                color = EgyptGold,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "السيادة المصرية المنجزة: $conqueredCount من أصل $totalCount دولة (${(conqueredCount * 100) / totalCount.coerceAtLeast(1)}%)",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Text(text = "✕", color = EgyptGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Search & Filter Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("ابحث عن أي دولة (مثلاً: أمريكا، بريطانيا، إسرائيل، ألمانيا...)", fontSize = 11.sp, color = TextMuted) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EgyptGold,
                            unfocusedBorderColor = SurfaceCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = SurfaceCard,
                            unfocusedContainerColor = SurfaceCard
                        )
                    )

                    // Toggle Unconquered
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (onlyUnconquered) EgyptGoldDark.copy(alpha = 0.4f) else SurfaceCard)
                            .border(1.dp, if (onlyUnconquered) EgyptGold else SurfaceCardBorder, RoundedCornerShape(8.dp))
                            .clickable { onlyUnconquered = !onlyUnconquered }
                            .padding(horizontal = 10.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = if (onlyUnconquered) "⚔️ غير المحتلة فقط" else "🌐 كل الدول",
                            color = if (onlyUnconquered) EgyptGold else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Continent Chips
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                ) {
                    item {
                        ContinentFilterChip(
                            label = "الكل (${allCountries.size})",
                            isSelected = selectedContinent == null,
                            onClick = { selectedContinent = null }
                        )
                    }
                    items(Continent.values()) { continent ->
                        val count = allCountries.count { it.continent == continent }
                        ContinentFilterChip(
                            label = "${continent.nameAr} ($count)",
                            isSelected = selectedContinent == continent,
                            onClick = { selectedContinent = continent }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // List of Countries
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredCountries, key = { it.id }) { country ->
                        CountryWarItemCard(
                            country = country,
                            onDemandCapitulation = {
                                viewModel.demandImmediateCapitulation(country)
                            },
                            onInvasion = {
                                viewModel.startBattle(country, isAirStrike = false, isNuclear = false)
                                onDismiss()
                            },
                            onAirStrike = {
                                viewModel.startBattle(country, isAirStrike = true, isNuclear = false)
                                onDismiss()
                            },
                            onNuclearStrike = {
                                viewModel.startBattle(country, isAirStrike = false, isNuclear = true)
                                onDismiss()
                            },
                            onFocusOnMap = {
                                viewModel.selectCountry(country)
                                onDismiss()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinentFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) EgyptGoldDark.copy(alpha = 0.45f) else SurfaceCard)
            .border(1.dp, if (isSelected) EgyptGold else SurfaceCardBorder, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) EgyptGold else TextMuted,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun CountryWarItemCard(
    country: Country,
    onDemandCapitulation: () -> Unit,
    onInvasion: () -> Unit,
    onAirStrike: () -> Unit,
    onNuclearStrike: () -> Unit,
    onFocusOnMap: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (country.isEgypt) EgyptGold else if (country.status == CountryStatus.CONQUERED) RadarGreen.copy(alpha = 0.6f) else SurfaceCardBorder,
                RoundedCornerShape(10.dp)
            )
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Header: Flag, Name, Continent & Power Stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = country.flag, fontSize = 24.sp)
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = country.nameAr,
                                color = if (country.isEgypt) EgyptGold else TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (country.isEgypt) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(EgyptGoldDark.copy(alpha = 0.3f))
                                        .border(0.8.dp, EgyptGold, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text("القوة العظمى 🇪🇬", color = EgyptGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text(
                            text = "${country.continent.nameAr} • السكان: ${country.population} مليون • الناتج: ${country.gdpBillion} مليار$",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                // Power & Defense pill
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "⚔️ هجوم: ${formatNumber(country.power)}",
                        color = if (country.isEgypt) EgyptGold else AlertRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "🛡️ دفاع: ${formatNumber(country.defense)}",
                        color = TacticalBlue,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Affordances
            if (country.isEgypt) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(EgyptGoldDark.copy(alpha = 0.2f))
                        .border(1.dp, EgyptGold, RoundedCornerShape(6.dp))
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🇪🇬 مقر القيادة العامة للقوات المسلحة المصرية والوطن الأم",
                        color = EgyptGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (country.status == CountryStatus.CONQUERED) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(RadarGreen.copy(alpha = 0.15f))
                            .border(1.dp, RadarGreen, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "👑 أراضي محررة خاضعة للسيادة المصرية الكاملة 🇪🇬",
                            color = RadarGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Button(
                        onClick = onFocusOnMap,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(EgyptGold)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("🎯 الخريطة", color = EgyptGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Instant Annexation Ultimatum
                    Button(
                        onClick = onDemandCapitulation,
                        colors = ButtonDefaults.buttonColors(containerColor = EgyptGoldDark),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(34.dp)
                    ) {
                        Text(
                            text = "👑 إخضاع وضم فوري",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Full Tactical Invasion
                    Button(
                        onClick = onInvasion,
                        colors = ButtonDefaults.buttonColors(containerColor = MilitaryRed),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(34.dp)
                    ) {
                        Text(
                            text = "⚔️ غزو شامل",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Quick Air Strike
                    Button(
                        onClick = onAirStrike,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(TacticalBlue)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(0.9f)
                            .height(34.dp)
                    ) {
                        Text(
                            text = "🚀 جوي",
                            color = TacticalBlue,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Quick Nuclear Strike
                    Button(
                        onClick = onNuclearStrike,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFFFB74D))),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(0.9f)
                            .height(34.dp)
                    ) {
                        Text(
                            text = "☢️ نووي",
                            color = Color(0xFFFFB74D),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Focus on Map
                    Button(
                        onClick = onFocusOnMap,
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(0.8f)
                            .height(34.dp)
                    ) {
                        Text(
                            text = "🎯",
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
