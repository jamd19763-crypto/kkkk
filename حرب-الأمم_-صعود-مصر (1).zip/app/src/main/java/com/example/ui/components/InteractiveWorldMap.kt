package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Continent
import com.example.model.Country
import com.example.model.CountryStatus
import com.example.model.MapExplosion
import com.example.model.MilitaryUnitType
import com.example.model.MovingUnit
import com.example.model.PlacedMapUnit
import com.example.model.TapDamageEffect
import com.example.model.CombatLaserBeam
import com.example.model.ConquestWave
import com.example.model.CraterMark
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CommandBlack
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.MilitaryRed
import com.example.ui.theme.OceanBlueDeep
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlin.math.atan2
import kotlin.math.hypot

@Composable
fun InteractiveWorldMap(
    countries: List<Country>,
    selectedCountry: Country?,
    onCountrySelected: (Country) -> Unit,
    movingUnits: List<MovingUnit> = emptyList(),
    placedUnits: List<PlacedMapUnit> = emptyList(),
    activeExplosions: List<MapExplosion> = emptyList(),
    activeTapDamages: List<TapDamageEffect> = emptyList(),
    combatLaserBeams: List<CombatLaserBeam> = emptyList(),
    conquestWaves: List<ConquestWave> = emptyList(),
    craterMarks: List<CraterMark> = emptyList(),
    screenShake: Float = 0f,
    screenFlashAlpha: Float = 0f,
    onTapTargetCountry: ((Country) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var selectedContinent by remember { mutableStateOf<Continent?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var isListView by remember { mutableStateOf(false) }
    var showFilterBar by remember { mutableStateOf(false) }

    // Map Transform State - Starts zoomed in directly on Egypt & Middle East
    var scale by remember { mutableFloatStateOf(1.55f) }
    var offsetX by remember { mutableFloatStateOf(0.0f) }
    var offsetY by remember { mutableFloatStateOf(0.0f) }
    var isInitialCentered by remember { mutableStateOf(false) }

    val filteredCountries = remember(countries, selectedContinent, searchQuery) {
        countries.filter { country ->
            val matchContinent = selectedContinent == null || country.continent == selectedContinent
            val matchSearch = searchQuery.isBlank() ||
                country.nameAr.contains(searchQuery, ignoreCase = true) ||
                country.nameEn.contains(searchQuery, ignoreCase = true)
            matchContinent && matchSearch
        }
    }

    // Fullscreen 2D RTS Map Container
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(OceanBlueDeep)
    ) {
        val screenW = constraints.maxWidth.toFloat()
        val screenH = constraints.maxHeight.toFloat()

        // Auto-center camera on Egypt on initial load
        LaunchedEffect(screenW, screenH) {
            if (!isInitialCentered && screenW > 0 && screenH > 0) {
                // Egypt is located at normX = 0.585f, normY = 0.400f
                val egyptNormX = 0.585f
                val egyptNormY = 0.400f
                offsetX = -(egyptNormX - 0.5f) * screenW * scale
                offsetY = -(egyptNormY - 0.5f) * screenH * scale
                isInitialCentered = true
            }
        }

        val shakeX = if (screenShake > 0) ((System.currentTimeMillis() % 16 - 8) * screenShake).dp else 0.dp
        val shakeY = if (screenShake > 0) (((System.currentTimeMillis() + 5) % 16 - 8) * screenShake).dp else 0.dp

        // Primary Pan & Zoom World Map Box
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = shakeX, y = shakeY)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.75f, 4.5f)
                        val maxOffsetX = (size.width * (scale - 0.5f)).coerceAtLeast(0f)
                        val maxOffsetY = (size.height * (scale - 0.5f)).coerceAtLeast(0f)
                        offsetX = (offsetX + pan.x).coerceIn(-maxOffsetX, maxOffsetX)
                        offsetY = (offsetY + pan.y).coerceIn(-maxOffsetY, maxOffsetY)
                    }
                }
                .pointerInput(filteredCountries, scale, offsetX, offsetY, selectedCountry) {
                    detectTapGestures { tapOffset ->
                        val w = size.width
                        val h = size.height
                        var closest: Country? = null
                        var minDistance = Float.MAX_VALUE

                        // Generous tap radius for effortless touch interaction
                        val touchRadiusPx = 52.dp.toPx()

                        filteredCountries.forEach { c ->
                            val nodeX = (c.normX * w * scale) + offsetX - ((w * (scale - 1f)) / 2f)
                            val nodeY = (c.normY * h * scale) + offsetY - ((h * (scale - 1f)) / 2f)
                            val dist = hypot(tapOffset.x - nodeX, tapOffset.y - nodeY)
                            if (dist < touchRadiusPx && dist < minDistance) {
                                minDistance = dist
                                closest = c
                            }
                        }
                        if (closest != null) {
                            if (selectedCountry?.id == closest?.id && !closest!!.isEgypt && closest!!.status != CountryStatus.CONQUERED) {
                                onTapTargetCountry?.invoke(closest!!)
                            } else {
                                onCountrySelected(closest!!)
                            }
                        }
                    }
                }
        ) {
            // 1. High-Resolution Natural World Map Texture Background
            Image(
                painter = painterResource(id = R.drawable.img_world_map_texture),
                contentDescription = "خريطة العالم الطبيعية الحقيقية",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX
                        translationY = offsetY
                    }
            )

            // 2. Real-Time Tactical Canvas: Country Zones, Territory Plaques, Moving Armies, Tracers, Explosions
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw Country Territories & Plaques
                filteredCountries.forEach { country ->
                    val nodeX = (country.normX * w * scale) + offsetX - ((w * (scale - 1f)) / 2f)
                    val nodeY = (country.normY * h * scale) + offsetY - ((h * (scale - 1f)) / 2f)

                    // Visible viewport boundary check
                    if (nodeX in -160f..(w + 160f) && nodeY in -160f..(h + 160f)) {
                        val isSelected = selectedCountry?.id == country.id
                        drawTacticalCountryTerritory(
                            country = country,
                            center = Offset(nodeX, nodeY),
                            isSelected = isSelected,
                            scale = scale
                        )

                        // Draw Stationed Military Units on this territory (Stack limit 5)
                        val unitsHere = placedUnits.filter { it.countryId == country.id }
                        unitsHere.forEach { pUnit ->
                            val unitX = nodeX + (pUnit.offsetX * w * scale)
                            val unitY = nodeY + (pUnit.offsetY * h * scale)
                            drawStationedMilitaryUnit(
                                unit = pUnit,
                                center = Offset(unitX, unitY),
                                scale = scale
                            )
                        }
                    }
                }

                // Draw Moving Units (Tanks, Fighter Jets, Infantry, Warships)
                movingUnits.forEach { unit ->
                    val sx = (unit.startX * w * scale) + offsetX - ((w * (scale - 1f)) / 2f)
                    val sy = (unit.startY * h * scale) + offsetY - ((h * (scale - 1f)) / 2f)
                    val tx = (unit.targetX * w * scale) + offsetX - ((w * (scale - 1f)) / 2f)
                    val ty = (unit.targetY * h * scale) + offsetY - ((h * (scale - 1f)) / 2f)

                    // Trajectory Line with glowing tactical dots
                    drawLine(
                        color = EgyptGold.copy(alpha = 0.65f),
                        start = Offset(sx, sy),
                        end = Offset(tx, ty),
                        strokeWidth = 2.5.dp.toPx()
                    )

                    // Current interpolated unit location
                    val curX = sx + (tx - sx) * unit.progress
                    val curY = sy + (ty - sy) * unit.progress

                    // High-Voltage Combat Tracer Beam (Line Renderer simulation)
                    if (unit.progress > 0.30f) {
                        val tracerEndX = curX + (tx - curX) * 0.55f
                        val tracerEndY = curY + (ty - curY) * 0.55f

                        // Outer glowing fire beam
                        drawLine(
                            color = Color(0xFFFF6D00).copy(alpha = 0.85f),
                            start = Offset(curX, curY),
                            end = Offset(tracerEndX, tracerEndY),
                            strokeWidth = 6.dp.toPx()
                        )
                        // Intense bright yellow core
                        drawLine(
                            color = Color(0xFFFFEB3B),
                            start = Offset(curX, curY),
                            end = Offset(tracerEndX, tracerEndY),
                            strokeWidth = 3.5.dp.toPx()
                        )
                    }

                    // Draw High-Fidelity Military Vehicle Sprite
                    val angleRad = atan2((ty - sy).toDouble(), (tx - sx).toDouble())
                    val angleDeg = (angleRad * 180.0 / Math.PI).toFloat()

                    drawDetailedMilitaryVehicle(
                        unitType = unit.unitType,
                        center = Offset(curX, curY),
                        angleDeg = angleDeg,
                        scale = scale
                    )
                }

                // Draw Particle Explosions (Fire Shockwaves & Billowing Smoke)
                activeExplosions.forEach { exp ->
                    val ex = (exp.x * w * scale) + offsetX - ((w * (scale - 1f)) / 2f)
                    val ey = (exp.y * h * scale) + offsetY - ((h * (scale - 1f)) / 2f)
                    val maxR = if (exp.isNuke) 85.dp.toPx() else 48.dp.toPx()
                    val curR = (14.dp.toPx() + exp.progress * maxR)
                    val alpha = (1f - exp.progress).coerceIn(0f, 1f)

                    // Expanding fiery shockwave ring
                    drawCircle(
                        color = if (exp.isNuke) AlertRed.copy(alpha = alpha) else Color(0xFFFF5722).copy(alpha = alpha),
                        radius = curR,
                        center = Offset(ex, ey),
                        style = Stroke(width = 5.dp.toPx())
                    )
                    // Inner fireball core
                    drawCircle(
                        color = Color(0xFFFFEB3B).copy(alpha = alpha * 0.9f),
                        radius = curR * 0.60f,
                        center = Offset(ex, ey)
                    )
                    // Smoke puff particle
                    drawCircle(
                        color = Color(0xFF37474F).copy(alpha = alpha * 0.75f),
                        radius = curR * 0.35f,
                        center = Offset(ex, ey)
                    )
                }

                // Draw Floating Damage Numbers & Sparks
                activeTapDamages.forEach { dmg ->
                    val dx = (dmg.x * w * scale) + offsetX - ((w * (scale - 1f)) / 2f)
                    val dy = (dmg.y * h * scale) + offsetY - ((h * (scale - 1f)) / 2f)

                    // Fiery impact burst
                    drawCircle(
                        color = if (dmg.isCritical) EgyptGold.copy(alpha = dmg.alpha) else AlertRed.copy(alpha = dmg.alpha),
                        radius = if (dmg.isCritical) 20.dp.toPx() else 12.dp.toPx(),
                        center = Offset(dx, dy)
                    )

                    // Text with drop shadow
                    val dmgPaint = android.graphics.Paint().apply {
                        color = if (dmg.isCritical) android.graphics.Color.YELLOW else android.graphics.Color.WHITE
                        textSize = if (dmg.isCritical) 44f else 32f
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        setShadowLayer(8f, 2f, 2f, android.graphics.Color.BLACK)
                        alpha = (dmg.alpha * 255).toInt().coerceIn(0, 255)
                    }
                    val textToDraw = if (dmg.isCritical) "💥 ضربة قاضية! -${formatNumber(dmg.damage)}" else "-${formatNumber(dmg.damage)}"
                    drawContext.canvas.nativeCanvas.drawText(textToDraw, dx, dy - 24f, dmgPaint)
                }
            }
        }

        // Floating Tactical Controls (Right Side)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Zoom In (+)
            TacticalCircleButton(text = "+", color = EgyptGold) {
                scale = (scale * 1.3f).coerceAtMost(4.5f)
            }

            // Zoom Out (-)
            TacticalCircleButton(text = "-", color = EgyptGold) {
                scale = (scale / 1.3f).coerceAtLeast(0.75f)
            }

            // Center on Egypt Command Center (🇪🇬)
            TacticalCircleButton(text = "🇪🇬", color = EgyptGold) {
                val egyptNormX = 0.585f
                val egyptNormY = 0.400f
                scale = 1.6f
                offsetX = -(egyptNormX - 0.5f) * screenW * scale
                offsetY = -(egyptNormY - 0.5f) * screenH * scale
            }

            // Reset View (⟲)
            TacticalCircleButton(text = "⟲", color = TextPrimary) {
                scale = 1.0f
                offsetX = 0f
                offsetY = 0f
            }

            // Toggle Search & Filter Drawer
            TacticalCircleButton(text = "🔍", color = if (showFilterBar) EgyptGold else TextMuted) {
                showFilterBar = !showFilterBar
            }

            // Toggle List Mode (📋)
            TacticalCircleButton(text = if (isListView) "🗺️" else "📋", color = if (isListView) RadarGreen else TextPrimary) {
                isListView = !isListView
            }
        }

        // Floating Collapsible Search & Filter Bar (Top overlay, doesn't eat screen space)
        AnimatedVisibility(
            visible = showFilterBar,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 52.dp, start = 16.dp, end = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark.copy(alpha = 0.95f))
                    .border(1.dp, EgyptGold, RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("🎯 البحث وتصفية مسارح العمليات", color = EgyptGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        IconButton(onClick = { showFilterBar = false }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                    }

                    // Search input
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("بحث عن دولة بالاسم العربي أو الإنجليزي...", fontSize = 11.sp, color = TextMuted) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EgyptGold, modifier = Modifier.size(16.dp)) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted, modifier = Modifier.size(14.dp))
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EgyptGold,
                            unfocusedBorderColor = SurfaceCardBorder,
                            focusedContainerColor = SurfaceCard,
                            unfocusedContainerColor = SurfaceCard,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().height(42.dp)
                    )

                    // Continent chips
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ContinentFilterChip(
                            title = "الكل (${countries.size})",
                            isSelected = selectedContinent == null,
                            onClick = { selectedContinent = null }
                        )
                        Continent.values().forEach { cont ->
                            ContinentFilterChip(
                                title = "${cont.nameAr} (${countries.count { it.continent == cont }})",
                                isSelected = selectedContinent == cont,
                                onClick = { selectedContinent = cont }
                            )
                        }
                    }
                }
            }
        }

        // Floating Tactical Legend (Bottom-Start)
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 12.dp, bottom = 62.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(CommandBlack.copy(alpha = 0.85f))
                .border(1.dp, SurfaceCardBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendItem(color = EgyptGold, label = "مصر 🇪🇬")
            LegendItem(color = EgyptGoldDark, label = "أرض محررة 👑")
            LegendItem(color = RadarGreen, label = "حليف 🛡️")
            LegendItem(color = MilitaryRed, label = "عدو ⚔️")
            LegendItem(color = TacticalBlue, label = "محايد 🌐")
        }

        // Tactical Country Roster List View Overlay (When toggled)
        if (isListView) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SurfaceDark.copy(alpha = 0.95f))
                    .padding(top = 50.dp, bottom = 60.dp, start = 16.dp, end = 16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("📋 سجل دول العالم ومسارح العمليات (${filteredCountries.size})", color = EgyptGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        IconButton(onClick = { isListView = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = EgyptGold)
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredCountries, key = { it.id }) { country ->
                            CountryListItem(
                                country = country,
                                isSelected = selectedCountry?.id == country.id,
                                onClick = {
                                    onCountrySelected(country)
                                    isListView = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TacticalCircleButton(
    text: String,
    color: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(SurfaceCard.copy(alpha = 0.92f))
            .border(1.2.dp, color, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

private fun DrawScope.drawTacticalCountryTerritory(
    country: Country,
    center: Offset,
    isSelected: Boolean,
    scale: Float
) {
    val statusColor = when (country.status) {
        CountryStatus.PLAYER_EGYPT -> EgyptGold
        CountryStatus.CONQUERED -> EgyptGoldDark
        CountryStatus.ALLIED -> RadarGreen
        CountryStatus.HOSTILE -> MilitaryRed
        CountryStatus.NEUTRAL -> TacticalBlue
    }

    // Dynamic Sizing - Substantially bigger plaques for grand RTS clarity
    val effectiveScale = scale.coerceIn(0.90f, 1.35f)
    val plaqueWidth = (if (country.isEgypt) 155f else 130f) * effectiveScale
    val plaqueHeight = (if (country.isEgypt) 44f else 38f) * effectiveScale
    val left = center.x - plaqueWidth / 2f
    val top = center.y - plaqueHeight / 2f

    // 1. Surrounding Influence & Sovereignty Zone Halo
    val zoneRadius = (if (country.isEgypt) 65f else 46f) * scale.coerceIn(0.85f, 1.4f)

    // Filled territorial aura
    drawCircle(
        color = statusColor.copy(alpha = if (country.isEgypt) 0.35f else 0.22f),
        radius = zoneRadius,
        center = center
    )
    // Pulsing territorial perimeter boundary
    drawCircle(
        color = statusColor.copy(alpha = if (country.isEgypt) 0.85f else 0.55f),
        radius = zoneRadius,
        center = center,
        style = Stroke(width = if (country.isEgypt) 3f else 1.8f)
    )

    // 2. High-Tech Tactical Plaque Box
    drawRoundRect(
        color = Color(0xFA0B1017),
        topLeft = Offset(left, top),
        size = Size(plaqueWidth, plaqueHeight),
        cornerRadius = CornerRadius(8f, 8f)
    )
    // Plaque Glowing Border
    drawRoundRect(
        color = if (isSelected) EgyptGold else statusColor,
        topLeft = Offset(left, top),
        size = Size(plaqueWidth, plaqueHeight),
        cornerRadius = CornerRadius(8f, 8f),
        style = Stroke(width = if (isSelected) 3.5f else 2f)
    )

    // 3. Crisp Native Text: Country Flag & Arabic Name
    val flagTextSize = (if (country.isEgypt) 20f else 17f) * effectiveScale * 1.5f
    val flagPaint = android.graphics.Paint().apply {
        this.textSize = flagTextSize
        textAlign = android.graphics.Paint.Align.RIGHT
        isAntiAlias = true
    }

    val nameTextSize = (if (country.isEgypt) 14f else 12f) * effectiveScale * 1.8f
    val namePaint = android.graphics.Paint().apply {
        color = if (country.isEgypt) android.graphics.Color.rgb(255, 215, 0) else android.graphics.Color.WHITE
        this.textSize = nameTextSize
        textAlign = android.graphics.Paint.Align.CENTER
        isAntiAlias = true
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setShadowLayer(4f, 1f, 1f, android.graphics.Color.BLACK)
    }

    val displayLabel = if (country.isEgypt) "🇪🇬 مصر (الوطن الأم)" else if (country.status == CountryStatus.CONQUERED) "🇪🇬 ${country.nameAr} (محررة)" else "${country.flag} ${country.nameAr}"

    drawContext.canvas.nativeCanvas.drawText(
        displayLabel,
        center.x,
        center.y + (nameTextSize * 0.15f),
        namePaint
    )

    // 4. Country HP / Defense Power Bar Under Plaque
    val barW = plaqueWidth * 0.88f
    val barH = 5f * effectiveScale
    val barLeft = center.x - barW / 2f
    val barTop = top + plaqueHeight + 3f
    val hpRatio = if (country.isEgypt) 1f else (country.power.toFloat() / 250000f).coerceIn(0.18f, 1f)

    drawRoundRect(
        color = Color(0xDD000000),
        topLeft = Offset(barLeft, barTop),
        size = Size(barW, barH),
        cornerRadius = CornerRadius(3f, 3f)
    )
    drawRoundRect(
        color = if (country.isEgypt) EgyptGold else if (hpRatio > 0.45f) RadarGreen else AlertRed,
        topLeft = Offset(barLeft, barTop),
        size = Size(barW * hpRatio, barH),
        cornerRadius = CornerRadius(3f, 3f)
    )

    // 5. Selected Reticle / Crosshairs if active
    if (isSelected) {
        val reticleSize = plaqueWidth * 0.62f
        val retColor = EgyptGold
        val rw = 12f * effectiveScale

        // Holographic corner crosshair brackets
        drawLine(retColor, Offset(center.x - reticleSize, center.y - reticleSize), Offset(center.x - reticleSize + rw, center.y - reticleSize), 3.5f)
        drawLine(retColor, Offset(center.x - reticleSize, center.y - reticleSize), Offset(center.x - reticleSize, center.y - reticleSize + rw), 3.5f)

        drawLine(retColor, Offset(center.x + reticleSize, center.y - reticleSize), Offset(center.x + reticleSize - rw, center.y - reticleSize), 3.5f)
        drawLine(retColor, Offset(center.x + reticleSize, center.y - reticleSize), Offset(center.x + reticleSize, center.y - reticleSize + rw), 3.5f)

        drawLine(retColor, Offset(center.x - reticleSize, center.y + reticleSize), Offset(center.x - reticleSize + rw, center.y + reticleSize), 3.5f)
        drawLine(retColor, Offset(center.x - reticleSize, center.y + reticleSize), Offset(center.x - reticleSize, center.y + reticleSize - rw), 3.5f)

        drawLine(retColor, Offset(center.x + reticleSize, center.y + reticleSize), Offset(center.x + reticleSize - rw, center.y + reticleSize), 3.5f)
        drawLine(retColor, Offset(center.x + reticleSize, center.y + reticleSize), Offset(center.x + reticleSize, center.y + reticleSize - rw), 3.5f)
    }
}

private fun DrawScope.drawStationedMilitaryUnit(
    unit: PlacedMapUnit,
    center: Offset,
    scale: Float
) {
    val unitScale = (scale * 0.85f).coerceIn(0.75f, 1.30f)
    val badgeRadius = 14f * unitScale

    // Stationed Unit Tactical Plaque Base Badge
    drawCircle(
        color = Color(0xEE0B131B),
        radius = badgeRadius,
        center = center
    )
    drawCircle(
        color = if (unit.isEgyptian) EgyptGold else MilitaryRed,
        radius = badgeRadius,
        center = center,
        style = Stroke(width = 2f)
    )

    // Render Unit Sprite
    drawDetailedMilitaryVehicle(
        unitType = unit.unitType,
        center = center,
        angleDeg = 0f,
        scale = unitScale * 0.85f
    )

    // Mini Health indicator pip
    drawCircle(
        color = RadarGreen,
        radius = 3.5f * unitScale,
        center = Offset(center.x + badgeRadius * 0.7f, center.y - badgeRadius * 0.7f)
    )
}

private fun DrawScope.drawDetailedMilitaryVehicle(
    unitType: MilitaryUnitType,
    center: Offset,
    angleDeg: Float,
    scale: Float
) {
    val unitScale = scale.coerceIn(0.95f, 1.55f)

    rotate(degrees = angleDeg, pivot = center) {
        when (unitType) {
            MilitaryUnitType.TANKS -> {
                // M1A1 Abrams Heavy Tank
                val hullW = 34f * unitScale
                val hullH = 22f * unitScale

                // 1. Dual Heavy Tread Tracks
                drawRoundRect(
                    color = Color(0xFF1B1B1B),
                    topLeft = Offset(center.x - hullW / 2f, center.y - hullH / 2f - 4f),
                    size = Size(hullW, 6f),
                    cornerRadius = CornerRadius(2f, 2f)
                )
                drawRoundRect(
                    color = Color(0xFF1B1B1B),
                    topLeft = Offset(center.x - hullW / 2f, center.y + hullH / 2f - 2f),
                    size = Size(hullW, 6f),
                    cornerRadius = CornerRadius(2f, 2f)
                )

                // 2. Camouflaged Armored Chassis
                drawRoundRect(
                    color = Color(0xFFC29B38),
                    topLeft = Offset(center.x - hullW / 2f, center.y - hullH / 2f),
                    size = Size(hullW, hullH),
                    cornerRadius = CornerRadius(4f, 4f)
                )
                drawRoundRect(
                    color = EgyptGold,
                    topLeft = Offset(center.x - hullW / 2f, center.y - hullH / 2f),
                    size = Size(hullW, hullH),
                    cornerRadius = CornerRadius(4f, 4f),
                    style = Stroke(width = 1.8f)
                )

                // 3. Armored Turret
                drawCircle(
                    color = Color(0xFF8D6E1A),
                    radius = 9f * unitScale,
                    center = center
                )
                drawCircle(
                    color = EgyptGold,
                    radius = 9f * unitScale,
                    center = center,
                    style = Stroke(width = 1.5f)
                )

                // 4. 120mm Smoothbore High-Velocity Cannon
                drawLine(
                    color = Color(0xFF1B1B1B),
                    start = center,
                    end = Offset(center.x + 28f * unitScale, center.y),
                    strokeWidth = 4.5f * unitScale
                )
                // Cannon Muzzle Brake
                drawCircle(
                    color = Color(0xFFFFD54F),
                    radius = 3.5f * unitScale,
                    center = Offset(center.x + 29f * unitScale, center.y)
                )
            }

            MilitaryUnitType.FIGHTER_JET -> {
                // Rafale Supersonic Delta-Wing Fighter
                val jetLength = 40f * unitScale

                // 1. Sleek Titanium Fuselage
                drawOval(
                    color = Color(0xFFCFD8DC),
                    topLeft = Offset(center.x - jetLength / 2f, center.y - 5f * unitScale),
                    size = Size(jetLength, 10f * unitScale)
                )

                // 2. Delta Wings & Canards
                val wingSpan = 32f * unitScale
                val wingPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(center.x + 8f * unitScale, center.y)
                    lineTo(center.x - 12f * unitScale, center.y - wingSpan / 2f)
                    lineTo(center.x - 5f * unitScale, center.y)
                    lineTo(center.x - 12f * unitScale, center.y + wingSpan / 2f)
                    close()
                }
                drawPath(wingPath, color = Color(0xFF78909C))
                drawPath(wingPath, color = EgyptGold, style = Stroke(width = 1.8f))

                // 3. Cockpit Glass Canopy
                drawOval(
                    color = Color(0xFF00E5FF),
                    topLeft = Offset(center.x + 4f * unitScale, center.y - 3f * unitScale),
                    size = Size(11f * unitScale, 6f * unitScale)
                )

                // 4. Dual Jet Engine Afterburner Exhaust Plumes
                drawLine(
                    color = Color(0xFFFF3D00),
                    start = Offset(center.x - jetLength / 2f, center.y),
                    end = Offset(center.x - jetLength / 2f - 16f * unitScale, center.y),
                    strokeWidth = 4.5f * unitScale
                )
                drawLine(
                    color = Color(0xFFFFD600),
                    start = Offset(center.x - jetLength / 2f, center.y),
                    end = Offset(center.x - jetLength / 2f - 9f * unitScale, center.y),
                    strokeWidth = 2.5f * unitScale
                )
            }

            MilitaryUnitType.DRONE -> {
                // Stealth UCAV Wing Drone (طائرة مسيرة قتالية شبحية)
                val droneSpan = 30f * unitScale
                val dronePath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(center.x + 12f * unitScale, center.y)
                    lineTo(center.x - 10f * unitScale, center.y - droneSpan / 2f)
                    lineTo(center.x - 4f * unitScale, center.y)
                    lineTo(center.x - 10f * unitScale, center.y + droneSpan / 2f)
                    close()
                }
                drawPath(dronePath, color = Color(0xFF263238))
                drawPath(dronePath, color = RadarGreen, style = Stroke(width = 1.6f))
                // Sensor camera dot
                drawCircle(color = RadarGreen, radius = 2.5f * unitScale, center = Offset(center.x + 8f * unitScale, center.y))
            }

            MilitaryUnitType.ARTILLERY -> {
                // Self-Propelled Howitzer Artillery (المدفعية الصاروخية ذاتية الحركة)
                val baseW = 32f * unitScale
                val baseH = 20f * unitScale
                drawRoundRect(
                    color = Color(0xFF424242),
                    topLeft = Offset(center.x - baseW / 2f, center.y - baseH / 2f),
                    size = Size(baseW, baseH),
                    cornerRadius = CornerRadius(3f, 3f)
                )
                drawRoundRect(
                    color = EgyptGoldDark,
                    topLeft = Offset(center.x - baseW / 2f, center.y - baseH / 2f),
                    size = Size(baseW, baseH),
                    cornerRadius = CornerRadius(3f, 3f),
                    style = Stroke(width = 1.6f)
                )
                // Long Heavy Howitzer Barrel
                drawLine(
                    color = Color(0xFFE0E0E0),
                    start = Offset(center.x - 4f * unitScale, center.y),
                    end = Offset(center.x + 34f * unitScale, center.y),
                    strokeWidth = 4f * unitScale
                )
                // Muzzle Flash / Barrel Cap
                drawCircle(color = Color(0xFFFF9800), radius = 3.5f * unitScale, center = Offset(center.x + 34f * unitScale, center.y))
            }

            MilitaryUnitType.NUCLEAR_ICBM -> {
                // Heavy Strategic ICBM Ballistic Missile (صاروخ باليستي عابر للقارات)
                val missileLen = 46f * unitScale
                val missileW = 10f * unitScale

                // Rocket Body (Cylinder)
                drawRoundRect(
                    color = Color(0xFFECEFF1),
                    topLeft = Offset(center.x - missileLen / 2f, center.y - missileW / 2f),
                    size = Size(missileLen, missileW),
                    cornerRadius = CornerRadius(4f, 4f)
                )
                drawRoundRect(
                    color = AlertRed,
                    topLeft = Offset(center.x - missileLen / 2f, center.y - missileW / 2f),
                    size = Size(missileLen, missileW),
                    cornerRadius = CornerRadius(4f, 4f),
                    style = Stroke(width = 1.8f)
                )

                // Nuclear Warhead Cone (Red tip)
                val warheadPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(center.x + missileLen / 2f, center.y - missileW / 2f)
                    lineTo(center.x + missileLen / 2f + 14f * unitScale, center.y)
                    lineTo(center.x + missileLen / 2f, center.y + missileW / 2f)
                    close()
                }
                drawPath(warheadPath, color = AlertRed)

                // Fiery Rocket Booster Exhaust Thruster
                drawLine(
                    color = Color(0xFFFF5722),
                    start = Offset(center.x - missileLen / 2f, center.y),
                    end = Offset(center.x - missileLen / 2f - 24f * unitScale, center.y),
                    strokeWidth = 6f * unitScale
                )
                drawLine(
                    color = Color(0xFFFFEB3B),
                    start = Offset(center.x - missileLen / 2f, center.y),
                    end = Offset(center.x - missileLen / 2f - 14f * unitScale, center.y),
                    strokeWidth = 3f * unitScale
                )
            }

            MilitaryUnitType.WARSHIP -> {
                // Naval Missile Frigate
                val shipLength = 42f * unitScale
                val shipWidth = 14f * unitScale

                drawRoundRect(
                    color = Color(0xFF37474F),
                    topLeft = Offset(center.x - shipLength / 2f, center.y - shipWidth / 2f),
                    size = Size(shipLength, shipWidth),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                drawRoundRect(
                    color = EgyptGold,
                    topLeft = Offset(center.x - shipLength / 2f, center.y - shipWidth / 2f),
                    size = Size(shipLength, shipWidth),
                    cornerRadius = CornerRadius(6f, 6f),
                    style = Stroke(width = 1.5f)
                )
                // Fore & Aft Gun Turrets
                drawCircle(color = Color(0xFF90A4AE), radius = 4.5f * unitScale, center = Offset(center.x + 10f * unitScale, center.y))
                drawCircle(color = Color(0xFF90A4AE), radius = 4.5f * unitScale, center = Offset(center.x - 8f * unitScale, center.y))
            }

            else -> {
                // Thunderbolt Commando Squad (الصاعقة)
                drawCircle(color = Color(0xFF2E7D32), radius = 14f * unitScale, center = center)
                drawCircle(color = EgyptGold, radius = 14f * unitScale, center = center, style = Stroke(width = 2.5f))
                // Rifle Barrel
                drawLine(
                    color = Color.White,
                    start = center,
                    end = Offset(center.x + 18f * unitScale, center.y),
                    strokeWidth = 3.5f * unitScale
                )
            }
        }
    }
}

@Composable
private fun ContinentFilterChip(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) EgyptGold else SurfaceCard)
            .border(1.dp, if (isSelected) EgyptGold else SurfaceCardBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            color = if (isSelected) CommandBlack else TextPrimary,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(text = label, fontSize = 10.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CountryListItem(
    country: Country,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val statusColor = when (country.status) {
        CountryStatus.PLAYER_EGYPT -> EgyptGold
        CountryStatus.CONQUERED -> EgyptGoldDark
        CountryStatus.ALLIED -> RadarGreen
        CountryStatus.HOSTILE -> MilitaryRed
        CountryStatus.NEUTRAL -> TacticalBlue
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) SurfaceCardBorder else SurfaceCard)
            .border(1.dp, if (isSelected) EgyptGold else SurfaceCardBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = country.flag, fontSize = 24.sp)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = country.nameAr,
                            color = if (country.isEgypt) EgyptGold else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        if (country.isEgypt) {
                            Text(text = " 🦅", fontSize = 12.sp)
                        }
                    }
                    Text(
                        text = "${country.continent.nameAr} • ${country.status.labelAr}",
                        color = statusColor,
                        fontSize = 10.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "القوة: ${formatNumber(country.power)}",
                    color = EgyptGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "السكان: ${country.population}M",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }
    }
}
