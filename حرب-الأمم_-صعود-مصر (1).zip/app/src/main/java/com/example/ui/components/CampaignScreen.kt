package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CampaignStage
import com.example.model.Country
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun CampaignScreen(
    viewModel: WarGameViewModel,
    onNavigateToCountry: (Country) -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState = viewModel.uiState.value
    val completedCount = uiState.campaignStages.count { it.isCompleted }
    val totalStages = uiState.campaignStages.size

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
            .padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📜 سجل حملات التحرير والغزو (40 مرحلة)",
                            color = EgyptGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "$completedCount / $totalStages",
                            color = RadarGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "من تأمين وادي النيل والشرق الأوسط، إلى فتح أوروبا وآسيا والأمريكتين وإعلان مصر سيدة العالم!",
                        color = TextMuted,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { completedCount.toFloat() / totalStages.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = EgyptGold,
                        trackColor = SurfaceDark
                    )
                }
            }
        }

        items(uiState.campaignStages, key = { it.id }) { stage ->
            CampaignStageCard(
                stage = stage,
                allCountries = uiState.countries,
                onStartMission = { targetCountry ->
                    onNavigateToCountry(targetCountry)
                },
                onClaimReward = { viewModel.claimStageReward(stage) }
            )
        }
    }
}

@Composable
private fun CampaignStageCard(
    stage: CampaignStage,
    allCountries: List<Country>,
    onStartMission: (Country) -> Unit,
    onClaimReward: () -> Unit
) {
    val targetCountries = allCountries.filter { stage.targetCountryIds.contains(it.id) }
    val isCompleted = stage.isCompleted
    val isUnlocked = stage.isUnlocked

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                when {
                    isCompleted -> RadarGreen
                    isUnlocked -> EgyptGold
                    else -> SurfaceCardBorder
                },
                RoundedCornerShape(10.dp)
            )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stage.titleAr,
                        color = if (isCompleted) RadarGreen else if (isUnlocked) EgyptGold else TextMuted,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${stage.continent.nameAr} • ${stage.descAr}",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when {
                                isCompleted -> RadarGreen.copy(alpha = 0.2f)
                                isUnlocked -> EgyptGoldDark.copy(alpha = 0.2f)
                                else -> SurfaceDark
                            }
                        )
                        .border(
                            1.dp,
                            when {
                                isCompleted -> RadarGreen
                                isUnlocked -> EgyptGold
                                else -> SurfaceCardBorder
                            },
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when {
                            isCompleted -> "تم النصر 🏆"
                            isUnlocked -> "متاحة للغزو ⚔️"
                            else -> "مُغلقة 🔒"
                        },
                        color = when {
                            isCompleted -> RadarGreen
                            isUnlocked -> EgyptGold
                            else -> TextMuted
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Target Countries with Flags
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(text = "الأهداف:", fontSize = 10.sp, color = TextMuted)
                targetCountries.forEach { target ->
                    Text(
                        text = "${target.flag} ${target.nameAr}",
                        fontSize = 11.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Reward
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = "المكافأة:", fontSize = 10.sp, color = TextMuted)
                Text(text = "🪙 +${formatNumber(stage.rewardGold)}", fontSize = 10.sp, color = EgyptGold)
                Text(text = "🔬 +${stage.rewardResearch}", fontSize = 10.sp, color = RadarGreen)
            }

            if (isUnlocked && !isCompleted) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    targetCountries.forEach { target ->
                        Button(
                            onClick = { onStartMission(target) },
                            colors = ButtonDefaults.buttonColors(containerColor = EgyptGold),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .testTag("attack_target_${target.id}")
                        ) {
                            Text(
                                text = "بدء غزو ${target.nameAr} ⚔️",
                                color = SurfaceDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
