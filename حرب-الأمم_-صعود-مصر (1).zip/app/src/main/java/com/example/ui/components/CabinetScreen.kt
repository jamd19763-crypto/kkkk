package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CabinetMinister
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun CabinetScreen(
    viewModel: WarGameViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
            .padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp)
    ) {
        // Cabinet Header Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "🏛️ مجلس الوزراء وحكومة الحرب الإمبراطورية",
                                color = EgyptGold,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "ترقية كفاءة الحقائب الوزارية لمضاعفة دخل الإمبراطورية والتصنيع الحربي والدبلوماسية",
                                color = TextMuted,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        // Gold Display
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceDark)
                                .border(1.dp, EgyptGold, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(text = "🪙 الذهب:", color = EgyptGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(text = formatNumber(uiState.resources.gold), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }
        }

        // List of Ministers
        items(uiState.ministers, key = { it.id }) { minister ->
            val upgradeCost = minister.upgradeCostGold * minister.level
            MinisterCard(
                minister = minister,
                upgradeCost = upgradeCost,
                canUpgrade = uiState.resources.gold >= upgradeCost,
                onUpgrade = { viewModel.upgradeMinister(minister) }
            )
        }
    }
}

@Composable
private fun MinisterCard(
    minister: CabinetMinister,
    upgradeCost: Long,
    canUpgrade: Boolean,
    onUpgrade: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.2.dp, EgyptGold.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(SurfaceDark)
                            .border(1.2.dp, EgyptGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = minister.avatarEmoji, fontSize = 22.sp)
                    }

                    Column {
                        Text(
                            text = minister.nameAr,
                            color = EgyptGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "حقيبة: ${minister.portfolioAr}",
                            color = TacticalBlue,
                            fontSize = 11.sp
                        )
                    }
                }

                // Level Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(RadarGreen.copy(alpha = 0.2f))
                        .border(1.dp, RadarGreen, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "المستوى ${minister.level} 🌟",
                        color = RadarGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = minister.bonusDescriptionAr, color = TextMuted, fontSize = 11.sp)

            Spacer(modifier = Modifier.height(10.dp))

            // Upgrade Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(text = "تكلفة التطوير:", color = TextMuted, fontSize = 11.sp)
                    Text(text = "🪙 ${formatNumber(upgradeCost)}", color = EgyptGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onUpgrade,
                    enabled = canUpgrade,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EgyptGold,
                        disabledContainerColor = SurfaceCardBorder
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("upgrade_minister_${minister.id}")
                ) {
                    Text(
                        text = "ترقية الحقيبة الوزارية 🏛️",
                        color = if (canUpgrade) SurfaceDark else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
