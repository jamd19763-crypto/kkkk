package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.Country
import com.example.model.CountryStatus
import com.example.model.MilitaryUnitType
import com.example.ui.components.AcademyScreen
import com.example.ui.components.CabinetScreen
import com.example.ui.components.CampaignScreen
import com.example.ui.components.CinematicIntroOverlay
import com.example.ui.components.CountryDetailSheet
import com.example.ui.components.CustomizationSkinsDialog
import com.example.ui.components.DailyMissionsDialog
import com.example.ui.components.GameSettingsDialog
import com.example.ui.components.GrandVictoryDialog
import com.example.ui.components.InfrastructureScreen
import com.example.ui.components.InteractiveWorldMap
import com.example.ui.components.LandscapeFloatingCountryPanel
import com.example.ui.components.LandscapeRtsBottomBar
import com.example.ui.components.LandscapeRtsTopBar
import com.example.ui.components.MarketScreen
import com.example.ui.components.MilitaryScreen
import com.example.ui.components.RankedLeagueDialog
import com.example.ui.components.TacticalBattleDialog
import com.example.ui.components.TechTreeScreen
import com.example.ui.components.WorldWarPickerModal
import com.example.ui.theme.CommandBlack
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.WarGameViewModel

@Composable
fun WarGameApp(
    viewModel: WarGameViewModel = viewModel()
) {
    // Enforce RTL layout direction for authentic Arabic military command interface
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val uiState by viewModel.uiState.collectAsState()

        var showMilitaryDialog by remember { mutableStateOf(false) }
        var showAcademyDialog by remember { mutableStateOf(false) }
        var showCabinetDialog by remember { mutableStateOf(false) }
        var showWorldWarPicker by remember { mutableStateOf(false) }
        var showUpgradesDialog by remember { mutableStateOf(false) }
        var showMarketDialog by remember { mutableStateOf(false) }
        var showCampaignDialog by remember { mutableStateOf(false) }
        var showMissionsDialog by remember { mutableStateOf(false) }
        var showRankedDialog by remember { mutableStateOf(false) }
        var showCustomizationDialog by remember { mutableStateOf(false) }
        var showSettingsDialog by remember { mutableStateOf(false) }
        var showCinematicIntro by remember { mutableStateOf(false) }
        var showCountryDetailSheet by remember { mutableStateOf<Country?>(null) }
        var upgradeTab by remember { mutableIntStateOf(0) }

        val currentStage = uiState.campaignStages.find { !it.isCompleted && it.isUnlocked }
            ?: uiState.campaignStages.firstOrNull()
        val stageTitle = currentStage?.let { "المرحلة ${it.id}: ${it.titleAr}" } ?: "السيادة العالمية"

        val conqueredCount = uiState.countries.count { it.status == CountryStatus.CONQUERED }
        val totalCount = uiState.countries.count { !it.isEgypt }

        // Expansive Fullscreen RTS Command View (100% Screen Map Canvas)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CommandBlack)
        ) {
            // 1. Foundation: The Big Grand 2D World Map Canvas spanning the entire viewport
            InteractiveWorldMap(
                countries = uiState.countries,
                selectedCountry = uiState.selectedCountry,
                onCountrySelected = { country -> viewModel.selectCountry(country) },
                movingUnits = uiState.movingUnits,
                placedUnits = uiState.placedUnits,
                activeExplosions = uiState.activeExplosions,
                activeTapDamages = uiState.activeTapDamages,
                screenShake = uiState.screenShake,
                onTapTargetCountry = { target -> viewModel.tapDamageEnemy(target) },
                modifier = Modifier.fillMaxSize()
            )

            // 2. Floating Top RTS Resource Bar Overlay
            LandscapeRtsTopBar(
                resources = uiState.resources,
                gameSpeed = uiState.gameSpeed,
                isPaused = uiState.isPaused,
                isMuted = uiState.isMuted,
                onToggleSpeed = {
                    val newSpeed = if (uiState.gameSpeed == 1f) 2f else 1f
                    viewModel.setGameSpeed(newSpeed)
                },
                onTogglePause = { viewModel.togglePause() },
                onToggleMute = { viewModel.toggleMute() },
                currentStageTitle = stageTitle,
                conqueredCount = conqueredCount,
                totalCount = totalCount,
                rankBadge = uiState.currentRankTier.badgeEmoji,
                rankTitle = uiState.currentRankTier.titleAr,
                onOpenMissions = { showMissionsDialog = true },
                onOpenRanked = { showRankedDialog = true },
                onOpenCustomization = { showCustomizationDialog = true },
                onOpenSettings = { showSettingsDialog = true },
                onReplayCinematic = { showCinematicIntro = true },
                modifier = Modifier.align(Alignment.TopCenter)
            )

            // 3. Floating Bottom RTS Command Dock Overlay
            LandscapeRtsBottomBar(
                selectedUnit = uiState.selectedUnitForDeployment,
                onSelectUnit = { unit -> viewModel.selectUnitForDeployment(unit) },
                selectedCountry = uiState.selectedCountry,
                onDeployUnit = {
                    uiState.selectedCountry?.let { target ->
                        viewModel.deployUnitToCountry(uiState.selectedUnitForDeployment, target)
                    }
                },
                onOpenMilitary = { showMilitaryDialog = true },
                onOpenAcademy = { showAcademyDialog = true },
                onOpenCabinet = { showCabinetDialog = true },
                onOpenWorldWarPicker = { showWorldWarPicker = true },
                onOpenUpgrades = { showUpgradesDialog = true },
                onOpenMarket = { showMarketDialog = true },
                onOpenCampaign = { showCampaignDialog = true },
                modifier = Modifier.align(Alignment.BottomCenter)
            )

            // 4. Floating Selected Target Country Dossier Panel (Docked on Top-End)
            uiState.selectedCountry?.let { country ->
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 58.dp, end = 12.dp)
                ) {
                    LandscapeFloatingCountryPanel(
                        country = country,
                        currentHp = uiState.targetCountryCurrentHp,
                        maxHp = uiState.targetCountryMaxHp,
                        consecutiveTaps = uiState.consecutiveTaps,
                        onTapAttack = { viewModel.tapDamageEnemy(country) },
                        onFullInvasion = { viewModel.startBattle(country) },
                        onDemandCapitulation = { viewModel.demandImmediateCapitulation(country) },
                        onAirStrike = { viewModel.startBattle(country, isAirStrike = true, isNuclear = false) },
                        onNuclearStrike = { viewModel.startBattle(country, isAirStrike = false, isNuclear = true) },
                        onOpenDetails = { showCountryDetailSheet = country },
                        onClose = { viewModel.selectCountry(null) },
                        placedUnitsCount = uiState.placedUnits.count { it.countryId == country.id },
                        onRecruitUnitOnTerritory = { unitType ->
                            viewModel.recruitAndPlaceUnitOnTerritory(country, unitType)
                        }
                    )
                }
            }

            // 5. Tactical Toast Notification at Center Top
            uiState.notificationMessage?.let { msg ->
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 62.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CommandBlack.copy(alpha = 0.92f))
                        .border(1.dp, EgyptGold, RoundedCornerShape(8.dp))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(text = msg, color = EgyptGold)
                }
            }

            // Military Forces & Fleet Dialog
            if (showMilitaryDialog) {
                Dialog(onDismissRequest = { showMilitaryDialog = false }) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(0.95f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SurfaceDark)
                            .border(1.5.dp, EgyptGold, RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🪖 ترسانة القوات المسلحة والأسطول المصري 🇪🇬",
                                    color = EgyptGold,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(onClick = { showMilitaryDialog = false }, modifier = Modifier.size(30.dp)) {
                                    Text(text = "✕", color = EgyptGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                                MilitaryScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }

            // Military Academy Dialog (Generals & High Command)
            if (showAcademyDialog) {
                Dialog(onDismissRequest = { showAcademyDialog = false }) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(0.95f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SurfaceDark)
                            .border(1.5.dp, EgyptGold, RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🎖️ الأكاديمية العسكرية العليا وهيئة الأركان 🇪🇬",
                                    color = EgyptGold,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(onClick = { showAcademyDialog = false }, modifier = Modifier.size(30.dp)) {
                                    Text(text = "✕", color = EgyptGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                                AcademyScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }

            // Cabinet & Government Dialog (Ministers)
            if (showCabinetDialog) {
                Dialog(onDismissRequest = { showCabinetDialog = false }) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(0.95f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SurfaceDark)
                            .border(1.5.dp, EgyptGold, RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🏛️ مجلس الوزراء وحكومة الحرب الإمبراطورية 🇪🇬",
                                    color = EgyptGold,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(onClick = { showCabinetDialog = false }, modifier = Modifier.size(30.dp)) {
                                    Text(text = "✕", color = EgyptGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                                CabinetScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }

            // World War Quick Conquest Modal
            if (showWorldWarPicker) {
                WorldWarPickerModal(
                    viewModel = viewModel,
                    onDismiss = { showWorldWarPicker = false }
                )
            }

            // Country Detail Sheet & Diplomacy
            showCountryDetailSheet?.let { c ->
                CountryDetailSheet(
                    country = c,
                    viewModel = viewModel,
                    onDismiss = { showCountryDetailSheet = null }
                )
            }

            // Upgrades & Tech Tree / Infrastructure Tabbed Dialog
            if (showUpgradesDialog) {
                Dialog(onDismissRequest = { showUpgradesDialog = false }) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(0.95f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SurfaceDark)
                            .border(1.5.dp, EgyptGold, RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🏛️ مركز التطوير والبناء القومي المصري",
                                    color = EgyptGold,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(onClick = { showUpgradesDialog = false }, modifier = Modifier.size(30.dp)) {
                                    Text(text = "✕", color = EgyptGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Tabs
                            TabRow(
                                selectedTabIndex = upgradeTab,
                                containerColor = SurfaceDark,
                                contentColor = EgyptGold,
                                indicator = { tabPositions ->
                                    TabRowDefaults.SecondaryIndicator(
                                        Modifier.tabIndicatorOffset(tabPositions[upgradeTab]),
                                        color = EgyptGold
                                    )
                                }
                            ) {
                                Tab(
                                    selected = upgradeTab == 0,
                                    onClick = { upgradeTab = 0 },
                                    text = {
                                        Text(
                                            text = "🔬 مجمع الأبحاث والتكنولوجيا",
                                            color = if (upgradeTab == 0) EgyptGold else TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                )
                                Tab(
                                    selected = upgradeTab == 1,
                                    onClick = { upgradeTab = 1 },
                                    text = {
                                        Text(
                                            text = "🏭 المصانع والبنية التحتية",
                                            color = if (upgradeTab == 1) EgyptGold else TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                                if (upgradeTab == 0) {
                                    TechTreeScreen(viewModel = viewModel)
                                } else {
                                    InfrastructureScreen(viewModel = viewModel)
                                }
                            }
                        }
                    }
                }
            }

            // Market & Resources Modal Dialog
            if (showMarketDialog) {
                Dialog(onDismissRequest = { showMarketDialog = false }) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(0.88f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceDark)
                            .border(1.2.dp, EgyptGold, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        MarketScreen(viewModel = viewModel)
                    }
                }
            }

            // Military Campaign Stages Dialog
            if (showCampaignDialog) {
                Dialog(onDismissRequest = { showCampaignDialog = false }) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(0.92f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceDark)
                            .border(1.2.dp, EgyptGold, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        CampaignScreen(
                            viewModel = viewModel,
                            onNavigateToCountry = { target ->
                                viewModel.selectCountry(target)
                                showCampaignDialog = false
                            }
                        )
                    }
                }
            }

            // Tactical Battle Dialog (Full Invasion Skirmish)
            uiState.activeBattle?.let { battle ->
                TacticalBattleDialog(
                    battle = battle,
                    onDismiss = { viewModel.dismissBattle() }
                )
            }

            // Dynamic World Event Popup Modal
            uiState.activeWorldEvent?.let { event ->
                Dialog(onDismissRequest = { viewModel.dismissWorldEvent() }) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(SurfaceDark)
                            .border(2.dp, EgyptGold, RoundedCornerShape(14.dp))
                            .padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(text = "${event.iconEmoji} حدث عالمي طارئ!", fontSize = 16.sp, color = EgyptGold, fontWeight = FontWeight.Bold)
                            Text(text = event.titleAr, fontSize = 14.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(text = event.descAr, fontSize = 11.sp, color = TextMuted)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(EgyptGoldDark.copy(alpha = 0.25f))
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "التأثير الإمبراطوري: ${event.effectDescAr}", fontSize = 11.sp, color = EgyptGold, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { viewModel.dismissWorldEvent() },
                                colors = ButtonDefaults.buttonColors(containerColor = EgyptGold),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().height(36.dp)
                            ) {
                                Text(text = "علم ويُنفذ لمجد مصر! 🇪🇬", color = CommandBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Grand Global Victory Dialog
            if (uiState.showGrandVictoryDialog) {
                GrandVictoryDialog(
                    onDismiss = { viewModel.dismissGrandVictoryDialog() },
                    onReset = {
                        viewModel.dismissGrandVictoryDialog()
                        viewModel.resetNewGame()
                    }
                )
            }

            // Daily Missions & 7-Day Streak Dialog
            if (showMissionsDialog) {
                DailyMissionsDialog(
                    dailyMissions = uiState.dailyMissions,
                    dailyStreak = uiState.dailyStreak,
                    onClaimMission = { missionId -> viewModel.claimDailyMissionReward(missionId) },
                    onClaimStreak = { viewModel.claimDailyStreakReward() },
                    onDismiss = { showMissionsDialog = false }
                )
            }

            // Ranked League & Tiers Dialog
            if (showRankedDialog) {
                RankedLeagueDialog(
                    playerRank = uiState.playerRank,
                    currentTier = uiState.currentRankTier,
                    onDismiss = { showRankedDialog = false }
                )
            }

            // Customization Skins Dialog
            if (showCustomizationDialog) {
                CustomizationSkinsDialog(
                    unitSkins = uiState.unitSkins,
                    playerGold = uiState.resources.gold,
                    onEquipSkin = { skinId -> viewModel.equipSkin(skinId) },
                    onUnlockSkin = { skinId -> viewModel.unlockSkin(skinId) },
                    onDismiss = { showCustomizationDialog = false }
                )
            }

            // Tactical Settings Dialog
            if (showSettingsDialog) {
                GameSettingsDialog(
                    settings = uiState.gameSettings,
                    isMuted = uiState.isMuted,
                    onToggleMute = { viewModel.toggleMute() },
                    onToggleVibration = {
                        viewModel.updateSettings(
                            uiState.gameSettings.copy(vibrationEnabled = !uiState.gameSettings.vibrationEnabled)
                        )
                    },
                    onSelectQuality = { quality ->
                        viewModel.updateSettings(
                            uiState.gameSettings.copy(graphicsQuality = quality)
                        )
                    },
                    onResetGame = {
                        showSettingsDialog = false
                        viewModel.resetNewGame()
                    },
                    onDismiss = { showSettingsDialog = false }
                )
            }

            // Cinematic Intro Overlay (On startup or manual replay)
            if (uiState.isCinematicActive || showCinematicIntro) {
                CinematicIntroOverlay(
                    onEnterGame = {
                        showCinematicIntro = false
                        viewModel.dismissCinematicIntro()
                    }
                )
            }
        }
    }
}
