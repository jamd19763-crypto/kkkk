package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Military Egyptian Gold & Obsidian Palette
val EgyptGold = Color(0xFFFFD700)
val EgyptGoldDark = Color(0xFFC59B27)
val EgyptGoldLight = Color(0xFFFFF275)

val MilitaryRed = Color(0xFFD32F2F)
val MilitaryRedDark = Color(0xFF8B0000)
val AlertRed = Color(0xFFFF5252)

val RadarGreen = Color(0xFF00E676)
val RadarGreenDark = Color(0xFF007E33)

val TacticalBlue = Color(0xFF0288D1)
val OceanBlue = Color(0xFF0B192C)
val OceanBlueDeep = Color(0xFF070F1E)

val CommandBlack = Color(0xFF0A0D14)
val SurfaceDark = Color(0xFF131822)
val SurfaceCard = Color(0xFF1C2230)
val SurfaceCardBorder = Color(0xFF2E384D)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
