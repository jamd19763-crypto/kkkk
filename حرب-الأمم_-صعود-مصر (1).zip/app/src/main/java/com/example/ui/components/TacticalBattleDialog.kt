package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CommandBlack
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptGoldDark
import com.example.ui.theme.EgyptGoldLight
import com.example.ui.theme.MilitaryRed
import com.example.ui.theme.MilitaryRedDark
import com.example.ui.theme.RadarGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TacticalBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.BattleState

@Composable
fun TacticalBattleDialog(
    battle: BattleState,
    onDismiss: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "battle_anim")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val playerRatio = if (battle.playerInitialPower > 0) {
        (battle.playerCurrentPower.toFloat() / battle.playerInitialPower.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val enemyRatio = if (battle.enemyInitialPower > 0) {
        (battle.enemyCurrentPower.toFloat() / battle.enemyInitialPower.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Dialog(
        onDismissRequest = { if (battle.isFinished) onDismiss() },
        properties = DialogProperties(dismissOnBackPress = battle.isFinished, dismissOnClickOutside = false)
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = SurfaceDark,
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, if (battle.isFinished && battle.isVictory) EgyptGold else MilitaryRed, RoundedCornerShape(14.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Battle Header
                Text(
                    text = when {
                        battle.isNuclear -> "☢️ ضربة باليستية نووية استراتيجية"
                        battle.isAirStrike -> "🚀 قصف جوي وصاروخي تكتيكي"
                        else -> "⚔️ معركة اجتياح عسكري شامل"
                    },
                    color = if (battle.isNuclear) AlertRed else EgyptGold,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Text(
                    text = if (battle.isFinished) "انتهت المعركة" else "جاري الاشتباك - الجولة ${battle.round}",
                    color = TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                )

                // Combatants Clash Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Egypt
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "🇪🇬", fontSize = 32.sp)
                        Text(
                            text = "مصر 🦅",
                            color = EgyptGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${formatNumber(battle.playerCurrentPower)}",
                            color = EgyptGoldLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // VS Flash badge
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (battle.isFinished) SurfaceCard else MilitaryRedDark)
                            .border(1.dp, EgyptGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (battle.isFinished) "🏁" else "⚡",
                            fontSize = 16.sp,
                            color = Color.White
                        )
                    }

                    // Enemy
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = battle.country.flag, fontSize = 32.sp)
                        Text(
                            text = battle.country.nameAr,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${formatNumber(battle.enemyCurrentPower)}",
                            color = AlertRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Health Bars
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "صمود القوات المصرية: ${(playerRatio * 100).toInt()}%", fontSize = 10.sp, color = EgyptGold)
                        Text(text = "صمود العدو: ${(enemyRatio * 100).toInt()}%", fontSize = 10.sp, color = AlertRed)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { playerRatio },
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = EgyptGold,
                            trackColor = SurfaceCard
                        )
                        LinearProgressIndicator(
                            progress = { enemyRatio },
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = AlertRed,
                            trackColor = SurfaceCard
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tactical Battle Animated Visual Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CommandBlack)
                        .border(1.dp, SurfaceCardBorder, RoundedCornerShape(8.dp))
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        if (!battle.isFinished) {
                            // Draw animated laser/artillery tracers with glowing recoil
                            val tracerProgress = pulse
                            // Tracer 1: Main Egyptian cannon
                            drawLine(
                                color = EgyptGold,
                                start = Offset(w * 0.15f, h * 0.5f),
                                end = Offset(w * (0.2f + 0.65f * tracerProgress), h * (0.35f + 0.25f * tracerProgress)),
                                strokeWidth = 4f,
                                cap = StrokeCap.Round
                            )

                            // Tracer 2: Egyptian Machine gun burst
                            drawLine(
                                color = Color(0xFFFFD54F),
                                start = Offset(w * 0.18f, h * 0.42f),
                                end = Offset(w * (0.25f + 0.55f * ((tracerProgress + 0.5f) % 1f)), h * (0.45f + 0.1f * tracerProgress)),
                                strokeWidth = 2f,
                                cap = StrokeCap.Round
                            )

                            // Muzzle Flash at origin
                            drawCircle(
                                color = Color(0xFFFFEB3B).copy(alpha = (1f - pulse)),
                                radius = 12f * (1f - pulse),
                                center = Offset(w * 0.15f, h * 0.5f)
                            )

                            // Enemy return fire
                            drawLine(
                                color = AlertRed,
                                start = Offset(w * 0.85f, h * 0.4f),
                                end = Offset(w * (0.8f - 0.55f * (1f - tracerProgress)), h * (0.6f - 0.25f * tracerProgress)),
                                strokeWidth = 3f,
                                cap = StrokeCap.Round
                            )

                            // Explosive flash & shockwave in the middle
                            if (battle.isNuclear) {
                                // Nuclear fireball & expanding shockwave ring
                                drawCircle(
                                    color = Color(0xFFFF5722).copy(alpha = 0.6f * pulse),
                                    radius = 45f * pulse,
                                    center = Offset(w * 0.5f, h * 0.5f)
                                )
                                drawCircle(
                                    color = Color(0xFFFFFF00).copy(alpha = 0.8f * pulse),
                                    radius = 28f * pulse,
                                    center = Offset(w * 0.5f, h * 0.5f)
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 50f * pulse,
                                    center = Offset(w * 0.5f, h * 0.5f),
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
                                )
                            } else {
                                drawCircle(
                                    color = Color(0xFFFF9800).copy(alpha = 0.4f * pulse),
                                    radius = 26f * pulse,
                                    center = Offset(w * 0.5f, h * 0.5f)
                                )
                                drawCircle(
                                    color = Color.White.copy(alpha = 0.85f * pulse),
                                    radius = 10f * pulse,
                                    center = Offset(w * 0.5f, h * 0.5f)
                                )
                            }
                        } else {
                            // Finished state canvas
                            val centerColor = if (battle.isVictory) EgyptGold else AlertRed
                            drawCircle(
                                color = centerColor.copy(alpha = 0.35f),
                                radius = 32f,
                                center = Offset(w * 0.5f, h * 0.5f)
                            )
                        }
                    }

                    if (battle.isFinished) {
                        Text(
                            text = if (battle.isVictory) "🏆 تم الانتصار وتحقيق الأهداف!" else "⚠️ تراجع تكتيكي",
                            color = if (battle.isVictory) EgyptGold else AlertRed,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Outcome Summary Text
                if (battle.isFinished) {
                    Text(
                        text = battle.summaryTextAr,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (battle.isVictory) EgyptGold else SurfaceCard
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("dismiss_battle_button")
                    ) {
                        Text(
                            text = if (battle.isVictory) "استلام الغنائم والعودة 🎖️" else "إغلاق وتجميع القوات",
                            color = if (battle.isVictory) CommandBlack else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
