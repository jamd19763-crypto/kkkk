package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

/**
 * Procedural offline audio synthesizer for military sounds using Android's AudioTrack,
 * with integrated hardware Haptic Feedback vibration support.
 * Runs 100% offline with zero external audio assets.
 */
class SoundEffectsManager(private val context: Context? = null) {

    private val scope = CoroutineScope(Dispatchers.Default)
    var isMuted: Boolean = false

    private val vibrator: Vibrator? by lazy {
        context?.let { ctx ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        }
    }

    fun vibrateShort(durationMs: Long = 40) {
        if (isMuted) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    fun vibrateHeavyExplosion() {
        if (isMuted) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 80, 50, 160), -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(180)
            }
        } catch (_: Exception) {}
    }

    fun playClick() {
        vibrateShort(25)
        if (isMuted) return
        scope.launch {
            generateTone(frequency = 800.0, durationMs = 40, decay = true)
        }
    }

    fun playDeployUnit() {
        vibrateShort(45)
        if (isMuted) return
        scope.launch {
            // Military command confirmation tone: two rapid high beeps
            generateTone(frequency = 600.0, durationMs = 60, decay = true)
            generateTone(frequency = 900.0, durationMs = 80, decay = true)
        }
    }

    fun playMarch() {
        vibrateShort(35)
        if (isMuted) return
        scope.launch {
            // Military snare drum beat simulation
            generateDrum(durationMs = 120)
        }
    }

    fun playArtilleryFire() {
        vibrateShort(65)
        if (isMuted) return
        scope.launch {
            // Low-frequency cannon boom with rapid decay
            generateExplosion(durationMs = 350)
        }
    }

    fun playMissileLaunch() {
        vibrateShort(50)
        if (isMuted) return
        scope.launch {
            // Upward frequency sweep (whoosh)
            generateSweep(startFreq = 200.0, endFreq = 1200.0, durationMs = 400)
        }
    }

    fun playAirRaidSiren() {
        vibrateHeavyExplosion()
        if (isMuted) return
        scope.launch {
            // Siren wail
            generateSiren(cycles = 2, durationMs = 600)
        }
    }

    fun playVictoryFanfare() {
        vibrateShort(80)
        if (isMuted) return
        scope.launch {
            // 4 triumphant notes: C4, E4, G4, C5
            val notes = listOf(261.63, 329.63, 392.00, 523.25)
            for (freq in notes) {
                generateTone(freq, 130, decay = false)
            }
        }
    }

    fun playExplosion() {
        vibrateHeavyExplosion()
        if (isMuted) return
        scope.launch {
            generateExplosion(durationMs = 450)
        }
    }

    fun playTankMovement() {
        vibrateShort(30)
        if (isMuted) return
        scope.launch {
            // Low diesel engine purr
            generateSweep(startFreq = 90.0, endFreq = 160.0, durationMs = 280)
        }
    }

    fun playRebellionAlert() {
        vibrateHeavyExplosion()
        if (isMuted) return
        scope.launch {
            // Intense dual alert pulses
            generateTone(frequency = 550.0, durationMs = 150, decay = false)
            generateTone(frequency = 350.0, durationMs = 220, decay = true)
        }
    }

    // --- ARABIC MILITARY VOICE-OVERS (TTS & SYNTHESIS) ---
    private var textToSpeech: android.speech.tts.TextToSpeech? = null

    init {
        try {
            textToSpeech = android.speech.tts.TextToSpeech(context) { status ->
                if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                    textToSpeech?.language = java.util.Locale("ar")
                    textToSpeech?.setPitch(0.85f)
                    textToSpeech?.setSpeechRate(0.95f)
                }
            }
        } catch (_: Exception) {}
    }

    fun speakArabicVoiceOver(phrase: String) {
        if (isMuted) return
        try {
            textToSpeech?.speak(phrase, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "voice_cmd")
        } catch (_: Exception) {}
    }

    fun playWarCryAllahuAkbar() {
        vibrateHeavyExplosion()
        speakArabicVoiceOver("الله أكبر! النصر لمصر!")
    }

    fun playCinematicIntroVoice() {
        vibrateHeavyExplosion()
        speakArabicVoiceOver("من قلب القاهرة... تبدأ الإمبراطورية!")
    }

    fun playConquestVoice() {
        vibrateHeavyExplosion()
        speakArabicVoiceOver("مصر... امتدت!")
    }

    fun playMissionCompletedVoice() {
        vibrateShort(80)
        speakArabicVoiceOver("مصر... انتصرت!")
    }

    fun playRankUpVoice() {
        vibrateShort(120)
        speakArabicVoiceOver("ترقية عسكرية عليا! فخر الأمة المصرية!")
    }

    fun playWarCryVictoryEgypt() {
        vibrateShort(100)
        speakArabicVoiceOver("النصر لمصر! والعالم لنا!")
    }

    fun playVoiceEgyptPreparesForWar() {
        vibrateShort(50)
        speakArabicVoiceOver("مصر تستعد للحرب العظمى!")
    }

    fun playGunfireMuzzle() {
        vibrateShort(30)
        if (isMuted) return
        scope.launch {
            // Rapid high-impact gunfire burst
            generateTone(frequency = 1200.0, durationMs = 30, decay = true)
            generateTone(frequency = 300.0, durationMs = 50, decay = true)
        }
    }

    fun playNuclearBlast() {
        vibrateHeavyExplosion()
        if (isMuted) return
        scope.launch {
            // Earth-shattering nuke rumble
            generateExplosion(durationMs = 900)
        }
    }

    fun playEpicWarHorn() {
        vibrateShort(75)
        if (isMuted) return
        scope.launch {
            // Resonant brass horn tones (D3 -> A3)
            generateTone(frequency = 146.83, durationMs = 400, decay = false)
            generateTone(frequency = 220.00, durationMs = 600, decay = true)
        }
    }



    private fun generateTone(frequency: Double, durationMs: Int, decay: Boolean) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val time = i.toDouble() / sampleRate
            val envelope = if (decay) (1.0 - (i.toDouble() / numSamples)) else 1.0
            val sample = (sin(2.0 * Math.PI * frequency * time) * 32767.0 * envelope * 0.4).toInt()
            buffer[i] = sample.toShort()
        }

        playBuffer(buffer, sampleRate)
    }

    private fun generateExplosion(durationMs: Int) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)
        var lastNoise = 0.0

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val envelope = (1.0 - progress) * (1.0 - progress)
            // Low rumble + white noise mix
            val noise = (Math.random() * 2.0 - 1.0)
            lastNoise = (lastNoise * 0.8) + (noise * 0.2) // Low pass filter
            val rumble = sin(2.0 * Math.PI * 65.0 * (i.toDouble() / sampleRate))
            val sample = ((lastNoise * 0.7 + rumble * 0.3) * 32767.0 * envelope * 0.6).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }

        playBuffer(buffer, sampleRate)
    }

    private fun generateDrum(durationMs: Int) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val envelope = 1.0 - (i.toDouble() / numSamples)
            val freq = 120.0 * envelope + 40.0
            val sample = (sin(2.0 * Math.PI * freq * (i.toDouble() / sampleRate)) * 32767.0 * envelope * 0.5).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }

        playBuffer(buffer, sampleRate)
    }

    private fun generateSweep(startFreq: Double, endFreq: Double, durationMs: Int) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val freq = startFreq + (endFreq - startFreq) * progress
            val envelope = sin(Math.PI * progress) // Fade in and out
            val sample = (sin(2.0 * Math.PI * freq * (i.toDouble() / sampleRate)) * 32767.0 * envelope * 0.4).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }

        playBuffer(buffer, sampleRate)
    }

    private fun generateSiren(cycles: Int, durationMs: Int) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val modulation = (sin(2.0 * Math.PI * cycles * progress) + 1.0) / 2.0
            val freq = 440.0 + (modulation * 400.0) // 440 to 840 Hz
            val sample = (sin(2.0 * Math.PI * freq * (i.toDouble() / sampleRate)) * 32767.0 * 0.35).toInt()
            buffer[i] = sample.coerceIn(-32767, 32767).toShort()
        }

        playBuffer(buffer, sampleRate)
    }

    private fun playBuffer(buffer: ShortArray, sampleRate: Int) {
        try {
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            // Release after playing
            scope.launch {
                kotlinx.coroutines.delay((buffer.size * 1000L / sampleRate) + 100)
                try {
                    track.stop()
                    track.release()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }
}
