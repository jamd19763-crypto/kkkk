package com.example.state

import android.content.Context
import android.content.SharedPreferences
import com.example.model.CountryStatus
import com.example.model.GameResources
import com.example.model.MilitaryUnitType
import org.json.JSONArray
import org.json.JSONObject

class SaveSystem(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("egypt_war_save_data", Context.MODE_PRIVATE)

    fun hasSave(slot: Int = 0): Boolean = prefs.contains("saved_gold_slot_$slot") || (slot == 0 && prefs.contains("saved_gold"))

    private fun obfuscate(input: String): String {
        val key = 0x5A.toByte()
        val bytes = input.toByteArray(Charsets.UTF_8)
        val masked = ByteArray(bytes.size) { i -> (bytes[i].toInt() xor key.toInt()).toByte() }
        return android.util.Base64.encodeToString(masked, android.util.Base64.NO_WRAP)
    }

    private fun deobfuscate(input: String): String {
        return try {
            val key = 0x5A.toByte()
            val decoded = android.util.Base64.decode(input, android.util.Base64.NO_WRAP)
            val unmasked = ByteArray(decoded.size) { i -> (decoded[i].toInt() xor key.toInt()).toByte() }
            String(unmasked, Charsets.UTF_8)
        } catch (_: Exception) {
            input
        }
    }

    fun saveGame(
        resources: GameResources,
        militaryUnits: Map<MilitaryUnitType, Int>,
        infrastructureLevels: Map<String, Int>,
        unlockedTechIds: Set<String>,
        countryStatuses: Map<String, CountryStatus>,
        completedStages: Set<Int>,
        recruitedGeneralIds: Set<String> = emptySet(),
        ministerLevels: Map<String, Int> = emptyMap(),
        gloryPoints: Long = 0L,
        slot: Int = 0
    ) {
        val editor = prefs.edit()
        val prefix = "slot_${slot}_"

        // Resources
        editor.putLong("${prefix}saved_gold", resources.gold)
        editor.putLong("${prefix}saved_oil", resources.oil)
        editor.putLong("${prefix}saved_iron", resources.iron)
        editor.putLong("${prefix}saved_food", resources.food)
        editor.putLong("${prefix}saved_manpower", resources.manpower)
        editor.putLong("${prefix}saved_research", resources.researchPoints)
        editor.putLong("${prefix}saved_glory", gloryPoints)

        // Backwards compatibility for slot 0
        if (slot == 0) {
            editor.putLong("saved_gold", resources.gold)
            editor.putLong("saved_oil", resources.oil)
            editor.putLong("saved_iron", resources.iron)
            editor.putLong("saved_food", resources.food)
            editor.putLong("saved_manpower", resources.manpower)
            editor.putLong("saved_research", resources.researchPoints)
        }

        // Military
        val milObj = JSONObject()
        militaryUnits.forEach { (type, count) ->
            milObj.put(type.id, count)
        }
        editor.putString("${prefix}saved_military", obfuscate(milObj.toString()))
        if (slot == 0) editor.putString("saved_military", milObj.toString())

        // Infrastructure
        val infraObj = JSONObject()
        infrastructureLevels.forEach { (id, level) ->
            infraObj.put(id, level)
        }
        editor.putString("${prefix}saved_infra", infraObj.toString())
        if (slot == 0) editor.putString("saved_infra", infraObj.toString())

        // Tech
        val techArray = JSONArray()
        unlockedTechIds.forEach { techArray.put(it) }
        editor.putString("${prefix}saved_tech", techArray.toString())
        if (slot == 0) editor.putString("saved_tech", techArray.toString())

        // Countries
        val countryObj = JSONObject()
        countryStatuses.forEach { (id, status) ->
            countryObj.put(id, status.name)
        }
        editor.putString("${prefix}saved_countries", countryObj.toString())
        if (slot == 0) editor.putString("saved_countries", countryObj.toString())

        // Stages
        val stageArray = JSONArray()
        completedStages.forEach { stageArray.put(it) }
        editor.putString("${prefix}saved_stages", stageArray.toString())
        if (slot == 0) editor.putString("saved_stages", stageArray.toString())

        // Generals & Ministers
        val genArray = JSONArray()
        recruitedGeneralIds.forEach { genArray.put(it) }
        editor.putString("${prefix}saved_generals", genArray.toString())

        val minObj = JSONObject()
        ministerLevels.forEach { (id, lvl) -> minObj.put(id, lvl) }
        editor.putString("${prefix}saved_ministers", minObj.toString())

        // Slot timestamp
        editor.putLong("${prefix}save_timestamp", System.currentTimeMillis())

        editor.apply()
    }

    fun loadResources(slot: Int = 0): GameResources? {
        val prefix = "slot_${slot}_"
        val hasSlotSave = prefs.contains("${prefix}saved_gold") || (slot == 0 && prefs.contains("saved_gold"))
        if (!hasSlotSave) return null

        val goldKey = if (prefs.contains("${prefix}saved_gold")) "${prefix}saved_gold" else "saved_gold"
        val oilKey = if (prefs.contains("${prefix}saved_oil")) "${prefix}saved_oil" else "saved_oil"
        val ironKey = if (prefs.contains("${prefix}saved_iron")) "${prefix}saved_iron" else "saved_iron"
        val foodKey = if (prefs.contains("${prefix}saved_food")) "${prefix}saved_food" else "saved_food"
        val manKey = if (prefs.contains("${prefix}saved_manpower")) "${prefix}saved_manpower" else "saved_manpower"
        val resKey = if (prefs.contains("${prefix}saved_research")) "${prefix}saved_research" else "saved_research"

        return GameResources(
            gold = prefs.getLong(goldKey, 500000L),
            oil = prefs.getLong(oilKey, 200000L),
            iron = prefs.getLong(ironKey, 250000L),
            food = prefs.getLong(foodKey, 200000L),
            manpower = prefs.getLong(manKey, 1000000L),
            researchPoints = prefs.getLong(resKey, 25000L)
        )
    }

    fun loadGlory(slot: Int = 0): Long {
        val prefix = "slot_${slot}_"
        return prefs.getLong("${prefix}saved_glory", 0L)
    }

    fun loadMilitary(slot: Int = 0): Map<MilitaryUnitType, Int> {
        val map = mutableMapOf<MilitaryUnitType, Int>()
        // Defaults if none - Superpower Egyptian Grand Army
        map[MilitaryUnitType.INFANTRY] = 5000
        map[MilitaryUnitType.TANKS] = 1200
        map[MilitaryUnitType.ARTILLERY] = 600
        map[MilitaryUnitType.FIGHTER_JET] = 450
        map[MilitaryUnitType.DRONE] = 600
        map[MilitaryUnitType.WARSHIP] = 120
        map[MilitaryUnitType.SUBMARINE] = 80
        map[MilitaryUnitType.BALLISTIC_MISSILE] = 150
        map[MilitaryUnitType.NUCLEAR_ICBM] = 25

        val prefix = "slot_${slot}_"
        val raw = prefs.getString("${prefix}saved_military", null) ?: prefs.getString("saved_military", null) ?: return map
        try {
            val jsonStr = if (raw.startsWith("{")) raw else deobfuscate(raw)
            val json = JSONObject(jsonStr)
            MilitaryUnitType.values().forEach { type ->
                if (json.has(type.id)) {
                    map[type] = json.getInt(type.id)
                }
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadInfrastructure(slot: Int = 0): Map<String, Int> {
        val map = mutableMapOf<String, Int>()
        val prefix = "slot_${slot}_"
        val str = prefs.getString("${prefix}saved_infra", null) ?: prefs.getString("saved_infra", null) ?: return map
        try {
            val json = JSONObject(str)
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                map[key] = json.getInt(key)
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadUnlockedTech(slot: Int = 0): Set<String> {
        val set = mutableSetOf("tech_radar")
        val prefix = "slot_${slot}_"
        val str = prefs.getString("${prefix}saved_tech", null) ?: prefs.getString("saved_tech", null) ?: return set
        try {
            val arr = JSONArray(str)
            for (i in 0 until arr.length()) {
                set.add(arr.getString(i))
            }
        } catch (_: Exception) {}
        return set
    }

    fun loadCountryStatuses(slot: Int = 0): Map<String, CountryStatus> {
        val map = mutableMapOf<String, CountryStatus>()
        val prefix = "slot_${slot}_"
        val str = prefs.getString("${prefix}saved_countries", null) ?: prefs.getString("saved_countries", null) ?: return map
        try {
            val json = JSONObject(str)
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val statusName = json.getString(key)
                try {
                    map[key] = CountryStatus.valueOf(statusName)
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadCompletedStages(slot: Int = 0): Set<Int> {
        val set = mutableSetOf<Int>()
        val prefix = "slot_${slot}_"
        val str = prefs.getString("${prefix}saved_stages", null) ?: prefs.getString("saved_stages", null) ?: return set
        try {
            val arr = JSONArray(str)
            for (i in 0 until arr.length()) {
                set.add(arr.getInt(i))
            }
        } catch (_: Exception) {}
        return set
    }

    fun loadRecruitedGenerals(slot: Int = 0): Set<String> {
        val set = mutableSetOf<String>()
        val prefix = "slot_${slot}_"
        val str = prefs.getString("${prefix}saved_generals", null) ?: return set
        try {
            val arr = JSONArray(str)
            for (i in 0 until arr.length()) {
                set.add(arr.getString(i))
            }
        } catch (_: Exception) {}
        return set
    }

    fun loadMinisterLevels(slot: Int = 0): Map<String, Int> {
        val map = mutableMapOf<String, Int>()
        val prefix = "slot_${slot}_"
        val str = prefs.getString("${prefix}saved_ministers", null) ?: return map
        try {
            val json = JSONObject(str)
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                map[key] = json.getInt(key)
            }
        } catch (_: Exception) {}
        return map
    }

    fun getSlotSaveDate(slot: Int): Long {
        return prefs.getLong("slot_${slot}_save_timestamp", 0L)
    }

    // --- LEGEND MODE: Rank, Streak & Settings Persistence ---
    fun saveRankPoints(points: Long) {
        prefs.edit().putLong("player_rank_points", points).apply()
    }

    fun loadRankPoints(): Long = prefs.getLong("player_rank_points", 1200L)

    fun saveDailyStreak(day: Int, lastDate: String) {
        prefs.edit()
            .putInt("streak_day", day)
            .putString("streak_last_date", lastDate)
            .apply()
    }

    fun loadStreakDay(): Int = prefs.getLong("streak_day", 1L).toInt()
    fun loadStreakLastDate(): String = prefs.getString("streak_last_date", "") ?: ""

    fun saveSettings(quality: String, sfx: Float, music: Float, vibration: Boolean, arabic: Boolean) {
        prefs.edit()
            .putString("settings_quality", quality)
            .putFloat("settings_sfx", sfx)
            .putFloat("settings_music", music)
            .putBoolean("settings_vibration", vibration)
            .putBoolean("settings_arabic", arabic)
            .apply()
    }

    fun loadSettingsQuality(): String = prefs.getString("settings_quality", "HIGH") ?: "HIGH"
    fun loadSettingsVibration(): Boolean = prefs.getBoolean("settings_vibration", true)

    fun clearSave(slot: Int = -1) {
        if (slot == -1) {
            prefs.edit().clear().apply()
        } else {
            val editor = prefs.edit()
            val prefix = "slot_${slot}_"
            prefs.all.keys.filter { it.startsWith(prefix) }.forEach { editor.remove(it) }
            if (slot == 0) {
                editor.remove("saved_gold")
                editor.remove("saved_oil")
                editor.remove("saved_iron")
                editor.remove("saved_food")
                editor.remove("saved_manpower")
                editor.remove("saved_research")
                editor.remove("saved_military")
                editor.remove("saved_infra")
                editor.remove("saved_tech")
                editor.remove("saved_countries")
                editor.remove("saved_stages")
            }
            editor.apply()
        }
    }
}
