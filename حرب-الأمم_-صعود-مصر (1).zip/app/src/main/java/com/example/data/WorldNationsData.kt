package com.example.data

import com.example.model.Continent
import com.example.model.Country
import com.example.model.CountryStatus

object WorldNationsData {

    fun getDefaultCountries(): List<Country> = listOf(
        // ---------------- AFRICA ----------------
        Country(
            id = "EGY",
            nameAr = "مصر (القوة العظمى الأولى عالمياً)",
            nameEn = "Egypt Superpower",
            flag = "🇪🇬",
            continent = Continent.AFRICA,
            normX = 0.585f,
            normY = 0.400f,
            power = 850000,
            defense = 950000,
            population = 112,
            gdpBillion = 4500,
            status = CountryStatus.PLAYER_EGYPT,
            isEgypt = true,
            garrisonInfantry = 2500000,
            garrisonTanks = 35000
        ),
        Country(
            id = "SDN",
            nameAr = "السودان",
            nameEn = "Sudan",
            flag = "🇸🇩",
            continent = Continent.AFRICA,
            normX = 0.580f,
            normY = 0.470f,
            power = 4200,
            defense = 4800,
            population = 48,
            gdpBillion = 35
        ),
        Country(
            id = "LBY",
            nameAr = "ليبيا",
            nameEn = "Libya",
            flag = "🇱🇾",
            continent = Continent.AFRICA,
            normX = 0.535f,
            normY = 0.395f,
            power = 3800,
            defense = 4000,
            population = 7,
            gdpBillion = 45
        ),
        Country(
            id = "DZA",
            nameAr = "الجزائر",
            nameEn = "Algeria",
            flag = "🇩🇿",
            continent = Continent.AFRICA,
            normX = 0.485f,
            normY = 0.390f,
            power = 12000,
            defense = 14000,
            population = 45,
            gdpBillion = 195
        ),
        Country(
            id = "MAR",
            nameAr = "المغرب",
            nameEn = "Morocco",
            flag = "🇲🇦",
            continent = Continent.AFRICA,
            normX = 0.450f,
            normY = 0.380f,
            power = 8500,
            defense = 9500,
            population = 38,
            gdpBillion = 140
        ),
        Country(
            id = "TUN",
            nameAr = "تونس",
            nameEn = "Tunisia",
            flag = "🇹🇳",
            continent = Continent.AFRICA,
            normX = 0.510f,
            normY = 0.355f,
            power = 3200,
            defense = 3600,
            population = 12,
            gdpBillion = 46
        ),
        Country(
            id = "ETH",
            nameAr = "إثيوبيا",
            nameEn = "Ethiopia",
            flag = "🇪🇹",
            continent = Continent.AFRICA,
            normX = 0.615f,
            normY = 0.505f,
            power = 7500,
            defense = 8200,
            population = 125,
            gdpBillion = 150
        ),
        Country(
            id = "NGA",
            nameAr = "نيجيريا",
            nameEn = "Nigeria",
            flag = "🇳🇬",
            continent = Continent.AFRICA,
            normX = 0.500f,
            normY = 0.510f,
            power = 9500,
            defense = 10000,
            population = 220,
            gdpBillion = 390
        ),
        Country(
            id = "ZAF",
            nameAr = "جنوب أفريقيا",
            nameEn = "South Africa",
            flag = "🇿🇦",
            continent = Continent.AFRICA,
            normX = 0.555f,
            normY = 0.720f,
            power = 11000,
            defense = 12500,
            population = 60,
            gdpBillion = 380
        ),
        Country(
            id = "KEN",
            nameAr = "كينيا",
            nameEn = "Kenya",
            flag = "🇰🇪",
            continent = Continent.AFRICA,
            normX = 0.610f,
            normY = 0.560f,
            power = 4900,
            defense = 5200,
            population = 54,
            gdpBillion = 115
        ),
        Country(
            id = "TCD",
            nameAr = "تشاد",
            nameEn = "Chad",
            flag = "🇹🇩",
            continent = Continent.AFRICA,
            normX = 0.540f,
            normY = 0.465f,
            power = 3100,
            defense = 3300,
            population = 18,
            gdpBillion = 12
        ),
        Country(
            id = "SOM",
            nameAr = "الصومال",
            nameEn = "Somalia",
            flag = "🇸🇴",
            continent = Continent.AFRICA,
            normX = 0.655f,
            normY = 0.510f,
            power = 2400,
            defense = 2600,
            population = 17,
            gdpBillion = 10
        ),
        Country(
            id = "COD",
            nameAr = "الكونغو الديمقراطية",
            nameEn = "DR Congo",
            flag = "🇨🇩",
            continent = Continent.AFRICA,
            normX = 0.545f,
            normY = 0.580f,
            power = 4500,
            defense = 4900,
            population = 102,
            gdpBillion = 65
        ),
        Country(
            id = "GHA",
            nameAr = "غانا",
            nameEn = "Ghana",
            flag = "🇬🇭",
            continent = Continent.AFRICA,
            normX = 0.470f,
            normY = 0.515f,
            power = 3400,
            defense = 3700,
            population = 34,
            gdpBillion = 75
        ),
        Country(
            id = "AGO",
            nameAr = "أنغولا",
            nameEn = "Angola",
            flag = "🇦🇴",
            continent = Continent.AFRICA,
            normX = 0.530f,
            normY = 0.635f,
            power = 6000,
            defense = 6500,
            population = 36,
            gdpBillion = 85
        ),
        Country(
            id = "SEN",
            nameAr = "السنغال",
            nameEn = "Senegal",
            flag = "🇸🇳",
            continent = Continent.AFRICA,
            normX = 0.430f,
            normY = 0.475f,
            power = 2900,
            defense = 3100,
            population = 17,
            gdpBillion = 30
        ),
        Country(
            id = "TZA",
            nameAr = "تنزانيا",
            nameEn = "Tanzania",
            flag = "🇹🇿",
            continent = Continent.AFRICA,
            normX = 0.600f,
            normY = 0.610f,
            power = 4200,
            defense = 4600,
            population = 65,
            gdpBillion = 78
        ),

        // ---------------- MIDDLE EAST & ASIA ----------------
        Country(
            id = "SAU",
            nameAr = "المملكة العربية السعودية",
            nameEn = "Saudi Arabia",
            flag = "🇸🇦",
            continent = Continent.ASIA,
            normX = 0.635f,
            normY = 0.435f,
            power = 18000,
            defense = 20000,
            population = 36,
            gdpBillion = 1100
        ),
        Country(
            id = "ARE",
            nameAr = "الإمارات العربية المتحدة",
            nameEn = "UAE",
            flag = "🇦🇪",
            continent = Continent.ASIA,
            normX = 0.670f,
            normY = 0.430f,
            power = 11500,
            defense = 13000,
            population = 10,
            gdpBillion = 500
        ),
        Country(
            id = "IRQ",
            nameAr = "العراق",
            nameEn = "Iraq",
            flag = "🇮🇶",
            continent = Continent.ASIA,
            normX = 0.630f,
            normY = 0.370f,
            power = 9200,
            defense = 9800,
            population = 44,
            gdpBillion = 250
        ),
        Country(
            id = "SYR",
            nameAr = "سوريا",
            nameEn = "Syria",
            flag = "🇸🇾",
            continent = Continent.ASIA,
            normX = 0.605f,
            normY = 0.360f,
            power = 5500,
            defense = 6200,
            population = 23,
            gdpBillion = 20
        ),
        Country(
            id = "JOR",
            nameAr = "الأردن",
            nameEn = "Jordan",
            flag = "🇯🇴",
            continent = Continent.ASIA,
            normX = 0.600f,
            normY = 0.380f,
            power = 4800,
            defense = 5200,
            population = 11,
            gdpBillion = 48
        ),
        Country(
            id = "YEM",
            nameAr = "اليمن",
            nameEn = "Yemen",
            flag = "🇾🇪",
            continent = Continent.ASIA,
            normX = 0.640f,
            normY = 0.480f,
            power = 4100,
            defense = 4500,
            population = 34,
            gdpBillion = 21
        ),
        Country(
            id = "OMN",
            nameAr = "سلطنة عمان",
            nameEn = "Oman",
            flag = "🇴🇲",
            continent = Continent.ASIA,
            normX = 0.675f,
            normY = 0.460f,
            power = 5400,
            defense = 5800,
            population = 5,
            gdpBillion = 105
        ),
        Country(
            id = "TUR",
            nameAr = "تركيا",
            nameEn = "Turkey",
            flag = "🇹🇷",
            continent = Continent.ASIA,
            normX = 0.590f,
            normY = 0.330f,
            power = 22000,
            defense = 24000,
            population = 86,
            gdpBillion = 900
        ),
        Country(
            id = "IRN",
            nameAr = "إيران",
            nameEn = "Iran",
            flag = "🇮🇷",
            continent = Continent.ASIA,
            normX = 0.665f,
            normY = 0.370f,
            power = 20000,
            defense = 21000,
            population = 88,
            gdpBillion = 380
        ),
        Country(
            id = "CHN",
            nameAr = "الصين العظمى",
            nameEn = "China",
            flag = "🇨🇳",
            continent = Continent.ASIA,
            normX = 0.810f,
            normY = 0.380f,
            power = 75000,
            defense = 80000,
            population = 1410,
            gdpBillion = 18000
        ),
        Country(
            id = "RUS",
            nameAr = "روسيا الاتحادية",
            nameEn = "Russia",
            flag = "🇷🇺",
            continent = Continent.ASIA,
            normX = 0.720f,
            normY = 0.220f,
            power = 78000,
            defense = 75000,
            population = 144,
            gdpBillion = 2000
        ),
        Country(
            id = "IND",
            nameAr = "الهند",
            nameEn = "India",
            flag = "🇮🇳",
            continent = Continent.ASIA,
            normX = 0.735f,
            normY = 0.450f,
            power = 58000,
            defense = 62000,
            population = 1420,
            gdpBillion = 3750
        ),
        Country(
            id = "PAK",
            nameAr = "باكستان",
            nameEn = "Pakistan",
            flag = "🇵🇰",
            continent = Continent.ASIA,
            normX = 0.700f,
            normY = 0.410f,
            power = 26000,
            defense = 28000,
            population = 240,
            gdpBillion = 340
        ),
        Country(
            id = "JPN",
            nameAr = "اليابان",
            nameEn = "Japan",
            flag = "🇯🇵",
            continent = Continent.ASIA,
            normX = 0.890f,
            normY = 0.360f,
            power = 34000,
            defense = 38000,
            population = 125,
            gdpBillion = 4200
        ),
        Country(
            id = "KOR",
            nameAr = "كوريا الجنوبية",
            nameEn = "South Korea",
            flag = "🇰🇷",
            continent = Continent.ASIA,
            normX = 0.860f,
            normY = 0.370f,
            power = 28000,
            defense = 30000,
            population = 52,
            gdpBillion = 1700
        ),
        Country(
            id = "IDN",
            nameAr = "إندونيسيا",
            nameEn = "Indonesia",
            flag = "🇮🇩",
            continent = Continent.ASIA,
            normX = 0.830f,
            normY = 0.580f,
            power = 17000,
            defense = 18500,
            population = 277,
            gdpBillion = 1350
        ),
        Country(
            id = "MYS",
            nameAr = "ماليزيا",
            nameEn = "Malaysia",
            flag = "🇲🇾",
            continent = Continent.ASIA,
            normX = 0.805f,
            normY = 0.530f,
            power = 8200,
            defense = 9000,
            population = 34,
            gdpBillion = 410
        ),
        Country(
            id = "THA",
            nameAr = "تايلاند",
            nameEn = "Thailand",
            flag = "🇹🇭",
            continent = Continent.ASIA,
            normX = 0.785f,
            normY = 0.480f,
            power = 9800,
            defense = 10500,
            population = 71,
            gdpBillion = 500
        ),
        Country(
            id = "VNM",
            nameAr = "فيتنام",
            nameEn = "Vietnam",
            flag = "🇻🇳",
            continent = Continent.ASIA,
            normX = 0.805f,
            normY = 0.465f,
            power = 13500,
            defense = 15000,
            population = 99,
            gdpBillion = 430
        ),
        Country(
            id = "KAZ",
            nameAr = "كازاخستان",
            nameEn = "Kazakhstan",
            flag = "🇰🇿",
            continent = Continent.ASIA,
            normX = 0.710f,
            normY = 0.310f,
            power = 7800,
            defense = 8500,
            population = 20,
            gdpBillion = 260
        ),

        // ---------------- EUROPE ----------------
        Country(
            id = "GBR",
            nameAr = "المملكة المتحدة (بريطانيا)",
            nameEn = "United Kingdom",
            flag = "🇬🇧",
            continent = Continent.EUROPE,
            normX = 0.470f,
            normY = 0.240f,
            power = 36000,
            defense = 39000,
            population = 68,
            gdpBillion = 3100
        ),
        Country(
            id = "FRA",
            nameAr = "فرنسا",
            nameEn = "France",
            flag = "🇫🇷",
            continent = Continent.EUROPE,
            normX = 0.490f,
            normY = 0.280f,
            power = 38000,
            defense = 40000,
            population = 68,
            gdpBillion = 3000
        ),
        Country(
            id = "DEU",
            nameAr = "ألمانيا",
            nameEn = "Germany",
            flag = "🇩🇪",
            continent = Continent.EUROPE,
            normX = 0.515f,
            normY = 0.255f,
            power = 35000,
            defense = 37000,
            population = 84,
            gdpBillion = 4450
        ),
        Country(
            id = "ITA",
            nameAr = "إيطاليا",
            nameEn = "Italy",
            flag = "🇮🇹",
            continent = Continent.EUROPE,
            normX = 0.525f,
            normY = 0.310f,
            power = 24000,
            defense = 26000,
            population = 59,
            gdpBillion = 2200
        ),
        Country(
            id = "ESP",
            nameAr = "إسبانيا",
            nameEn = "Spain",
            flag = "🇪🇸",
            continent = Continent.EUROPE,
            normX = 0.465f,
            normY = 0.330f,
            power = 18000,
            defense = 20000,
            population = 48,
            gdpBillion = 1580
        ),
        Country(
            id = "GRC",
            nameAr = "اليونان",
            nameEn = "Greece",
            flag = "🇬🇷",
            continent = Continent.EUROPE,
            normX = 0.560f,
            normY = 0.340f,
            power = 10500,
            defense = 12000,
            population = 11,
            gdpBillion = 240
        ),
        Country(
            id = "POL",
            nameAr = "بولندا",
            nameEn = "Poland",
            flag = "🇵🇱",
            continent = Continent.EUROPE,
            normX = 0.550f,
            normY = 0.250f,
            power = 17500,
            defense = 19000,
            population = 38,
            gdpBillion = 840
        ),
        Country(
            id = "UKR",
            nameAr = "أوكرانيا",
            nameEn = "Ukraine",
            flag = "🇺🇦",
            continent = Continent.EUROPE,
            normX = 0.590f,
            normY = 0.260f,
            power = 16000,
            defense = 18000,
            population = 38,
            gdpBillion = 160
        ),
        Country(
            id = "SWE",
            nameAr = "السويد",
            nameEn = "Sweden",
            flag = "🇸🇪",
            continent = Continent.EUROPE,
            normX = 0.535f,
            normY = 0.180f,
            power = 12500,
            defense = 13500,
            population = 10,
            gdpBillion = 600
        ),
        Country(
            id = "NOR",
            nameAr = "النرويج",
            nameEn = "Norway",
            flag = "🇳🇴",
            continent = Continent.EUROPE,
            normX = 0.510f,
            normY = 0.180f,
            power = 9500,
            defense = 10500,
            population = 5,
            gdpBillion = 550
        ),
        Country(
            id = "NLD",
            nameAr = "هولندا",
            nameEn = "Netherlands",
            flag = "🇳🇱",
            continent = Continent.EUROPE,
            normX = 0.495f,
            normY = 0.245f,
            power = 11000,
            defense = 12000,
            population = 18,
            gdpBillion = 1100
        ),

        // ---------------- NORTH AMERICA ----------------
        Country(
            id = "USA",
            nameAr = "الولايات المتحدة الأمريكية",
            nameEn = "United States",
            flag = "🇺🇸",
            continent = Continent.NORTH_AMERICA,
            normX = 0.240f,
            normY = 0.320f,
            power = 95000,
            defense = 98000,
            population = 335,
            gdpBillion = 27000
        ),
        Country(
            id = "CAN",
            nameAr = "كندا",
            nameEn = "Canada",
            flag = "🇨🇦",
            continent = Continent.NORTH_AMERICA,
            normX = 0.230f,
            normY = 0.200f,
            power = 22000,
            defense = 24000,
            population = 40,
            gdpBillion = 2150
        ),
        Country(
            id = "MEX",
            nameAr = "المكسيك",
            nameEn = "Mexico",
            flag = "🇲🇽",
            continent = Continent.NORTH_AMERICA,
            normX = 0.210f,
            normY = 0.410f,
            power = 14500,
            defense = 16000,
            population = 130,
            gdpBillion = 1800
        ),
        Country(
            id = "CUB",
            nameAr = "كوبا",
            nameEn = "Cuba",
            flag = "🇨🇺",
            continent = Continent.NORTH_AMERICA,
            normX = 0.270f,
            normY = 0.415f,
            power = 4800,
            defense = 5300,
            population = 11,
            gdpBillion = 100
        ),
        Country(
            id = "PAN",
            nameAr = "بنما",
            nameEn = "Panama",
            flag = "🇵🇦",
            continent = Continent.NORTH_AMERICA,
            normX = 0.270f,
            normY = 0.485f,
            power = 2200,
            defense = 2400,
            population = 4,
            gdpBillion = 75
        ),

        // ---------------- SOUTH AMERICA ----------------
        Country(
            id = "BRA",
            nameAr = "البرازيل",
            nameEn = "Brazil",
            flag = "🇧🇷",
            continent = Continent.SOUTH_AMERICA,
            normX = 0.350f,
            normY = 0.630f,
            power = 28000,
            defense = 31000,
            population = 215,
            gdpBillion = 2170
        ),
        Country(
            id = "ARG",
            nameAr = "الأرجنتين",
            nameEn = "Argentina",
            flag = "🇦🇷",
            continent = Continent.SOUTH_AMERICA,
            normX = 0.315f,
            normY = 0.770f,
            power = 12000,
            defense = 13500,
            population = 46,
            gdpBillion = 640
        ),
        Country(
            id = "COL",
            nameAr = "كولومبيا",
            nameEn = "Colombia",
            flag = "🇨🇴",
            continent = Continent.SOUTH_AMERICA,
            normX = 0.280f,
            normY = 0.520f,
            power = 9500,
            defense = 10500,
            population = 52,
            gdpBillion = 360
        ),
        Country(
            id = "CHL",
            nameAr = "تشيلي",
            nameEn = "Chile",
            flag = "🇨🇱",
            continent = Continent.SOUTH_AMERICA,
            normX = 0.290f,
            normY = 0.740f,
            power = 8500,
            defense = 9500,
            population = 19,
            gdpBillion = 330
        ),
        Country(
            id = "VEN",
            nameAr = "فنزويلا",
            nameEn = "Venezuela",
            flag = "🇻🇪",
            continent = Continent.SOUTH_AMERICA,
            normX = 0.300f,
            normY = 0.500f,
            power = 7200,
            defense = 7800,
            population = 29,
            gdpBillion = 100
        ),
        Country(
            id = "PER",
            nameAr = "بيرو",
            nameEn = "Peru",
            flag = "🇵🇪",
            continent = Continent.SOUTH_AMERICA,
            normX = 0.275f,
            normY = 0.600f,
            power = 6500,
            defense = 7000,
            population = 34,
            gdpBillion = 265
        ),

        // ---------------- OCEANIA ----------------
        Country(
            id = "AUS",
            nameAr = "أستراليا",
            nameEn = "Australia",
            flag = "🇦🇺",
            continent = Continent.OCEANIA,
            normX = 0.880f,
            normY = 0.720f,
            power = 24000,
            defense = 27000,
            population = 26,
            gdpBillion = 1700
        ),
        Country(
            id = "NZL",
            nameAr = "نيوزيلندا",
            nameEn = "New Zealand",
            flag = "🇳🇿",
            continent = Continent.OCEANIA,
            normX = 0.950f,
            normY = 0.810f,
            power = 5500,
            defense = 6200,
            population = 5,
            gdpBillion = 250
        )
    )

    fun getDefaultTechItems(): List<com.example.model.TechItem> = listOf(
        // Branch 1: WARFARE (الحرب والتسليح)
        com.example.model.TechItem(
            id = "tech_radar",
            titleAr = "منظومات الرصد والتتبع الراداري 3D",
            descAr = "زيادة مدى كشف القوات الجوية المعادية ورفع كفاءة الدفاع الجوي",
            costResearch = 300,
            costGold = 5000,
            isUnlocked = true,
            iconEmoji = "📡",
            categoryAr = "دفاعات جوية",
            defenseBonusPercent = 15,
            branch = com.example.model.TechBranch.WARFARE,
            tier = 1
        ),
        com.example.model.TechItem(
            id = "tech_armor",
            titleAr = "دروع السيراميك التفاعلية للآليات",
            descAr = "تحصين دبابات الجيش المصري ومدرعاته ضد المقذوفات المضادة للدروع",
            costResearch = 600,
            costGold = 10000,
            isUnlocked = false,
            iconEmoji = "🛡️",
            categoryAr = "قوات برية",
            defenseBonusPercent = 25,
            attackBonusPercent = 10,
            branch = com.example.model.TechBranch.WARFARE,
            tier = 2
        ),
        com.example.model.TechItem(
            id = "tech_drones",
            titleAr = "أسراب الدرونات الانتحارية المسلحة",
            descAr = "تطوير طائرات مسيرة ذكية توجه بالذكاء الاصطناعي لاختراق دفاعات العدو",
            costResearch = 1200,
            costGold = 18000,
            isUnlocked = false,
            iconEmoji = "🛰️",
            categoryAr = "طيران وتكنولوجيا",
            attackBonusPercent = 30,
            branch = com.example.model.TechBranch.WARFARE,
            tier = 3
        ),
        com.example.model.TechItem(
            id = "tech_missiles",
            titleAr = "صواريخ كروز المجنحة فرط الصوتية",
            descAr = "صواريخ دقيقة تضرب في العمق بسرعة تتجاوز 5 أضعاف سرعة الصوت",
            costResearch = 2500,
            costGold = 35000,
            isUnlocked = false,
            iconEmoji = "🚀",
            categoryAr = "سلاح استراتيجي",
            attackBonusPercent = 45,
            branch = com.example.model.TechBranch.WARFARE,
            tier = 4
        ),
        com.example.model.TechItem(
            id = "tech_nuclear",
            titleAr = "مشروع الردع النووي الاستراتيجي (الضبعة)",
            descAr = "تطوير الترسانة النووية الحسمية لفتح الصواريخ النووية العابرة للقارات والسيطرة على العالم",
            costResearch = 12000,
            costGold = 150000,
            isUnlocked = false,
            iconEmoji = "☢️",
            categoryAr = "الردع الشامل",
            attackBonusPercent = 100,
            defenseBonusPercent = 80,
            branch = com.example.model.TechBranch.WARFARE,
            tier = 5
        ),

        // Branch 2: ECONOMY (الاقتصاد والتصنيع)
        com.example.model.TechItem(
            id = "tech_automation",
            titleAr = "أتمتة مجمعات الذخيرة والمصانع الحربية",
            descAr = "زيادة إنتاج الحديد ومصانع السلاح بنسبة 35%",
            costResearch = 800,
            costGold = 12000,
            isUnlocked = false,
            iconEmoji = "⚙️",
            categoryAr = "تصنيع عسكري",
            incomeBonusPercent = 20,
            branch = com.example.model.TechBranch.ECONOMY,
            tier = 1
        ),
        com.example.model.TechItem(
            id = "tech_deep_refining",
            titleAr = "التكرير العميق وحقول الغاز المسال",
            descAr = "مضاعفة ناتج استخراج النفط والغاز لدعم تحركات الجيوش",
            costResearch = 1800,
            costGold = 25000,
            isUnlocked = false,
            iconEmoji = "🛢️",
            categoryAr = "طاقة واستخراج",
            incomeBonusPercent = 35,
            branch = com.example.model.TechBranch.ECONOMY,
            tier = 2
        ),
        com.example.model.TechItem(
            id = "tech_satellite",
            titleAr = "شبكة الأقمار الصناعية الاقتصادية والملاحية",
            descAr = "تأمين تدفق التجارة العالمية عبر قناة السويس ومراقبة خطوط الإمداد",
            costResearch = 3800,
            costGold = 50000,
            isUnlocked = false,
            iconEmoji = "🛰️",
            categoryAr = "فضاء واستخبارات",
            incomeBonusPercent = 50,
            defenseBonusPercent = 20,
            branch = com.example.model.TechBranch.ECONOMY,
            tier = 3
        ),

        // Branch 3: DIPLOMACY (الدبلوماسية والسيادة)
        com.example.model.TechItem(
            id = "tech_electronic_warfare",
            titleAr = "الحرب الإلكترونية والتجسس الاستخباراتي",
            descAr = "شل منظومات اتصالات العدو وكشف خططه التوسعية مبكراً",
            costResearch = 1500,
            costGold = 22000,
            isUnlocked = false,
            iconEmoji = "⚡",
            categoryAr = "حرب سيبرانية",
            attackBonusPercent = 25,
            defenseBonusPercent = 25,
            branch = com.example.model.TechBranch.DIPLOMACY,
            tier = 1
        ),
        com.example.model.TechItem(
            id = "tech_propaganda",
            titleAr = "الإعلام الاستراتيجي والحرب النفسية",
            descAr = "تقليل خطر الثورات والتمرد في الأراضي المحررة بنسبة 50%",
            costResearch = 3000,
            costGold = 45000,
            isUnlocked = false,
            iconEmoji = "📻",
            categoryAr = "حرب نفسية",
            incomeBonusPercent = 15,
            branch = com.example.model.TechBranch.DIPLOMACY,
            tier = 2
        ),
        com.example.model.TechItem(
            id = "tech_hegemony_pact",
            titleAr = "معاهدة الهيمنة المصرية والتحالفات الإمبراطورية",
            descAr = "تخفيض تكاليف المعاهدات ورفع دخل التحالفات الدولية إلى أقصى حد",
            costResearch = 6500,
            costGold = 95000,
            isUnlocked = false,
            iconEmoji = "🌐",
            categoryAr = "سيادة عالمية",
            incomeBonusPercent = 40,
            attackBonusPercent = 35,
            branch = com.example.model.TechBranch.DIPLOMACY,
            tier = 3
        )
    )

    fun getDefaultGenerals(): List<com.example.model.MilitaryGeneral> = listOf(
        com.example.model.MilitaryGeneral(
            id = "gen_armored",
            nameAr = "الفريق أحمد الشاذلي",
            titleAr = "قائد سلاح المدرعات والصاعقة",
            avatarEmoji = "🎖️",
            attackBonusPercent = 30,
            defenseBonusPercent = 15,
            specialtyDescAr = "+30% هجوم للدبابات والمشاة الآلية واقتحام المدن الخاطف",
            costGlory = 500,
            isRecruited = true,
            isAssigned = true
        ),
        com.example.model.MilitaryGeneral(
            id = "gen_air",
            nameAr = "اللواء طيار هشام نصر",
            titleAr = "نسر القوات الجوية والاعتراض",
            avatarEmoji = "🦅",
            attackBonusPercent = 40,
            defenseBonusPercent = 10,
            specialtyDescAr = "+40% قوة للضربات الجوية ومقاتلات السيادة الجوية والمسيرات",
            costGlory = 1200,
            isRecruited = false,
            isAssigned = false
        ),
        com.example.model.MilitaryGeneral(
            id = "gen_naval",
            nameAr = "الأدميرال سيف الدين بحري",
            titleAr = "قائد الأسطول الشمالي والجنوبي",
            avatarEmoji = "⚓",
            attackBonusPercent = 25,
            defenseBonusPercent = 35,
            specialtyDescAr = "+35% حماية سواحل وتدمير الفرقاطات والغواصات المعادية",
            costGlory = 1500,
            isRecruited = false,
            isAssigned = false
        ),
        com.example.model.MilitaryGeneral(
            id = "gen_strategic",
            nameAr = "المشير طارق النمر",
            titleAr = "رئيس هيئة العمليات المشتركة",
            avatarEmoji = "⭐",
            attackBonusPercent = 50,
            defenseBonusPercent = 50,
            specialtyDescAr = "+50% قوة قتالية دفاعية وهجومية شاملة في كافة مسارح الحرب",
            costGlory = 3000,
            isRecruited = false,
            isAssigned = false
        )
    )

    fun getDefaultMinisters(): List<com.example.model.CabinetMinister> = listOf(
        com.example.model.CabinetMinister(
            id = "min_defense",
            nameAr = "وزير الدفاع والإنتاج الحربي",
            portfolioAr = "الدفاع والإنتاج الحربي",
            avatarEmoji = "⚔️",
            level = 1,
            bonusDescriptionAr = "+15% إنتاجية المصانع الحربية وخفض تكاليف التجنيد",
            upgradeCostGold = 35000
        ),
        com.example.model.CabinetMinister(
            id = "min_economy",
            nameAr = "وزير المالية والاقتصاد القومي",
            portfolioAr = "الاقتصاد والاستثمار",
            avatarEmoji = "💰",
            level = 1,
            bonusDescriptionAr = "+20% عائدات قناة السويس والذهب من الأراضي التابعة",
            upgradeCostGold = 40000
        ),
        com.example.model.CabinetMinister(
            id = "min_foreign",
            nameAr = "وزير الشؤون الخارجية والدبلوماسية",
            portfolioAr = "الخارجية والتحالفات",
            avatarEmoji = "🌐",
            level = 1,
            bonusDescriptionAr = "+25% نجاح المعاهدات الدبلوماسية وخفض خطر التمرد",
            upgradeCostGold = 30000
        ),
        com.example.model.CabinetMinister(
            id = "min_industry",
            nameAr = "وزير البترول والثروة المعدنية",
            portfolioAr = "الطاقة والتعدين",
            avatarEmoji = "🛢️",
            level = 1,
            bonusDescriptionAr = "+30% تدفق النفط والغاز والحديد الخام للجيش",
            upgradeCostGold = 45000
        )
    )

    fun getDefaultCampaignStages(): List<com.example.model.CampaignStage> {
        val stages = mutableListOf<com.example.model.CampaignStage>()
        
        // Stages 1-10: Nile Valley & Arabian Peninsula
        val s1Targets = listOf("SDN")
        stages.add(
            com.example.model.CampaignStage(
                id = 1,
                titleAr = "المرحلة 1: تأمين العمق الجنوبي (السودان)",
                descAr = "ضم السودان الشقيق وتأمين شريان الحياة لنهر النيل",
                continent = Continent.AFRICA,
                targetCountryIds = s1Targets,
                rewardGold = 10000,
                rewardResearch = 200,
                isUnlocked = true
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 2,
                titleAr = "المرحلة 2: تأمين البوابة الغربية (ليبيا)",
                descAr = "بسط الاستقرار على الحدود الغربية الغنية بالنفط",
                continent = Continent.AFRICA,
                targetCountryIds = listOf("LBY"),
                rewardGold = 15000,
                rewardResearch = 300
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 3,
                titleAr = "المرحلة 3: منابع النيل العظيم (إثيوبيا)",
                descAr = "فرض السيادة الكاملة على مصادر مياه النيل الخالدة",
                continent = Continent.AFRICA,
                targetCountryIds = listOf("ETH"),
                rewardGold = 20000,
                rewardResearch = 400
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 4,
                titleAr = "المرحلة 4: شبه الجزيرة والخليج (الأردن وسوريا)",
                descAr = "توحيد بلاد الشام وتأمين الجناح الشرقي للوطن",
                continent = Continent.ASIA,
                targetCountryIds = listOf("JOR", "SYR"),
                rewardGold = 25000,
                rewardResearch = 500
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 5,
                titleAr = "المرحلة 5: قلب الجزيرة العربية (السعودية)",
                descAr = "التحالف أو السيطرة على أكبر قوة اقتصادية ونفطية في المنطقة",
                continent = Continent.ASIA,
                targetCountryIds = listOf("SAU"),
                rewardGold = 40000,
                rewardResearch = 700
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 6,
                titleAr = "المرحلة 6: مضيق باب المندب وهرمز (اليمن وعمان والإمارات)",
                descAr = "السيطرة التامة على أهم المضائق البحرية وطرق التجارة العالمية",
                continent = Continent.ASIA,
                targetCountryIds = listOf("YEM", "OMN", "ARE"),
                rewardGold = 50000,
                rewardResearch = 900
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 7,
                titleAr = "المرحلة 7: بلاد الرافدين والخليج (العراق)",
                descAr = "استعادة أمجاد الحضارات وضم بلاد الرافدين للتاج المصري",
                continent = Continent.ASIA,
                targetCountryIds = listOf("IRQ"),
                rewardGold = 45000,
                rewardResearch = 850
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 8,
                titleAr = "المرحلة 8: حوض شمال أفريقيا (تونس والجزائر)",
                descAr = "ضم المغرب العربي وتوحيد طاقات شمال أفريقيا",
                continent = Continent.AFRICA,
                targetCountryIds = listOf("TUN", "DZA"),
                rewardGold = 60000,
                rewardResearch = 1000
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 9,
                titleAr = "المرحلة 9: أقصى المغرب والمحيط (المغرب والسنغال)",
                descAr = "الوصول للمحيط الأطلسي وتأمين مضيق جبل طارق",
                continent = Continent.AFRICA,
                targetCountryIds = listOf("MAR", "SEN"),
                rewardGold = 65000,
                rewardResearch = 1100
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 10,
                titleAr = "المرحلة 10: حوض الأناضول وفارس (تركيا وإيران)",
                descAr = "كسر القوى الإقليمية الكبرى وتأمين آسيا الصغرى",
                continent = Continent.ASIA,
                targetCountryIds = listOf("TUR", "IRN"),
                rewardGold = 85000,
                rewardResearch = 1500
            )
        )

        // Stages 11-20: Mediterranean & Central Europe
        stages.add(
            com.example.model.CampaignStage(
                id = 11,
                titleAr = "المرحلة 11: جزر وبحر إيجه (اليونان)",
                descAr = "تحويل البحر الأبيض المتوسط إلى بحيرة مصرية خالصة",
                continent = Continent.EUROPE,
                targetCountryIds = listOf("GRC"),
                rewardGold = 70000,
                rewardResearch = 1200
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 12,
                titleAr = "المرحلة 12: شبه الجزيرة الإيطالية (إيطاليا)",
                descAr = "استعادة العظمة التاريخية والسيطرة على روما والجنوب الأوروبي",
                continent = Continent.EUROPE,
                targetCountryIds = listOf("ITA"),
                rewardGold = 90000,
                rewardResearch = 1600
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 13,
                titleAr = "المرحلة 13: الأندلس وشبه جزيرة أيبيريا (إسبانيا)",
                descAr = "العبور إلى إسبانيا وتأمين البوابة الأوروبية الجنوبية",
                continent = Continent.EUROPE,
                targetCountryIds = listOf("ESP"),
                rewardGold = 95000,
                rewardResearch = 1700
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 14,
                titleAr = "المرحلة 14: غرب أفريقيا والعمق الاستوائي (نيجيريا وغانا)",
                descAr = "تسخير الموارد البشرية والاقتصادية الهائلة لغرب أفريقيا",
                continent = Continent.AFRICA,
                targetCountryIds = listOf("NGA", "GHA"),
                rewardGold = 80000,
                rewardResearch = 1400
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 15,
                titleAr = "المرحلة 15: قلب القارة السمراء (الكونغو وتشاد)",
                descAr = "السيطرة على أكبر احتياطيات المعادن النادرة في إفريقيا",
                continent = Continent.AFRICA,
                targetCountryIds = listOf("COD", "TCD"),
                rewardGold = 75000,
                rewardResearch = 1300
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 16,
                titleAr = "المرحلة 16: شرق وجنوب أفريقيا (كينيا وتنزانيا وأنغولا)",
                descAr = "السيطرة على السواحل الشرقية للمحيط الهندي",
                continent = Continent.AFRICA,
                targetCountryIds = listOf("KEN", "TZA", "AGO"),
                rewardGold = 90000,
                rewardResearch = 1500
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 17,
                titleAr = "المرحلة 17: رأس الرجاء الصالح (جنوب أفريقيا)",
                descAr = "اكتمال السيادة المصرية على قارة أفريقيا بالكامل!",
                continent = Continent.AFRICA,
                targetCountryIds = listOf("ZAF"),
                rewardGold = 120000,
                rewardResearch = 2000
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 18,
                titleAr = "المرحلة 18: أوروبا الشرقية (أوكرانيا وبولندا)",
                descAr = "فتح السهول الزراعية الخصبة ومراكز الصناعة الأوروبية",
                continent = Continent.EUROPE,
                targetCountryIds = listOf("UKR", "POL"),
                rewardGold = 100000,
                rewardResearch = 1800
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 19,
                titleAr = "المرحلة 19: محرك أوروبا الصناعي (ألمانيا)",
                descAr = "إخضاع أكبر قوة صناعية واقتصادية في القارة العجوز",
                continent = Continent.EUROPE,
                targetCountryIds = listOf("DEU"),
                rewardGold = 140000,
                rewardResearch = 2200
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 20,
                titleAr = "المرحلة 20: الإمبراطورية الفرانكفونية (فرنسا)",
                descAr = "دخول باريس وكسر القوة النووية والدفاعية الفرنسية",
                continent = Continent.EUROPE,
                targetCountryIds = listOf("FRA"),
                rewardGold = 150000,
                rewardResearch = 2400
            )
        )

        // Stages 21-30: Western Europe, Scandinavia & Central Asia
        stages.add(
            com.example.model.CampaignStage(
                id = 21,
                titleAr = "المرحلة 21: الجزر البريطانية (المملكة المتحدة)",
                descAr = "إنزال بحري وجوي تاريخي على الأراضي البريطانية",
                continent = Continent.EUROPE,
                targetCountryIds = listOf("GBR"),
                rewardGold = 160000,
                rewardResearch = 2500
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 22,
                titleAr = "المرحلة 22: دول الشمال الإسكندنافية (السويد والنرويج وهولندا)",
                descAr = "السيطرة التامة على قارة أوروبا بالكامل!",
                continent = Continent.EUROPE,
                targetCountryIds = listOf("SWE", "NOR", "NLD"),
                rewardGold = 170000,
                rewardResearch = 2600
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 23,
                titleAr = "المرحلة 23: آسيا الوسطى وسهوب القوقاز (كازاخستان)",
                descAr = "تأمين موارد اليورانيوم الهائلة ومحطات الفضاء",
                continent = Continent.ASIA,
                targetCountryIds = listOf("KAZ"),
                rewardGold = 110000,
                rewardResearch = 2000
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 24,
                titleAr = "المرحلة 24: شبه القارة الهندية (باكستان)",
                descAr = "تطويق القوة النووية في جنوب آسيا",
                continent = Continent.ASIA,
                targetCountryIds = listOf("PAK"),
                rewardGold = 130000,
                rewardResearch = 2200
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 25,
                titleAr = "المرحلة 25: العملاق الملياري (الهند)",
                descAr = "معركة حاسمة لإخضاع ثاني أكبر كتلة سكانية وعسكرية في العالم",
                continent = Continent.ASIA,
                targetCountryIds = listOf("IND"),
                rewardGold = 200000,
                rewardResearch = 3000
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 26,
                titleAr = "المرحلة 26: جنوب شرق آسيا (تايلاند وفيتنام)",
                descAr = "السيطرة على مضايق المحيط الهادي وشبه جزيرة الهند الصينية",
                continent = Continent.ASIA,
                targetCountryIds = listOf("THA", "VNM"),
                rewardGold = 140000,
                rewardResearch = 2400
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 27,
                titleAr = "المرحلة 27: أرخبيل البحار (ماليزيا وإندونيسيا)",
                descAr = "السيطرة على ممر ملقا الملاحي وأكبر دولة جزرية في العالم",
                continent = Continent.ASIA,
                targetCountryIds = listOf("MYS", "IDN"),
                rewardGold = 160000,
                rewardResearch = 2600
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 28,
                titleAr = "المرحلة 28: نمور آسيا التكنولوجية (كوريا الجنوبية)",
                descAr = "الاستيلاء على مجمعات الرقائق الإلكترونية والتقنيات الفائقة",
                continent = Continent.ASIA,
                targetCountryIds = listOf("KOR"),
                rewardGold = 180000,
                rewardResearch = 3000
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 29,
                titleAr = "المرحلة 29: إمبراطورية الشمس المشرقة (اليابان)",
                descAr = "إنزال برمائي حاسم على جزر اليابان وإخضاع تقنياتها العسكرية",
                continent = Continent.ASIA,
                targetCountryIds = listOf("JPN"),
                rewardGold = 220000,
                rewardResearch = 3500
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 30,
                titleAr = "المرحلة 30: قارة أستراليا وأوقيانوسيا (أستراليا ونيوزيلندا)",
                descAr = "ضم قارة أوقيانوسيا بأكملها تحت الراية المصرية",
                continent = Continent.OCEANIA,
                targetCountryIds = listOf("AUS", "NZL"),
                rewardGold = 200000,
                rewardResearch = 3200
            )
        )

        // Stages 31-40: Superpowers & The Americas (Global Domination!)
        stages.add(
            com.example.model.CampaignStage(
                id = 31,
                titleAr = "المرحلة 31: الدب الروسي وسيبيريا (روسيا الاتحادية)",
                descAr = "الملحمة الكبرى في شتاء روسيا وإخضاع أكبر ترسانة نووية برية",
                continent = Continent.ASIA,
                targetCountryIds = listOf("RUS"),
                rewardGold = 300000,
                rewardResearch = 5000
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 32,
                titleAr = "المرحلة 32: التنين الآسيوي الصيني (الصين العظمى)",
                descAr = "أضخم معركة برية وبحرية في تاريخ البشرية ضد العملاق الصيني",
                continent = Continent.ASIA,
                targetCountryIds = listOf("CHN"),
                rewardGold = 350000,
                rewardResearch = 6000
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 33,
                titleAr = "المرحلة 33: ممر بنما الكاريبي (بنما وكوبا)",
                descAr = "الوصول لقارتي أمريكا والسيطرة على قناة بنما",
                continent = Continent.NORTH_AMERICA,
                targetCountryIds = listOf("PAN", "CUB"),
                rewardGold = 180000,
                rewardResearch = 2800
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 34,
                titleAr = "المرحلة 34: الأنديز والنفط الفنزويلي (كولومبيا وفنزويلا)",
                descAr = "ضم أكبر احتياطيات نفطية في أمريكا اللاتينية",
                continent = Continent.SOUTH_AMERICA,
                targetCountryIds = listOf("COL", "VEN"),
                rewardGold = 220000,
                rewardResearch = 3200
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 35,
                titleAr = "المرحلة 35: حضارات الإنكا والأمازون (بيرو وتشيلي)",
                descAr = "السيطرة على مناجم النحاس وسلسلة جبال الأنديز الشاهقة",
                continent = Continent.SOUTH_AMERICA,
                targetCountryIds = listOf("PER", "CHL"),
                rewardGold = 230000,
                rewardResearch = 3400
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 36,
                titleAr = "المرحلة 36: أرض التانغو والفضة (الأرجنتين)",
                descAr = "الوصول إلى أقصى نقطة في جنوب القارة الأمريكية",
                continent = Continent.SOUTH_AMERICA,
                targetCountryIds = listOf("ARG"),
                rewardGold = 250000,
                rewardResearch = 3600
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 37,
                titleAr = "المرحلة 37: عملاق أمريكا الجنوبية (البرازيل)",
                descAr = "اكتمال السيطرة على قارة أمريكا الجنوبية بأكملها!",
                continent = Continent.SOUTH_AMERICA,
                targetCountryIds = listOf("BRA"),
                rewardGold = 300000,
                rewardResearch = 4500
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 38,
                titleAr = "المرحلة 38: بلاد الأزتيك والحدود الشمالية (المكسيك)",
                descAr = "التمركز العسكري على حدود القوة العظمى الأخيرة",
                continent = Continent.NORTH_AMERICA,
                targetCountryIds = listOf("MEX"),
                rewardGold = 280000,
                rewardResearch = 4000
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 39,
                titleAr = "المرحلة 39: القطب الشمالي وأراضي التندرا (كندا)",
                descAr = "تطويق الولايات المتحدة من الشمال وتأمين الممرات الجليدية",
                continent = Continent.NORTH_AMERICA,
                targetCountryIds = listOf("CAN"),
                rewardGold = 320000,
                rewardResearch = 4800
            )
        )
        stages.add(
            com.example.model.CampaignStage(
                id = 40,
                titleAr = "المرحلة 40: معركة السيادة العالمية الكبرى (الولايات المتحدة)",
                descAr = "المعركة النهائية الحاسمة: إسقاط البنتاجون ورفع العلم المصري فوق واشنطن لإعلان السيادة المصرية على كوكب الأرض!",
                continent = Continent.NORTH_AMERICA,
                targetCountryIds = listOf("USA"),
                rewardGold = 1000000,
                rewardResearch = 20000
            )
        )

        return stages
    }

    fun getDefaultDailyMissions(): List<com.example.model.DailyMission> = listOf(
        com.example.model.DailyMission(
            id = "mission_conquer_3",
            titleAr = "احتلال 3 دول اليوم",
            descAr = "إخضاع 3 دول جديدة وضمها تحت لواء السيادة المصرية",
            iconEmoji = "🌍",
            targetCount = 3,
            currentCount = 0,
            rewardGold = 50000L,
            rewardGlory = 300L,
            rewardTechPoints = 800L
        ),
        com.example.model.DailyMission(
            id = "mission_battles_5",
            titleAr = "خوض 5 معارك تكتيكية مظفرة",
            descAr = "إلحاق الهزيمة بقوات العدو دون التراجع في مسارح العمليات",
            iconEmoji = "⚔️",
            targetCount = 5,
            currentCount = 0,
            rewardGold = 35000L,
            rewardGlory = 250L,
            rewardTechPoints = 500L
        ),
        com.example.model.DailyMission(
            id = "mission_research_tech",
            titleAr = "تطوير بحث علمي استراتيجي",
            descAr = "ترقية شجرة الأبحاث لتعزيز الترسانة النووية أو الاقتصاد",
            iconEmoji = "🔬",
            targetCount = 1,
            currentCount = 0,
            rewardGold = 25000L,
            rewardGlory = 150L,
            rewardTechPoints = 1200L
        ),
        com.example.model.DailyMission(
            id = "mission_deploy_troops",
            titleAr = "حشد 10 كتائب قتالية",
            descAr = "تجنيد ونشر تشكيلات عسكرية على خريطة العالم الاستراتيجية",
            iconEmoji = "🪖",
            targetCount = 10,
            currentCount = 0,
            rewardGold = 30000L,
            rewardGlory = 200L,
            rewardTechPoints = 400L
        )
    )

    fun getDefaultCustomizationSkins(): List<com.example.model.UnitSkin> = listOf(
        com.example.model.UnitSkin(
            id = "skin_tank_pharaoh",
            unitTypeId = "tanks",
            nameAr = "درع رمسيس الذهبي (Abrams M1A2)",
            descAr = "طلاء مموه ذهبي وأسود مع دروع سيراميكية ثقيلة وشعار النسر الملكي المصري",
            rarity = com.example.model.SkinRarity.LEGENDARY,
            bonusAttackPercent = 20,
            bonusDefensePercent = 15,
            previewEmoji = "🛡️",
            costGold = 100000L,
            isUnlocked = true,
            isEquipped = true
        ),
        com.example.model.UnitSkin(
            id = "skin_fighter_horus",
            unitTypeId = "fighter_jets",
            nameAr = "صقر حورس الليلي (Rafale F4)",
            descAr = "طلاء شبحي ممتص للرادارات مع أجنحة مرصعة بتمويه الصحراء المصرية المقاتلة",
            rarity = com.example.model.SkinRarity.EPIC,
            bonusAttackPercent = 25,
            bonusDefensePercent = 10,
            previewEmoji = "🦅",
            costGold = 150000L,
            isUnlocked = false,
            isEquipped = false
        ),
        com.example.model.UnitSkin(
            id = "skin_infantry_saeka",
            unitTypeId = "infantry",
            nameAr = "زي قوات الصاعقة 777 القتالية",
            descAr = "خوذات تكتيكية مدعمة بأنظمة رؤية ليلية وبنادق هجومية عيار ثقيل بتمويه قتالي",
            rarity = com.example.model.SkinRarity.RARE,
            bonusAttackPercent = 15,
            bonusDefensePercent = 15,
            previewEmoji = "🎖️",
            costGold = 60000L,
            isUnlocked = true,
            isEquipped = true
        ),
        com.example.model.UnitSkin(
            id = "skin_missile_anubis",
            unitTypeId = "hypersonic_missiles",
            nameAr = "رعد أنوبيس الفرط-صوتي (Hypersonic)",
            descAr = "رؤوس حربية مزدوجة ومحركات نفاثة تنير سماء المعركة بخطوط لهب مضيئة",
            rarity = com.example.model.SkinRarity.LEGENDARY,
            bonusAttackPercent = 35,
            bonusDefensePercent = 5,
            previewEmoji = "🚀",
            costGold = 250000L,
            isUnlocked = false,
            isEquipped = false
        )
    )
}

