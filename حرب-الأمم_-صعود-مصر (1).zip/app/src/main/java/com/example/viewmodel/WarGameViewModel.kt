package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundEffectsManager
import com.example.data.WorldNationsData
import com.example.model.CampaignStage
import com.example.model.CombatLog
import com.example.model.CombatLogType
import com.example.model.Continent
import com.example.model.ContinentalWarStatus
import com.example.model.Country
import com.example.model.CountryStatus
import com.example.model.GameResources
import com.example.model.InfrastructureType
import com.example.model.MilitaryUnitType
import com.example.model.MovingUnit
import com.example.model.MapExplosion
import com.example.model.PlacedMapUnit
import com.example.model.TapDamageEffect
import com.example.model.CombatLaserBeam
import com.example.model.ConquestWave
import com.example.model.CraterMark
import com.example.model.CabinetMinister
import com.example.model.GameStateMode
import com.example.model.MilitaryGeneral
import com.example.model.TacticalBattlePayload
import com.example.model.TechBranch
import com.example.model.TechItem
import com.example.model.WorldEvent
import com.example.model.DailyMission
import com.example.model.DailyStreak
import com.example.model.MilitaryRankTier
import com.example.model.PlayerRankInfo
import com.example.model.UnitSkin
import com.example.model.GameSettings
import com.example.model.GraphicsQuality
import com.example.state.SaveSystem
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

enum class GameTab(val titleAr: String, val icon: String) {
    WORLD_MAP("الخريطة", "🗺️"),
    MILITARY("الجيش", "⚔️"),
    ACADEMY("الأكاديمية", "🎖️"),
    CABINET("الحكومة", "🏛️"),
    INFRASTRUCTURE("البناء", "🏭"),
    RESEARCH("الأبحاث", "🔬"),
    CAMPAIGN("المراحل", "📜"),
    MARKET("السوق", "⚖️")
}

data class BattleState(
    val country: Country,
    val isAirStrike: Boolean = false,
    val isNuclear: Boolean = false,
    val playerCurrentPower: Long,
    val enemyCurrentPower: Long,
    val playerInitialPower: Long,
    val enemyInitialPower: Long,
    val round: Int = 1,
    val isFinished: Boolean = false,
    val isVictory: Boolean = false,
    val summaryTextAr: String = ""
)

data class WarGameUiState(
    val gameStateMode: GameStateMode = GameStateMode.WORLD_MAP,
    val currentTab: GameTab = GameTab.WORLD_MAP,
    val resources: GameResources = GameResources(),
    val countries: List<Country> = emptyList(),
    val selectedCountry: Country? = null,
    val militaryUnits: Map<MilitaryUnitType, Int> = emptyMap(),
    val infrastructureLevels: Map<String, Int> = emptyMap(),
    val techItems: List<TechItem> = emptyList(),
    val campaignStages: List<CampaignStage> = emptyList(),
    val combatLogs: List<CombatLog> = emptyList(),
    val activeBattle: BattleState? = null,
    val gameSpeed: Float = 1.0f,
    val isMuted: Boolean = false,
    val isPaused: Boolean = false,
    val showGrandVictoryDialog: Boolean = false,
    val notificationMessage: String? = null,
    val movingUnits: List<MovingUnit> = emptyList(),
    val activeExplosions: List<MapExplosion> = emptyList(),
    val activeTapDamages: List<TapDamageEffect> = emptyList(),
    val combatLaserBeams: List<CombatLaserBeam> = emptyList(),
    val conquestWaves: List<ConquestWave> = emptyList(),
    val craterMarks: List<CraterMark> = emptyList(),
    val screenShake: Float = 0f,
    val screenFlashAlpha: Float = 0f,
    val isSlowMotionActive: Boolean = false,
    val mushroomCloudLocation: Offset? = null,
    val consecutiveTaps: Int = 0,
    val selectedUnitForDeployment: MilitaryUnitType = MilitaryUnitType.TANKS,
    val targetCountryCurrentHp: Long = 0L,
    val targetCountryMaxHp: Long = 0L,
    val isRtsCombatActive: Boolean = false,
    val placedUnits: List<PlacedMapUnit> = emptyList(),
    val activeWorldEvent: WorldEvent? = null,
    val gloryPoints: Long = 0L,
    val continentalWarStatuses: List<ContinentalWarStatus> = emptyList(),
    val globalCoalitionAgainstPlayer: Boolean = false,
    val isRecruitingOnTerritory: Boolean = false,
    val generals: List<MilitaryGeneral> = emptyList(),
    val ministers: List<CabinetMinister> = emptyList(),
    val activeSaveSlot: Int = 0,
    // Legend Mode: Cinematic, Missions, Rank, Customization & Settings
    val dailyMissions: List<DailyMission> = emptyList(),
    val dailyStreak: DailyStreak = DailyStreak(),
    val playerRank: PlayerRankInfo = PlayerRankInfo(),
    val currentRankTier: MilitaryRankTier = MilitaryRankTier.GOLD,
    val unitSkins: List<UnitSkin> = emptyList(),
    val gameSettings: GameSettings = GameSettings(),
    val isCinematicActive: Boolean = true,
    val conquestSlowMoCountry: Country? = null,
    val isNightVisionActive: Boolean = false,
    val victoryCinematicCountry: Country? = null
)

class WarGameViewModel(application: Application) : AndroidViewModel(application) {

    private val saveSystem = SaveSystem(application)
    val soundManager = SoundEffectsManager(application)

    private val _uiState = MutableStateFlow(WarGameUiState())
    val uiState: StateFlow<WarGameUiState> = _uiState.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    init {
        loadInitialState()
        startGameTicker()
        startFastAnimationTicker()
    }

    private fun loadInitialState() {
        val slot = _uiState.value.activeSaveSlot
        val loadedResources = saveSystem.loadResources(slot) ?: GameResources()
        val loadedMilitary = saveSystem.loadMilitary(slot)
        val loadedInfra = saveSystem.loadInfrastructure(slot)
        val loadedTechIds = saveSystem.loadUnlockedTech(slot)
        val loadedCountryStatuses = saveSystem.loadCountryStatuses(slot)
        val loadedCompletedStages = saveSystem.loadCompletedStages(slot)
        val loadedGenerals = saveSystem.loadRecruitedGenerals(slot)
        val loadedMinisterLevels = saveSystem.loadMinisterLevels(slot)
        val loadedGlory = saveSystem.loadGlory(slot)

        // Base countries updated with loaded statuses
        val baseCountries = WorldNationsData.getDefaultCountries().map { c ->
            if (loadedCountryStatuses.containsKey(c.id)) {
                c.copy(status = loadedCountryStatuses[c.id] ?: c.status)
            } else {
                c
            }
        }

        // Tech items
        val baseTech = WorldNationsData.getDefaultTechItems().map { t ->
            t.copy(isUnlocked = loadedTechIds.contains(t.id))
        }

        // Generals
        val baseGenerals = WorldNationsData.getDefaultGenerals().map { g ->
            if (loadedGenerals.contains(g.id)) g.copy(isRecruited = true) else g
        }

        // Ministers
        val baseMinisters = WorldNationsData.getDefaultMinisters().map { m ->
            val lvl = loadedMinisterLevels[m.id] ?: m.level
            m.copy(level = lvl)
        }

        // Campaign stages
        val baseStages = WorldNationsData.getDefaultCampaignStages().map { stage ->
            val isDone = loadedCompletedStages.contains(stage.id)
            val isUnlock = stage.id == 1 || loadedCompletedStages.contains(stage.id - 1)
            stage.copy(isCompleted = isDone, isUnlocked = isUnlock)
        }

        val initialLogs = listOf(
            CombatLog(
                timestampFormatted = timeFormat.format(Date()),
                messageAr = "تم تفعيل مركز القيادة والعمليات العسكرية المصرية. مستعدون للسيادة العالمية!",
                type = CombatLogType.ALLIANCE
            )
        )

        // Initialize starter stationed units on Egypt map
        val starterPlacedUnits = listOf(
            PlacedMapUnit(countryId = "egypt", unitType = MilitaryUnitType.INFANTRY, isEgyptian = true, offsetX = -0.012f, offsetY = -0.010f),
            PlacedMapUnit(countryId = "egypt", unitType = MilitaryUnitType.TANKS, isEgyptian = true, offsetX = 0.012f, offsetY = -0.008f),
            PlacedMapUnit(countryId = "egypt", unitType = MilitaryUnitType.FIGHTER_JET, isEgyptian = true, offsetX = 0f, offsetY = 0.012f)
        )

        // Initialize continental war statuses
        val initialContinentalStatuses = Continent.values().map { cont ->
            val countriesInCont = baseCountries.filter { it.continent == cont }
            val leader = countriesInCont.maxByOrNull { it.power }?.id ?: countriesInCont.firstOrNull()?.id ?: ""
            ContinentalWarStatus(
                continent = cont,
                leaderCountryId = leader,
                totalTerritories = countriesInCont.size,
                playerConqueredCount = countriesInCont.count { it.isEgypt || it.status == CountryStatus.CONQUERED }
            )
        }

        // Legend Mode: Missions, Streak, Rank, Skins
        val defaultMissions = WorldNationsData.getDefaultDailyMissions()
        val defaultSkins = WorldNationsData.getDefaultCustomizationSkins()
        val loadedRankPoints = saveSystem.loadRankPoints()
        val streakDay = saveSystem.loadStreakDay().coerceIn(1, 7)
        val streakDate = saveSystem.loadStreakLastDate()
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val hasClaimedToday = streakDate == todayStr

        val calculatedRankTier = MilitaryRankTier.values()
            .sortedByDescending { it.minPoints }
            .firstOrNull { loadedRankPoints >= it.minPoints } ?: MilitaryRankTier.BRONZE

        _uiState.update {
            it.copy(
                resources = loadedResources,
                countries = baseCountries,
                militaryUnits = loadedMilitary,
                infrastructureLevels = loadedInfra,
                techItems = baseTech,
                campaignStages = baseStages,
                combatLogs = initialLogs,
                placedUnits = starterPlacedUnits,
                continentalWarStatuses = initialContinentalStatuses,
                generals = baseGenerals,
                ministers = baseMinisters,
                gloryPoints = if (loadedGlory > 0L) loadedGlory else it.gloryPoints,
                dailyMissions = defaultMissions,
                dailyStreak = DailyStreak(currentDay = streakDay, lastLoginDate = streakDate, hasClaimedToday = hasClaimedToday),
                playerRank = PlayerRankInfo(rankPoints = loadedRankPoints),
                currentRankTier = calculatedRankTier,
                unitSkins = defaultSkins
            )
        }
    }

    private fun startGameTicker() {
        viewModelScope.launch {
            var tickCount = 0
            while (true) {
                val delayMs = when {
                    _uiState.value.isPaused -> 1000L
                    _uiState.value.gameSpeed == 2.0f -> 500L
                    else -> 1000L
                }
                delay(delayMs)

                if (!_uiState.value.isPaused) {
                    tickCount++
                    processResourceGeneration()

                    // Every 12 ticks (~12 seconds), trigger AI events & Continental wars
                    if (tickCount % 12 == 0) {
                        processAiWarSkirmishes()
                        checkContinentalAlliancesAndWars()
                    }

                    // Every 20 ticks (~20 seconds), roll for dynamic World Events
                    if (tickCount % 20 == 0) {
                        triggerRandomWorldEvent()
                    }

                    // Every 15 ticks (~15 seconds), check rebellion risk in conquered lands
                    if (tickCount % 15 == 0) {
                        processRebellionCheck()
                    }

                    // Auto-save every 30 seconds
                    if (tickCount % 30 == 0) {
                        autoSave()
                    }
                }
            }
        }
    }

    private fun processResourceGeneration() {
        val current = _uiState.value
        val infra = current.infrastructureLevels
        val conqueredCount = current.countries.count { it.status == CountryStatus.CONQUERED }

        // Tech bonuses
        var incomeBonus = 0
        current.techItems.filter { it.isUnlocked }.forEach {
            incomeBonus += it.incomeBonusPercent
        }

        // Base superpower income per second
        var goldInc = 1500L + (conqueredCount * 300L)
        var oilInc = 500L + (conqueredCount * 120L)
        var ironInc = 600L + (conqueredCount * 150L)
        var foodInc = 700L + (conqueredCount * 160L)
        var manpowerInc = 500L + (conqueredCount * 120L)
        var researchInc = 150L + (conqueredCount * 40L)

        // Infrastructure bonuses
        val factoryLvl = infra[InfrastructureType.WEAPONS_FACTORY.id] ?: 0
        ironInc += factoryLvl * 50L

        val canalLvl = infra[InfrastructureType.SUEZ_CANAL.id] ?: 0
        goldInc += canalLvl * 250L

        val pyramidsLvl = infra[InfrastructureType.TOURISM_PYRAMIDS.id] ?: 0
        goldInc += pyramidsLvl * 180L

        val toshkaLvl = infra[InfrastructureType.AGRICULTURE_TOSHKA.id] ?: 0
        foodInc += toshkaLvl * 80L
        manpowerInc += toshkaLvl * 30L

        val oilRigsLvl = infra[InfrastructureType.OIL_RIGS.id] ?: 0
        oilInc += oilRigsLvl * 120L

        val portLvl = infra[InfrastructureType.NAVAL_PORT.id] ?: 0
        goldInc += portLvl * 100L

        // Apply tech and minister multipliers
        val economyMinister = current.ministers.find { it.id == "min_economy" }
        val industryMinister = current.ministers.find { it.id == "min_industry" }

        val ecoLevel = economyMinister?.level ?: 1
        val indLevel = industryMinister?.level ?: 1

        goldInc = (goldInc * (100 + incomeBonus + (ecoLevel - 1) * 15)) / 100
        oilInc = (oilInc * (100 + (indLevel - 1) * 20)) / 100
        ironInc = (ironInc * (100 + (indLevel - 1) * 20)) / 100

        _uiState.update { state ->
            val res = state.resources
            state.copy(
                resources = res.copy(
                    gold = res.gold + goldInc,
                    oil = res.oil + oilInc,
                    iron = res.iron + ironInc,
                    food = res.food + foodInc,
                    manpower = res.manpower + manpowerInc,
                    researchPoints = res.researchPoints + researchInc
                )
            )
        }
    }

    private fun processAiWarSkirmishes() {
        val nonPlayerCountries = _uiState.value.countries.filter {
            it.status == CountryStatus.NEUTRAL || it.status == CountryStatus.HOSTILE
        }
        if (nonPlayerCountries.size < 2) return

        // Pick two random AI nations to simulate global tension
        val attacker = nonPlayerCountries.random()
        val defender = nonPlayerCountries.filter { it.id != attacker.id }.randomOrNull() ?: return

        val outcomes = listOf(
            "اشتباكات حدودية وقصف مدفعي بين ${attacker.nameAr} و${defender.nameAr}.",
            "مناوشات عسكرية بحرية بين أساطيل ${attacker.nameAr} و${defender.nameAr}.",
            "${attacker.nameAr} تفرض عقوبات اقتصادية وتعلن حالة التأهب القصوى ضد ${defender.nameAr}.",
            "معركة جوية خاطفة بين مقاتلات ${attacker.nameAr} ودفاعات ${defender.nameAr}."
        )

        addCombatLog(
            message = outcomes.random(),
            type = CombatLogType.ENEMY_WAR
        )
    }

    private fun startFastAnimationTicker() {
        viewModelScope.launch {
            while (true) {
                delay(40L) // ~25 FPS visual simulation loop
                if (!_uiState.value.isPaused) {
                    updateVisualUnitsAndFx()
                }
            }
        }
    }

    private fun updateVisualUnitsAndFx() {
        val current = _uiState.value
        val speedMultiplier = if (current.isSlowMotionActive) current.gameSpeed * 0.3f else current.gameSpeed

        // Update Moving Units
        val survivingUnits = mutableListOf<MovingUnit>()
        val newExplosions = current.activeExplosions.toMutableList()
        val newLasers = current.combatLaserBeams.toMutableList()
        val newCraters = current.craterMarks.toMutableList()
        var triggeredFlash = current.screenFlashAlpha

        current.movingUnits.forEach { unit ->
            val nextProg = unit.progress + (unit.speed * speedMultiplier)
            if (nextProg >= 1.0f) {
                // Unit arrived at destination!
                val targetCountry = current.countries.find { it.id == unit.targetCountryId }
                targetCountry?.let { target ->
                    soundManager.playArtilleryFire()
                    val isNuke = unit.unitType == MilitaryUnitType.NUCLEAR_ICBM
                    newExplosions.add(
                        MapExplosion(
                            x = target.normX,
                            y = target.normY,
                            isNuke = isNuke,
                            debrisCount = if (isNuke) 24 else 12,
                            shockwaveMaxRadius = if (isNuke) 120f else 60f
                        )
                    )

                    // Generate dynamic impact crater on battlefield terrain
                    newCraters.add(
                        CraterMark(
                            x = target.normX,
                            y = target.normY,
                            isNuclear = isNuke,
                            alpha = 0.95f
                        )
                    )

                    if (isNuke) {
                        triggeredFlash = 0.85f
                        soundManager.playExplosion()
                    }

                    // Deal direct damage
                    val dmg = unit.unitType.attackPower * 5L
                    applyDirectDamageToCountry(target, dmg)

                    // If aggressive invasion unit arrived, conquer or advance capture
                    if (unit.isAggressiveInvasion && target.status != CountryStatus.CONQUERED) {
                        conquerCountryDirectly(target)
                    }
                }
            } else {
                survivingUnits.add(unit.copy(progress = nextProg))

                // Periodically generate tracer combat beams when units approach targets
                if (nextProg > 0.45f && Math.random() < 0.25) {
                    val unitCurX = unit.startX + (unit.targetX - unit.startX) * nextProg
                    val unitCurY = unit.startY + (unit.targetY - unit.startY) * nextProg
                    newLasers.add(
                        CombatLaserBeam(
                            startX = unitCurX,
                            startY = unitCurY,
                            endX = unit.targetX + ((Math.random() - 0.5) * 0.02).toFloat(),
                            endY = unit.targetY + ((Math.random() - 0.5) * 0.02).toFloat(),
                            isEgyptian = true
                        )
                    )
                }
            }
        }

        // Update Explosions
        val survivingExplosions = mutableListOf<MapExplosion>()
        newExplosions.forEach { exp ->
            val nextProg = exp.progress + (if (exp.isNuke) 0.04f else 0.07f) * (if (current.isSlowMotionActive) 0.4f else 1.0f)
            if (nextProg < 1.0f) {
                survivingExplosions.add(exp.copy(progress = nextProg))
            }
        }

        // Update Laser Tracer Beams
        val survivingLasers = mutableListOf<CombatLaserBeam>()
        newLasers.forEach { laser ->
            val nextProg = laser.progress + 0.18f
            if (nextProg < 1.0f) {
                survivingLasers.add(laser.copy(progress = nextProg))
            }
        }

        // Update Conquest Golden Waves
        val survivingWaves = mutableListOf<ConquestWave>()
        current.conquestWaves.forEach { wave ->
            val nextProg = wave.progress + 0.035f
            if (nextProg < 1.0f) {
                survivingWaves.add(wave.copy(progress = nextProg))
            }
        }

        // Update Tap Damages
        val survivingDamages = mutableListOf<TapDamageEffect>()
        current.activeTapDamages.forEach { dmg ->
            val nextAlpha = dmg.alpha - 0.06f
            if (nextAlpha > 0f) {
                survivingDamages.add(dmg.copy(alpha = nextAlpha, y = dmg.y - 0.003f))
            }
        }

        // Fade craters slowly
        val survivingCraters = mutableListOf<CraterMark>()
        newCraters.takeLast(16).forEach { crater ->
            val nextAlpha = crater.alpha - 0.002f
            if (nextAlpha > 0.2f) {
                survivingCraters.add(crater.copy(alpha = nextAlpha))
            }
        }

        // Decay screen shake & flash
        val nextShake = (current.screenShake * 0.82f).let { if (it < 0.05f) 0f else it }
        val nextFlash = (triggeredFlash * 0.78f).let { if (it < 0.03f) 0f else it }

        _uiState.update { state ->
            state.copy(
                movingUnits = survivingUnits,
                activeExplosions = survivingExplosions,
                combatLaserBeams = survivingLasers,
                conquestWaves = survivingWaves,
                craterMarks = survivingCraters,
                activeTapDamages = survivingDamages,
                screenShake = nextShake,
                screenFlashAlpha = nextFlash
            )
        }
    }

    fun selectUnitForDeployment(unitType: MilitaryUnitType) {
        soundManager.playClick()
        _uiState.update { it.copy(selectedUnitForDeployment = unitType) }
    }

    fun deployUnitToCountry(unitType: MilitaryUnitType, target: Country) {
        if (target.isEgypt || target.status == CountryStatus.CONQUERED) {
            showNotification("هذه المنطقة خاضعة بالفعل للسيادة المصرية!")
            return
        }

        val available = _uiState.value.militaryUnits[unitType] ?: 0
        if (available <= 0) {
            val res = _uiState.value.resources
            if (res.gold >= unitType.costGold && res.manpower >= unitType.costManpower) {
                recruitUnits(unitType, 1)
            } else {
                showNotification("الموارد غير كافية لنشر ${unitType.nameAr}")
                return
            }
        }

        soundManager.playTankMovement()

        val egyptPos = Offset(0.58f, 0.48f)
        val newUnit = MovingUnit(
            unitType = unitType,
            startX = egyptPos.x,
            startY = egyptPos.y,
            targetX = target.normX,
            targetY = target.normY,
            targetCountryId = target.id,
            speed = 0.030f * _uiState.value.gameSpeed
        )

        _uiState.update { state ->
            val units = state.militaryUnits.toMutableMap()
            val cur = units[unitType] ?: 0
            if (cur > 0) units[unitType] = cur - 1
            state.copy(
                militaryUnits = units,
                movingUnits = state.movingUnits + newUnit
            )
        }

        showNotification("🚀 انطلقت ${unitType.nameAr} المصرية لضرب دفاعات ${target.nameAr}!")
    }

    fun tapDamageEnemy(target: Country) {
        if (target.isEgypt || target.status == CountryStatus.CONQUERED) return

        val currentTaps = _uiState.value.consecutiveTaps + 1
        val isCritical = currentTaps % 5 == 0 // 5 consecutive taps triggers a devastating strike!
        val playerAttack = (calculateTotalPlayerPower() / 8L).coerceAtLeast(250L)
        val damage = if (isCritical) playerAttack * 5L else playerAttack

        soundManager.playArtilleryFire()
        if (isCritical) {
            soundManager.playExplosion()
        }

        _uiState.update { state ->
            val damages = state.activeTapDamages.toMutableList()
            damages.add(
                TapDamageEffect(
                    x = target.normX,
                    y = target.normY,
                    damage = damage,
                    isCritical = isCritical
                )
            )
            val explosions = state.activeExplosions.toMutableList()
            explosions.add(
                MapExplosion(
                    x = target.normX,
                    y = target.normY,
                    isNuke = isCritical
                )
            )
            state.copy(
                consecutiveTaps = currentTaps,
                screenShake = if (isCritical) 1.0f else 0.35f,
                activeTapDamages = damages,
                activeExplosions = explosions
            )
        }

        applyDirectDamageToCountry(target, damage)
    }

    private fun applyDirectDamageToCountry(target: Country, damage: Long) {
        val curHp = _uiState.value.targetCountryCurrentHp
        val newHp = (curHp - damage).coerceAtLeast(0L)

        _uiState.update { it.copy(targetCountryCurrentHp = newHp) }

        if (newHp <= 0L) {
            conquerCountryDirectly(target)
        }
    }

    fun conquerCountryDirectly(target: Country) {
        soundManager.playVictoryFanfare()
        val lootGold = (target.gdpBillion * 200L).coerceAtLeast(25000L)
        val lootOil = 8000L
        val lootIron = 9000L

        _uiState.update { state ->
            val updatedCountries = state.countries.map { c ->
                if (c.id == target.id) c.copy(status = CountryStatus.CONQUERED) else c
            }

            // Check campaign stages
            val updatedStages = state.campaignStages.map { stage ->
                val allTargetsConquered = stage.targetCountryIds.all { tid ->
                    updatedCountries.find { it.id == tid }?.status == CountryStatus.CONQUERED
                }
                if (allTargetsConquered && !stage.isCompleted) {
                    stage.copy(isCompleted = true)
                } else stage
            }

            val finalStages = updatedStages.mapIndexed { idx, stage ->
                val prevCompleted = idx == 0 || updatedStages[idx - 1].isCompleted
                stage.copy(isUnlocked = prevCompleted)
            }

            val newRes = state.resources.copy(
                gold = state.resources.gold + lootGold,
                oil = state.resources.oil + lootOil,
                iron = state.resources.iron + lootIron,
                researchPoints = state.resources.researchPoints + 200
            )

            state.copy(
                countries = updatedCountries,
                campaignStages = finalStages,
                resources = newRes,
                selectedCountry = updatedCountries.find { it.id == target.id },
                targetCountryCurrentHp = 0L,
                consecutiveTaps = 0,
                screenShake = 1.0f
            )
        }

        addCombatLog(
            message = "تم تحرير وبسط السيادة المصرية 🇪🇬 على أراضي ${target.nameAr} ${target.flag}!",
            type = CombatLogType.CONQUEST
        )

        showNotification("👑 تم تحرير ${target.nameAr}! رفرف العلم المصري وغنم الجيش ${formatNumber(lootGold)} ذهب!")

        // 3-second Slow-Motion Victory Shockwave & Golden Territory Expansion
        val goldenWave = ConquestWave(
            centerX = target.normX,
            centerY = target.normY,
            targetCountryNameAr = target.nameAr,
            targetCountryFlag = target.flag
        )
        _uiState.update {
            it.copy(
                conquestWaves = it.conquestWaves + goldenWave,
                isSlowMotionActive = true,
                conquestSlowMoCountry = target,
                screenShake = 0.9f
            )
        }
        viewModelScope.launch {
            delay(3000L) // 3 seconds of epic Slow Motion
            _uiState.update { it.copy(isSlowMotionActive = false, conquestSlowMoCountry = null) }
        }

        // Check Grand World Victory
        val nonPlayerRemaining = _uiState.value.countries.count {
            !it.isEgypt && it.status != CountryStatus.CONQUERED
        }
        if (nonPlayerRemaining == 0) {
            _uiState.update { it.copy(showGrandVictoryDialog = true) }
        }

        autoSave()
    }

    private fun formatNumber(number: Long): String {
        return when {
            number >= 1_000_000_000 -> String.format(Locale.US, "%.1fB", number / 1_000_000_000.0)
            number >= 1_000_000 -> String.format(Locale.US, "%.1fM", number / 1_000_000.0)
            number >= 1_000 -> String.format(Locale.US, "%.1fK", number / 1_000.0)
            else -> number.toString()
        }
    }

    fun selectTab(tab: GameTab) {
        soundManager.playClick()
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun selectCountry(country: Country?) {
        soundManager.playClick()
        _uiState.update { state ->
            val hp = if (country != null) (country.power + country.defense) else 0L
            state.copy(
                selectedCountry = country,
                consecutiveTaps = 0,
                targetCountryCurrentHp = hp,
                targetCountryMaxHp = hp
            )
        }
    }

    fun toggleMute() {
        val newMute = !_uiState.value.isMuted
        soundManager.isMuted = newMute
        _uiState.update { it.copy(isMuted = newMute) }
    }

    fun togglePause() {
        soundManager.playClick()
        _uiState.update { it.copy(isPaused = !it.isPaused) }
    }

    fun setGameSpeed(speed: Float) {
        soundManager.playClick()
        _uiState.update { it.copy(gameSpeed = speed) }
    }

    // --- RECRUITMENT & MILITARY COMMAND ---
    fun recruitUnits(unitType: MilitaryUnitType, quantity: Int = 1) {
        val currentRes = _uiState.value.resources
        val totalGold = unitType.costGold * quantity
        val totalOil = unitType.costOil * quantity
        val totalIron = unitType.costIron * quantity
        val totalManpower = unitType.costManpower * quantity

        if (currentRes.gold < totalGold || currentRes.oil < totalOil ||
            currentRes.iron < totalIron || currentRes.manpower < totalManpower
        ) {
            showNotification("الموارد غير كافية لتجنيد $quantity من ${unitType.nameAr}")
            return
        }

        // Deduct resources & add unit count
        _uiState.update { state ->
            val units = state.militaryUnits.toMutableMap()
            val currentCount = units[unitType] ?: 0
            units[unitType] = currentCount + quantity

            val newRes = state.resources.copy(
                gold = state.resources.gold - totalGold,
                oil = state.resources.oil - totalOil,
                iron = state.resources.iron - totalIron,
                manpower = state.resources.manpower - totalManpower
            )
            state.copy(resources = newRes, militaryUnits = units)
        }

        soundManager.playMarch()
        showNotification("تم تجنيد $quantity × ${unitType.nameAr} بنجاح!")
        advanceDailyMission("deploy", quantity)
        autoSave()
    }

    // --- BASE BUILDING & INFRASTRUCTURE ---
    fun upgradeInfrastructure(infraType: InfrastructureType) {
        val currentLvl = _uiState.value.infrastructureLevels[infraType.id] ?: 0
        if (currentLvl >= 10) {
            showNotification("تمت ترقية ${infraType.nameAr} إلى الحد الأقصى!")
            return
        }

        val multiplier = currentLvl + 1
        val costGold = infraType.baseCostGold * multiplier
        val costIron = infraType.baseCostIron * multiplier
        val res = _uiState.value.resources

        if (res.gold < costGold || res.iron < costIron) {
            showNotification("الموارد غير كافية لترقية ${infraType.nameAr}")
            return
        }

        _uiState.update { state ->
            val infra = state.infrastructureLevels.toMutableMap()
            infra[infraType.id] = currentLvl + 1
            val newRes = state.resources.copy(
                gold = state.resources.gold - costGold,
                iron = state.resources.iron - costIron
            )
            state.copy(resources = newRes, infrastructureLevels = infra)
        }

        soundManager.playClick()
        showNotification("تمت ترقية ${infraType.nameAr} إلى المستوى ${currentLvl + 1}!")
        autoSave()
    }

    // --- RESEARCH & TECH TREE ---
    fun unlockTechnology(tech: TechItem) {
        val res = _uiState.value.resources
        if (tech.isUnlocked) return

        if (res.researchPoints < tech.costResearch || res.gold < tech.costGold) {
            showNotification("نقاط الأبحاث أو الذهب غير كافية لتطوير ${tech.titleAr}")
            return
        }

        _uiState.update { state ->
            val updatedTech = state.techItems.map {
                if (it.id == tech.id) it.copy(isUnlocked = true) else it
            }
            val newRes = state.resources.copy(
                researchPoints = state.resources.researchPoints - tech.costResearch,
                gold = state.resources.gold - tech.costGold
            )
            state.copy(resources = newRes, techItems = updatedTech)
        }

        soundManager.playVictoryFanfare()
        showNotification("تم إنجاز البحث: ${tech.titleAr}!")
        advanceDailyMission("tech", 1)
        autoSave()
    }

    // --- TRADE MARKET ---
    fun buyResource(resourceName: String, amount: Long, costGold: Long) {
        val res = _uiState.value.resources
        if (res.gold < costGold) {
            showNotification("الذهب غير كافٍ لإتمام الصفقة التجارية")
            return
        }

        _uiState.update { state ->
            val current = state.resources
            val newRes = when (resourceName) {
                "oil" -> current.copy(gold = current.gold - costGold, oil = current.oil + amount)
                "iron" -> current.copy(gold = current.gold - costGold, iron = current.iron + amount)
                "food" -> current.copy(gold = current.gold - costGold, food = current.food + amount)
                "manpower" -> current.copy(gold = current.gold - costGold, manpower = current.manpower + amount)
                else -> current
            }
            state.copy(resources = newRes)
        }
        soundManager.playClick()
        showNotification("تم شراء $amount بنجاح عبر السوق التجاري!")
    }

    fun sellResource(resourceName: String, amount: Long, gainGold: Long) {
        val res = _uiState.value.resources
        val hasEnough = when (resourceName) {
            "oil" -> res.oil >= amount
            "iron" -> res.iron >= amount
            "food" -> res.food >= amount
            else -> false
        }

        if (!hasEnough) {
            showNotification("الكمية المتوفرة لديك غير كافية للبيع")
            return
        }

        _uiState.update { state ->
            val current = state.resources
            val newRes = when (resourceName) {
                "oil" -> current.copy(gold = current.gold + gainGold, oil = current.oil - amount)
                "iron" -> current.copy(gold = current.gold + gainGold, iron = current.iron - amount)
                "food" -> current.copy(gold = current.gold + gainGold, food = current.food - amount)
                else -> current
            }
            state.copy(resources = newRes)
        }
        soundManager.playClick()
        showNotification("تم تصدير الفائض والحصول على $gainGold ذهب!")
    }

    // --- COMBAT & WAR SYSTEM ---
    fun startBattle(target: Country, isAirStrike: Boolean = false, isNuclear: Boolean = false) {
        if (target.isEgypt || target.status == CountryStatus.CONQUERED) {
            showNotification("هذه الأرض خاضعة بالفعل للسيادة المصرية!")
            return
        }

        val totalPlayerPower = calculateTotalPlayerPower()
        if (totalPlayerPower <= 0 && !isNuclear && !isAirStrike) {
            showNotification("جيشك لا يمتلك أي وحدات مقاتلة! قم بالتجنيد أولاً.")
            return
        }

        val targetPower = target.power + target.defense
        val egyptPos = Offset(0.585f, 0.400f)

        if (isNuclear) {
            val hasNuke = (_uiState.value.militaryUnits[MilitaryUnitType.NUCLEAR_ICBM] ?: 0) > 0
            val isNukeTech = _uiState.value.techItems.find { it.id == "tech_nuclear" }?.isUnlocked == true
            if (!hasNuke || !isNukeTech) {
                showNotification("لم تقم بتطوير أو تصنيع الصواريخ النووية بعد!")
                return
            }
            soundManager.playAirRaidSiren()
            soundManager.speakArabicVoiceOver("إطلاق الصاروخ الباليستي النووي!")

            // Launch Nuclear ICBM projectile traversing the map in a high arc
            val icbmUnit = MovingUnit(
                unitType = MilitaryUnitType.NUCLEAR_ICBM,
                startX = egyptPos.x,
                startY = egyptPos.y,
                targetX = target.normX,
                targetY = target.normY,
                targetCountryId = target.id,
                speed = 0.018f,
                isCurvedFlight = true,
                curveHeight = -0.15f,
                isAggressiveInvasion = true
            )
            _uiState.update { it.copy(movingUnits = it.movingUnits + icbmUnit, screenShake = 0.8f) }
        } else if (isAirStrike) {
            soundManager.playMissileLaunch()
            soundManager.speakArabicVoiceOver("سلاح الجو ينفذ ضربة جراحية خاطفة!")

            // Launch 3 curved Rafale jet squadrons & missiles
            val airFleet = listOf(
                MovingUnit(
                    unitType = MilitaryUnitType.FIGHTER_JET,
                    startX = egyptPos.x,
                    startY = egyptPos.y,
                    targetX = target.normX,
                    targetY = target.normY,
                    targetCountryId = target.id,
                    speed = 0.035f,
                    isCurvedFlight = true,
                    curveHeight = -0.08f,
                    isAggressiveInvasion = true
                ),
                MovingUnit(
                    unitType = MilitaryUnitType.DRONE,
                    startX = egyptPos.x + 0.015f,
                    startY = egyptPos.y - 0.01f,
                    targetX = target.normX + 0.01f,
                    targetY = target.normY - 0.01f,
                    targetCountryId = target.id,
                    speed = 0.028f,
                    isCurvedFlight = true,
                    curveHeight = 0.06f,
                    isAggressiveInvasion = true
                )
            )
            _uiState.update { it.copy(movingUnits = it.movingUnits + airFleet, screenShake = 0.4f) }
        } else {
            soundManager.playArtilleryFire()
            soundManager.playTankMovement()
            soundManager.speakArabicVoiceOver("الجيش المصري يزحف لبدء الحرب الشاملة!")

            // Launch mixed ground and air invasion armada
            val invasionArmada = listOf(
                MovingUnit(
                    unitType = MilitaryUnitType.TANKS,
                    startX = egyptPos.x - 0.015f,
                    startY = egyptPos.y + 0.005f,
                    targetX = target.normX - 0.01f,
                    targetY = target.normY,
                    targetCountryId = target.id,
                    speed = 0.020f,
                    isCurvedFlight = false,
                    isAggressiveInvasion = true
                ),
                MovingUnit(
                    unitType = MilitaryUnitType.ARTILLERY,
                    startX = egyptPos.x,
                    startY = egyptPos.y,
                    targetX = target.normX,
                    targetY = target.normY,
                    targetCountryId = target.id,
                    speed = 0.018f,
                    isCurvedFlight = false,
                    isAggressiveInvasion = true
                ),
                MovingUnit(
                    unitType = MilitaryUnitType.FIGHTER_JET,
                    startX = egyptPos.x + 0.015f,
                    startY = egyptPos.y - 0.01f,
                    targetX = target.normX + 0.01f,
                    targetY = target.normY - 0.01f,
                    targetCountryId = target.id,
                    speed = 0.036f,
                    isCurvedFlight = true,
                    curveHeight = -0.07f,
                    isAggressiveInvasion = true
                )
            )
            _uiState.update { it.copy(movingUnits = it.movingUnits + invasionArmada, screenShake = 0.6f) }
        }

        val initialBattle = BattleState(
            country = target,
            isAirStrike = isAirStrike,
            isNuclear = isNuclear,
            playerCurrentPower = totalPlayerPower,
            enemyCurrentPower = targetPower,
            playerInitialPower = totalPlayerPower,
            enemyInitialPower = targetPower,
            round = 1
        )

        _uiState.update { it.copy(activeBattle = initialBattle) }
        runBattleSimulation(initialBattle)
    }

    private fun runBattleSimulation(battle: BattleState) {
        viewModelScope.launch {
            var round = 1
            var playerPwr = battle.playerCurrentPower
            var enemyPwr = battle.enemyCurrentPower

            while (round <= 4 && playerPwr > 0 && enemyPwr > 0) {
                delay(800)
                soundManager.playArtilleryFire()

                if (battle.isNuclear) {
                    // Nuclear strike instant wipe
                    enemyPwr = 0
                    break
                } else if (battle.isAirStrike) {
                    val damage = (playerPwr * 0.45).toLong().coerceAtLeast(2000L)
                    enemyPwr = max(0, enemyPwr - damage)
                    playerPwr = max(0, (playerPwr * 0.95).toLong())
                } else {
                    val playerDmg = (playerPwr * 0.35 + Math.random() * 500).toLong()
                    val enemyDmg = (enemyPwr * 0.25 + Math.random() * 400).toLong()
                    enemyPwr = max(0, enemyPwr - playerDmg)
                    playerPwr = max(0, playerPwr - enemyDmg)
                }

                round++
                val curPlayer = playerPwr
                val curEnemy = enemyPwr
                val curRound = round
                _uiState.update { state ->
                    state.activeBattle?.let { ab ->
                        state.copy(
                            activeBattle = ab.copy(
                                playerCurrentPower = curPlayer,
                                enemyCurrentPower = curEnemy,
                                round = curRound
                            )
                        )
                    } ?: state
                }
            }

            delay(600)
            val won = enemyPwr <= 0 || (playerPwr > enemyPwr * 1.5)
            finishBattle(won, battle)
        }
    }

    private fun finishBattle(isVictory: Boolean, battle: BattleState) {
        val target = battle.country
        val lootGold = (target.gdpBillion * 150L).coerceAtLeast(10000L)
        val lootOil = 5000L

        if (isVictory) {
            soundManager.playVictoryFanfare()
            // Mark country as CONQUERED
            _uiState.update { state ->
                val updatedCountries = state.countries.map { c ->
                    if (c.id == target.id) {
                        c.copy(status = CountryStatus.CONQUERED)
                    } else c
                }

                // Check campaign completion
                val updatedStages = state.campaignStages.map { stage ->
                    val allTargetsConquered = stage.targetCountryIds.all { tid ->
                        updatedCountries.find { it.id == tid }?.status == CountryStatus.CONQUERED
                    }
                    if (allTargetsConquered && !stage.isCompleted) {
                        stage.copy(isCompleted = true)
                    } else stage
                }

                // Unlock next stages
                val finalStages = updatedStages.mapIndexed { idx, stage ->
                    val prevCompleted = idx == 0 || updatedStages[idx - 1].isCompleted
                    stage.copy(isUnlocked = prevCompleted)
                }

                val newRes = state.resources.copy(
                    gold = state.resources.gold + lootGold,
                    oil = state.resources.oil + lootOil,
                    researchPoints = state.resources.researchPoints + 150
                )

                val summary = "انتصار كاسح! تم بسط السيادة المصرية الكاملة على أراضي ${target.nameAr} وغنم $lootGold ذهب!"

                state.copy(
                    countries = updatedCountries,
                    campaignStages = finalStages,
                    resources = newRes,
                    activeBattle = state.activeBattle?.copy(
                        isFinished = true,
                        isVictory = true,
                        summaryTextAr = summary
                    ),
                    selectedCountry = updatedCountries.find { it.id == target.id }
                )
            }

            addCombatLog(
                message = "تم فتح وإخضاع ${target.nameAr} ${target.flag} تحت راية الجيش المصري!",
                type = CombatLogType.CONQUEST
            )

            // Check Grand World Domination (all countries conquered)
            val nonPlayerRemaining = _uiState.value.countries.count {
                !it.isEgypt && it.status != CountryStatus.CONQUERED
            }
            if (nonPlayerRemaining == 0) {
                _uiState.update { it.copy(showGrandVictoryDialog = true) }
            }

            // Legend Mode Hooks: Daily mission & Rank points & Slow-mo cinematic
            advanceDailyMission("conquer", 1)
            advanceDailyMission("battle", 1)
            addRankPoints(120L)
            triggerConquestSlowMo(target)

        } else {
            // Defeat or retreat
            _uiState.update { state ->
                val summary = "صمدت دفاعات ${target.nameAr}. تراجعت القوات لإعادة التموضع والتعزيز."
                state.copy(
                    activeBattle = state.activeBattle?.copy(
                        isFinished = true,
                        isVictory = false,
                        summaryTextAr = summary
                    )
                )
            }

            addCombatLog(
                message = "انسحاب تكتيكي للقوات من معركة ${target.nameAr} لإعادة التجميع.",
                type = CombatLogType.DEFEAT
            )
        }

        autoSave()
    }

    fun dismissBattle() {
        _uiState.update { it.copy(activeBattle = null) }
    }

    fun dismissGrandVictoryDialog() {
        _uiState.update { it.copy(showGrandVictoryDialog = false) }
    }

    fun declareDiplomacy(target: Country, newStatus: CountryStatus) {
        val costGold = when (newStatus) {
            CountryStatus.ALLIED -> 15000L
            CountryStatus.NEUTRAL -> 5000L
            else -> 0L
        }

        if (_uiState.value.resources.gold < costGold) {
            showNotification("الذهب غير كافٍ لإبرام المعاهدة الدبلوماسية!")
            return
        }

        _uiState.update { state ->
            val updated = state.countries.map {
                if (it.id == target.id) it.copy(status = newStatus) else it
            }
            val newRes = state.resources.copy(gold = state.resources.gold - costGold)
            state.copy(countries = updated, resources = newRes, selectedCountry = target.copy(status = newStatus))
        }

        soundManager.playClick()
        val text = when (newStatus) {
            CountryStatus.ALLIED -> "تم توقيع معاهدة دفاع مشترك وتحالف عسكري مع ${target.nameAr}!"
            CountryStatus.NEUTRAL -> "تم توقيع هدنة ووقف إطلاق النار مع ${target.nameAr}."
            CountryStatus.HOSTILE -> "تم إعلان العداء وقطع العلاقات الدبلوماسية مع ${target.nameAr}!"
            else -> ""
        }
        addCombatLog(text, CombatLogType.DIPLOMACY)
        showNotification(text)
        autoSave()
    }

    fun claimStageReward(stage: CampaignStage) {
        if (!stage.isCompleted) return
        _uiState.update { state ->
            val res = state.resources.copy(
                gold = state.resources.gold + stage.rewardGold,
                researchPoints = state.resources.researchPoints + stage.rewardResearch
            )
            state.copy(resources = res)
        }
        soundManager.playVictoryFanfare()
        showNotification("تم استلام مكافأة المرحلة: +${stage.rewardGold} ذهب، +${stage.rewardResearch} أبحاث!")
        autoSave()
    }

    private fun addCombatLog(message: String, type: CombatLogType) {
        val newLog = CombatLog(
            timestampFormatted = timeFormat.format(Date()),
            messageAr = message,
            type = type
        )
        _uiState.update { state ->
            val list = (listOf(newLog) + state.combatLogs).take(40)
            state.copy(combatLogs = list)
        }
    }

    private fun showNotification(msg: String) {
        _uiState.update { it.copy(notificationMessage = msg) }
        viewModelScope.launch {
            delay(3500)
            _uiState.update {
                if (it.notificationMessage == msg) it.copy(notificationMessage = null) else it
            }
        }
    }

    fun calculateTotalPlayerPower(): Long {
        var power = 850000L // Egypt base superpower attack power
        _uiState.value.militaryUnits.forEach { (type, count) ->
            power += type.attackPower * count
        }

        // Tech attack bonuses
        var bonusPercent = 0
        _uiState.value.techItems.filter { it.isUnlocked }.forEach {
            bonusPercent += it.attackBonusPercent
        }

        // General attack bonus (active general)
        val activeGeneral = _uiState.value.generals.find { it.isAssigned }
        if (activeGeneral != null) {
            bonusPercent += activeGeneral.attackBonusPercent
        }

        return (power * (100 + bonusPercent)) / 100
    }

    fun calculateTotalPlayerDefense(): Long {
        var defense = 950000L // Egypt base superpower defense
        _uiState.value.militaryUnits.forEach { (type, count) ->
            defense += type.defensePower * count
        }

        // Infrastructure defense
        val radarLvl = _uiState.value.infrastructureLevels[InfrastructureType.RADAR_STATION.id] ?: 0
        defense += radarLvl * 5000L

        val airbaseLvl = _uiState.value.infrastructureLevels[InfrastructureType.AIRBASE.id] ?: 0
        defense += airbaseLvl * 4000L

        var bonusPercent = 0
        _uiState.value.techItems.filter { it.isUnlocked }.forEach {
            bonusPercent += it.defenseBonusPercent
        }

        // General defense bonus
        val activeGeneral = _uiState.value.generals.find { it.isAssigned }
        if (activeGeneral != null) {
            bonusPercent += activeGeneral.defenseBonusPercent
        }

        return (defense * (100 + bonusPercent)) / 100
    }

    fun demandImmediateCapitulation(target: Country) {
        if (target.isEgypt || target.status == CountryStatus.CONQUERED) {
            showNotification("هذه الأرض خاضعة بالفعل للسيادة المصرية!")
            return
        }

        val totalPlayerPower = calculateTotalPlayerPower()
        val targetPower = target.power + target.defense

        if (totalPlayerPower >= targetPower) {
            // Immediate Capitulation Fleet En-Route: Dispatch fast vanguard tanks & jets directly to target!
            soundManager.playTankMovement()
            soundManager.playMissileLaunch()
            soundManager.speakArabicVoiceOver("الجيش المصري يتقدم لبسط السيادة فوراً على ${target.nameAr}!")
            showNotification("⚡ تم إرسال أرتال مدرعات الصاعقة ومقاتلات السيادة لضم ${target.nameAr} فوراً!")

            val egyptPos = Offset(0.585f, 0.400f)
            val vanguardFleet = listOf(
                MovingUnit(
                    unitType = MilitaryUnitType.TANKS,
                    startX = egyptPos.x - 0.01f,
                    startY = egyptPos.y,
                    targetX = target.normX - 0.01f,
                    targetY = target.normY,
                    targetCountryId = target.id,
                    speed = 0.024f,
                    isCurvedFlight = false,
                    isAggressiveInvasion = true
                ),
                MovingUnit(
                    unitType = MilitaryUnitType.FIGHTER_JET,
                    startX = egyptPos.x + 0.01f,
                    startY = egyptPos.y - 0.01f,
                    targetX = target.normX + 0.01f,
                    targetY = target.normY - 0.01f,
                    targetCountryId = target.id,
                    speed = 0.038f,
                    isCurvedFlight = true,
                    curveHeight = -0.06f,
                    isAggressiveInvasion = true
                )
            )

            _uiState.update { it.copy(movingUnits = it.movingUnits + vanguardFleet, screenShake = 0.5f) }
        } else {
            showNotification("رفضت ${target.nameAr} الاستسلام الفوري! بدأت القوات الغزو الشامل.")
            startBattle(target, isAirStrike = false, isNuclear = false)
        }
    }

    fun autoSave() {
        val s = _uiState.value
        val countryMap = s.countries.associate { it.id to it.status }
        val completed = s.campaignStages.filter { it.isCompleted }.map { it.id }.toSet()
        val unlockedTech = s.techItems.filter { it.isUnlocked }.map { it.id }.toSet()
        val recruitedGens = s.generals.filter { it.isRecruited }.map { it.id }.toSet()
        val minMap = s.ministers.associate { it.id to it.level }

        saveSystem.saveGame(
            resources = s.resources,
            militaryUnits = s.militaryUnits,
            infrastructureLevels = s.infrastructureLevels,
            unlockedTechIds = unlockedTech,
            countryStatuses = countryMap,
            completedStages = completed,
            recruitedGeneralIds = recruitedGens,
            ministerLevels = minMap,
            gloryPoints = s.gloryPoints,
            slot = s.activeSaveSlot
        )
    }

    // --- ACADEMY & CABINET ACTIONS ---
    fun recruitGeneral(general: MilitaryGeneral) {
        if (general.isRecruited) return
        if (_uiState.value.gloryPoints < general.costGlory) {
            showNotification("نقاط المجد غير كافية لتعيين ${general.nameAr}!")
            return
        }

        soundManager.playVictoryFanfare()
        _uiState.update { state ->
            val updated = state.generals.map {
                if (it.id == general.id) it.copy(isRecruited = true, isAssigned = true)
                else it.copy(isAssigned = false) // only 1 primary active commander in chief
            }
            state.copy(
                generals = updated,
                gloryPoints = state.gloryPoints - general.costGlory
            )
        }
        showNotification("🎖️ تم تعيين ${general.nameAr} قائداً عاماً للقوات المسلحة المصرية!")
        addCombatLog("تم تعيين ${general.nameAr} (${general.titleAr}) قائداً استراتيجياً للعمليات.", CombatLogType.ALLIANCE)
        autoSave()
    }

    fun assignGeneral(general: MilitaryGeneral) {
        if (!general.isRecruited) return
        soundManager.playClick()
        _uiState.update { state ->
            val updated = state.generals.map {
                it.copy(isAssigned = it.id == general.id)
            }
            state.copy(generals = updated)
        }
        showNotification("تم تكليف ${general.nameAr} بقيادة مسارح العمليات الحربية!")
    }

    fun upgradeMinister(minister: CabinetMinister) {
        val cost = minister.upgradeCostGold * minister.level
        if (_uiState.value.resources.gold < cost) {
            showNotification("الذهب غير كافٍ لترقية وتطوير ${minister.nameAr}!")
            return
        }

        soundManager.playVictoryFanfare()
        _uiState.update { state ->
            val updatedMinisters = state.ministers.map {
                if (it.id == minister.id) it.copy(level = it.level + 1) else it
            }
            val newRes = state.resources.copy(gold = state.resources.gold - cost)
            state.copy(ministers = updatedMinisters, resources = newRes)
        }
        showNotification("🏛️ تم ترقية حقيبة ${minister.nameAr} إلى المستوى ${minister.level + 1}!")
        addCombatLog("تطوير أداء الحكومة: ترقية حقيبة ${minister.portfolioAr} بنجاح.", CombatLogType.DIPLOMACY)
        autoSave()
    }

    fun switchSaveSlot(newSlot: Int) {
        soundManager.playClick()
        _uiState.update { it.copy(activeSaveSlot = newSlot) }
        loadInitialState()
        showNotification("تم الانتقال إلى خانة الحفظ (Slot $newSlot)")
    }

    // --- RECRUIT & PLACE UNIT DIRECTLY ON MAP TERRITORY (Max 5 Stack) ---
    fun recruitAndPlaceUnitOnTerritory(country: Country, unitType: MilitaryUnitType) {
        val currentUnitsOnTerritory = _uiState.value.placedUnits.count { it.countryId == country.id }
        if (currentUnitsOnTerritory >= 5) {
            showNotification("⚠️ الحد الأقصى للمنطقة (5 وحدات) مكتمل! انقل بعض الوحدات أو وزعها.")
            return
        }

        val res = _uiState.value.resources
        if (res.gold < unitType.costGold || res.oil < unitType.costOil ||
            res.iron < unitType.costIron || res.manpower < unitType.costManpower
        ) {
            showNotification("الموارد غير كافية لنشر ${unitType.nameAr}")
            return
        }

        soundManager.playDeployUnit()

        // Calculate minor offset so 5 units stack neatly in a rosette around the territory center
        val slotIndex = currentUnitsOnTerritory
        val offsets = listOf(
            Pair(0f, 0f),
            Pair(-0.016f, -0.012f),
            Pair(0.016f, -0.012f),
            Pair(-0.016f, 0.014f),
            Pair(0.016f, 0.014f)
        )
        val offset = offsets.getOrElse(slotIndex) { Pair(0f, 0f) }

        val newPlacedUnit = PlacedMapUnit(
            countryId = country.id,
            unitType = unitType,
            isEgyptian = true,
            healthPercent = 1.0f,
            offsetX = offset.first,
            offsetY = offset.second
        )

        _uiState.update { state ->
            val updatedPlaced = state.placedUnits + newPlacedUnit
            val newRes = state.resources.copy(
                gold = state.resources.gold - unitType.costGold,
                oil = state.resources.oil - unitType.costOil,
                iron = state.resources.iron - unitType.costIron,
                manpower = state.resources.manpower - unitType.costManpower
            )
            val updatedCountries = state.countries.map { c ->
                if (c.id == country.id) {
                    c.copy(
                        assignedGarrisonUnits = c.assignedGarrisonUnits + 1,
                        rebellionRisk = (c.rebellionRisk - 0.25f).coerceAtLeast(0f)
                    )
                } else c
            }
            state.copy(
                resources = newRes,
                placedUnits = updatedPlaced,
                countries = updatedCountries
            )
        }

        showNotification("🛡️ تم نشر ${unitType.nameAr} المصرية في ${country.nameAr} بنجاح! (${currentUnitsOnTerritory + 1}/5)")
        addCombatLog(
            message = "تم نشر وتثبيت ${unitType.nameAr} في منطقة ${country.nameAr} لحفظ الأمن والسيطرة.",
            type = CombatLogType.ALLIANCE
        )
    }

    // --- REBELLION & OCCUPATION MANAGEMENT ---
    fun processRebellionCheck() {
        val conqueredNations = _uiState.value.countries.filter { it.status == CountryStatus.CONQUERED && !it.isEgypt }
        if (conqueredNations.isEmpty()) return

        val candidate = conqueredNations.random()
        val stationedUnits = _uiState.value.placedUnits.count { it.countryId == candidate.id }

        // If no stationed Egyptian units, rebellion risk builds up
        if (stationedUnits == 0) {
            val newRisk = (candidate.rebellionRisk + 0.35f).coerceAtMost(1.0f)
            if (newRisk >= 0.85f && Math.random() < 0.65) {
                // Outbreak of rebellion! Country returns to hostile status
                soundManager.playRebellionAlert()
                _uiState.update { state ->
                    val updated = state.countries.map {
                        if (it.id == candidate.id) it.copy(status = CountryStatus.HOSTILE, rebellionRisk = 0f) else it
                    }
                    state.copy(countries = updated)
                }
                addCombatLog(
                    message = "⚠️ تمرد مسلح شعبي اندلع في ${candidate.nameAr}! فقدت مصر السيطرة لغياب الحاميات العسكرية.",
                    type = CombatLogType.ENEMY_WAR
                )
                showNotification("🚨 تمرد في ${candidate.nameAr}! أرسل قواتك فوراً لإعادة بسط السيطرة!")
            } else {
                _uiState.update { state ->
                    val updated = state.countries.map {
                        if (it.id == candidate.id) it.copy(rebellionRisk = newRisk) else it
                    }
                    state.copy(countries = updated)
                }
            }
        }
    }

    // --- DYNAMIC WORLD EVENTS GENERATION ---
    fun triggerRandomWorldEvent() {
        val eventsPool = listOf(
            WorldEvent(
                id = "oil_discovery",
                titleAr = "اكتشاف حقل غاز ونفط استراتيجي عملاق",
                descAr = "أعلنت هيئة الطاقة المصرية اكتشاف حقل طاقة تاريخي في البحر المتوسط، مما يضاعف مخزون النفط!",
                effectDescAr = "+20,000 برميل نفط و+30,000 سبيكة ذهب",
                iconEmoji = "🛢️",
                oilDelta = 20000L,
                goldDelta = 30000L
            ),
            WorldEvent(
                id = "arms_deal",
                titleAr = "صفقة أسلحة وتحديث دفاعي استراتيجي",
                descAr = "إبرام معاهدة تسليح كبرى ونقل تكنولوجيا تصنيع الرادارات والمدرعات إلى المصانع الحربية المصرية.",
                effectDescAr = "+500 نقطة بحث علمي و+15,000 طن حديد",
                iconEmoji = "🛡️",
                ironDelta = 15000L,
                researchDelta = 500L
            ),
            WorldEvent(
                id = "nile_flood",
                titleAr = "فيضان النيل المبارك وموسم حصاد استثنائي",
                descAr = "تدفق مائي غير مسبوق في بحيرة ناصر ومشاريع توشكى، محققاً طفرة زراعية وأمناً غذائياً كاملاً.",
                effectDescAr = "+40,000 طن قمح وغذاء و+5,000 قوة بشرية",
                iconEmoji = "🌾",
                foodDelta = 40000L
            ),
            WorldEvent(
                id = "global_recession",
                titleAr = "أزمة اقتصادية عالمية وتهاوي عملات الخصوم",
                descAr = "أزمة تضخمية تضرب اقتصادات الأعداء مما يرفع قيمة الجنيه المصري ويزيد إيرادات قناة السويس.",
                effectDescAr = "+50,000 سبيكة ذهب لمصر",
                iconEmoji = "📈",
                goldDelta = 50000L
            )
        )

        val selectedEvent = eventsPool.random()
        soundManager.playMarch()

        _uiState.update { state ->
            val res = state.resources
            val updatedRes = res.copy(
                gold = res.gold + selectedEvent.goldDelta,
                oil = res.oil + selectedEvent.oilDelta,
                iron = res.iron + selectedEvent.ironDelta,
                food = res.food + selectedEvent.foodDelta,
                researchPoints = res.researchPoints + selectedEvent.researchDelta
            )
            state.copy(
                resources = updatedRes,
                activeWorldEvent = selectedEvent,
                gloryPoints = state.gloryPoints + 150L
            )
        }

        addCombatLog(
            message = "حدث عالمي: ${selectedEvent.titleAr} - ${selectedEvent.effectDescAr}",
            type = CombatLogType.ALLIANCE
        )
    }

    fun dismissWorldEvent() {
        soundManager.playClick()
        _uiState.update { it.copy(activeWorldEvent = null) }
    }

    // --- CONTINENTAL WARS & HEGEMONY CLAIM ---
    fun checkContinentalAlliancesAndWars() {
        val state = _uiState.value
        val updatedStatuses = Continent.values().map { cont ->
            val countriesInCont = state.countries.filter { it.continent == cont }
            val conqueredCount = countriesInCont.count { it.isEgypt || it.status == CountryStatus.CONQUERED }
            val currentStatus = state.continentalWarStatuses.find { it.continent == cont }
            ContinentalWarStatus(
                continent = cont,
                leaderCountryId = currentStatus?.leaderCountryId ?: countriesInCont.firstOrNull()?.id ?: "",
                totalTerritories = countriesInCont.size,
                playerConqueredCount = conqueredCount,
                rewardClaimed = currentStatus?.rewardClaimed ?: false
            )
        }

        _uiState.update { it.copy(continentalWarStatuses = updatedStatuses) }
    }

    fun claimContinentalDominanceReward(continent: Continent) {
        val status = _uiState.value.continentalWarStatuses.find { it.continent == continent } ?: return
        if (status.playerConqueredCount < status.totalTerritories || status.rewardClaimed) {
            showNotification("لم يتم توحيد القارة بالكامل بعد!")
            return
        }

        soundManager.playVictoryFanfare()
        val bonusGlory = 1500L
        val bonusGold = 150000L

        _uiState.update { state ->
            val updatedStatuses = state.continentalWarStatuses.map {
                if (it.continent == continent) it.copy(rewardClaimed = true) else it
            }
            state.copy(
                continentalWarStatuses = updatedStatuses,
                gloryPoints = state.gloryPoints + bonusGlory,
                resources = state.resources.copy(gold = state.resources.gold + bonusGold)
            )
        }

        showNotification("🏆 تم تتويج مصر إمبراطورية مهيمنة على قارة ${continent.nameAr}! (+1,500 نقطة مجد و +150,000 ذهب)")
        addCombatLog(
            message = "إعلان تاريخي: بسطت مصر السيادة الإمبراطورية الكاملة على قارة ${continent.nameAr} بأسرها!",
            type = CombatLogType.VICTORY
        )
    }

    fun toggleRecruitOnTerritory(active: Boolean) {
        soundManager.playClick()
        _uiState.update { it.copy(isRecruitingOnTerritory = active) }
    }

    // --- LEGEND MODE: DAILY MISSIONS & STREAK ---
    fun advanceDailyMission(missionTypeKey: String, amount: Int = 1) {
        _uiState.update { state ->
            val updatedMissions = state.dailyMissions.map { m ->
                val matches = when (missionTypeKey) {
                    "conquer" -> m.id == "mission_conquer_3"
                    "battle" -> m.id == "mission_battles_5"
                    "tech" -> m.id == "mission_research_tech"
                    "deploy" -> m.id == "mission_deploy_troops"
                    else -> false
                }
                if (matches && !m.isCompleted) {
                    val newCount = min(m.targetCount, m.currentCount + amount)
                    val isDone = newCount >= m.targetCount
                    if (isDone) {
                        soundManager.playMissionCompletedVoice()
                    }
                    m.copy(currentCount = newCount, isCompleted = isDone)
                } else m
            }
            state.copy(dailyMissions = updatedMissions)
        }
    }

    fun claimDailyMissionReward(missionId: String) {
        val mission = _uiState.value.dailyMissions.find { it.id == missionId } ?: return
        if (!mission.isCompleted || mission.isClaimed) return

        soundManager.playVictoryFanfare()
        _uiState.update { state ->
            val updatedMissions = state.dailyMissions.map {
                if (it.id == missionId) it.copy(isClaimed = true) else it
            }
            val newRes = state.resources.copy(
                gold = state.resources.gold + mission.rewardGold,
                researchPoints = state.resources.researchPoints + mission.rewardTechPoints
            )
            state.copy(
                dailyMissions = updatedMissions,
                resources = newRes,
                gloryPoints = state.gloryPoints + mission.rewardGlory
            )
        }
        showNotification("🎁 تم استلام جائزة المهمة: +${mission.rewardGold} ذهب و +${mission.rewardGlory} مجد!")
    }

    fun claimDailyStreakReward() {
        val currentStreak = _uiState.value.dailyStreak
        if (currentStreak.hasClaimedToday) {
            showNotification("لقد استلمت مكافأة تسجيل الدخول اليومية بالفعل!")
            return
        }

        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val nextDay = if (currentStreak.currentDay >= 7) 1 else currentStreak.currentDay + 1
        val rewardGold = nextDay * 20000L
        val rewardGlory = nextDay * 100L

        soundManager.playVictoryFanfare()
        saveSystem.saveDailyStreak(nextDay, todayStr)

        _uiState.update { state ->
            state.copy(
                dailyStreak = DailyStreak(currentDay = nextDay, lastLoginDate = todayStr, hasClaimedToday = true),
                resources = state.resources.copy(gold = state.resources.gold + rewardGold),
                gloryPoints = state.gloryPoints + rewardGlory
            )
        }
        showNotification("🔥 مكافأة الدخول المتتالي (يوم $nextDay): +$rewardGold ذهب و +$rewardGlory مجد!")
    }

    // --- LEGEND MODE: RANKED LEAGUE SYSTEM ---
    fun addRankPoints(pointsToAdd: Long) {
        val currentInfo = _uiState.value.playerRank
        val newPoints = max(0L, currentInfo.rankPoints + pointsToAdd)
        val newTier = MilitaryRankTier.values()
            .sortedByDescending { it.minPoints }
            .firstOrNull { newPoints >= it.minPoints } ?: MilitaryRankTier.BRONZE

        val oldTier = _uiState.value.currentRankTier
        val hasTierUp = newTier.minPoints > oldTier.minPoints

        saveSystem.saveRankPoints(newPoints)

        _uiState.update { state ->
            state.copy(
                playerRank = currentInfo.copy(rankPoints = newPoints, wins = currentInfo.wins + 1, battles = currentInfo.battles + 1),
                currentRankTier = newTier
            )
        }

        if (hasTierUp) {
            soundManager.playRankUpVoice()
            showNotification("⭐ تهانينا! ترقية استراتيجية إلى تصنيف: ${newTier.titleAr} ${newTier.badgeEmoji}")
        }
    }

    // --- LEGEND MODE: CUSTOMIZATION SKINS ---
    fun equipSkin(skinId: String) {
        soundManager.playClick()
        _uiState.update { state ->
            val targetSkin = state.unitSkins.find { it.id == skinId } ?: return@update state
            val updatedSkins = state.unitSkins.map {
                if (it.unitTypeId == targetSkin.unitTypeId) {
                    it.copy(isEquipped = it.id == skinId)
                } else it
            }
            state.copy(unitSkins = updatedSkins)
        }
        showNotification("تم تفعيل وتجهيز المظهر القتالي بنجاح!")
    }

    fun unlockSkin(skinId: String) {
        val skin = _uiState.value.unitSkins.find { it.id == skinId } ?: return
        if (skin.isUnlocked) return
        if (_uiState.value.resources.gold < skin.costGold) {
            showNotification("الذهب غير كافٍ لشراء هذا المظهر القتالي الأسطوري!")
            return
        }

        soundManager.playVictoryFanfare()
        _uiState.update { state ->
            val updatedSkins = state.unitSkins.map {
                if (it.id == skinId) it.copy(isUnlocked = true, isEquipped = true) else it
            }
            state.copy(
                unitSkins = updatedSkins,
                resources = state.resources.copy(gold = state.resources.gold - skin.costGold)
            )
        }
        showNotification("🎉 تم فتح مظهر ${skin.nameAr} وإضافته لترسانتك العسكرية!")
    }

    // --- LEGEND MODE: SETTINGS ---
    fun updateGraphicsQuality(quality: GraphicsQuality) {
        soundManager.playClick()
        _uiState.update { state ->
            state.copy(gameSettings = state.gameSettings.copy(graphicsQuality = quality))
        }
    }

    fun toggleVibration() {
        soundManager.playClick()
        val newVibe = !_uiState.value.gameSettings.vibrationEnabled
        _uiState.update { state ->
            state.copy(gameSettings = state.gameSettings.copy(vibrationEnabled = newVibe))
        }
    }

    fun updateSettings(newSettings: GameSettings) {
        soundManager.playClick()
        _uiState.update { state ->
            state.copy(gameSettings = newSettings)
        }
        saveSystem.saveSettings(
            quality = newSettings.graphicsQuality.name,
            sfx = newSettings.sfxVolume,
            music = newSettings.musicVolume,
            vibration = newSettings.vibrationEnabled,
            arabic = newSettings.languageArabic
        )
    }

    fun dismissCinematicIntro() {
        soundManager.playCinematicIntroVoice()
        _uiState.update { it.copy(isCinematicActive = false) }
    }

    fun toggleNightVision() {
        soundManager.playClick()
        _uiState.update { it.copy(isNightVisionActive = !it.isNightVisionActive) }
    }

    fun triggerConquestSlowMo(country: Country) {
        soundManager.playConquestVoice()
        _uiState.update { it.copy(conquestSlowMoCountry = country) }
        viewModelScope.launch {
            delay(2800)
            _uiState.update { it.copy(conquestSlowMoCountry = null) }
        }
    }

    fun triggerCinematicIntro() {
        soundManager.playCinematicIntroVoice()
        _uiState.update { it.copy(isCinematicActive = true) }
        viewModelScope.launch {
            delay(3800)
            _uiState.update { it.copy(isCinematicActive = false) }
        }
    }

    fun setGameStateMode(mode: GameStateMode) {
        soundManager.playClick()
        _uiState.update { it.copy(gameStateMode = mode) }
    }

    fun resetNewGame() {
        saveSystem.clearSave()
        loadInitialState()
        showNotification("تمت إعادة تعيين اللعبة وبدء حملة جديدة!")
    }
}

