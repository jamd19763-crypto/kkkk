package com.example.model

enum class Continent(val nameAr: String, val nameEn: String, val colorHex: Long) {
    AFRICA("أفريقيا", "Africa", 0xFFD4AF37),
    ASIA("آسيا", "Asia", 0xFFE65100),
    EUROPE("أوروبا", "Europe", 0xFF1976D2),
    NORTH_AMERICA("أمريكا الشمالية", "North America", 0xFF388E3C),
    SOUTH_AMERICA("أمريكا الجنوبية", "South America", 0xFF00796B),
    OCEANIA("أستراليا وأوقيانوسيا", "Oceania", 0xFF7B1FA2)
}

enum class CountryStatus(val labelAr: String) {
    PLAYER_EGYPT("القيادة المصرية (اللاعب)"),
    CONQUERED("أرض خاضعة للسيادة المصرية"),
    HOSTILE("دولة معادية"),
    ALLIED("دولة حليفة"),
    NEUTRAL("دولة محايدة")
}

enum class AiPersonality(val labelAr: String, val aggressiveness: Float, val alliancePreference: Float) {
    WARMONGER("عدواني عسكري", 0.85f, 0.2f),
    DEFENSIVE("دفاعي حذر", 0.35f, 0.6f),
    ECONOMIC("تجاري دبلوماسي", 0.20f, 0.85f),
    OPPORTUNIST("انتهازي استراتيجي", 0.60f, 0.45f)
}

data class Country(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val flag: String,
    val continent: Continent,
    val normX: Float, // 0f..1f on world map canvas
    val normY: Float, // 0f..1f on world map canvas
    val power: Long,
    val defense: Long,
    val population: Long, // Millions
    val gdpBillion: Long,
    val status: CountryStatus = CountryStatus.NEUTRAL,
    val isEgypt: Boolean = false,
    val garrisonInfantry: Int = 1000,
    val garrisonTanks: Int = 100,
    val rebellionRisk: Float = 0f, // 0.0f..1.0f (rebellion chance in conquered territories)
    val assignedGarrisonUnits: Int = 0, // Egyptian garrisons stationed to suppress unrest
    val aiPersonality: AiPersonality = AiPersonality.DEFENSIVE,
    val neighborIds: List<String> = emptyList()
)

enum class MilitaryUnitType(
    val id: String,
    val nameAr: String,
    val descAr: String,
    val iconEmoji: String,
    val costGold: Long,
    val costOil: Long,
    val costIron: Long,
    val costManpower: Long,
    val attackPower: Long,
    val defensePower: Long,
    val speedKmh: Int,
    val operationalRangeKm: Int,
    val tier: Int = 1
) {
    INFANTRY(
        "infantry",
        "مشاة الصاعقة والمشاة الآلية",
        "العمود الفقري للقوات البرية، اقتحام المدن وتثبيت السيطرة",
        "🪖",
        costGold = 500,
        costOil = 50,
        costIron = 100,
        costManpower = 100,
        attackPower = 150,
        defensePower = 180,
        speedKmh = 40,
        operationalRangeKm = 300
    ),
    TANKS(
        "tanks",
        "دبابات القتال M1A2 أبرامز",
        "رأس الحربة في المعارك البرية، دروع ثقيلة وقوة نيران ساحقة",
        "🛡️",
        costGold = 2500,
        costOil = 300,
        costIron = 800,
        costManpower = 40,
        attackPower = 800,
        defensePower = 950,
        speedKmh = 65,
        operationalRangeKm = 500
    ),
    ARTILLERY(
        "artillery",
        "راجمات صواريخ رعد ومدفعية ميدانية",
        "قصف استراتيجي بعيد المدى وتدمير دفاعات العدو وتحصيناته",
        "💥",
        costGold = 3500,
        costOil = 200,
        costIron = 1000,
        costManpower = 30,
        attackPower = 1200,
        defensePower = 500,
        speedKmh = 50,
        operationalRangeKm = 800
    ),
    FIGHTER_JET(
        "fighter_jet",
        "مقاتلات رافال وسيادة جوية",
        "السيطرة المطلقة على السماء، ضربات جراحية سريعة واعتراض",
        "✈️",
        costGold = 10000,
        costOil = 1500,
        costIron = 2000,
        costManpower = 20,
        attackPower = 3500,
        defensePower = 2000,
        speedKmh = 2200,
        operationalRangeKm = 3500
    ),
    DRONE(
        "drone",
        "طائرات مسيرة انتحارية واستطلاع (30 يونيو)",
        "طائرات بدون طيار لضرب الأهداف الاستراتيجية بدقة فائقة وتكلفة اقتصادية",
        "🛰️",
        costGold = 4000,
        costOil = 400,
        costIron = 600,
        costManpower = 5,
        attackPower = 1600,
        defensePower = 600,
        speedKmh = 350,
        operationalRangeKm = 1200
    ),
    WARSHIP(
        "warship",
        "فرقاطات بحرية وحاملات مروحيات (ميسترال)",
        "فرض السيادة على البحرين المتوسط والأحمر وحماية حقول الغاز",
        "🚢",
        costGold = 18000,
        costOil = 2500,
        costIron = 5000,
        costManpower = 150,
        attackPower = 6000,
        defensePower = 7000,
        speedKmh = 55,
        operationalRangeKm = 8000
    ),
    SUBMARINE(
        "submarine",
        "غواصات هجومية تكتيكية (تايب 209)",
        "سلاح الأعماق الشبح لاصطياد أساطيل العدو وقطع خطوط الإمداد",
        "⚓",
        costGold = 22000,
        costOil = 1800,
        costIron = 6000,
        costManpower = 50,
        attackPower = 8500,
        defensePower = 6000,
        speedKmh = 40,
        operationalRangeKm = 10000
    ),
    BALLISTIC_MISSILE(
        "ballistic_missile",
        "صواريخ باليستية بعيدة المدى",
        "ضربات ردع استراتيجية تدك القواعد العسكرية للعدو في أي قارة",
        "🚀",
        costGold = 35000,
        costOil = 4000,
        costIron = 8000,
        costManpower = 10,
        attackPower = 18000,
        defensePower = 1000,
        speedKmh = 7000,
        operationalRangeKm = 5000
    ),
    NUCLEAR_ICBM(
        "nuclear_icbm",
        "رؤوس نووية باليستية عابرة للقارات",
        "السلاح الفاصل وسلاح الردع الشامل لتحقيق النصر النهائي الحاسم",
        "☢️",
        costGold = 150000,
        costOil = 20000,
        costIron = 35000,
        costManpower = 5,
        attackPower = 150000,
        defensePower = 50000,
        speedKmh = 25000,
        operationalRangeKm = 20000
    )
}

enum class InfrastructureType(
    val id: String,
    val nameAr: String,
    val descAr: String,
    val iconEmoji: String,
    val baseCostGold: Long,
    val baseCostIron: Long,
    val benefitDescAr: String
) {
    WEAPONS_FACTORY(
        "factory",
        "مجمع مصانع الصناعات الدفاعية",
        "إنتاج الذخائر وتصنيع الدروع والأسلحة المتطورة محلياً",
        "🏭",
        baseCostGold = 5000,
        baseCostIron = 1200,
        "+50 حديد/ث، +15% سرعة إنتاج الجيش"
    ),
    AIRBASE(
        "airbase",
        "قواعد ومطارات عسكرية متقدمة",
        "مدارج طائرات محصنة وحظائر تحت الأرض للسيادة الجوية",
        "🛫",
        baseCostGold = 8000,
        baseCostIron = 2000,
        "+300 قوة دفاع جوي، زيادة مدى المقاتلات"
    ),
    NAVAL_PORT(
        "port",
        "ترسانة وموانئ الإسكندرية والبحر الأحمر",
        "بناء الفرقاطات والغواصات والسيطرة على المضائق البحرية",
        "⚓",
        baseCostGold = 10000,
        baseCostIron = 3000,
        "+100 ذهب/ث من التجارة، تسريع صيانة الأسطول"
    ),
    RADAR_STATION(
        "radar",
        "منظومات الرادار والإنذار المبكر",
        "كشف الطائرات والصواريخ المعادية وتأمين سماء الوطن",
        "📡",
        baseCostGold = 7000,
        baseCostIron = 1500,
        "اعتراض ضربات العدو بنسبة 40%، كشف تحركات الخصوم"
    ),
    SUEZ_CANAL(
        "suez_canal",
        "مشروع تطوير قناة السويس وممراتها",
        "أهم ممر ملاحي في العالم، يفرض رسوم عبور ضخمة على تجارة الأمم",
        "🚢",
        baseCostGold = 12000,
        baseCostIron = 2500,
        "+250 ذهب/ث من رسوم الملاحة العالمية"
    ),
    TOURISM_PYRAMIDS(
        "pyramids_tourism",
        "تطوير قطاع السياحة (الأهرامات، الأقصر، المتحف الكبير)",
        "استثمار التاريخ المصري الخالد في جذب ملايين السياح وموارد نقدية ضخمة",
        "🏛️",
        baseCostGold = 6000,
        baseCostIron = 500,
        "+180 ذهب/ث من السياحة، رفع الروح المعنوية"
    ),
    AGRICULTURE_TOSHKA(
        "toshka_farms",
        "مشروع الدلتا الجديدة ومزارع توشكى",
        "استصلاح ملايين الأفدنة لتحقيق الاكتفاء الذاتي من القمح والغذاء",
        "🌾",
        baseCostGold = 4500,
        baseCostIron = 800,
        "+80 غذاء/ث، نمو متسارع في أعداد التجنيد والسكان"
    ),
    OIL_RIGS(
        "oil_rigs",
        "حقل ظهر وحقول نفط الصحراء الغربية",
        "استخراج وتكرير النفط والغاز الطبيعي لتغذية الآليات العسكرية",
        "🛢️",
        baseCostGold = 9000,
        baseCostIron = 2200,
        "+120 نفط/ث، استقلال طاقوي كامل"
    )
}

data class TechItem(
    val id: String,
    val titleAr: String,
    val descAr: String,
    val costResearch: Long,
    val costGold: Long,
    val isUnlocked: Boolean = false,
    val iconEmoji: String,
    val categoryAr: String,
    val attackBonusPercent: Int = 0,
    val defenseBonusPercent: Int = 0,
    val incomeBonusPercent: Int = 0,
    val branch: TechBranch = TechBranch.WARFARE,
    val tier: Int = 1
)

data class GameResources(
    val gold: Long = 500000,
    val oil: Long = 200000,
    val iron: Long = 250000,
    val food: Long = 200000,
    val manpower: Long = 1000000,
    val researchPoints: Long = 25000
)

data class CampaignStage(
    val id: Int,
    val titleAr: String,
    val descAr: String,
    val continent: Continent,
    val targetCountryIds: List<String>,
    val rewardGold: Long,
    val rewardResearch: Long,
    val isCompleted: Boolean = false,
    val isUnlocked: Boolean = false
)

data class CombatLog(
    val id: Long = System.currentTimeMillis(),
    val timestampFormatted: String,
    val messageAr: String,
    val type: CombatLogType
)

enum class CombatLogType {
    VICTORY,
    DEFEAT,
    CONQUEST,
    AIR_STRIKE,
    DIPLOMACY,
    ALLIANCE,
    ENEMY_WAR
}

data class MovingUnit(
    val id: Long = System.nanoTime(),
    val unitType: MilitaryUnitType,
    val startX: Float,
    val startY: Float,
    val targetX: Float,
    val targetY: Float,
    var progress: Float = 0f,
    val targetCountryId: String,
    val speed: Float = 0.035f,
    val isCurvedFlight: Boolean = false, // Curved arc for fighters, bombers & ballistic missiles
    val curveHeight: Float = 0f,
    val isAggressiveInvasion: Boolean = false
)

data class MapExplosion(
    val id: Long = System.nanoTime(),
    val x: Float,
    val y: Float,
    var progress: Float = 0f,
    val isNuke: Boolean = false,
    val debrisCount: Int = 8,
    val shockwaveMaxRadius: Float = 60f
)

data class CombatLaserBeam(
    val id: Long = System.nanoTime(),
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val isEgyptian: Boolean = true,
    var progress: Float = 0f
)

data class ConquestWave(
    val id: Long = System.nanoTime(),
    val centerX: Float,
    val centerY: Float,
    var progress: Float = 0f,
    val targetCountryNameAr: String,
    val targetCountryFlag: String
)

data class CraterMark(
    val id: Long = System.nanoTime(),
    val x: Float,
    val y: Float,
    val isNuclear: Boolean = false,
    var alpha: Float = 1.0f
)

data class TapDamageEffect(
    val id: Long = System.nanoTime(),
    val x: Float,
    val y: Float,
    val damage: Long,
    val isCritical: Boolean = false,
    var alpha: Float = 1.0f
)

/**
 * Represents a stationed/placed military sprite on a specific country or region.
 * Max stack limit is 5 units per territory.
 */
data class PlacedMapUnit(
    val id: Long = System.nanoTime(),
    val countryId: String,
    val unitType: MilitaryUnitType,
    val isEgyptian: Boolean = true,
    val healthPercent: Float = 1.0f,
    val offsetX: Float = 0f, // minor offset inside the territory plaque
    val offsetY: Float = 0f
)

/**
 * Random global world events (Famines, Oil discovery, Arms deals, etc.)
 */
data class WorldEvent(
    val id: String,
    val titleAr: String,
    val descAr: String,
    val effectDescAr: String,
    val iconEmoji: String,
    val goldDelta: Long = 0L,
    val oilDelta: Long = 0L,
    val ironDelta: Long = 0L,
    val foodDelta: Long = 0L,
    val researchDelta: Long = 0L,
    val moraleBoost: Boolean = false
)

/**
 * Continental War status & Hegemony Leader
 */
data class ContinentalWarStatus(
    val continent: Continent,
    val leaderCountryId: String,
    val totalTerritories: Int,
    val playerConqueredCount: Int,
    val rewardClaimed: Boolean = false
)

/**
 * Military Academy General: boosts troop performance in battle
 */
data class MilitaryGeneral(
    val id: String,
    val nameAr: String,
    val titleAr: String,
    val avatarEmoji: String,
    val attackBonusPercent: Int,
    val defenseBonusPercent: Int,
    val specialtyDescAr: String,
    val costGlory: Long,
    val isRecruited: Boolean = false,
    val isAssigned: Boolean = false
)

/**
 * Cabinet Minister: boosts economic and administrative domains
 */
data class CabinetMinister(
    val id: String,
    val nameAr: String,
    val portfolioAr: String, // Defense, Economy, Foreign Affairs, Industry
    val avatarEmoji: String,
    val level: Int = 1, // I, II, III, IV
    val bonusDescriptionAr: String,
    val upgradeCostGold: Long
)

/**
 * Tech Tree Branches: Economy, Warfare, Diplomacy
 */
enum class TechBranch(val titleAr: String, val iconEmoji: String) {
    WARFARE("الحرب والتسليح", "⚔️"),
    ECONOMY("الاقتصاد والتصنيع", "🏭"),
    DIPLOMACY("الدبلوماسية والسيادة", "🌐")
}

/**
 * State Machine Modes for the Grand RTS
 */
enum class GameStateMode {
    CINEMATIC_INTRO,
    MAIN_MENU,
    WORLD_MAP,
    DEPLOYMENT_PREP,
    TACTICAL_BATTLE,
    DIPLOMACY,
    RESEARCH,
    ACADEMY,
    CABINET,
    DAILY_MISSIONS,
    RANKED_LEAGUE,
    CUSTOMIZATION,
    SETTINGS,
    VICTORY
}

/**
 * Tactical Battle Payload passed when attacking a territory
 */
data class TacticalBattlePayload(
    val targetCountry: Country,
    val playerUnits: Map<MilitaryUnitType, Int>,
    val enemyUnits: Map<MilitaryUnitType, Int>,
    val playerTotalPower: Long,
    val enemyTotalPower: Long,
    val terrainTypeAr: String = "سهول وتضاريس صحراوية محصنة",
    val assignedGeneral: MilitaryGeneral? = null
)

/**
 * Daily Missions & 7-Day Login Streak System (PUBG / Free Fire style)
 */
data class DailyMission(
    val id: String,
    val titleAr: String,
    val descAr: String,
    val iconEmoji: String,
    val targetCount: Int,
    val currentCount: Int = 0,
    val rewardGold: Long = 0L,
    val rewardGlory: Long = 0L,
    val rewardTechPoints: Long = 0L,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false
)

data class DailyStreak(
    val currentDay: Int = 1, // 1 to 7
    val lastLoginDate: String = "",
    val hasClaimedToday: Boolean = false
)

/**
 * Ranked Mode & League Tiers (Bronze -> Legend)
 */
enum class MilitaryRankTier(
    val tierId: String,
    val titleAr: String,
    val badgeEmoji: String,
    val minPoints: Long,
    val colorHex: Long
) {
    BRONZE("bronze", "برونزي عسكري", "🥉", 0L, 0xFFCD7F32),
    SILVER("silver", "فضي تكتيكي", "🥈", 500L, 0xFFC0C0C0),
    GOLD("gold", "ذهبي استراتيجي", "🥇", 1500L, 0xFFFFD700),
    PLATINUM("platinum", "بلاتيني النخبة", "🛡️", 3000L, 0xFF00E5FF),
    DIAMOND("diamond", "ماسي القيادة", "💎", 5000L, 0xFF9C27B0),
    MASTER("master", "أستاذ الحرب (سيد المعارك)", "⭐", 8000L, 0xFFFF5722),
    LEGEND("legend", "أسطورة الإمبراطورية المصرية", "👑", 12000L, 0xFFFFD700)
}

data class PlayerRankInfo(
    val rankPoints: Long = 1200L,
    val wins: Int = 12,
    val battles: Int = 15,
    val seasonNumber: Int = 1,
    val seasonDaysRemaining: Int = 18
)

/**
 * Customization (Skins, Camo & Gear with stat bonuses)
 */
enum class SkinRarity(val labelAr: String, val colorHex: Long) {
    COMMON("عادي", 0xFF9E9E9E),
    RARE("نادر", 0xFF2196F3),
    EPIC("ملحمي", 0xFF9C27B0),
    LEGENDARY("أسطوري مصري", 0xFFFFD700)
}

data class UnitSkin(
    val id: String,
    val unitTypeId: String, // infantry, tanks, fighter_jets, etc.
    val nameAr: String,
    val descAr: String,
    val rarity: SkinRarity,
    val bonusAttackPercent: Int = 0,
    val bonusDefensePercent: Int = 0,
    val previewEmoji: String,
    val costGold: Long = 0L,
    val isUnlocked: Boolean = false,
    val isEquipped: Boolean = false
)

/**
 * Settings (Quality, Audio, Haptics, Language)
 */
enum class GraphicsQuality(val labelAr: String) {
    LOW("منخفضة (توفير بطارية)"),
    MEDIUM("متوسطة (متوازنة)"),
    HIGH("عالية (60 إطار/ثانية)"),
    ULTRA("فائقة الجودة (سينمائي)")
}

data class GameSettings(
    val graphicsQuality: GraphicsQuality = GraphicsQuality.HIGH,
    val sfxVolume: Float = 1.0f,
    val musicVolume: Float = 0.8f,
    val vibrationEnabled: Boolean = true,
    val languageArabic: Boolean = true
)



