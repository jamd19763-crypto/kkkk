using System;
using UnityEngine;
using WarOfNations.ScriptableObjects;
using WarOfNations.Map;
using WarOfNations.Combat;

namespace WarOfNations.Units
{
    /// <summary>
    /// وحدة عسكرية مرئية تتحرك على الخريطة كـ Sprite وتطلق نيران مدفعية (Line Renderer)
    /// </summary>
    [RequireComponent(typeof(SpriteRenderer))]
    public class Unit : MonoBehaviour
    {
        [Header("بيانات الوحدة")]
        public UnitData Data;
        public SpriteRenderer IconRenderer;

        [Header("نظام إطلاق النار (Tracer Fire)")]
        public LineRenderer TracerLineRenderer;
        public Color TracerColor = new Color(1f, 0.92f, 0.23f); // أصفر فاقع (Line Renderer)

        private Vector3 _startPosition;
        private Vector3 _targetPosition;
        private CountryRegion _targetRegion;
        private float _progress = 0f;
        private bool _isMoving = false;
        private Action _onArrivalCallback;
        private float _tracerTimer = 0f;

        private void Awake()
        {
            if (IconRenderer == null) IconRenderer = GetComponent<SpriteRenderer>();
            SetupTracerLineRenderer();
        }

        private void SetupTracerLineRenderer()
        {
            if (TracerLineRenderer == null)
            {
                TracerLineRenderer = gameObject.AddComponent<LineRenderer>();
                TracerLineRenderer.startWidth = 0.08f;
                TracerLineRenderer.endWidth = 0.03f;
                TracerLineRenderer.material = new Material(Shader.Find("Sprites/Default"));
                TracerLineRenderer.startColor = TracerColor;
                TracerLineRenderer.endColor = new Color(1f, 0.4f, 0f, 0.8f);
                TracerLineRenderer.positionCount = 2;
                TracerLineRenderer.enabled = false;
                TracerLineRenderer.sortingOrder = 10;
            }
        }

        public void Initialize(UnitData data, Vector3 start, CountryRegion targetRegion, Action onArrival = null)
        {
            Data = data;
            _startPosition = start;
            _targetRegion = targetRegion;
            _targetPosition = (targetRegion != null ? targetRegion.transform.position : start);
            _onArrivalCallback = onArrival;
            _progress = 0f;
            _isMoving = true;

            transform.position = _startPosition;

            // توجيه زاوية حركة الـ Sprite نحو الهدف
            Vector3 dir = (_targetPosition - _startPosition).normalized;
            float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0f, 0f, angle);

            // تحميل صورة الـ Sprite تلقائياً إذا لم تكن معينة
            AssignUnitSprite(data);
        }

        private void AssignUnitSprite(UnitData data)
        {
            if (IconRenderer != null && IconRenderer.sprite == null)
            {
                string resName = (data != null && data.Type == UnitType.FighterJet) ? "JetSprite" : "TankSprite";
                Sprite loaded = Resources.Load<Sprite>(resName);
                if (loaded != null)
                {
                    IconRenderer.sprite = loaded;
                }
                else
                {
                    Texture2D tex = Resources.Load<Texture2D>(resName);
                    if (tex != null)
                    {
                        IconRenderer.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 100f);
                    }
                }
            }
        }

        private void Update()
        {
            if (!_isMoving) return;

            float speed = (Data != null ? Data.MoveSpeed : 3.5f);
            float totalDist = Vector3.Distance(_startPosition, _targetPosition);
            if (totalDist > 0.01f)
            {
                _progress += (speed * Time.deltaTime) / totalDist;
            }
            else
            {
                _progress = 1.0f;
            }

            transform.position = Vector3.Lerp(_startPosition, _targetPosition, _progress);

            // إطلاق طلقات نارية مرئية (Line Renderer) عند الاقتراب من الحدود
            if (_progress > 0.35f && TracerLineRenderer != null)
            {
                _tracerTimer += Time.deltaTime;
                if (_tracerTimer > 0.12f)
                {
                    _tracerTimer = 0f;
                    TracerLineRenderer.enabled = !TracerLineRenderer.enabled;
                    if (TracerLineRenderer.enabled)
                    {
                        TracerLineRenderer.SetPosition(0, transform.position);
                        Vector3 burstEnd = Vector3.Lerp(transform.position, _targetPosition, 0.65f) + (Vector3)(UnityEngine.Random.insideUnitCircle * 0.3f);
                        TracerLineRenderer.SetPosition(1, burstEnd);
                    }
                }
            }

            if (_progress >= 1.0f)
            {
                OnArrivedAtTarget();
            }
        }

        private void OnArrivedAtTarget()
        {
            _isMoving = false;
            if (TracerLineRenderer != null) TracerLineRenderer.enabled = false;

            if (_targetRegion != null)
            {
                long dmg = (Data != null ? Data.AttackPower * 4 : 3500);
                _targetRegion.ReceiveDamage(dmg);

                // إحداث انفجار مرئي واهتزاز شاشة
                if (BattleSystem.Instance != null)
                {
                    BattleSystem.Instance.SpawnExplosion(_targetPosition, isMajor: (Data != null && Data.Type == UnitType.NuclearICBM));
                }

                if (MapCamera.Instance != null)
                {
                    MapCamera.Instance.TriggerScreenShake(0.45f);
                }
            }

            _onArrivalCallback?.Invoke();
            Destroy(gameObject, 0.05f);
        }
    }
}
