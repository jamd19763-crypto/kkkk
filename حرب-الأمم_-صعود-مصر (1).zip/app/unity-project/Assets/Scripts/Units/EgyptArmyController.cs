using UnityEngine;
using WarOfNations.ScriptableObjects;
using WarOfNations.Map;
using WarOfNations.Core;

namespace WarOfNations.Units
{
    public class EgyptArmyController : MonoBehaviour
    {
        public static EgyptArmyController Instance { get; private set; }

        [Header("Egypt Headquarters Location")]
        public Transform EgyptHQTransform;

        [Header("Unit Prefab Reference")]
        public GameObject UnitPrefab;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);
        }

        public bool DispatchUnit(UnitData unitData, CountryRegion targetCountry)
        {
            if (unitData == null || targetCountry == null) return false;

            // Check if resources are sufficient
            if (GameManager.Instance != null)
            {
                bool canAfford = GameManager.Instance.SpendResources(
                    unitData.CostGold,
                    unitData.CostOil,
                    unitData.CostIron,
                    unitData.CostManpower
                );

                if (!canAfford)
                {
                    Debug.LogWarning("الموارد غير كافية لنشر الوحدة!");
                    return false;
                }
            }

            Vector3 startPos = EgyptHQTransform != null ? EgyptHQTransform.position : Vector3.zero;
            GameObject unitObj = Instantiate(UnitPrefab, startPos, Quaternion.identity);
            Unit unit = unitObj.GetComponent<Unit>();

            if (unit != null)
            {
                unit.Initialize(unitData, startPos, targetCountry);
            }

            Debug.Log($"تم تحريك {unitData.UnitNameAr} من مصر صوب {targetCountry.Data.CountryNameAr}!");
            return true;
        }
    }
}
