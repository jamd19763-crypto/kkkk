using UnityEngine;

namespace WarOfNations.ScriptableObjects
{
    public enum UnitType
    {
        Infantry,
        Tank,
        FighterJet,
        Warship,
        RocketLauncher,
        Drone,
        NuclearICBM
    }

    [CreateAssetMenu(fileName = "NewUnitData", menuName = "WarOfNations/UnitData")]
    public class UnitData : ScriptableObject
    {
        [Header("Unit Identity")]
        public string UnitId;
        public string UnitNameAr;
        public UnitType Type;
        public Sprite UnitIcon;
        public GameObject UnitPrefab;

        [Header("Combat Stats")]
        public long AttackPower = 500;
        public long DefensePower = 400;
        public float MoveSpeed = 3.5f;
        public float AttackRange = 1.5f;

        [Header("Costs")]
        public long CostGold = 500;
        public long CostOil = 50;
        public long CostIron = 100;
        public long CostManpower = 250;
    }
}
