using System.Collections.Generic;
using UnityEngine;

namespace WarOfNations.ScriptableObjects
{
    public enum NationContinent
    {
        Africa,
        Asia,
        Europe,
        NorthAmerica,
        SouthAmerica,
        Oceania
    }

    public enum NationAllegiance
    {
        PlayerEgypt,
        ConqueredByEgypt,
        Neutral,
        Allied,
        Hostile
    }

    [CreateAssetMenu(fileName = "NewCountryData", menuName = "WarOfNations/CountryData")]
    public class CountryData : ScriptableObject
    {
        [Header("Geographic & Political Identity")]
        public string CountryId;
        public string CountryNameAr;
        public string CountryNameEn;
        public Sprite FlagSprite;
        public NationContinent Continent;
        public NationAllegiance Allegiance = NationAllegiance.Neutral;
        public bool IsEgypt = false;

        [Header("Defense & Economy")]
        public long MaxDefenseHP = 15000;
        public long CurrentDefenseHP = 15000;
        public long ArmyPower = 5000;
        public long PopulationMillions = 50;
        public long GDPBillion = 100;

        [Header("Strategic Connections")]
        public List<CountryData> NeighboringCountries = new List<CountryData>();
    }
}
