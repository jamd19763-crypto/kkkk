#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using WarOfNations.Core;
using WarOfNations.Map;
using WarOfNations.Units;
using WarOfNations.Combat;
using WarOfNations.UI;

namespace WarOfNations.Editor
{
    /// <summary>
    /// أداة إعداد المشهد التلقائي في Unity (1-Click Scene Setup)
    /// تقوم ببناء هيكل المشهد بالكامل بضغطة زر واحدة من قائمة Unity:
    /// [WarOfNations -> Setup Complete RTS Scene]
    /// </summary>
    public static class RtsSceneBuilder
    {
        [MenuItem("WarOfNations/Setup Complete RTS Scene (تجهيز المشهد بالكامل)", false, 1)]
        public static void BuildRtsScene()
        {
            // 1. الكاميرا الاستراتيجية
            Camera mainCam = Camera.main;
            if (mainCam == null)
            {
                GameObject camObj = new GameObject("Main Camera");
                mainCam = camObj.AddComponent<Camera>();
                camObj.tag = "MainCamera";
            }
            mainCam.orthographic = true;
            mainCam.orthographicSize = 6.5f;
            mainCam.backgroundColor = new Color(0.05f, 0.08f, 0.14f); // أزرق داكن محيطي
            mainCam.transform.position = new Vector3(0f, 0f, -10f);

            MapCamera mapCam = mainCam.GetComponent<MapCamera>();
            if (mapCam == null) mapCam = mainCam.gameObject.AddComponent<MapCamera>();

            // 2. مدير اللعبة والنظام الأساسي
            GameObject coreObj = GameObject.Find("GameCore");
            if (coreObj == null) coreObj = new GameObject("GameCore");

            if (coreObj.GetComponent<GameManager>() == null) coreObj.AddComponent<GameManager>();
            if (coreObj.GetComponent<InputManager>() == null) coreObj.AddComponent<InputManager>();
            if (coreObj.GetComponent<BattleSystem>() == null) coreObj.AddComponent<BattleSystem>();
            if (coreObj.GetComponent<CombatVisualEffects>() == null) coreObj.AddComponent<CombatVisualEffects>();
            if (coreObj.GetComponent<EgyptArmyController>() == null) coreObj.AddComponent<EgyptArmyController>();

            // 3. خريطة العالم والمناطق
            GameObject mapObj = GameObject.Find("WorldMap");
            if (mapObj == null) mapObj = new GameObject("WorldMap");

            WorldMapRenderer wm = mapObj.GetComponent<WorldMapRenderer>();
            if (wm == null) wm = mapObj.AddComponent<WorldMapRenderer>();
            wm.InitializeWorldMapBackground();
            wm.GenerateDefaultCountryRegions();

            Debug.Log("✅ تم تجهيز مشهد حرب الأمم (RTS Landscape Scene) بالكامل بنجاح!");
            EditorUtility.DisplayDialog("نجاح التجهيز", "تم إنشاء كامل عناصر المشهد: الكاميرا الأفقية، خريطة العالم، أقاليم الدول، ونظام المعارك!", "حسناً");
        }
    }
}
#endif
