using UnityEngine;
using WarOfNations.Core;

namespace WarOfNations.Economy
{
    /// <summary>
    /// Collects resources every second with double yield (2x) for Egyptian superpower dominance.
    /// </summary>
    public class EgyptEconomy : MonoBehaviour
    {
        [Header("Economy Settings")]
        public float CollectionIntervalSeconds = 1.0f;
        public float EgyptSuperpowerBonus = 2.0f;

        [Header("Base Yields Per Second")]
        public long BaseGoldYield = 200;
        public long BaseOilYield = 80;
        public long BaseIronYield = 90;
        public long BaseManpowerYield = 50;

        private float _timer = 0f;

        private void Update()
        {
            _timer += Time.deltaTime;
            if (_timer >= CollectionIntervalSeconds)
            {
                _timer = 0f;
                CollectNationalIncome();
            }
        }

        private void CollectNationalIncome()
        {
            if (GameManager.Instance == null || GameManager.Instance.IsPaused) return;

            int conqueredCount = GameManager.Instance.ConqueredCountriesCount;

            long addedGold = (long)((BaseGoldYield + (conqueredCount * 90)) * EgyptSuperpowerBonus);
            long addedOil = (long)((BaseOilYield + (conqueredCount * 40)) * EgyptSuperpowerBonus);
            long addedIron = (long)((BaseIronYield + (conqueredCount * 45)) * EgyptSuperpowerBonus);
            long addedManpower = (long)((BaseManpowerYield + (conqueredCount * 30)) * EgyptSuperpowerBonus);

            GameManager.Instance.Gold += addedGold;
            GameManager.Instance.Oil += addedOil;
            GameManager.Instance.Iron += addedIron;
            GameManager.Instance.Manpower += addedManpower;
        }
    }
}
