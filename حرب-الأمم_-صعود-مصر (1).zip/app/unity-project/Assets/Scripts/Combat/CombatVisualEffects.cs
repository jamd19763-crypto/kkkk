using UnityEngine;

namespace WarOfNations.Combat
{
    /// <summary>
    /// مؤثرات المعارك المرئية (Combat Visual Effects)
    /// تشمل: الانفجارات (Particle System مع دخان ونار)، طلقات المدفعية، والاهتزاز
    /// </summary>
    public class CombatVisualEffects : MonoBehaviour
    {
        public static CombatVisualEffects Instance { get; private set; }

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);
        }

        /// <summary>
        /// توليد انفجار مرئي فوري برمجياً عند موقع الهدف
        /// </summary>
        public void CreateProceduralExplosion(Vector3 position, bool isMajor = false)
        {
            GameObject expObj = new GameObject("Combat_Explosion_FX");
            expObj.transform.position = position;

            ParticleSystem ps = expObj.AddComponent<ParticleSystem>();
            var main = ps.main;
            main.duration = 0.8f;
            main.startLifetime = isMajor ? 0.9f : 0.5f;
            main.startSpeed = isMajor ? 6f : 3.5f;
            main.startSize = isMajor ? 1.2f : 0.6f;
            main.startColor = new ParticleSystem.MinMaxGradient(
                new Color(1f, 0.9f, 0.1f), // نار ذهبية صفراء
                new Color(1f, 0.2f, 0f)    // أحمر ناري
            );
            main.loop = false;
            main.playOnAwake = true;

            var emission = ps.emission;
            emission.rateOverTime = 0;
            emission.SetBursts(new ParticleSystem.Burst[] { new ParticleSystem.Burst(0f, isMajor ? 40 : 20) });

            var shape = ps.shape;
            shape.shapeType = ParticleSystemShapeType.Sphere;
            shape.radius = isMajor ? 0.8f : 0.4f;

            // دخان رمادي يتلاشى
            var col = ps.colorOverLifetime;
            col.enabled = true;
            Gradient grad = new Gradient();
            grad.SetKeys(
                new GradientColorKey[] { new GradientColorKey(Color.yellow, 0.0f), new GradientColorKey(Color.gray, 1.0f) },
                new GradientAlphaKey[] { new GradientAlphaKey(1.0f, 0.0f), new GradientAlphaKey(0.0f, 1.0f) }
            );
            col.color = grad;

            ps.Play();
            Destroy(expObj, 1.5f);
        }
    }
}
