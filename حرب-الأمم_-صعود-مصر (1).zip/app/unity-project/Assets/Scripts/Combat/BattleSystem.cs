using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using WarOfNations.Map;
using WarOfNations.ScriptableObjects;

namespace WarOfNations.Combat
{
    public class BattleSystem : MonoBehaviour
    {
        public static BattleSystem Instance { get; private set; }

        [Header("Effects")]
        public GameObject ExplosionPrefab;
        public GameObject TapSparkPrefab;

        [Header("Audio")]
        public AudioSource CombatAudioSource;
        public AudioClip ArtilleryClip;
        public AudioClip ExplosionClip;
        public AudioClip AirRaidClip;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);
        }

        private void Start()
        {
            StartCoroutine(AiVsAiWarSimulationLoop());
        }

        public void OnRegionTapped(CountryRegion target, bool isCritical)
        {
            if (target == null) return;

            long baseDamage = isCritical ? 3500 : 800;
            target.ReceiveDamage(baseDamage);

            // Screen shake
            if (MapCamera.Instance != null)
            {
                MapCamera.Instance.TriggerScreenShake(isCritical ? 0.7f : 0.25f);
            }

            // Audio
            if (CombatAudioSource != null)
            {
                AudioClip clipToPlay = isCritical ? ExplosionClip : ArtilleryClip;
                if (clipToPlay != null) CombatAudioSource.PlayOneShot(clipToPlay);
            }

            // Visual explosion
            SpawnExplosion(target.transform.position, isMajor: isCritical);
        }

        public void SpawnExplosion(Vector3 position, bool isMajor = false)
        {
            if (ExplosionPrefab != null)
            {
                GameObject exp = Instantiate(ExplosionPrefab, position, Quaternion.identity);
                if (isMajor) exp.transform.localScale *= 2.2f;
                Destroy(exp, 1.2f);
            }
        }

        private IEnumerator AiVsAiWarSimulationLoop()
        {
            while (true)
            {
                yield return new WaitForSeconds(10f);

                // AI nations skirmish in background
                CountryRegion[] regions = FindObjectsOfType<CountryRegion>();
                List<CountryRegion> eligible = new List<CountryRegion>();
                foreach (var r in regions)
                {
                    if (r.Data != null && !r.Data.IsEgypt && r.Data.Allegiance != NationAllegiance.ConqueredByEgypt)
                    {
                        eligible.Add(r);
                    }
                }

                if (eligible.Count >= 2)
                {
                    var c1 = eligible[Random.Range(0, eligible.Count)];
                    var c2 = eligible[Random.Range(0, eligible.Count)];
                    if (c1 != c2)
                    {
                        Debug.Log($"[تقرير استخباراتي]: مناوشات عسكرية حدودية بين {c1.Data.CountryNameAr} و {c2.Data.CountryNameAr}.");
                    }
                }
            }
        }
    }
}
