using System.Collections.Generic;
using UnityEngine;
using WarOfNations.ScriptableObjects;

namespace WarOfNations.Map
{
    /// <summary>
    /// مدير خريطة العالم الاستراتيجية (World Map Renderer)
    /// مسؤول عن تحميل صورة خريطة العالم كخلفية حقيقية،
    /// وتقسيم الخريطة إلى أقاليم جغرافية ومناطق دول باستخدام PolygonCollider2D
    /// </summary>
    public class WorldMapRenderer : MonoBehaviour
    {
        public static WorldMapRenderer Instance { get; private set; }

        [Header("خلفية خريطة العالم")]
        [Tooltip("صورة خريطة العالم الطبيعية (World Map Texture)")]
        public Sprite WorldMapSprite;
        public SpriteRenderer MapBackgroundRenderer;

        [Header("إعدادات الأبعاد والكاميرا")]
        public Vector2 MapWorldSize = new Vector2(36f, 20f); // 16:9 Landscape Dimensions

        [Header("قائمة الأقاليم والدول")]
        public List<CountryRegion> RegisteredRegions = new List<CountryRegion>();

        [Header("Prefab منطقة الدولة")]
        public GameObject CountryRegionPrefab;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            InitializeWorldMapBackground();
        }

        private void Start()
        {
            // إنشاء المناطق والدول الجغرافية إذا لم تكن موجودة مسبقاً في المشهد
            if (RegisteredRegions.Count == 0)
            {
                GenerateDefaultCountryRegions();
            }
        }

        /// <summary>
        /// تحميل خلفية خريطة العالم من المجلد Resources أو استخدام الصورة المحددة
        /// </summary>
        public void InitializeWorldMapBackground()
        {
            if (MapBackgroundRenderer == null)
            {
                GameObject bgObj = new GameObject("WorldMap_Background");
                bgObj.transform.SetParent(transform);
                bgObj.transform.localPosition = Vector3.zero;
                MapBackgroundRenderer = bgObj.AddComponent<SpriteRenderer>();
                MapBackgroundRenderer.sortingOrder = -10; // خلفية اللعبة
            }

            // محاولة قراءة الصورة من Resources إذا لم تكن معينة في المفتش
            if (WorldMapSprite == null)
            {
                Texture2D loadedTex = Resources.Load<Texture2D>("WorldMap");
                if (loadedTex != null)
                {
                    WorldMapSprite = Sprite.Create(
                        loadedTex,
                        new Rect(0, 0, loadedTex.width, loadedTex.height),
                        new Vector2(0.5f, 0.5f),
                        100f
                    );
                    Debug.Log("تم تحميل صورة خريطة العالم بنجاح من Resources/WorldMap!");
                }
                else
                {
                    Debug.LogWarning("لم يتم العثور على Resources/WorldMap - يرجى وضع صورة WorldMap.png في مجلد Assets/Resources/");
                }
            }

            if (WorldMapSprite != null)
            {
                MapBackgroundRenderer.sprite = WorldMapSprite;

                // ضبط الحجم ليتناسب مع 16:9 Landscape بدقة 60 FPS
                float spriteW = WorldMapSprite.bounds.size.x;
                float spriteH = WorldMapSprite.bounds.size.y;
                if (spriteW > 0.1f && spriteH > 0.1f)
                {
                    float scaleX = MapWorldSize.x / spriteW;
                    float scaleY = MapWorldSize.y / spriteH;
                    MapBackgroundRenderer.transform.localScale = new Vector3(scaleX, scaleY, 1f);
                }
            }
        }

        /// <summary>
        /// توليد المناطق الجغرافية الأساسية وحدودها بمقاييس واقعية
        /// </summary>
        public void GenerateDefaultCountryRegions()
        {
            // مواقع تقريبية للدول على خريطة العالم 16:9 المتمركزة عند (0,0)
            CreateRegionOnMap("egypt", "جمهورية مصر العربية", "Egypt", new Vector2(1.8f, 0.5f), true, NationAllegiance.PlayerEgypt, 120000, 105);
            CreateRegionOnMap("libya", "دولة ليبيا", "Libya", new Vector2(-1.2f, 0.6f), false, NationAllegiance.Hostile, 45000, 7);
            CreateRegionOnMap("sudan", "جمهورية السودان", "Sudan", new Vector2(1.7f, -1.8f), false, NationAllegiance.Allied, 35000, 48);
            CreateRegionOnMap("saudi", "المملكة العربية السعودية", "Saudi Arabia", new Vector2(4.2f, 0.3f), false, NationAllegiance.Allied, 95000, 36);
            CreateRegionOnMap("syria", "الجمهورية العربية السورية", "Syria", new Vector2(3.5f, 1.9f), false, NationAllegiance.Allied, 30000, 22);
            CreateRegionOnMap("israel", "الكيان المعادي", "Hostile Entity", new Vector2(2.5f, 1.2f), false, NationAllegiance.Hostile, 85000, 9);
            CreateRegionOnMap("uk", "المملكة المتحدة", "United Kingdom", new Vector2(-1.5f, 4.8f), false, NationAllegiance.Hostile, 110000, 67);
            CreateRegionOnMap("france", "الجمهورية الفرنسية", "France", new Vector2(-0.8f, 3.8f), false, NationAllegiance.Hostile, 105000, 68);
            CreateRegionOnMap("usa", "الولايات المتحدة الأمريكية", "USA", new Vector2(-9.5f, 3.5f), false, NationAllegiance.Hostile, 190000, 335);
            CreateRegionOnMap("russia", "روسيا الاتحادية", "Russia", new Vector2(8.5f, 5.5f), false, NationAllegiance.Neutral, 160000, 144);
            CreateRegionOnMap("china", "جمهورية الصين الشعبية", "China", new Vector2(10.5f, 2.0f), false, NationAllegiance.Neutral, 175000, 1410);
        }

        private void CreateRegionOnMap(
            string id,
            string nameAr,
            string nameEn,
            Vector2 worldPos,
            bool isEgypt,
            NationAllegiance allegiance,
            long defenseHP,
            int population
        )
        {
            GameObject regionObj = new GameObject($"Region_{id}");
            regionObj.transform.SetParent(transform);
            regionObj.transform.position = new Vector3(worldPos.x, worldPos.y, 0f);

            // إضافة كوليدر التفاعل
            PolygonCollider2D polyCollider = regionObj.AddComponent<PolygonCollider2D>();
            // نقاط مضلع افتراضية كحدود مبدئية قابلة للتعديل
            float r = isEgypt ? 1.4f : 1.0f;
            polyCollider.points = new Vector2[]
            {
                new Vector2(-r, -r * 0.6f),
                new Vector2(-r * 0.7f, r * 0.7f),
                new Vector2(r * 0.7f, r * 0.8f),
                new Vector2(r, -r * 0.5f)
            };

            // إضافة المكون المرئي
            SpriteRenderer sr = regionObj.AddComponent<SpriteRenderer>();
            sr.sortingOrder = 1;

            CountryRegion cr = regionObj.AddComponent<CountryRegion>();
            cr.RegionRenderer = sr;

            // بناء بيانات الدولة
            CountryData data = ScriptableObject.CreateInstance<CountryData>();
            data.CountryId = id;
            data.CountryNameAr = nameAr;
            data.CountryNameEn = nameEn;
            data.IsEgypt = isEgypt;
            data.Allegiance = allegiance;
            data.MaxDefenseHP = defenseHP;
            data.CurrentDefenseHP = defenseHP;
            data.PopulationMillion = population;
            data.GDPBillion = population * 4;
            data.Continent = "الشرق الأوسط وأفريقيا";
            cr.Data = data;

            cr.RefreshVisuals();
            RegisteredRegions.Add(cr);
        }

        public CountryRegion GetEgyptRegion()
        {
            return RegisteredRegions.Find(r => r.Data != null && r.Data.IsEgypt);
        }
    }
}
