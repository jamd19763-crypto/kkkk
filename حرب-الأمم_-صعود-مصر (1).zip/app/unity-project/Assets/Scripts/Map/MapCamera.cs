using UnityEngine;
using WarOfNations.Core;

namespace WarOfNations.Map
{
    /// <summary>
    /// Smooth orthographic camera controller for panning and zooming across the 2D World Map.
    /// Supports Screen Shake on explosions and tactical strikes.
    /// </summary>
    public class MapCamera : MonoBehaviour
    {
        public static MapCamera Instance { get; private set; }

        [Header("Camera Zoom Settings")]
        public Camera Cam;
        public float MinOrthoSize = 3.0f;
        public float MaxOrthoSize = 12.0f;
        public float ZoomSmoothSpeed = 10.0f;

        [Header("Camera Pan Bounds")]
        public Vector2 MinBounds = new Vector2(-20f, -12f);
        public Vector2 MaxBounds = new Vector2(20f, 12f);
        public float PanSpeed = 0.015f;

        private float _targetOrthoSize;
        private Vector3 _targetPosition;
        private float _shakeIntensity = 0f;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            if (Cam == null) Cam = GetComponent<Camera>();
            _targetOrthoSize = Cam.orthographicSize;
            _targetPosition = transform.position;
        }

        private void Start()
        {
            if (InputManager.Instance != null)
            {
                InputManager.Instance.OnMapDrag += HandleDrag;
                InputManager.Instance.OnMapPinchZoom += HandleZoom;
            }
        }

        private void OnDestroy()
        {
            if (InputManager.Instance != null)
            {
                InputManager.Instance.OnMapDrag -= HandleDrag;
                InputManager.Instance.OnMapPinchZoom -= HandleZoom;
            }
        }

        private void HandleDrag(Vector2 delta)
        {
            float speedFactor = (Cam.orthographicSize / MaxOrthoSize) * PanSpeed;
            _targetPosition -= new Vector3(delta.x * speedFactor, delta.y * speedFactor, 0f);
            ClampTargetPosition();
        }

        private void HandleZoom(float delta)
        {
            _targetOrthoSize = Mathf.Clamp(_targetOrthoSize - delta, MinOrthoSize, MaxOrthoSize);
        }

        private void ClampTargetPosition()
        {
            _targetPosition.x = Mathf.Clamp(_targetPosition.x, MinBounds.x, MaxBounds.x);
            _targetPosition.y = Mathf.Clamp(_targetPosition.y, MinBounds.y, MaxBounds.y);
        }

        public void TriggerScreenShake(float intensity = 0.5f)
        {
            _shakeIntensity = Mathf.Max(_shakeIntensity, intensity);
        }

        private void LateUpdate()
        {
            // Smooth zoom
            Cam.orthographicSize = Mathf.Lerp(Cam.orthographicSize, _targetOrthoSize, Time.deltaTime * ZoomSmoothSpeed);

            // Screen shake
            Vector3 shakeOffset = Vector3.zero;
            if (_shakeIntensity > 0.01f)
            {
                shakeOffset = new Vector3(
                    Random.Range(-1f, 1f) * _shakeIntensity,
                    Random.Range(-1f, 1f) * _shakeIntensity,
                    0f
                );
                _shakeIntensity = Mathf.Lerp(_shakeIntensity, 0f, Time.deltaTime * 6f);
            }

            // Smooth pan
            transform.position = Vector3.Lerp(transform.position, _targetPosition + shakeOffset, Time.deltaTime * 12f);
        }
    }
}
