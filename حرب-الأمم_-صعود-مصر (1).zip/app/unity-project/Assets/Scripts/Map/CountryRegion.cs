using UnityEngine;
using WarOfNations.ScriptableObjects;
using WarOfNations.Core;
using WarOfNations.Combat;

namespace WarOfNations.Map
{
    [RequireComponent(typeof(PolygonCollider2D), typeof(SpriteRenderer))]
    public class CountryRegion : MonoBehaviour
    {
        [Header("Data")]
        public CountryData Data;

        [Header("Renderers & Colors")]
        public SpriteRenderer RegionRenderer;
        public SpriteRenderer FlagIconRenderer;
        public Color EgyptColor = new Color(0.83f, 0.69f, 0.22f); // Gold
        public Color ConqueredColor = new Color(0.72f, 0.58f, 0.15f); // Conquered Gold
        public Color HostileColor = new Color(0.85f, 0.2f, 0.2f); // Red
        public Color NeutralColor = new Color(0.2f, 0.45f, 0.7f); // Blue
        public Color HighlightBorderColor = Color.green;

        private int _consecutiveTapCount = 0;
        private PolygonCollider2D _collider;

        private void Awake()
        {
            _collider = GetComponent<PolygonCollider2D>();
            if (RegionRenderer == null) RegionRenderer = GetComponent<SpriteRenderer>();
        }

        private void Start()
        {
            RefreshVisuals();
        }

        public void RefreshVisuals()
        {
            if (Data == null) return;

            if (Data.IsEgypt)
            {
                RegionRenderer.color = EgyptColor;
            }
            else if (Data.Allegiance == NationAllegiance.ConqueredByEgypt)
            {
                RegionRenderer.color = ConqueredColor;
            }
            else if (Data.Allegiance == NationAllegiance.Hostile)
            {
                RegionRenderer.color = HostileColor;
            }
            else
            {
                RegionRenderer.color = NeutralColor;
            }
        }

        public void Highlight(bool enable)
        {
            if (enable)
            {
                RegionRenderer.color = Color.Lerp(RegionRenderer.color, Color.white, 0.35f);
            }
            else
            {
                RefreshVisuals();
            }
        }

        private void OnMouseDown()
        {
            if (Data == null || Data.IsEgypt || Data.Allegiance == NationAllegiance.ConqueredByEgypt)
                return;

            _consecutiveTapCount++;
            bool isCriticalStrike = (_consecutiveTapCount % 5 == 0);

            // Trigger Battle System Tap Strike
            if (BattleSystem.Instance != null)
            {
                BattleSystem.Instance.OnRegionTapped(this, isCriticalStrike);
            }
        }

        public void ReceiveDamage(long damage)
        {
            Data.CurrentDefenseHP = Mathf.Max(0, Data.CurrentDefenseHP - damage);

            if (Data.CurrentDefenseHP <= 0)
            {
                LiberateToEgypt();
            }
        }

        public void LiberateToEgypt()
        {
            Data.Allegiance = NationAllegiance.ConqueredByEgypt;
            RefreshVisuals();

            // Screen shake & sound
            if (MapCamera.Instance != null)
            {
                MapCamera.Instance.TriggerScreenShake(0.8f);
            }

            if (GameManager.Instance != null)
            {
                GameManager.Instance.AddConquestLoot(Data.GDPBillion * 250, 6000);
            }

            Debug.Log($"تم بسط السيادة المصرية على {Data.CountryNameAr}!");
        }
    }
}
