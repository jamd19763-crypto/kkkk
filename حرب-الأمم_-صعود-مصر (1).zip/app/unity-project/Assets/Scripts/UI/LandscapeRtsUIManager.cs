using UnityEngine;
using UnityEngine.UI;
using WarOfNations.Core;
using WarOfNations.Map;
using WarOfNations.Units;
using WarOfNations.ScriptableObjects;

namespace WarOfNations.UI
{
    /// <summary>
    /// واجهة المستخدم للعبة RTS في الوضع الأفقي (Landscape UI)
    /// تشمل:
    /// 1. الشريط العلوي (Top Bar): الموارد (ذهب، نفط، حديد، بشر).
    /// 2. الشريط السفلي (Bottom Bar): أزرار الوحدات الكبيرة (مشاة، دبابة، طائرة، سفينة).
    /// 3. لوحة تفاصيل الدولة: تعرض قوة الدولة وزر الهجوم الأحمر الكبير.
    /// </summary>
    public class LandscapeRtsUIManager : MonoBehaviour
    {
        public static LandscapeRtsUIManager Instance { get; private set; }

        [Header("الشريط العلوي (الموارد)")]
        public Text GoldText;
        public Text OilText;
        public Text IronText;
        public Text ManpowerText;

        [Header("الشريط السفلي (أزرار الوحدات العسكرية)")]
        public Button InfantryButton;
        public Button TankButton;
        public Button FighterJetButton;
        public Button WarshipButton;

        [Header("لوحة معلومات الدولة المحددة")]
        public GameObject CountryInfoPanel;
        public Text CountryNameText;
        public Text CountryDetailsText;
        public Slider CountryHPSlider;
        public Button AttackButton;

        [Header("الوحدة المختارة حالياً")]
        public UnitType SelectedUnitType = UnitType.ArmoredDivision;

        private CountryRegion _selectedRegion;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);
        }

        private void Start()
        {
            SetupButtonListeners();
            if (CountryInfoPanel != null) CountryInfoPanel.SetActive(false);
        }

        private void SetupButtonListeners()
        {
            if (InfantryButton != null)
                InfantryButton.onClick.AddListener(() => SelectUnit(UnitType.MechanizedBrigade));

            if (TankButton != null)
                TankButton.onClick.AddListener(() => SelectUnit(UnitType.ArmoredDivision));

            if (FighterJetButton != null)
                FighterJetButton.onClick.AddListener(() => SelectUnit(UnitType.FighterJet));

            if (WarshipButton != null)
                WarshipButton.onClick.AddListener(() => SelectUnit(UnitType.SubmarineFleet));

            if (AttackButton != null)
                AttackButton.onClick.AddListener(OnAttackClicked);
        }

        public void SelectUnit(UnitType unitType)
        {
            SelectedUnitType = unitType;
            Debug.Log($"تم اختيار الوحدة: {unitType}");
        }

        public void ShowCountryInfo(CountryRegion region)
        {
            _selectedRegion = region;
            if (region == null || region.Data == null)
            {
                if (CountryInfoPanel != null) CountryInfoPanel.SetActive(false);
                return;
            }

            if (CountryInfoPanel != null)
            {
                CountryInfoPanel.SetActive(true);

                if (CountryNameText != null)
                    CountryNameText.text = $"{region.Data.CountryNameAr} ({region.Data.CountryNameEn})";

                if (CountryDetailsText != null)
                    CountryDetailsText.text = $"السكان: {region.Data.PopulationMillion}M • الدفاع: {region.Data.CurrentDefenseHP:N0}";

                if (CountryHPSlider != null)
                {
                    CountryHPSlider.maxValue = region.Data.MaxDefenseHP;
                    CountryHPSlider.value = region.Data.CurrentDefenseHP;
                }
            }
        }

        public void OnAttackClicked()
        {
            if (_selectedRegion == null || _selectedRegion.Data == null) return;
            if (_selectedRegion.Data.IsEgypt || _selectedRegion.Data.Allegiance == NationAllegiance.ConqueredByEgypt) return;

            // إرسال الجيش المصري نحو الدولة المختارة
            if (EgyptArmyController.Instance != null)
            {
                EgyptArmyController.Instance.DispatchUnitToTarget(SelectedUnitType, _selectedRegion);
            }
        }

        private void Update()
        {
            UpdateResourceTexts();
        }

        private void UpdateResourceTexts()
        {
            if (GameManager.Instance == null || GameManager.Instance.Economy == null) return;

            var eco = GameManager.Instance.Economy;
            if (GoldText != null) GoldText.text = $"🪙 {eco.Gold:N0}";
            if (OilText != null) OilText.text = $"🛢️ {eco.Oil:N0}";
            if (IronText != null) IronText.text = $"⚙️ {eco.Iron:N0}";
            if (ManpowerText != null) ManpowerText.text = $"👥 {eco.Manpower:N0}";
        }
    }
}
