using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WarOfNations.Core
{
    public enum GameState
    {
        WorldMap,
        TacticalCombat,
        Paused,
        Victory
    }

    /// <summary>
    /// Core Game Manager for "حرب الأمم: صعود مصر"
    /// Manages global game state, speed, Egypt's economy, and event bus.
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Header("Game State")]
        public GameState CurrentState = GameState.WorldMap;
        public float GameSpeed = 1.0f;
        public bool IsPaused = false;

        [Header("Egypt National Resources")]
        public long Gold = 25000;
        public long Oil = 8000;
        public long Iron = 10000;
        public long Manpower = 50000;
        public long ResearchPoints = 500;

        [Header("Egypt Army Multiplier")]
        public float EgyptResourceBonusMultiplier = 2.0f;
        public int ConqueredCountriesCount = 0;

        public event Action<long, long, long, long> OnResourcesUpdated;
        public event Action<GameState> OnGameStateChanged;

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                Application.targetFrameRate = 60;
                Screen.orientation = ScreenOrientation.LandscapeLeft;
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void Start()
        {
            StartCoroutine(ResourceGenerationLoop());
        }

        private IEnumerator ResourceGenerationLoop()
        {
            while (true)
            {
                float delay = IsPaused ? 1.0f : (1.0f / GameSpeed);
                yield return new WaitForSeconds(delay);

                if (!IsPaused)
                {
                    GenerateResources();
                }
            }
        }

        private void GenerateResources()
        {
            // Base generation with 2x Egypt superpower bonus
            long goldGen = (long)((150 + ConqueredCountriesCount * 80) * EgyptResourceBonusMultiplier);
            long oilGen = (long)((50 + ConqueredCountriesCount * 30) * EgyptResourceBonusMultiplier);
            long ironGen = (long)((60 + ConqueredCountriesCount * 35) * EgyptResourceBonusMultiplier);
            long manpowerGen = (long)((40 + ConqueredCountriesCount * 25) * EgyptResourceBonusMultiplier);

            Gold += goldGen;
            Oil += oilGen;
            Iron += ironGen;
            Manpower += manpowerGen;

            OnResourcesUpdated?.Invoke(Gold, Oil, Iron, Manpower);
        }

        public bool SpendResources(long goldCost, long oilCost, long ironCost, long manpowerCost)
        {
            if (Gold >= goldCost && Oil >= oilCost && Iron >= ironCost && Manpower >= manpowerCost)
            {
                Gold -= goldCost;
                Oil -= oilCost;
                Iron -= ironCost;
                Manpower -= manpowerCost;
                OnResourcesUpdated?.Invoke(Gold, Oil, Iron, Manpower);
                return true;
            }
            return false;
        }

        public void AddConquestLoot(long goldLoot, long oilLoot)
        {
            Gold += goldLoot;
            Oil += oilLoot;
            ConqueredCountriesCount++;
            OnResourcesUpdated?.Invoke(Gold, Oil, Iron, Manpower);
        }

        public void SetSpeed(float speed)
        {
            GameSpeed = Mathf.Clamp(speed, 0.5f, 3.0f);
            Time.timeScale = IsPaused ? 0f : GameSpeed;
        }

        public void TogglePause()
        {
            IsPaused = !IsPaused;
            Time.timeScale = IsPaused ? 0f : GameSpeed;
            OnGameStateChanged?.Invoke(IsPaused ? GameState.Paused : CurrentState);
        }
    }
}
