using System;
using UnityEngine;

namespace WarOfNations.Core
{
    /// <summary>
    /// Handles touch and mouse inputs: Tap, Drag (pan), and Pinch-to-zoom for RTS World Map.
    /// </summary>
    public class InputManager : MonoBehaviour
    {
        public static InputManager Instance { get; private set; }

        public event Action<Vector2> OnMapDrag;
        public event Action<float> OnMapPinchZoom;
        public event Action<Vector2> OnWorldTap;

        private Vector2 _lastTouchPos;
        private bool _isDragging = false;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);
        }

        private void Update()
        {
            HandleTouchInput();
            HandleMouseFallback();
        }

        private void HandleTouchInput()
        {
            if (Input.touchCount == 1)
            {
                Touch touch = Input.GetTouch(0);

                if (touch.phase == TouchPhase.Began)
                {
                    _lastTouchPos = touch.position;
                    _isDragging = false;
                }
                else if (touch.phase == TouchPhase.Moved)
                {
                    Vector2 delta = touch.position - _lastTouchPos;
                    if (delta.sqrMagnitude > 25f)
                    {
                        _isDragging = true;
                        OnMapDrag?.Invoke(delta);
                        _lastTouchPos = touch.position;
                    }
                }
                else if (touch.phase == TouchPhase.Ended)
                {
                    if (!_isDragging)
                    {
                        OnWorldTap?.Invoke(touch.position);
                    }
                    _isDragging = false;
                }
            }
            else if (Input.touchCount == 2)
            {
                Touch touch0 = Input.GetTouch(0);
                Touch touch1 = Input.GetTouch(1);

                Vector2 prevPos0 = touch0.position - touch0.deltaPosition;
                Vector2 prevPos1 = touch1.position - touch1.deltaPosition;

                float prevDistance = (prevPos0 - prevPos1).magnitude;
                float currentDistance = (touch0.position - touch1.position).magnitude;

                float zoomDelta = (currentDistance - prevDistance) * 0.01f;
                OnMapPinchZoom?.Invoke(zoomDelta);
            }
        }

        private void HandleMouseFallback()
        {
            if (Input.touchCount > 0) return;

            if (Input.GetMouseButtonDown(0))
            {
                _lastTouchPos = Input.mousePosition;
                _isDragging = false;
            }
            else if (Input.GetMouseButton(0))
            {
                Vector2 delta = (Vector2)Input.mousePosition - _lastTouchPos;
                if (delta.sqrMagnitude > 16f)
                {
                    _isDragging = true;
                    OnMapDrag?.Invoke(delta);
                    _lastTouchPos = Input.mousePosition;
                }
            }
            else if (Input.GetMouseButtonUp(0))
            {
                if (!_isDragging)
                {
                    OnWorldTap?.Invoke(Input.mousePosition);
                }
                _isDragging = false;
            }

            float scroll = Input.GetAxis("Mouse ScrollWheel");
            if (Mathf.Abs(scroll) > 0.01f)
            {
                OnMapPinchZoom?.Invoke(scroll * 2f);
            }
        }
    }
}
