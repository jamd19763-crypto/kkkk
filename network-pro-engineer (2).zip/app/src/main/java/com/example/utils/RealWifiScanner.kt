package com.example.utils

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class LiveWifiAccessPoint(
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val frequencyMhz: Int,
    val channelNumber: Int,
    val securityType: String,
    val signalBars: Int,
    val distanceEstimateMeters: Double,
    val is5GhzOr6Ghz: Boolean
)

object RealWifiScanner {

    @SuppressLint("MissingPermission")
    suspend fun scanSurroundingWifi(context: Context): List<LiveWifiAccessPoint> = withContext(Dispatchers.IO) {
        val resultsList = mutableListOf<LiveWifiAccessPoint>()
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                ?: return@withContext emptyList()

            @Suppress("DEPRECATION")
            try {
                wifiManager.startScan()
            } catch (_: Exception) {}

            val rawResults: List<ScanResult> = wifiManager.scanResults ?: emptyList()

            for (res in rawResults) {
                val rawSsid = res.SSID
                val ssid = if (rawSsid.isNullOrBlank()) "شبكة مخفية (Hidden Network)" else rawSsid
                val bssid = res.BSSID ?: "00:00:00:00:00:00"
                val rssi = res.level
                val freq = res.frequency
                val channel = frequencyToChannel(freq)
                val security = parseCapabilities(res.capabilities ?: "")
                val bars = calculateWifiBars(rssi)
                val distance = calculateDistanceMeters(rssi, freq)
                val isHighBand = freq > 4900

                resultsList.add(
                    LiveWifiAccessPoint(
                        ssid = ssid,
                        bssid = bssid,
                        rssiDbm = rssi,
                        frequencyMhz = freq,
                        channelNumber = channel,
                        securityType = security,
                        signalBars = bars,
                        distanceEstimateMeters = distance,
                        is5GhzOr6Ghz = isHighBand
                    )
                )
            }

            // Sort by strongest signal first
            resultsList.sortByDescending { it.rssiDbm }
        } catch (_: Exception) {}

        resultsList
    }

    private fun frequencyToChannel(freq: Int): Int {
        return when {
            freq in 2412..2484 -> (freq - 2407) / 5
            freq in 5170..5825 -> (freq - 5000) / 5
            freq in 5955..7115 -> (freq - 5950) / 5
            else -> 1
        }
    }

    private fun parseCapabilities(caps: String): String {
        return when {
            caps.contains("WPA3") || caps.contains("SAE") -> "WPA3 Personal (الأحدث والأكثر أماناً)"
            caps.contains("WPA2") -> "WPA2-PSK (قياسي آمن)"
            caps.contains("WPA") -> "WPA (قديم)"
            caps.contains("WEP") -> "WEP (غير آمن ومخترق)"
            else -> "شبكة مفتوحة بدون تشفير (Open)"
        }
    }

    private fun calculateWifiBars(rssi: Int): Int {
        return when {
            rssi >= -55 -> 4
            rssi >= -70 -> 3
            rssi >= -80 -> 2
            rssi >= -90 -> 1
            else -> 0
        }
    }

    private fun calculateDistanceMeters(level: Int, freqMhz: Int): Double {
        val exp = (27.55 - (20 * Math.log10(freqMhz.toDouble())) + Math.abs(level)) / 20.0
        val dist = Math.pow(10.0, exp)
        return String.format(java.util.Locale.US, "%.1f", dist.coerceIn(0.5, 120.0)).toDoubleOrNull() ?: 10.0
    }
}
