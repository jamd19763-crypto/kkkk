package com.example.data.model

data class GovernorateData(
    val id: Int,
    val nameAr: String,
    val nameEn: String,
    val capital: String,
    val population: Long,
    val areaKm2: Double,
    val centersCount: Int,
    val landlinePrefix: String,
    val estimatedTowers: Int,
    val topDistricts: List<String>,
    val centerLat: Double,
    val centerLon: Double
)

object EgyptGeoData {
    const val TOTAL_POPULATION_EGYPT = 106_500_000L
    const val TOTAL_EXPATS = 12_000_000L
    const val TOTAL_ESTIMATED_TOWERS = 48_500

    val GOVERNORATES = listOf(
        GovernorateData(
            id = 1,
            nameAr = "القاهرة",
            nameEn = "Cairo",
            capital = "القاهرة",
            population = 10_450_000L,
            areaKm2 = 3085.0,
            centersCount = 46,
            landlinePrefix = "02",
            estimatedTowers = 6850,
            topDistricts = listOf("مدينة نصر", "مصر الجديدة", "المعادي", "التجمع الخامس", "حلوان", "شبرا", "عين شمس", "الزمالك", "المرج", "المطرية"),
            centerLat = 30.0444,
            centerLon = 31.2357
        ),
        GovernorateData(
            id = 2,
            nameAr = "الجيزة",
            nameEn = "Giza",
            capital = "الجيزة",
            population = 9_520_000L,
            areaKm2 = 13184.0,
            centersCount = 20,
            landlinePrefix = "02",
            estimatedTowers = 5920,
            topDistricts = listOf("الدقي", "العجوزة", "الهرم", "فيصل", "6 أكتوبر", "الشيخ زايد", "البدرشين", "الصف", "العياط", "أوسيم"),
            centerLat = 30.0131,
            centerLon = 31.2089
        ),
        GovernorateData(
            id = 3,
            nameAr = "الشرقية",
            nameEn = "Sharqia",
            capital = "الزقازيق",
            population = 8_020_000L,
            areaKm2 = 4911.0,
            centersCount = 19,
            landlinePrefix = "055",
            estimatedTowers = 4250,
            topDistricts = listOf("الزقازيق", "العاشر من رمضان", "بلبيس", "منيا القمح", "فاقوس", "أبو حماد", "ديرب نجم", "الحسينية", "ههيا"),
            centerLat = 30.5877,
            centerLon = 31.5020
        ),
        GovernorateData(
            id = 4,
            nameAr = "الدقهلية",
            nameEn = "Dakahlia",
            capital = "المنصورة",
            population = 7_150_000L,
            areaKm2 = 3538.0,
            centersCount = 21,
            landlinePrefix = "050",
            estimatedTowers = 3850,
            topDistricts = listOf("المنصورة", "طلخا", "ميت غمر", "دكرنس", "السنبلاوين", "بلقاس", "شربين", "منية النصر", "أجا", "الجمالية"),
            centerLat = 31.0409,
            centerLon = 31.3785
        ),
        GovernorateData(
            id = 5,
            nameAr = "البحيرة",
            nameEn = "Beheira",
            capital = "دمنهور",
            population = 6_950_000L,
            areaKm2 = 9826.0,
            centersCount = 16,
            landlinePrefix = "045",
            estimatedTowers = 3520,
            topDistricts = listOf("دمنهور", "كفر الدوار", "إيتاي البارود", "أبو حمص", "كوم حمادة", "حوش عيسى", "رشيد", "وادي النطرون"),
            centerLat = 31.0343,
            centerLon = 30.4680
        ),
        GovernorateData(
            id = 6,
            nameAr = "القليوبية",
            nameEn = "Qalyubia",
            capital = "بنها",
            population = 6_180_000L,
            areaKm2 = 1124.0,
            centersCount = 11,
            landlinePrefix = "013",
            estimatedTowers = 3210,
            topDistricts = listOf("بنها", "شبرا الخيمة", "قليوب", "الخانكة", "القناطر الخيرية", "طوخ", "شبين القناطر", "كفر شكر"),
            centerLat = 30.4660,
            centerLon = 31.1853
        ),
        GovernorateData(
            id = 7,
            nameAr = "المنيا",
            nameEn = "Minya",
            capital = "المنيا",
            population = 6_350_000L,
            areaKm2 = 32279.0,
            centersCount = 9,
            landlinePrefix = "086",
            estimatedTowers = 2940,
            topDistricts = listOf("المنيا", "ملوي", "مغاغة", "بني مزار", "سمالوط", "أبو قرقاص", "ديرمواس", "مطاي", "العدوة"),
            centerLat = 28.1099,
            centerLon = 30.7503
        ),
        GovernorateData(
            id = 8,
            nameAr = "الإسكندرية",
            nameEn = "Alexandria",
            capital = "الإسكندرية",
            population = 5_580_000L,
            areaKm2 = 2300.0,
            centersCount = 10,
            landlinePrefix = "03",
            estimatedTowers = 3680,
            topDistricts = listOf("سيدي جابر", "سموحة", "المنتزه", "العجمي", "الرمل", "المنشية", "محرم بك", "العامرية", "برج العرب"),
            centerLat = 31.2001,
            centerLon = 29.9187
        ),
        GovernorateData(
            id = 9,
            nameAr = "الغربية",
            nameEn = "Gharbia",
            capital = "طنطا",
            population = 5_430_000L,
            areaKm2 = 1942.0,
            centersCount = 8,
            landlinePrefix = "040",
            estimatedTowers = 2850,
            topDistricts = listOf("طنطا", "المحلة الكبرى", "كفر الزيات", "زفتى", "السنطة", "بسيون", "سمنود", "قطور"),
            centerLat = 30.7865,
            centerLon = 31.0004
        ),
        GovernorateData(
            id = 10,
            nameAr = "سوهاج",
            nameEn = "Sohag",
            capital = "سوهاج",
            population = 5_720_000L,
            areaKm2 = 11022.0,
            centersCount = 12,
            landlinePrefix = "093",
            estimatedTowers = 2650,
            topDistricts = listOf("سوهاج", "طهطا", "جرجا", "أخميم", "المراغة", "البلينا", "المنشاة", "دار السلام", "جهينة"),
            centerLat = 26.5591,
            centerLon = 31.6957
        ),
        GovernorateData(
            id = 11,
            nameAr = "أسيوط",
            nameEn = "Asyut",
            capital = "أسيوط",
            population = 5_120_000L,
            areaKm2 = 25926.0,
            centersCount = 11,
            landlinePrefix = "088",
            estimatedTowers = 2480,
            topDistricts = listOf("أسيوط", "ديروط", "القوصية", "منفلوط", "أبنوب", "الفتح", "أبو تيج", "صدفا", "الغنايم"),
            centerLat = 27.1809,
            centerLon = 31.1837
        ),
        GovernorateData(
            id = 12,
            nameAr = "المنوفية",
            nameEn = "Monufia",
            capital = "شبين الكوم",
            population = 4_730_000L,
            areaKm2 = 2499.0,
            centersCount = 10,
            landlinePrefix = "048",
            estimatedTowers = 2390,
            topDistricts = listOf("شبين الكوم", "منوف", "أشمون", "قويسنا", "تلا", "بركة السبع", "الشهداء", "الباجور", "مدينة السادات"),
            centerLat = 30.5583,
            centerLon = 30.9930
        ),
        GovernorateData(
            id = 13,
            nameAr = "الفيوم",
            nameEn = "Fayoum",
            capital = "الفيوم",
            population = 4_120_000L,
            areaKm2 = 6068.0,
            centersCount = 6,
            landlinePrefix = "084",
            estimatedTowers = 1950,
            topDistricts = listOf("الفيوم", "إطسا", "سنورس", "طامية", "يوسف الصديق", "إبشواي"),
            centerLat = 29.3084,
            centerLon = 30.8428
        ),
        GovernorateData(
            id = 14,
            nameAr = "كفر الشيخ",
            nameEn = "Kafr El Sheikh",
            capital = "كفر الشيخ",
            population = 3_740_000L,
            areaKm2 = 3467.0,
            centersCount = 10,
            landlinePrefix = "047",
            estimatedTowers = 1880,
            topDistricts = listOf("كفر الشيخ", "دسوق", "فوه", "مطوبس", "بيلا", "قلين", "الحامول", "سيدي سالم", "الرياض", "بلطيم"),
            centerLat = 31.1107,
            centerLon = 30.9388
        ),
        GovernorateData(
            id = 15,
            nameAr = "قنا",
            nameEn = "Qena",
            capital = "قنا",
            population = 3_650_000L,
            areaKm2 = 10798.0,
            centersCount = 9,
            landlinePrefix = "096",
            estimatedTowers = 1790,
            topDistricts = listOf("قنا", "نجع حمادي", "قوص", "دشنا", "فرشوط", "أبو تشت", "الوقف", "نقادة"),
            centerLat = 26.1551,
            centerLon = 32.7160
        ),
        GovernorateData(
            id = 16,
            nameAr = "بني سويف",
            nameEn = "Beni Suef",
            capital = "بني سويف",
            population = 3_620_000L,
            areaKm2 = 10954.0,
            centersCount = 7,
            landlinePrefix = "082",
            estimatedTowers = 1680,
            topDistricts = listOf("بني سويف", "الواسطى", "ناصر", "إهناسيا", "ببا", "الفشن", "سمسطا"),
            centerLat = 29.0661,
            centerLon = 31.0994
        ),
        GovernorateData(
            id = 17,
            nameAr = "أسوان",
            nameEn = "Aswan",
            capital = "أسوان",
            population = 1_650_000L,
            areaKm2 = 62726.0,
            centersCount = 5,
            landlinePrefix = "097",
            estimatedTowers = 1240,
            topDistricts = listOf("أسوان", "كوم أمبو", "إدفو", "نصر النوبة", "دراو", "أبو سمبل"),
            centerLat = 24.0889,
            centerLon = 32.8998
        ),
        GovernorateData(
            id = 18,
            nameAr = "دمياط",
            nameEn = "Damietta",
            capital = "دمياط",
            population = 1_620_000L,
            areaKm2 = 910.0,
            centersCount = 5,
            landlinePrefix = "057",
            estimatedTowers = 1150,
            topDistricts = listOf("دمياط", "فارسكور", "الزرقا", "كفر سعد", "رأس البر", "دمياط الجديدة"),
            centerLat = 31.4175,
            centerLon = 31.8144
        ),
        GovernorateData(
            id = 19,
            nameAr = "الإسماعيلية",
            nameEn = "Ismailia",
            capital = "الإسماعيلية",
            population = 1_450_000L,
            areaKm2 = 5067.0,
            centersCount = 7,
            landlinePrefix = "064",
            estimatedTowers = 1180,
            topDistricts = listOf("الإسماعيلية", "التل الكبير", "فايد", "القنطرة غرب", "القنطرة شرق", "أبو صوير", "القصاصين"),
            centerLat = 30.5965,
            centerLon = 32.2715
        ),
        GovernorateData(
            id = 20,
            nameAr = "الأقصر",
            nameEn = "Luxor",
            capital = "الأقصر",
            population = 1_400_000L,
            areaKm2 = 2410.0,
            centersCount = 7,
            landlinePrefix = "095",
            estimatedTowers = 990,
            topDistricts = listOf("الأقصر", "إسنا", "أرمنت", "الطود", "البياضية", "القرنة", "الزينية"),
            centerLat = 25.6872,
            centerLon = 32.6396
        ),
        GovernorateData(
            id = 21,
            nameAr = "بورسعيد",
            nameEn = "Port Said",
            capital = "بورسعيد",
            population = 810_000L,
            areaKm2 = 1345.0,
            centersCount = 8,
            landlinePrefix = "066",
            estimatedTowers = 870,
            topDistricts = listOf("حي الشرق", "حي العرب", "حي المناخ", "حي الضواحي", "بورفؤاد", "حي الزهور", "حي الجنوب"),
            centerLat = 31.2653,
            centerLon = 32.3019
        ),
        GovernorateData(
            id = 22,
            nameAr = "السويس",
            nameEn = "Suez",
            capital = "السويس",
            population = 795_000L,
            areaKm2 = 9002.0,
            centersCount = 5,
            landlinePrefix = "062",
            estimatedTowers = 840,
            topDistricts = listOf("حي السويس", "حي الأربعين", "حي عتاقة", "حي فيصل", "حي الجناين", "العين السخنة"),
            centerLat = 29.9668,
            centerLon = 32.5498
        ),
        GovernorateData(
            id = 23,
            nameAr = "مطروح",
            nameEn = "Matrouh",
            capital = "مرسى مطروح",
            population = 560_000L,
            areaKm2 = 166563.0,
            centersCount = 8,
            landlinePrefix = "046",
            estimatedTowers = 760,
            topDistricts = listOf("مرسى مطروح", "الحمام", "العلمين", "الضبعة", "سيوة", "النجيلة", "سيدي براني", "السلوم"),
            centerLat = 31.3543,
            centerLon = 27.2373
        ),
        GovernorateData(
            id = 24,
            nameAr = "شمال سيناء",
            nameEn = "North Sinai",
            capital = "العريش",
            population = 510_000L,
            areaKm2 = 28992.0,
            centersCount = 6,
            landlinePrefix = "068",
            estimatedTowers = 690,
            topDistricts = listOf("العريش", "بئر العبد", "الشيخ زويد", "رفح", "الحسنة", "نخل"),
            centerLat = 31.1321,
            centerLon = 33.8033
        ),
        GovernorateData(
            id = 25,
            nameAr = "البحر الأحمر",
            nameEn = "Red Sea",
            capital = "الغردقة",
            population = 410_000L,
            areaKm2 = 119099.0,
            centersCount = 7,
            landlinePrefix = "065",
            estimatedTowers = 740,
            topDistricts = listOf("الغردقة", "رأس غارب", "سفاجا", "القصير", "مرسى علم", "شلاتين", "حلايب"),
            centerLat = 27.2579,
            centerLon = 33.8116
        ),
        GovernorateData(
            id = 26,
            nameAr = "الوادي الجديد",
            nameEn = "New Valley",
            capital = "الخارجة",
            population = 275_000L,
            areaKm2 = 440098.0,
            centersCount = 5,
            landlinePrefix = "092",
            estimatedTowers = 460,
            topDistricts = listOf("الخارجة", "الداخلة", "الفرافرة", "باريس", "بلاط"),
            centerLat = 25.4514,
            centerLon = 30.5471
        ),
        GovernorateData(
            id = 27,
            nameAr = "جنوب سيناء",
            nameEn = "South Sinai",
            capital = "طور سيناء",
            population = 125_000L,
            areaKm2 = 31272.0,
            centersCount = 9,
            landlinePrefix = "069",
            estimatedTowers = 590,
            topDistricts = listOf("شرم الشيخ", "طور سيناء", "دهب", "نويبع", "طابا", "راس سدر", "أبو زنيمة", "أبو رديس", "سانت كاترين"),
            centerLat = 28.2364,
            centerLon = 33.6254
        )
    )

    fun findGovernorate(query: String): GovernorateData? {
        val q = query.trim()
        if (q.isEmpty()) return null
        return GOVERNORATES.find {
            it.nameAr.contains(q, ignoreCase = true) ||
            it.nameEn.contains(q, ignoreCase = true) ||
            it.capital.contains(q, ignoreCase = true) ||
            it.topDistricts.any { d -> d.contains(q, ignoreCase = true) }
        }
    }

    fun findGovByLandline(code: String): GovernorateData? {
        val clean = code.trim().removePrefix("+20").removePrefix("20")
        return GOVERNORATES.find { it.landlinePrefix == clean || "0" + clean == it.landlinePrefix }
    }

    fun searchByName(query: String): List<GovernorateData> {
        val q = query.trim()
        if (q.isEmpty()) return GOVERNORATES
        return GOVERNORATES.filter {
            it.nameAr.contains(q, ignoreCase = true) ||
            it.nameEn.contains(q, ignoreCase = true) ||
            it.capital.contains(q, ignoreCase = true) ||
            it.topDistricts.any { d -> d.contains(q, ignoreCase = true) }
        }
    }
}
