package com.example.data.model

/**
 * Complete hardware and system specifications of the user device.
 */
data class DeviceHardwareInfo(
    val manufacturer: String = "Unknown",
    val model: String = "Unknown",
    val brand: String = "Unknown",
    val deviceCode: String = "Unknown",
    val board: String = "Unknown",
    val hardware: String = "Unknown",
    val androidVersion: String = "Unknown",
    val apiLevel: Int = 0,
    val securityPatch: String = "Unknown",
    val buildId: String = "Unknown",
    val kernelVersion: String = "Unknown",
    val totalRamMb: Long = 0,
    val availableRamMb: Long = 0,
    val totalStorageGb: Double = 0.0,
    val availableStorageGb: Double = 0.0,
    val cpuAbi: String = "Unknown",
    val cpuCores: Int = 1,
    val uptimeFormatted: String = "0h 0m"
)

/**
 * Deep, comprehensive network interface, IP, and Wi-Fi diagnostics.
 */
data class DeepNetworkInfo(
    val localIpv4: String = "127.0.0.1",
    val localIpv6: String = "fe80::",
    val publicIp: String = "...",
    val gatewayIp: String = "192.168.1.1",
    val subnetMask: String = "255.255.255.0",
    val primaryDns: String = "8.8.8.8",
    val secondaryDns: String = "8.8.4.4",
    val interfaceName: String = "wlan0",
    val mtuSize: Int = 1500,
    val macAddressStatus: String = "عنوان MAC عشوائي (محمي)",
    val connectionType: String = "واي فاي (Wi-Fi)",
    // Wi-Fi Specific
    val isWifiConnected: Boolean = false,
    val wifiSsid: String = "غير متصل",
    val wifiBssid: String = "00:00:00:00:00:00",
    val wifiRssiDbm: Int = -60,
    val wifiLinkSpeedMbps: Int = 0,
    val wifiFrequencyMhz: Int = 0,
    val wifiBandLabel: String = "2.4 GHz",
    val wifiChannel: Int = 1,
    val wifiStandard: String = "Wi-Fi 5 (802.11ac)",
    // Cellular Specific
    val isCellularConnected: Boolean = false,
    val cellularOperator: String = "فودافون مصر",
    val cellularGeneration: String = "4G LTE",
    val dataState: String = "متصل",
    val roamingState: String = "معطل (محلي)"
)

/**
 * Represents a device discovered on the local Wi-Fi / LAN subnet.
 */
data class LanDevice(
    val ipAddress: String,
    val hostname: String = "جهاز متصل",
    val pingLatencyMs: Long = 0,
    val macAddress: String? = null,
    val vendorName: String = "جهاز شبكة محلي",
    val isCurrentDevice: Boolean = false,
    val isGateway: Boolean = false,
    val openPortsSummary: String = "",
    val deviceCategory: String = "هاتف / حاسوب"
)

/**
 * Result of a DNS benchmark test against high-performance servers.
 */
data class DnsBenchmarkResult(
    val providerName: String,
    val primaryIp: String,
    val dotHostname: String, // For Private DNS
    val latencyMs: Long,
    val status: String,
    val isFastest: Boolean = false,
    val description: String
)

/**
 * State of the interactive security and anti-tracking audit.
 */
data class SecurityAuditState(
    val isPrivateDnsActive: Boolean = false,
    val isVpnActive: Boolean = false,
    val isWifiEncrypted: Boolean = true,
    val wifiSecurityType: String = "WPA2/WPA3",
    val is2gDisabled: Boolean = false,
    val isMacRandomized: Boolean = true,
    val ipLeakRisk: String = "منخفض (آمن)",
    val securityScore: Int = 85
)
