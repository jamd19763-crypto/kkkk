package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.EgyptGeoData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        CellReadingEntity::class,
        GovernorateEntity::class,
        DistrictEntity::class,
        NumberLookupEntity::class,
        FieldMeasurementEntity::class,
        ReportedTowerEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun cellReadingDao(): CellReadingDao
    abstract fun egyptDataDao(): EgyptDataDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "egypt_network_radar_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Prepopulate Egyptian Governorates
                            INSTANCE?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    populateInitialData(database.egyptDataDao())
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance

                // Also ensure prepopulation happens if already opened
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val count = instance.egyptDataDao().getGovernoratesCount()
                        if (count == 0) {
                            populateInitialData(instance.egyptDataDao())
                        }
                    } catch (_: Exception) {}
                }

                instance
            }
        }

        private suspend fun populateInitialData(dao: EgyptDataDao) {
            val govEntities = EgyptGeoData.GOVERNORATES.map { g ->
                GovernorateEntity(
                    id = g.id,
                    nameAr = g.nameAr,
                    nameEn = g.nameEn,
                    capital = g.capital,
                    population = g.population,
                    areaKm2 = g.areaKm2,
                    centersCount = g.centersCount,
                    landlinePrefix = g.landlinePrefix,
                    estimatedTowers = g.estimatedTowers,
                    topDistrictsCsv = g.topDistricts.joinToString(", "),
                    centerLat = g.centerLat,
                    centerLon = g.centerLon
                )
            }
            dao.insertGovernorates(govEntities)

            // Populate sample districts for prominent governorates
            val districtEntities = mutableListOf<DistrictEntity>()
            EgyptGeoData.GOVERNORATES.forEach { gov ->
                gov.topDistricts.forEachIndexed { index, districtName ->
                    val popEst = (gov.population / gov.centersCount).coerceAtLeast(50_000L)
                    val towersEst = (gov.estimatedTowers / gov.centersCount).coerceAtLeast(30)
                    districtEntities.add(
                        DistrictEntity(
                            govId = gov.id,
                            nameAr = districtName,
                            nameEn = districtName,
                            estimatedPopulation = popEst,
                            estimatedTowers = towersEst,
                            approxLat = gov.centerLat + (index * 0.01 - 0.05),
                            approxLon = gov.centerLon + (index * 0.01 - 0.05)
                        )
                    )
                }
            }
            dao.insertDistricts(districtEntities)
        }
    }
}
