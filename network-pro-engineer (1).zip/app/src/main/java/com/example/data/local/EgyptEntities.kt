package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "governorates")
data class GovernorateEntity(
    @PrimaryKey val id: Int,
    val nameAr: String,
    val nameEn: String,
    val capital: String,
    val population: Long,
    val areaKm2: Double,
    val centersCount: Int,
    val landlinePrefix: String,
    val estimatedTowers: Int,
    val topDistrictsCsv: String,
    val centerLat: Double,
    val centerLon: Double
)

@Entity(tableName = "districts")
data class DistrictEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val govId: Int,
    val nameAr: String,
    val nameEn: String,
    val estimatedPopulation: Long,
    val estimatedTowers: Int,
    val approxLat: Double,
    val approxLon: Double
)

@Entity(tableName = "number_lookups")
data class NumberLookupEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phoneNumber: String,
    val operatorName: String,
    val governorate: String,
    val centralOffice: String,
    val estimatedName: String,
    val isMobile: Boolean,
    val lookupTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "field_measurements")
data class FieldMeasurementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val latitude: Double,
    val longitude: Double,
    val rsrp: Int,
    val rsrq: Int,
    val sinr: Double,
    val pci: Int,
    val cellId: Long,
    val band: String,
    val operator: String,
    val networkType: String,
    val signalQuality: String
)

@Entity(tableName = "reported_towers")
data class ReportedTowerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cellId: Long,
    val operatorName: String,
    val bandName: String,
    val frequencyMhz: Double,
    val latitude: Double,
    val longitude: Double,
    val reportedAddress: String,
    val notes: String,
    val timestamp: Long = System.currentTimeMillis()
)
