package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cell_readings")
data class CellReadingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val networkType: String,
    val cellIdDec: Long,
    val cellIdHex: String,
    val tacOrLac: Int,
    val pci: Int,
    val earfcn: Int,
    val bandName: String,
    val frequencyMhz: Double,
    val mcc: String,
    val mnc: String,
    val rsrp: Int,
    val rsrq: Int,
    val rssnr: Double,
    val cqi: Int,
    val asu: Int,
    val signalQuality: String,
    val userLat: Double,
    val userLon: Double,
    val towerLat: Double?,
    val towerLon: Double?,
    val distanceMeters: Double?,
    val distanceMethod: String,
    val operatorName: String,
    val localIp: String
)
