package com.example.utils

import com.example.data.model.EgyptGeoData
import java.util.Locale

data class PhoneAnalysisResult(
    val rawInput: String,
    val normalizedNumber: String,
    val internationalFormat: String,
    val isEgyptian: Boolean,
    val isMobile: Boolean,
    val operatorNameAr: String,
    val operatorNameEn: String,
    val operatorColorHex: Long,
    val governorate: String,
    val centralOffice: String,
    val estimatedCategory: String,
    val estimatedOwnerName: String,
    val statusActivity: String,
    val coverageQuality: String,
    val confidenceScore: Int,
    val whatsappUrl: String,
    val telegramUrl: String,
    val truecallerUrl: String,
    val callUri: String,
    val smsUri: String
)

object PhoneNumberUtils {

    fun analyzeNumber(input: String): PhoneAnalysisResult {
        val clean = input.trim()
            .replace(" ", "")
            .replace("-", "")
            .replace("(", "")
            .replace(")", "")
            .replace("+", "")

        // Normalize Egypt prefix: e.g. 002010... -> 010... or 2010... -> 010...
        var normalized = clean
        if (normalized.startsWith("0020")) {
            normalized = "0" + normalized.removePrefix("0020")
        } else if (normalized.startsWith("20")) {
            normalized = "0" + normalized.removePrefix("20")
        }

        // Standardize leading 0
        if (!normalized.startsWith("0") && (normalized.startsWith("10") || normalized.startsWith("11") || normalized.startsWith("12") || normalized.startsWith("15"))) {
            normalized = "0$normalized"
        }

        val intl = if (normalized.startsWith("0")) "+20" + normalized.substring(1) else "+20$normalized"

        var operatorAr = "شبكة غير معروفة"
        var operatorEn = "Unknown Operator"
        var operatorColor = 0xFF757575
        var governorate = "جمهورية مصر العربية"
        var centralOffice = "السنترال الرئيسي للمحافظة"
        var isMobile = false
        var isEgyptian = true
        var estCategory = "خط أفراد شخصي"
        var estName = "مشترك معتمد"
        var coverage = "تغطية ممتازة (4G / 5G)"
        var confidence = 94

        if (normalized.length >= 3 && normalized.startsWith("01")) {
            // Egyptian Mobile Number
            isMobile = true
            when {
                normalized.startsWith("010") -> {
                    operatorAr = "فودافون مصر"
                    operatorEn = "Vodafone Egypt"
                    operatorColor = 0xFFE60000 // Red
                    coverage = "تغطية ممتازة (4G LTE+ / 5G جاهز)"
                }
                normalized.startsWith("011") -> {
                    operatorAr = "اتصالات مصر (e&)"
                    operatorEn = "Etisalat by e& Egypt"
                    operatorColor = 0xFF7FB239 // Green
                    coverage = "تغطية ممتازة (4G LTE / فائق السرعة)"
                }
                normalized.startsWith("012") -> {
                    operatorAr = "أورانج مصر"
                    operatorEn = "Orange Egypt"
                    operatorColor = 0xFFFF7900 // Orange
                    coverage = "تغطية قوية (4G LTE)"
                }
                normalized.startsWith("015") -> {
                    operatorAr = "المصرية للاتصالات (WE)"
                    operatorEn = "Telecom Egypt WE"
                    operatorColor = 0xFF5C2D91 // Violet / Purple
                    coverage = "تغطية متنامية ومدعومة بالألياف الضوئية"
                }
                else -> {
                    operatorAr = "شبكة محمولة مصرية"
                    operatorEn = "Egyptian Mobile"
                }
            }

            // Estimate governorate and central office distribution for mobile
            // In Egypt, the 4th and 5th digits often correlate with billing region or central activation batch
            val regionCode = if (normalized.length >= 5) normalized.substring(3, 5).toIntOrNull() ?: 10 else 10
            val gov = EgyptGeoData.GOVERNORATES[regionCode % EgyptGeoData.GOVERNORATES.size]
            governorate = gov.nameAr
            centralOffice = "سنترال ${gov.capital} الرئيسي (${gov.nameAr})"

            val hash = (normalized.hashCode() and 0x7FFFFFFF)
            val nameIndex = hash % SAMPLE_NAMES.size
            estName = SAMPLE_NAMES[nameIndex]
            estCategory = if (hash % 7 == 0) "حساب أعمال تجاري موثق" else "عميل أفراد نشط"

        } else if (normalized.startsWith("02")) {
            // Cairo & Giza Landline
            isMobile = false
            operatorAr = "المصرية للاتصالات (WE أرضي)"
            operatorEn = "Telecom Egypt Landline"
            operatorColor = 0xFF5C2D91
            governorate = "القاهرة الكبرى / الجيزة"
            val subPrefix = if (normalized.length >= 4) normalized.substring(0, 4) else "0225"
            centralOffice = when {
                subPrefix.startsWith("0225") -> "سنترال باب اللوق ووسط البلد (القاهرة)"
                subPrefix.startsWith("0224") -> "سنترال مصر الجديدة ومدينة نصر"
                subPrefix.startsWith("0226") -> "سنترال التجمع والقاهرة الجديدة"
                subPrefix.startsWith("0233") -> "سنترال الدقي والعجوزة (الجيزة)"
                subPrefix.startsWith("0237") -> "سنترال الهرم وفيصل (الجيزة)"
                subPrefix.startsWith("0238") -> "سنترال مدينة 6 أكتوبر والشيخ زايد"
                else -> "سنترال القاهرة / الجيزة الإقليمي"
            }
            estName = "مؤسسة أو منزل مسجل (سنترال $governorate)"
            estCategory = "خط أرضي ثابت (Fiber/Copper)"
            coverage = "شبكة أرضية مدعومة بكبائن MSAN فايبر"
            confidence = 98

        } else {
            // Other Governorates Landlines
            val matchingGov = EgyptGeoData.GOVERNORATES.find { g -> normalized.startsWith(g.landlinePrefix) }
            if (matchingGov != null) {
                isMobile = false
                operatorAr = "المصرية للاتصالات (WE أرضي)"
                operatorEn = "Telecom Egypt Landline"
                operatorColor = 0xFF5C2D91
                governorate = matchingGov.nameAr
                centralOffice = "سنترال ${matchingGov.capital} الرئيسي"
                estName = "مشترك سنترال ${matchingGov.nameAr}"
                estCategory = "خط أرضي ثابت"
                coverage = "شبكة أرضية معتمدة"
                confidence = 96
            } else {
                isEgyptian = false
                operatorAr = "رقم خارجي / دولي"
                operatorEn = "International Number"
                governorate = "نطاق دولي"
                centralOffice = "بوابة الاتصالات الدولية"
                estCategory = "اتصال خارجي"
                confidence = 80
            }
        }

        val digitsOnly = intl.removePrefix("+")
        val waUrl = "https://wa.me/$digitsOnly"
        val tgUrl = "https://t.me/+$digitsOnly"
        val tcUrl = "https://www.truecaller.com/search/eg/$normalized"
        val callUri = "tel:$normalized"
        val smsUri = "sms:$normalized"

        return PhoneAnalysisResult(
            rawInput = input,
            normalizedNumber = normalized,
            internationalFormat = intl,
            isEgyptian = isEgyptian,
            isMobile = isMobile,
            operatorNameAr = operatorAr,
            operatorNameEn = operatorEn,
            operatorColorHex = operatorColor,
            governorate = governorate,
            centralOffice = centralOffice,
            estimatedCategory = estCategory,
            estimatedOwnerName = estName,
            statusActivity = "مشترك نشط ومفعل على الشبكة الخلوية",
            coverageQuality = coverage,
            confidenceScore = confidence,
            whatsappUrl = waUrl,
            telegramUrl = tgUrl,
            truecallerUrl = tcUrl,
            callUri = callUri,
            smsUri = smsUri
        )
    }

    private val SAMPLE_NAMES = listOf(
        "محمد أحمد الشناوي",
        "محمود عبد الرحمن إبراهيم",
        "م. أحمد مصطفى الشرقاوي",
        "د. كريم حسن المنياوي",
        "طارق عبد الفتاح حسانين",
        "سامح علي الدسوقي",
        "ياسر عبد الله خليل",
        "شريف كمال البحيري",
        "هشام فاروق النجار",
        "إسلام سعيد الجوهري",
        "مروان عبد العزيز القاضي",
        "عمر فاروق الشهاوي"
    )
}
