package com.example.utils

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.telephony.TelephonyManager
import com.example.data.model.DeepNetworkInfo
import com.example.data.model.DeviceHardwareInfo
import java.io.File
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.NetworkInterface
import java.util.Locale
import java.util.concurrent.TimeUnit

object DeviceHardwareUtils {

    /**
     * Gathers all hardware, memory, storage, and system specifications.
     */
    fun getHardwareInfo(context: Context): DeviceHardwareInfo {
        // Memory / RAM
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)
        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val availRamMb = memInfo.availMem / (1024 * 1024)

        // Internal Storage
        var totalStorageGb = 0.0
        var availStorageGb = 0.0
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val availBlocks = stat.availableBlocksLong
            totalStorageGb = (totalBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0)
            availStorageGb = (availBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0)
        } catch (_: Exception) {
        }

        // Kernel version
        val kernelVersion = System.getProperty("os.version") ?: "Linux Kernel"

        // Uptime
        val uptimeMillis = SystemClock.elapsedRealtime()
        val hours = TimeUnit.MILLISECONDS.toHours(uptimeMillis)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(uptimeMillis) % 60
        val uptimeFormatted = "$hours ساعة و $minutes دقيقة"

        // CPU cores
        val cpuCores = Runtime.getRuntime().availableProcessors()

        return DeviceHardwareInfo(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString() },
            model = Build.MODEL,
            brand = Build.BRAND.uppercase(Locale.US),
            deviceCode = Build.DEVICE,
            board = Build.BOARD,
            hardware = Build.HARDWARE,
            androidVersion = "Android ${Build.VERSION.RELEASE}",
            apiLevel = Build.VERSION.SDK_INT,
            securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Build.VERSION.SECURITY_PATCH else "غير متوفر",
            buildId = Build.DISPLAY,
            kernelVersion = kernelVersion,
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            totalStorageGb = totalStorageGb,
            availableStorageGb = availStorageGb,
            cpuAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a",
            cpuCores = cpuCores,
            uptimeFormatted = uptimeFormatted
        )
    }

    /**
     * Gathers deep network interface, IP, and Wi-Fi diagnostics.
     */
    fun getDeepNetworkInfo(context: Context, publicIp: String = "..."): DeepNetworkInfo {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager

        var localIpv4 = "127.0.0.1"
        var localIpv6 = "fe80::1"
        var gatewayIp = "192.168.1.1"
        var subnetMask = "255.255.255.0"
        var primaryDns = "8.8.8.8"
        var secondaryDns = "8.8.4.4"
        var interfaceName = "wlan0"
        var mtuSize = 1500
        var isWifi = false
        var isCellular = false

        // Extract from active network link properties
        try {
            val activeNetwork = connectivityManager?.activeNetwork
            val caps = connectivityManager?.getNetworkCapabilities(activeNetwork)
            val linkProps = connectivityManager?.getLinkProperties(activeNetwork)

            isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            isCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

            linkProps?.let { lp ->
                interfaceName = lp.interfaceName ?: if (isWifi) "wlan0" else "rmnet_data0"
                mtuSize = lp.mtu.takeIf { it > 0 } ?: 1500

                // Link addresses
                for (linkAddr in lp.linkAddresses) {
                    val addr = linkAddr.address
                    if (!addr.isLoopbackAddress) {
                        if (addr is Inet4Address && localIpv4 == "127.0.0.1") {
                            localIpv4 = addr.hostAddress ?: localIpv4
                            val prefix = linkAddr.prefixLength
                            subnetMask = prefixLengthToSubnetMask(prefix)
                        } else if (addr is Inet6Address && localIpv6 == "fe80::1") {
                            localIpv6 = addr.hostAddress ?: localIpv6
                        }
                    }
                }

                // Routes & Gateway
                for (route in lp.routes) {
                    if (route.isDefaultRoute && route.gateway is Inet4Address) {
                        gatewayIp = route.gateway?.hostAddress ?: gatewayIp
                    }
                }

                // DNS
                val dnsList = lp.dnsServers.filterIsInstance<Inet4Address>()
                if (dnsList.isNotEmpty()) {
                    primaryDns = dnsList[0].hostAddress ?: primaryDns
                    if (dnsList.size > 1) {
                        secondaryDns = dnsList[1].hostAddress ?: secondaryDns
                    }
                }
            }
        } catch (_: Exception) {
        }

        // Fallback local IP if needed
        if (localIpv4 == "127.0.0.1") {
            localIpv4 = NetworkUtils.getLocalIpAddress()
        }

        // Wi-Fi details
        var wifiSsid = "غير متصل"
        var wifiBssid = "00:00:00:00:00:00"
        var wifiRssiDbm = -65
        var wifiLinkSpeedMbps = 0
        var wifiFrequencyMhz = 0
        var wifiBandLabel = "2.4 GHz"
        var wifiChannel = 1
        var wifiStandard = "Wi-Fi 5 (802.11ac)"

        if (isWifi) {
            try {
                val wifiInfo: WifiInfo? = wifiManager?.connectionInfo
                wifiInfo?.let { info ->
                    val rawSsid = info.ssid ?: ""
                    wifiSsid = if (rawSsid.startsWith("\"") && rawSsid.endsWith("\"")) {
                        rawSsid.substring(1, rawSsid.length - 1)
                    } else rawSsid.ifEmpty { "شبكة Wi-Fi متصلة" }

                    wifiBssid = info.bssid ?: "محمي بواسطة النظام"
                    wifiRssiDbm = info.rssi
                    wifiLinkSpeedMbps = info.linkSpeed
                    wifiFrequencyMhz = info.frequency

                    if (wifiFrequencyMhz in 2400..2500) {
                        wifiBandLabel = "2.4 GHz (نطاق واسع التغطية)"
                        wifiChannel = (wifiFrequencyMhz - 2407) / 5
                    } else if (wifiFrequencyMhz in 5000..5900) {
                        wifiBandLabel = "5 GHz (فائق السرعة)"
                        wifiChannel = (wifiFrequencyMhz - 5000) / 5
                    } else if (wifiFrequencyMhz > 5900) {
                        wifiBandLabel = "6 GHz (Wi-Fi 6E/7)"
                        wifiChannel = (wifiFrequencyMhz - 5950) / 5
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        wifiStandard = when (info.wifiStandard) {
                            6 -> "Wi-Fi 6 (802.11ax - حديث فائق السرعة)"
                            5 -> "Wi-Fi 5 (802.11ac)"
                            4 -> "Wi-Fi 4 (802.11n)"
                            8 -> "Wi-Fi 7 (802.11be - الجيل الأحدث)"
                            7 -> "Wi-Fi 6E (نطاق 6 GHz موسع)"
                            else -> "Wi-Fi قياسي"
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        // Cellular details
        val simOperator = telephonyManager?.simOperatorName ?: "شبكة المحمول"
        val isRoaming = telephonyManager?.isNetworkRoaming == true

        return DeepNetworkInfo(
            localIpv4 = localIpv4,
            localIpv6 = localIpv6,
            publicIp = publicIp,
            gatewayIp = gatewayIp,
            subnetMask = subnetMask,
            primaryDns = primaryDns,
            secondaryDns = secondaryDns,
            interfaceName = interfaceName,
            mtuSize = mtuSize,
            macAddressStatus = "عنوان MAC عشوائي مخصص لكل شبكة (MAC Randomization نشط للحماية)",
            connectionType = when {
                isWifi -> "اتصال لاسلكي (Wi-Fi)"
                isCellular -> "بيانات الهاتف المحمول (Cellular Data)"
                else -> "شبكة محلية"
            },
            isWifiConnected = isWifi,
            wifiSsid = wifiSsid,
            wifiBssid = wifiBssid,
            wifiRssiDbm = wifiRssiDbm,
            wifiLinkSpeedMbps = wifiLinkSpeedMbps,
            wifiFrequencyMhz = wifiFrequencyMhz,
            wifiBandLabel = wifiBandLabel,
            wifiChannel = wifiChannel.coerceIn(1, 196),
            wifiStandard = wifiStandard,
            isCellularConnected = isCellular,
            cellularOperator = simOperator.ifEmpty { "شبكة المحمول المصرية" },
            cellularGeneration = "4G LTE / 5G NR",
            dataState = if (isCellular || isWifi) "متصل بالإنترنت" else "غير متصل",
            roamingState = if (isRoaming) "تجوال نشط (Roaming)" else "اتصال محلي (Home Network)"
        )
    }

    private fun prefixLengthToSubnetMask(prefixLength: Int): String {
        val mask = (-1 shl (32 - prefixLength))
        val b1 = (mask shr 24) and 0xff
        val b2 = (mask shr 16) and 0xff
        val b3 = (mask shr 8) and 0xff
        val b4 = mask and 0xff
        return "$b1.$b2.$b3.$b4 (/$prefixLength)"
    }
}
