package com.example.utils

import com.example.data.model.DnsBenchmarkResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

object DnsBenchmarkUtil {

    private val providers = listOf(
        Triple("Cloudflare DNS (الأسرع عالمياً)", "1.1.1.1", "one.one.one.one"),
        Triple("Google Public DNS (الأكثر استقراراً)", "8.8.8.8", "dns.google"),
        Triple("Quad9 (فائق الأمان وحجب التهديدات)", "9.9.9.9", "dns.quad9.net"),
        Triple("AdGuard DNS (حجب الإعلانات والتعقب)", "94.140.14.14", "dns.adguard-dns.com"),
        Triple("OpenDNS (سيسكو Cisco)", "208.67.222.222", "dns.opendns.com"),
        Triple("CleanBrowsing (حماية عائلية)", "185.228.168.168", "family-filter-dns.cleanbrowsing.org")
    )

    /**
     * Benchmarks response latency for all popular DNS providers.
     */
    suspend fun benchmarkDnsServers(): List<DnsBenchmarkResult> = withContext(Dispatchers.IO) {
        coroutineScope {
            val deferredList = providers.map { (name, ip, dotHost) ->
                async {
                    measureDnsLatency(name, ip, dotHost)
                }
            }
            val results = deferredList.awaitAll().sortedBy { it.latencyMs }
            
            // Mark the fastest
            if (results.isNotEmpty()) {
                val minLatency = results.first().latencyMs
                results.mapIndexed { index, item ->
                    if (index == 0 && item.latencyMs < 500) {
                        item.copy(isFastest = true)
                    } else {
                        item
                    }
                }
            } else {
                results
            }
        }
    }

    private fun measureDnsLatency(name: String, ip: String, dotHost: String): DnsBenchmarkResult {
        var totalLatency = 0L
        var successfulPings = 0
        val attempts = 2

        for (i in 1..attempts) {
            val start = System.currentTimeMillis()
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(ip, 53), 400)
                    val elapsed = System.currentTimeMillis() - start
                    totalLatency += elapsed
                    successfulPings++
                }
            } catch (_: Exception) {
            }
        }

        val avgLatency = if (successfulPings > 0) totalLatency / successfulPings else 999L
        val status = when {
            avgLatency < 35 -> "استجابة فائقة السرعة ⚡"
            avgLatency < 75 -> "استجابة ممتازة"
            avgLatency < 150 -> "استجابة مقبولة"
            else -> "بطيء أو غير متاح"
        }

        val desc = when {
            name.contains("Cloudflare") -> "الخيار الأفضل للألعاب (Gaming) وتصفح السوشيال ميديا فائق السرعة في مصر."
            name.contains("Google") -> "الخادم الأكثر استقراراً وموثوقية مع خوادم يوتيوب وجوجل بلاي."
            name.contains("AdGuard") -> "يحجب الإعلانات المزعجة في التطبيقات والمواقع ويوفر حماية قوية من التعقب."
            name.contains("Quad9") -> "يحجب مواقع التصيد والبرمجيات الخبيثة تلقائياً على مستوى الـ DNS."
            else -> "خادم موثوق يسرع حل أسماء النطاقات واستقرار الإنترنت."
        }

        return DnsBenchmarkResult(
            providerName = name,
            primaryIp = ip,
            dotHostname = dotHost,
            latencyMs = avgLatency,
            status = status,
            isFastest = false,
            description = desc
        )
    }
}
