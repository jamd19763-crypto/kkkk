package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.DashboardViewModel
import com.example.ui.components.ApiKeyDialog
import com.example.ui.components.NetScanDialog
import com.example.ui.components.ReportTowerDialog
import com.example.ui.screens.CyberIntelligenceScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DeviceAndLanScreen
import com.example.ui.screens.FieldEngineerScreen
import com.example.ui.screens.HierarchyScreen
import com.example.ui.screens.NetworkBoosterScreen
import com.example.ui.screens.RadarMapScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SignalOrange

class MainActivity : ComponentActivity() {

    private val viewModel: DashboardViewModel by viewModels {
        DashboardViewModel.Factory(NetworkRadarApp.instance.networkRepository)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme(darkTheme = true) {
                // Ensure RTL layout for Arabic interface
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
                    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
                    val isServiceRunning by viewModel.isServiceRunning.collectAsStateWithLifecycle()
                    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
                    val isApiKeyDialogOpen by viewModel.isApiKeyDialogOpen.collectAsStateWithLifecycle()
                    val isNetScanDialogOpen by viewModel.isNetScanDialogOpen.collectAsStateWithLifecycle()
                    val isReportTowerDialogOpen by viewModel.isReportTowerDialogOpen.collectAsStateWithLifecycle()
                    val apiKeyInput by viewModel.apiKeyInput.collectAsStateWithLifecycle()

                    val snackbarHostState = remember { SnackbarHostState() }
                    var selectedTab by remember { mutableIntStateOf(0) }

                    LaunchedEffect(userMessage) {
                        userMessage?.let { msg ->
                            snackbarHostState.showSnackbar(msg)
                            viewModel.dismissMessage()
                        }
                    }

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = Color(0xFF0A0A0E),
                        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                        topBar = {
                            Column {
                                TopAppBar(
                                    title = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .background(EgyptRed, CircleShape)
                                                    .border(1.5.dp, EgyptGold, CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Radar,
                                                    contentDescription = null,
                                                    tint = EgyptGold,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = stringResource(R.string.app_name),
                                                style = MaterialTheme.typography.titleMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 18.sp
                                                ),
                                                color = EgyptWhite
                                            )
                                        }
                                    },
                                    colors = TopAppBarDefaults.topAppBarColors(
                                        containerColor = Color(0xFF121217),
                                        titleContentColor = EgyptWhite
                                    ),
                                    actions = {
                                        // Simulation Mode Toggle
                                        IconButton(onClick = { viewModel.toggleSimulationMode() }) {
                                            Icon(
                                                imageVector = Icons.Default.Science,
                                                contentDescription = "تبديل المحاكاة",
                                                tint = if (telemetry.isSimulated) SignalOrange else Color.Gray
                                            )
                                        }

                                        // API Settings Dialog
                                        IconButton(onClick = { viewModel.openApiKeyDialog() }) {
                                            Icon(
                                                imageVector = Icons.Default.Key,
                                                contentDescription = "إعدادات API",
                                                tint = EgyptGold
                                            )
                                        }

                                        // Refresh Button / Loading indicator
                                        IconButton(
                                            onClick = { viewModel.refreshNow() },
                                            enabled = !isScanning
                                        ) {
                                            if (isScanning) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(18.dp),
                                                    strokeWidth = 2.dp,
                                                    color = EgyptGold
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.Refresh,
                                                    contentDescription = stringResource(R.string.btn_refresh),
                                                    tint = EgyptGold
                                                )
                                            }
                                        }
                                    }
                                )

                                ScrollableTabRow(
                                    selectedTabIndex = selectedTab,
                                    containerColor = Color(0xFF161622),
                                    contentColor = EgyptGold,
                                    edgePadding = 8.dp
                                ) {
                                    Tab(
                                        selected = selectedTab == 0,
                                        onClick = { selectedTab = 0 },
                                        text = { Text("الرادار والبرج", fontSize = 12.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) },
                                        icon = { Icon(Icons.Default.CellTower, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    Tab(
                                        selected = selectedTab == 1,
                                        onClick = { selectedTab = 1 },
                                        text = { Text("الخريطة والتغطية", fontSize = 12.sp, fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) },
                                        icon = { Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    Tab(
                                        selected = selectedTab == 2,
                                        onClick = { selectedTab = 2 },
                                        text = { Text("جهازي والـ IP", fontSize = 12.sp, fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) },
                                        icon = { Icon(Icons.Default.Devices, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    Tab(
                                        selected = selectedTab == 3,
                                        onClick = { selectedTab = 3 },
                                        text = { Text("درع الأمان والاستخبارات", fontSize = 12.sp, fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal) },
                                        icon = { Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    Tab(
                                        selected = selectedTab == 4,
                                        onClick = { selectedTab = 4 },
                                        text = { Text("تقوية الشبكة والنت", fontSize = 12.sp, fontWeight = if (selectedTab == 4) FontWeight.Bold else FontWeight.Normal) },
                                        icon = { Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    Tab(
                                        selected = selectedTab == 5,
                                        onClick = { selectedTab = 5 },
                                        text = { Text("استعلام الأرقام", fontSize = 12.sp, fontWeight = if (selectedTab == 5) FontWeight.Bold else FontWeight.Normal) },
                                        icon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    Tab(
                                        selected = selectedTab == 6,
                                        onClick = { selectedTab = 6 },
                                        text = { Text("وضع المهندس", fontSize = 12.sp, fontWeight = if (selectedTab == 6) FontWeight.Bold else FontWeight.Normal) },
                                        icon = { Icon(Icons.Default.Engineering, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    Tab(
                                        selected = selectedTab == 7,
                                        onClick = { selectedTab = 7 },
                                        text = { Text("دليل مصر", fontSize = 12.sp, fontWeight = if (selectedTab == 7) FontWeight.Bold else FontWeight.Normal) },
                                        icon = { Icon(Icons.Default.LocationCity, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                }
                            }
                        },
                        bottomBar = {
                            NavigationBar(
                                containerColor = Color(0xFF121218)
                            ) {
                                NavigationBarItem(
                                    selected = selectedTab == 0,
                                    onClick = { selectedTab = 0 },
                                    icon = { Icon(Icons.Default.CellTower, contentDescription = null) },
                                    label = { Text("الرادار", fontSize = 10.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EgyptGold,
                                        selectedTextColor = EgyptGold,
                                        indicatorColor = EgyptRed.copy(alpha = 0.25f),
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 1,
                                    onClick = { selectedTab = 1 },
                                    icon = { Icon(Icons.Default.Map, contentDescription = null) },
                                    label = { Text("الخريطة", fontSize = 10.sp, fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EgyptGold,
                                        selectedTextColor = EgyptGold,
                                        indicatorColor = EgyptRed.copy(alpha = 0.25f),
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 2,
                                    onClick = { selectedTab = 2 },
                                    icon = { Icon(Icons.Default.Devices, contentDescription = null) },
                                    label = { Text("جهازي والـ IP", fontSize = 10.sp, fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EgyptGold,
                                        selectedTextColor = EgyptGold,
                                        indicatorColor = EgyptRed.copy(alpha = 0.25f),
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 3,
                                    onClick = { selectedTab = 3 },
                                    icon = { Icon(Icons.Default.Shield, contentDescription = null) },
                                    label = { Text("درع الأمان", fontSize = 10.sp, fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EgyptGold,
                                        selectedTextColor = EgyptGold,
                                        indicatorColor = EgyptRed.copy(alpha = 0.25f),
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 4,
                                    onClick = { selectedTab = 4 },
                                    icon = { Icon(Icons.Default.Speed, contentDescription = null) },
                                    label = { Text("تقوية النت", fontSize = 10.sp, fontWeight = if (selectedTab == 4) FontWeight.Bold else FontWeight.Normal) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EgyptGold,
                                        selectedTextColor = EgyptGold,
                                        indicatorColor = EgyptRed.copy(alpha = 0.25f),
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (selectedTab) {
                                0 -> DashboardScreen(
                                    telemetry = telemetry,
                                    isScanning = isScanning,
                                    isServiceRunning = isServiceRunning,
                                    onRefresh = { viewModel.refreshNow() },
                                    onSaveReading = { viewModel.saveCurrentReading() },
                                    onToggleService = { viewModel.toggleService(this@MainActivity) },
                                    onOpenNetScan = { viewModel.openNetScanDialog() },
                                    onToggleFieldEngineer = { viewModel.toggleFieldEngineerMode() },
                                    onOpenReportTower = { viewModel.openReportTowerDialog() }
                                )
                                1 -> RadarMapScreen(
                                    telemetry = telemetry,
                                    onOpenReportTower = { viewModel.openReportTowerDialog() }
                                )
                                2 -> DeviceAndLanScreen(
                                    viewModel = viewModel
                                )
                                3 -> CyberIntelligenceScreen(
                                    viewModel = viewModel
                                )
                                4 -> NetworkBoosterScreen(
                                    viewModel = viewModel
                                )
                                5 -> SearchScreen(
                                    viewModel = viewModel
                                )
                                6 -> FieldEngineerScreen(
                                    viewModel = viewModel
                                )
                                7 -> HierarchyScreen(
                                    viewModel = viewModel
                                )
                            }
                        }

                        // API Key Dialog
                        ApiKeyDialog(
                            isOpen = isApiKeyDialogOpen,
                            apiKey = apiKeyInput,
                            onKeyChange = { viewModel.updateApiKeyInput(it) },
                            onSave = { viewModel.saveApiKey() },
                            onDismiss = { viewModel.closeApiKeyDialog() }
                        )

                        // NetScan Dialog
                        NetScanDialog(
                            isOpen = isNetScanDialogOpen,
                            networks = telemetry.availableNetworks,
                            onDismiss = { viewModel.closeNetScanDialog() },
                            onLockNetwork = { mccMnc -> viewModel.lockNetwork(mccMnc) }
                        )

                        // Report Tower Dialog
                        ReportTowerDialog(
                            isOpen = isReportTowerDialogOpen,
                            currentLat = telemetry.userLatitude,
                            currentLon = telemetry.userLongitude,
                            onDismiss = { viewModel.closeReportTowerDialog() },
                            onSubmit = { cellId, op, band, freq, lat, lon, addr, notes ->
                                viewModel.reportTower(cellId, op, band, freq, lat, lon, addr, notes)
                            }
                        )
                    }
                }
            }
        }
    }
}
