package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.NetworkRadarApp
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class CellMonitorService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var monitorJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(
                    NetworkRadarApp.NOTIFICATION_ID,
                    createNotification("جاري تهيئة المسح…", 0, "4G LTE")
                )
                startPeriodicMonitoring()
            }
        }
        return START_STICKY
    }

    private fun startPeriodicMonitoring() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            val repository = NetworkRadarApp.instance.networkRepository
            while (isActive) {
                try {
                    val telemetry = repository.refreshTelemetry()
                    val cell = telemetry.servingCell
                    val notif = createNotification(
                        cellId = cell?.cellIdHex ?: "غير متصل",
                        rsrp = cell?.rsrp ?: -120,
                        networkType = cell?.networkType ?: "خلوي"
                    )
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    manager.notify(NetworkRadarApp.NOTIFICATION_ID, notif)
                } catch (_: Exception) {
                }
                delay(5000) // 5-second sampling interval
            }
        }
    }

    private fun createNotification(cellId: String, rsrp: Int, networkType: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, CellMonitorService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val contentText = getString(R.string.notif_content, cellId, rsrp, networkType)

        return NotificationCompat.Builder(this, NetworkRadarApp.NOTIFICATION_CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title, networkType))
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف المراقبة", stopPendingIntent)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        monitorJob?.cancel()
    }

    companion object {
        const val ACTION_START_SERVICE = "ACTION_START_CELL_MONITOR"
        const val ACTION_STOP_SERVICE = "ACTION_STOP_CELL_MONITOR"

        fun start(context: Context) {
            val intent = Intent(context, CellMonitorService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, CellMonitorService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
