package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = TelecomCyan,
    onPrimary = Color(0xFF003640),
    primaryContainer = TelecomBlue,
    onPrimaryContainer = Color(0xFFC7F3FF),
    secondary = Color(0xFF4DD0E1),
    onSecondary = Color(0xFF00363D),
    tertiary = SignalGreen,
    onTertiary = Color(0xFF003915),
    background = TelecomBackground,
    onBackground = Color(0xFFE2E8F0),
    surface = TelecomDarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = TelecomDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFF94A3B8)
)

private val LightColorScheme = lightColorScheme(
    primary = LightTelecomPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC7F3FF),
    onPrimaryContainer = Color(0xFF001F28),
    secondary = LightTelecomSecondary,
    onSecondary = Color.White,
    tertiary = Color(0xFF00897B),
    onTertiary = Color.White,
    background = LightTelecomBackground,
    onBackground = Color(0xFF191C1D),
    surface = LightTelecomSurface,
    onSurface = Color(0xFF191C1D),
    surfaceVariant = LightTelecomSurfaceVariant,
    onSurfaceVariant = Color(0xFF40484C)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to sleek telecom engineering dark theme
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
