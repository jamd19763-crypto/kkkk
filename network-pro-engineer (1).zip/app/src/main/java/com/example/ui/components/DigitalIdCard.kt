package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.SignalGreen
import com.example.utils.PhoneAnalysisResult

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DigitalIdCard(
    analysis: PhoneAnalysisResult,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val opColor = Color(analysis.operatorColorHex)

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EgyptDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, EgyptGold.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Digital Identity Title & Confidence
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(EgyptGold.copy(alpha = 0.15f), CircleShape)
                            .border(1.dp, EgyptGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = EgyptGold,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "بطاقة الهوية الرقمية",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            ),
                            color = EgyptWhite
                        )
                        Text(
                            text = "تحليل السنترال والمشغل في مصر",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFA0A0A0)
                        )
                    }
                }

                // Confidence badge
                Box(
                    modifier = Modifier
                        .background(SignalGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .border(1.dp, SignalGreen, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "دقة ${analysis.confidenceScore}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = SignalGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Phone Numbers & Estimated Name
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF141418), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(opColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = analysis.estimatedOwnerName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = EgyptWhite
                    )
                    Text(
                        text = "${analysis.normalizedNumber} (${analysis.internationalFormat})",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = EgyptGold
                    )
                    Text(
                        text = analysis.estimatedCategory,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF90CAF9)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Metadata Grid: Operator, Central Office, Governorate, Coverage
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF18181F), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                InfoItemRow(
                    label = "المشغل الرسمي:",
                    value = analysis.operatorNameAr,
                    valueColor = opColor
                )
                InfoItemRow(
                    label = "المحافظة التابعة:",
                    value = analysis.governorate,
                    valueColor = EgyptWhite
                )
                InfoItemRow(
                    label = "السنترال المغذي:",
                    value = analysis.centralOffice,
                    valueColor = EgyptGold
                )
                InfoItemRow(
                    label = "حالة النشاط:",
                    value = analysis.statusActivity,
                    valueColor = SignalGreen
                )
                InfoItemRow(
                    label = "تغطية الشبكة:",
                    value = analysis.coverageQuality,
                    valueColor = Color(0xFF80D8FF)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Deep Links Action Buttons
            Text(
                text = "إجراءات الفحص والربط المباشر (Deep Links):",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold
                ),
                color = EgyptGold
            )

            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // WhatsApp
                Button(
                    onClick = { openUri(context, analysis.whatsappUrl) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("واتساب", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                // Telegram
                Button(
                    onClick = { openUri(context, analysis.telegramUrl) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229ED9)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تيليجرام", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                // Truecaller
                Button(
                    onClick = { openUri(context, analysis.truecallerUrl) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0084FF)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("بحث تروكولر", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                // Call
                OutlinedButton(
                    onClick = { openUri(context, analysis.callUri) },
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EgyptGold)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp), tint = EgyptGold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("اتصال", color = EgyptGold, fontSize = 12.sp)
                }

                // SMS
                OutlinedButton(
                    onClick = { openUri(context, analysis.smsUri) },
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray)
                ) {
                    Icon(Icons.Default.Message, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("رسالة", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun InfoItemRow(
    label: String,
    value: String,
    valueColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFAAAAAA)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
            color = valueColor
        )
    }
}

private fun openUri(context: Context, uriString: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString))
        context.startActivity(intent)
    } catch (_: Exception) {}
}
