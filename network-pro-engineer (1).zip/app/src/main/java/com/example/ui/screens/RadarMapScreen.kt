package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NetworkTelemetry
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.OperatorEtisalat
import com.example.ui.theme.OperatorOrange
import com.example.ui.theme.OperatorVodafone
import com.example.ui.theme.OperatorWE
import com.example.ui.theme.SignalDeadZone
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalOrange
import com.example.ui.theme.SignalYellow
import com.example.ui.theme.TelecomCyan
import com.example.utils.NetworkUtils
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

data class SimulatedTower(
    val id: Long,
    val operatorName: String,
    val operatorColor: Color,
    val band: String,
    val freqMhz: Double,
    val pci: Int,
    val distanceMeters: Double,
    val bearingDegrees: Float,
    val signalDbm: Int
)

@Composable
fun RadarMapScreen(
    telemetry: NetworkTelemetry,
    onOpenReportTower: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var zoomScale by remember { mutableFloatStateOf(1.0f) }
    var panOffsetX by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }
    var selectedOperatorFilter by remember { mutableStateOf("الكل") }
    var showHeatmapOverlay by remember { mutableStateOf(true) }
    var selectedTowerDetail by remember { mutableStateOf<SimulatedTower?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "radar_sweep")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweepAngle"
    )

    val pulseRadiusFraction by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )

    // Egyptian towers around the location
    val baseTowers = remember {
        listOf(
            SimulatedTower(28475932L, "فودافون مصر", OperatorVodafone, "Band 3 (1800 MHz)", 1800.0, 284, 380.0, 52f, -76),
            SimulatedTower(28475933L, "فودافون مصر", OperatorVodafone, "Band 1 (2100 MHz)", 2100.0, 285, 620.0, 140f, -84),
            SimulatedTower(19482710L, "أورانج مصر", OperatorOrange, "Band 3 (1800 MHz)", 1800.0, 114, 450.0, 280f, -80),
            SimulatedTower(19482715L, "أورانج مصر", OperatorOrange, "Band 8 (900 MHz)", 900.0, 118, 890.0, 195f, -88),
            SimulatedTower(33819201L, "اتصالات مصر (e&)", OperatorEtisalat, "Band 3 (1800 MHz)", 1800.0, 402, 510.0, 85f, -82),
            SimulatedTower(44901234L, "المصرية للاتصالات (WE)", OperatorWE, "Band 3 (1800 MHz)", 1800.0, 512, 590.0, 320f, -86),
            SimulatedTower(28475990L, "فودافون مصر 5G", OperatorVodafone, "Band n78 (3500 MHz)", 3500.0, 412, 750.0, 15f, -91)
        )
    }

    val visibleTowers = remember(selectedOperatorFilter) {
        if (selectedOperatorFilter == "الكل") baseTowers
        else baseTowers.filter { it.operatorName.contains(selectedOperatorFilter) }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF08080C))
    ) {
        // Radar Canvas with Heatmap Overlay & Dynamic Towers
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        zoomScale = (zoomScale * zoom).coerceIn(0.5f, 4.0f)
                        panOffsetX += pan.x
                        panOffsetY += pan.y
                    }
                }
        ) {
            val center = Offset(size.width / 2f + panOffsetX, size.height / 2f + panOffsetY)
            val maxRadarRadius = (size.minDimension / 2f) * 0.85f * zoomScale

            // Draw Heatmap Overlay Gradient if enabled
            if (showHeatmapOverlay) {
                // High Coverage zone (Green) around center
                drawCircle(
                    brush = Brush.radialGradient(
                        0.0f to SignalGreen.copy(alpha = 0.25f),
                        0.45f to SignalYellow.copy(alpha = 0.15f),
                        0.75f to SignalOrange.copy(alpha = 0.08f),
                        1.0f to Color.Transparent,
                        center = center,
                        radius = maxRadarRadius
                    ),
                    center = center,
                    radius = maxRadarRadius
                )

                // Dead zones / outer fringe
                drawCircle(
                    color = SignalDeadZone.copy(alpha = 0.08f),
                    center = center,
                    radius = maxRadarRadius * 1.25f,
                    style = Stroke(width = 40.dp.toPx())
                )
            }

            // Radar Background Rings (100m, 250m, 500m, 1000m)
            val ringFractions = listOf(0.25f, 0.5f, 0.75f, 1.0f)
            ringFractions.forEach { frac ->
                drawCircle(
                    color = EgyptGold.copy(alpha = 0.22f),
                    radius = maxRadarRadius * frac,
                    center = center,
                    style = Stroke(
                        width = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                )
            }

            // Radar Axis Lines (Crosshairs)
            drawLine(
                color = EgyptGold.copy(alpha = 0.2f),
                start = Offset(center.x - maxRadarRadius, center.y),
                end = Offset(center.x + maxRadarRadius, center.y),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = EgyptGold.copy(alpha = 0.2f),
                start = Offset(center.x, center.y - maxRadarRadius),
                end = Offset(center.x, center.y + maxRadarRadius),
                strokeWidth = 1.dp.toPx()
            )

            // Animated Radar Sweep Hand
            rotate(degrees = sweepAngle, pivot = center) {
                drawLine(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, EgyptGold.copy(alpha = 0.8f))
                    ),
                    start = center,
                    end = Offset(center.x + maxRadarRadius, center.y),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Pulse Wave around user
            drawCircle(
                color = TelecomCyan.copy(alpha = (1f - pulseRadiusFraction) * 0.5f),
                radius = 45.dp.toPx() * pulseRadiusFraction,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // User Location Dot
            drawCircle(
                color = TelecomCyan,
                radius = 7.dp.toPx(),
                center = center
            )
            drawCircle(
                color = EgyptWhite,
                radius = 3.dp.toPx(),
                center = center
            )

            // Plot Visible Cell Towers
            visibleTowers.forEach { tower ->
                val towerDistPx = (tower.distanceMeters / 1000.0 * maxRadarRadius).toFloat()
                val rad = Math.toRadians((tower.bearingDegrees - 90).toDouble())
                val towerOffset = Offset(
                    (center.x + towerDistPx * cos(rad)).toFloat(),
                    (center.y + towerDistPx * sin(rad)).toFloat()
                )

                // Tower Signal Radius
                drawCircle(
                    color = tower.operatorColor.copy(alpha = 0.18f),
                    radius = 28.dp.toPx() * zoomScale,
                    center = towerOffset
                )

                // Tower Vector Point
                drawCircle(
                    color = tower.operatorColor,
                    radius = 7.dp.toPx(),
                    center = towerOffset
                )
                drawCircle(
                    color = EgyptWhite,
                    radius = 2.5.dp.toPx(),
                    center = towerOffset
                )

                // Beam connecting user to serving tower
                if (tower.id == 28475932L) {
                    drawLine(
                        color = EgyptGold.copy(alpha = 0.6f),
                        start = center,
                        end = towerOffset,
                        strokeWidth = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                    )
                }
            }
        }

        // Top Filter Bar & Controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .align(Alignment.TopCenter)
        ) {
            // Governorate and Mode Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14141CCC)),
                border = androidx.compose.foundation.BorderStroke(1.dp, EgyptGold.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(SignalGreen)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "نطاق ${telemetry.currentGovernorate} - ${telemetry.currentDistrict}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = EgyptWhite
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("خريطة التغطية", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                        Spacer(modifier = Modifier.width(6.dp))
                        Switch(
                            checked = showHeatmapOverlay,
                            onCheckedChange = { showHeatmapOverlay = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = EgyptGold,
                                checkedTrackColor = EgyptRed
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Operators Horizontal Scrollable Filter Chips
            val scrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val operators = listOf("الكل", "فودافون", "أورانج", "اتصالات", "المصرية")
                operators.forEach { op ->
                    val isSelected = selectedOperatorFilter == op
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) EgyptRed else Color(0xFF1A1A24))
                            .border(1.dp, if (isSelected) EgyptGold else Color(0xFF333340), RoundedCornerShape(20.dp))
                            .clickable { selectedOperatorFilter = op }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = op,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            ),
                            color = if (isSelected) Color.White else Color.LightGray
                        )
                    }
                }
            }
        }

        // Bottom Details & Legend Area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.BottomCenter)
        ) {
            // Selected Tower Detail Card
            if (selectedTowerDetail != null) {
                val tower = selectedTowerDetail!!
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161620)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tower.operatorColor)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${tower.operatorName} (Cell ID: ${tower.id})",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = EgyptWhite
                            )
                            IconButton(onClick = { selectedTowerDetail = null }) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = Color.Gray)
                            }
                        }
                        Text(
                            text = "${tower.band} | PCI: ${tower.pci} | المسافة: ${NetworkUtils.formatDistance(tower.distanceMeters)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = EgyptGold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Legend Strip
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF121218EE)),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFF2C2C38))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LegendItem(color = SignalGreen, label = "ممتازة (4G/5G)")
                        LegendItem(color = SignalYellow, label = "متوسطة")
                        LegendItem(color = SignalOrange, label = "ضعيفة")
                        LegendItem(color = SignalDeadZone, label = "منطقة ميتة")
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "بيانات الأبراج تعتمد على OpenCellID والمجتمع",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF888888)
                        )

                        Text(
                            text = "تبليغ عن برج ❯",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = EgyptGold,
                            modifier = Modifier.clickable { onOpenReportTower() }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(70.dp))
        }

        // Floating Action Buttons (Recenter & Zoom)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SmallFloatingActionButton(
                onClick = { zoomScale = (zoomScale * 1.25f).coerceAtMost(4.0f) },
                containerColor = Color(0xFF22222E),
                contentColor = EgyptGold
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In")
            }

            SmallFloatingActionButton(
                onClick = { zoomScale = (zoomScale / 1.25f).coerceAtLeast(0.5f) },
                containerColor = Color(0xFF22222E),
                contentColor = EgyptGold
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
            }

            FloatingActionButton(
                onClick = {
                    zoomScale = 1.0f
                    panOffsetX = 0f
                    panOffsetY = 0f
                },
                containerColor = EgyptRed,
                contentColor = Color.White,
                modifier = Modifier.testTag("btn_recenter")
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = "Recenter")
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color.LightGray, fontSize = 10.sp)
    }
}
