package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.CellReadingEntity
import com.example.data.local.FieldMeasurementEntity
import com.example.data.local.GovernorateEntity
import com.example.data.local.NumberLookupEntity
import com.example.data.model.AvailableNetwork
import com.example.data.model.DeepNetworkInfo
import com.example.data.model.DeviceHardwareInfo
import com.example.data.model.DnsBenchmarkResult
import com.example.data.model.LanDevice
import com.example.data.model.NetworkTelemetry
import com.example.data.model.SecurityAuditState
import com.example.data.repository.NetworkRepository
import com.example.service.CellMonitorService
import com.example.utils.DeviceHardwareUtils
import com.example.utils.DnsBenchmarkUtil
import com.example.utils.LanScanner
import com.example.utils.PhoneAnalysisResult
import com.example.utils.PhoneNumberUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DashboardViewModel(
    val repository: NetworkRepository
) : ViewModel() {

    val telemetry: StateFlow<NetworkTelemetry> = repository.telemetryState

    // Device & Hardware Specs
    private val _hardwareInfo = MutableStateFlow(DeviceHardwareUtils.getHardwareInfo(repository.context))
    val hardwareInfo: StateFlow<DeviceHardwareInfo> = _hardwareInfo.asStateFlow()

    // Deep Network & IP Info
    private val _deepNetworkInfo = MutableStateFlow(
        DeviceHardwareUtils.getDeepNetworkInfo(repository.context, repository.telemetryState.value.publicIp)
    )
    val deepNetworkInfo: StateFlow<DeepNetworkInfo> = _deepNetworkInfo.asStateFlow()

    // LAN / Subnet Devices
    private val _lanDevices = MutableStateFlow<List<LanDevice>>(emptyList())
    val lanDevices: StateFlow<List<LanDevice>> = _lanDevices.asStateFlow()

    private val _isScanningLan = MutableStateFlow(false)
    val isScanningLan: StateFlow<Boolean> = _isScanningLan.asStateFlow()

    private val _lanScanProgress = MutableStateFlow(Pair(0, 254))
    val lanScanProgress: StateFlow<Pair<Int, Int>> = _lanScanProgress.asStateFlow()

    // DNS Benchmark
    private val _dnsBenchmarkResults = MutableStateFlow<List<DnsBenchmarkResult>>(emptyList())
    val dnsBenchmarkResults: StateFlow<List<DnsBenchmarkResult>> = _dnsBenchmarkResults.asStateFlow()

    private val _isBenchmarkingDns = MutableStateFlow(false)
    val isBenchmarkingDns: StateFlow<Boolean> = _isBenchmarkingDns.asStateFlow()

    // Security Audit State
    private val _securityAuditState = MutableStateFlow(
        SecurityAuditState(
            isPrivateDnsActive = false,
            isVpnActive = false,
            isWifiEncrypted = true,
            wifiSecurityType = "WPA2/WPA3 Personal",
            is2gDisabled = false,
            isMacRandomized = true,
            ipLeakRisk = "منخفض (آمن)",
            securityScore = 85
        )
    )
    val securityAuditState: StateFlow<SecurityAuditState> = _securityAuditState.asStateFlow()

    val historyList: StateFlow<List<CellReadingEntity>> = repository.historyReadings
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val fieldMeasurements: StateFlow<List<FieldMeasurementEntity>> = repository.fieldMeasurements
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val numberLookups: StateFlow<List<NumberLookupEntity>> = repository.egyptDataDao.getNumberLookups()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val governoratesList: StateFlow<List<GovernorateEntity>> = repository.egyptDataDao.getAllGovernorates()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    private val _isApiKeyDialogOpen = MutableStateFlow(false)
    val isApiKeyDialogOpen: StateFlow<Boolean> = _isApiKeyDialogOpen.asStateFlow()

    private val _isNetScanDialogOpen = MutableStateFlow(false)
    val isNetScanDialogOpen: StateFlow<Boolean> = _isNetScanDialogOpen.asStateFlow()

    private val _isReportTowerDialogOpen = MutableStateFlow(false)
    val isReportTowerDialogOpen: StateFlow<Boolean> = _isReportTowerDialogOpen.asStateFlow()

    private val _apiKeyInput = MutableStateFlow(repository.openCellIdApiKey)
    val apiKeyInput: StateFlow<String> = _apiKeyInput.asStateFlow()

    private val _phoneSearchQuery = MutableStateFlow("")
    val phoneSearchQuery: StateFlow<String> = _phoneSearchQuery.asStateFlow()

    private val _currentPhoneAnalysis = MutableStateFlow<PhoneAnalysisResult?>(null)
    val currentPhoneAnalysis: StateFlow<PhoneAnalysisResult?> = _currentPhoneAnalysis.asStateFlow()

    init {
        refreshNow()
        refreshDeepNetworkInfo()
        benchmarkDns()
        scanLocalNetwork()
    }

    fun refreshDeepNetworkInfo() {
        viewModelScope.launch {
            _hardwareInfo.value = DeviceHardwareUtils.getHardwareInfo(repository.context)
            _deepNetworkInfo.value = DeviceHardwareUtils.getDeepNetworkInfo(
                repository.context,
                repository.telemetryState.value.publicIp
            )
        }
    }

    fun scanLocalNetwork() {
        viewModelScope.launch {
            _isScanningLan.value = true
            try {
                val currentLocalIp = _deepNetworkInfo.value.localIpv4
                val currentGateway = _deepNetworkInfo.value.gatewayIp
                val results = LanScanner.scanSubnet(
                    localIp = currentLocalIp,
                    gatewayIp = currentGateway,
                    onProgress = { cur, total ->
                        _lanScanProgress.value = Pair(cur, total)
                    },
                    onDeviceFound = { newDevice ->
                        val currentList = _lanDevices.value.toMutableList()
                        val idx = currentList.indexOfFirst { it.ipAddress == newDevice.ipAddress }
                        if (idx >= 0) {
                            currentList[idx] = newDevice
                        } else {
                            currentList.add(newDevice)
                        }
                        _lanDevices.value = currentList
                    }
                )
                _lanDevices.value = results
                _userMessage.value = "تم اكتمال مسح الشبكة: تم كشف ${results.size} أجهزة متصلة"
            } catch (e: Exception) {
                _userMessage.value = "فشل مسح الشبكة: ${e.localizedMessage}"
            } finally {
                _isScanningLan.value = false
            }
        }
    }

    fun benchmarkDns() {
        viewModelScope.launch {
            _isBenchmarkingDns.value = true
            try {
                val results = DnsBenchmarkUtil.benchmarkDnsServers()
                _dnsBenchmarkResults.value = results
            } catch (_: Exception) {
            } finally {
                _isBenchmarkingDns.value = false
            }
        }
    }

    fun refreshNow() {
        viewModelScope.launch {
            _isScanning.value = true
            try {
                repository.refreshTelemetry()
            } catch (e: Exception) {
                _userMessage.value = "خطأ أثناء التحديث: ${e.localizedMessage}"
            } finally {
                _isScanning.value = false
            }
        }
    }

    fun saveCurrentReading() {
        viewModelScope.launch {
            val id = repository.saveCurrentReading(telemetry.value)
            if (id > 0) {
                _userMessage.value = "تم حفظ قراءة البرج بنجاح في قاعدة البيانات المحلية"
            } else {
                _userMessage.value = "تعذر حفظ القراءة (لا توجد بيانات برج متاحة)"
            }
        }
    }

    fun deleteReading(id: Long) {
        viewModelScope.launch {
            repository.deleteReading(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _userMessage.value = "تم تفريغ جميع سجلات القراءات"
        }
    }

    fun toggleService(context: Context) {
        if (_isServiceRunning.value) {
            CellMonitorService.stop(context)
            _isServiceRunning.value = false
            _userMessage.value = "تم إيقاف خدمة المراقبة المستمرة"
        } else {
            CellMonitorService.start(context)
            _isServiceRunning.value = true
            _userMessage.value = "تم تشغيل خدمة المراقبة المستمرة كل 5 ثوانٍ"
        }
    }

    fun toggleSimulationMode() {
        repository.isSimulationMode = !repository.isSimulationMode
        refreshNow()
        val status = if (repository.isSimulationMode) "تفعيل" else "تعطيل"
        _userMessage.value = "تم $status وضع المحاكاة الهندسية"
    }

    fun openApiKeyDialog() {
        _apiKeyInput.value = repository.openCellIdApiKey
        _isApiKeyDialogOpen.value = true
    }

    fun closeApiKeyDialog() {
        _isApiKeyDialogOpen.value = false
    }

    fun updateApiKeyInput(key: String) {
        _apiKeyInput.value = key
    }

    fun saveApiKey() {
        repository.openCellIdApiKey = _apiKeyInput.value.trim()
        _isApiKeyDialogOpen.value = false
        _userMessage.value = "تم حفظ مفتاح OpenCellID API بنجاح"
        refreshNow()
    }

    fun refreshPublicIp() {
        viewModelScope.launch {
            repository.fetchPublicIp()
            _userMessage.value = "تم تحديث عنوان IP العام"
        }
    }

    // --- NetScan Dialog and Locking ---

    fun openNetScanDialog() {
        repository.performNetScan()
        _isNetScanDialogOpen.value = true
    }

    fun closeNetScanDialog() {
        _isNetScanDialogOpen.value = false
    }

    fun lockNetwork(mccMnc: String) {
        repository.lockNetwork(mccMnc)
        _userMessage.value = "تم تثبيت الشبكة يدوياً على كود $mccMnc"
    }

    // --- Report Missing Tower ---

    fun openReportTowerDialog() {
        _isReportTowerDialogOpen.value = true
    }

    fun closeReportTowerDialog() {
        _isReportTowerDialogOpen.value = false
    }

    fun reportTower(
        cellId: Long,
        operator: String,
        band: String,
        freqMhz: Double,
        lat: Double,
        lon: Double,
        address: String,
        notes: String
    ) {
        viewModelScope.launch {
            repository.reportMissingTower(cellId, operator, band, freqMhz, lat, lon, address, notes)
            _userMessage.value = "تم تسجيل وإرسال بيانات البرج إلى خريطة الرادار"
        }
    }

    // --- Field Engineer Mode (2-second logging) ---

    fun toggleFieldEngineerMode() {
        if (telemetry.value.isEngineerModeActive) {
            repository.stopFieldEngineerMode()
            _userMessage.value = "تم إيقاف تسجيل وضع المهندس الميداني"
        } else {
            repository.startFieldEngineerMode()
            _userMessage.value = "تم تفعيل وضع المهندس الميداني (تسجيل دوري كل ثانيتين)"
        }
    }

    fun exportFieldMeasurements(onComplete: (String) -> Unit) {
        viewModelScope.launch {
            val csv = repository.exportFieldMeasurementsCsv()
            onComplete(csv)
            _userMessage.value = "تم تجهيز تقرير CSV للقياسات الميدانية"
        }
    }

    fun clearFieldMeasurements() {
        viewModelScope.launch {
            repository.clearFieldMeasurements()
            _userMessage.value = "تم مسح سجلات القياسات الميدانية"
        }
    }

    // --- Phone Number Lookup ---

    fun updatePhoneSearchQuery(query: String) {
        _phoneSearchQuery.value = query
    }

    fun performPhoneSearch(input: String? = null) {
        val q = (input ?: _phoneSearchQuery.value).trim()
        if (q.isBlank()) return

        val analysis = PhoneNumberUtils.analyzeNumber(q)
        _currentPhoneAnalysis.value = analysis

        // Record to search history
        viewModelScope.launch {
            repository.egyptDataDao.insertNumberLookup(
                NumberLookupEntity(
                    phoneNumber = analysis.normalizedNumber,
                    operatorName = analysis.operatorNameAr,
                    governorate = analysis.governorate,
                    centralOffice = analysis.centralOffice,
                    estimatedName = analysis.estimatedOwnerName,
                    isMobile = analysis.isMobile
                )
            )
        }
    }

    fun deleteNumberLookup(id: Long) {
        viewModelScope.launch {
            repository.egyptDataDao.deleteNumberLookup(id)
        }
    }

    fun clearNumberLookups() {
        viewModelScope.launch {
            repository.egyptDataDao.clearNumberLookups()
            _userMessage.value = "تم مسح سجل عمليات البحث السابقة"
        }
    }

    fun dismissMessage() {
        _userMessage.value = null
    }

    class Factory(private val repository: NetworkRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
                return DashboardViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
