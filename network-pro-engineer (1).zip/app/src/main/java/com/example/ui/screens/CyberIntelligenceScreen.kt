package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.DashboardViewModel
import com.example.ui.theme.EgyptDarkCard
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalOrange
import com.example.ui.theme.SignalYellow

@Composable
fun CyberIntelligenceScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val auditState by viewModel.securityAuditState.collectAsStateWithLifecycle()
    var selectedSection by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(EgyptDarkSurface)
    ) {
        // Section Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedSection,
            containerColor = Color(0xFF14141E),
            contentColor = EgyptGold,
            edgePadding = 12.dp
        ) {
            Tab(
                selected = selectedSection == 0,
                onClick = { selectedSection = 0 },
                text = { Text("كيف ترصد المباحث والأجهزة الهواتف؟", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                icon = { Icon(Icons.Default.Policy, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedSection == 1,
                onClick = { selectedSection = 1 },
                text = { Text("درع الحماية وإخفاء الاتصال", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                icon = { Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedSection == 2,
                onClick = { selectedSection = 2 },
                text = { Text("فاحص درع الأمان التفاعلي", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                icon = { Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        when (selectedSection) {
            0 -> ForensicIntelligenceGuideView()
            1 -> AntiTrackingCloakingGuideView(context)
            2 -> InteractiveSecurityAuditView(auditState, context)
        }
    }
}

@Composable
private fun ForensicIntelligenceGuideView() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptRed.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(EgyptRed.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Policy, contentDescription = null, tint = EgyptRed)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "موسوعة التحقيق السيبراني واستخبارات الاتصالات",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = EgyptGold
                            )
                            Text(
                                text = "كيف ترصد مباحث الإنترنت والجهات الأمنية الهواتف والأجهزة هندسياً؟",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.LightGray
                            )
                        }
                    }
                }
            }
        }

        item {
            InvestigationTechniqueCard(
                number = "1",
                title = "سجلات تفاصيل المكالمات والبيانات (CDR - Call Detail Records)",
                shortDesc = "السجل الزمني الإلزامي المحفوظ لدى جميع مشغلي المحمول بموجب القانون",
                fullExplanation = "بموجب قانون تنظيم الاتصالات المصري رقم 10 لسنة 2003، تلتزم شركات المحمول (فودافون، أورانج، اتصالات، وي) بحفظ سجلات كاملة لجميع المكالمات والرسائل وجلسات الإنترنت لمدة لا تقل عن 180 يوماً. يتضمن السجل: رقم المتصل والمتلقي، توقيت الاتصال بالثانية، مدة المكالمة، معرّف الشريحة (IMSI)، معرّف العتاد (IMEI)، ورقم البرج والقطاع الدقيق (Cell ID & Sector) الذي انطلقت منه المكالمة.",
                threatLevel = "رصد كامل للموقع وسجل جهات الاتصال",
                icon = Icons.Default.CellTower
            )
        }

        item {
            InvestigationTechniqueCard(
                number = "2",
                title = "مصائد الـ IMSI وأبراج التجسس الوهمية (IMSI Catchers / StingRay)",
                shortDesc = "أجهزة محمولة تبث إشارات أبراج وهمية تجبر الهواتف على كشف هويتها",
                fullExplanation = "تعتمد تقنية الـ IMSI Catcher على بث إشارة برج خلوي قوي جداً، مما يجعل هواتف الضحايا القريبة ترتبط بالبرج الوهمي تلقائياً وفق خوارزمية اختيار أقوى إشارة. يمارس الجهاز هجوم خفض التشفير (Cipher Downgrade) بإجبار الهاتف على التبديل لشبكة الجيل الثاني (2G GSM) حيث التشفير معدوم (A5/0) أو سهل الكسر (A5/1)، مما يتيح استخراج رقم IMSI الخاص بك واعتراض المكالمات وتحديد موقعك بالمتر.",
                threatLevel = "اعتراض الرسائل والمكالمات وتتبع الموقع المباشر",
                icon = Icons.Default.Warning
            )
        }

        item {
            InvestigationTechniqueCard(
                number = "3",
                title = "تثليث الأبراج الخلوية وتحديد الموقع بدقة (Cell Tower Triangulation)",
                shortDesc = "تحديد موقعك الجغرافي دون الحاجة لتشغيل الـ GPS إطلاقاً",
                fullExplanation = "عندما يكون الهاتف قيد التشغيل، يتصل ببرج رئيسي (Serving Cell) ويتبادل إشارات استطلاع مع 2 إلى 5 أبراج مجاورة (Neighbor Cells). تقوم مراكز التحكم بالشبكة بحساب فروق التوقيت الزمنية لوصول الإشارة (TDOA - Time Difference of Arrival) وزاوية الوصول (AoA - Angle of Arrival). عبر تقاطع هذه الدوائر الهندسية الثلاث، يتم تحديد موقع الهاتف في دائرة ضيقة (من 50 إلى 200 متر في المدن) حتى لو كان نظام الـ GPS مغلقاً تماماً.",
                threatLevel = "تتبع جغرافي دقيق بدون GPS",
                icon = Icons.Default.MyLocation
            )
        }

        item {
            InvestigationTechniqueCard(
                number = "4",
                title = "الربط بين عنوان الـ IP المؤقت والرقم القومي (CGNAT Logs to National ID)",
                shortDesc = "كيف تصل مباحث الإنترنت لمرتكب الجريمة من خلال منشور أو تعليق؟",
                fullExplanation = "عند نشر أي محتوى على الإنترنت (فيسبوك، تليجرام، موقع ويب)، يسجل الخادم عنوان الـ IP العام (Public IP) ورقم المنفذ (Port) والطابع الزمني بالملي ثانية. وبما أن شركات المحمول تستخدم تقنية CGNAT (مشاركة عنوان IP واحد بين آلاف المستخدمين)، تصدر النيابة أمراً قضائياً للشركة لمطابقة المنفذ والوقت المحدد في سجلات الـ NAT. يظهر فوراً رقم الشريحة (MSISDN) المسجل بالرقم القومي واسم المشترك وعنوانه المسجل في العقد.",
                threatLevel = "كشف الهوية الشخصية والرقم القومي",
                icon = Icons.Default.Fingerprint
            )
        }

        item {
            InvestigationTechniqueCard(
                number = "5",
                title = "فحص الحزم العميقة والاعتراض القانوني (DPI & Lawful Interception)",
                shortDesc = "تحليل حزم البيانات المارة عبر البوابات الدولية والسنترالات المركزية",
                fullExplanation = "تثبّت بوابات الاتصالات المركزية أجهزة فحص الحزم العميقة (DPI) المعتمدة بموجب المعايير الدولية ETSI للاعتراض القانوني. تمكّن هذه المنظومات من فحص حركة البيانات وتحديد البروتوكولات المستخدمة (مثل بروتوكولات VPN، مكالمات VoIP غير المرخصة، وتطبيقات المراسلة المشفرة) وحجب الخدمات أو تتبع تدفق الحزم نحو خوادم معينة.",
                threatLevel = "تحليل بروتوكولات الاتصال وحركة البيانات",
                icon = Icons.Default.Router
            )
        }

        item {
            InvestigationTechniqueCard(
                number = "6",
                title = "سجل هوية العتاد وسيريال الجهاز (IMEI Tracking & EIR)",
                shortDesc = "تتبع الهاتف حتى عند استبدال وتغيير الشريحة SIM",
                fullExplanation = "كل هاتف يمتلك رقم هوية عتاد فريد (IMEI). بمجرد إدخال أي شريحة SIM جديدة في الهاتف، ترسل الشبكة طلب هوية عتاد وتسجل في قاعدة بيانات EIR أن الشريحة رقم (ب) تعمل الآن على نفس الهاتف الذي كانت تعمل عليه الشريحة (أ). لذلك، فإن تغيير الشريحة لا يمنع الأجهزة الأمنية من تتبع صاحب الجهاز الحقيقي فور تشغيله.",
                threatLevel = "كشف الشخص حتى لو غيّر الشريحة SIM",
                icon = Icons.Default.PhoneAndroid
            )
        }
    }
}

@Composable
private fun AntiTrackingCloakingGuideView(context: Context) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF162416)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SignalGreen.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(SignalGreen.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = SignalGreen)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "درع الحماية وإخفاء الاتصال (Anti-Tracking Shield)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = SignalGreen
                            )
                            Text(
                                text = "الحقائق الهندسية لحماية الخصوصية ومكافحة التتبع الخلوي",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.LightGray
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "⚖️ الحقيقة الهندسية: هل يمكن إخفاء اتصالي عن برج المحمول نهائياً؟",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EgyptGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "في فيزياء الاتصالات الخلوية (معايير 3GPP GSM/LTE/5G)، لا يمكن لجهازك تبادل بايت واحد من البيانات مع البرج دون مصافحة راديوية (Radio Handshake) وتبادل معرّفات (RRC Setup & TMSI). طالما أن مودم الشريحة يرسل موجات كهرومغناطيسية للبرج، فالبرج يراك بالضرورة.\n\nولكن: يمكنك تطبيق الاستراتيجيات الهندسية التالية لإخفاء هويتك وعزل اتصالك تماماً عن الأبراج:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        item {
            DefenseStrategyCard(
                icon = Icons.Default.AirplanemodeActive,
                title = "1. استراتيجية الاتصال الخفي عبر (VoWiFi + VPN)",
                description = "الحل الهندسي الأقوى لعزل نفسك عن أبراج الاتصال تماماً:",
                steps = listOf(
                    "تفعيل وضع الطيران (Airplane Mode): هذا يطفئ مودم الراديو الخلوي (Baseband) بالكامل، مما يجعل هاتفك غير مرئي لجميع أبراج المحمول.",
                    "تشغيل شبكة الواي فاي وتفعيل مكالمات الواي فاي (VoWiFi / Wi-Fi Calling).",
                    "تشغيل شبكة افتراضية مشفرة (VPN مثل WireGuard أو IKEv2).",
                    "النتيجة: يمكنك إجراء واستقبال مكالماتك وتصفح الإنترنت بنفق مشفر بالكامل دون إرسال إشارة راديوية واحدة لأي برج اتصالات أرضي!"
                ),
                tint = SignalGreen
            )
        }

        item {
            DefenseStrategyCard(
                icon = Icons.Default.Lock,
                title = "2. حظر شبكات الجيل الثاني (Disable 2G / Anti-Stingray)",
                description = "الحماية الصامتة من مصائد الـ IMSI Catchers وأجهزة المراقبة المحمولة:",
                steps = listOf(
                    "تقوم أجهزة التنصت والتتبع اللاسلكي بإجبار الهاتف على التراجع إلى شبكة 2G لأن تشفيرها القديم A5/1 قابل للكسر فورياً.",
                    "انتقل إلى إعدادات الهاتف -> الشبكة -> نوع الشبكة المفضل -> اختر (LTE / 5G Only) وتفعيل ميزة 'تعطيل 2G' المتاحة في أندرويد 12 فأحدث.",
                    "بذلك يرفض هاتفك الاتصال بأي برج وهمي غير مشفر مهما كانت قوة إشارته."
                ),
                tint = EgyptGold
            )
        }

        item {
            DefenseStrategyCard(
                icon = Icons.Default.Dns,
                title = "3. تشفير استعلامات النطاق (Private DNS over TLS - DoT)",
                description = "حجب تعقب المواقع والتطبيقات من شركات الاتصالات والسنترالات:",
                steps = listOf(
                    "بشكل افتراضي، ترسل استعلامات الـ DNS كحزم نصوص واضحة غير مشفرة لمزود الخدمة (ISP)، مما يكشف كل موقع أو تطبيق تفتحه.",
                    "توجه إلى إعدادات أندرويد -> الشبكة والإنترنت -> نظام اسم النطاق الخاص (Private DNS).",
                    "أدخل عنوان مزود مشفر مثل: dns.adguard-dns.com (لحجب الإعلانات والتعقب) أو one.one.one.one (كلاود فلير فائق السرعة)."
                ),
                tint = Color(0xFF2196F3)
            )
        }

        item {
            DefenseStrategyCard(
                icon = Icons.Default.Wifi,
                title = "4. عشوائية عنوان الـ MAC الفيزيائي (MAC Randomization)",
                description = "منع تتبع تحركاتك الجغرافية في الأماكن العامة والمولات:",
                steps = listOf(
                    "عند البحث عن شبكات Wi-Fi، يرسل الهاتف حزم استطلاع (Probe Requests) تحتوي على معرّف العتاد MAC.",
                    "تستخدم الحساسات في المراكز التجارية لتتبع خط سير كل جهاز وحساب مدة مكوثه.",
                    "تأكد من تفعيل خيار 'استخدام عنوان MAC عشوائي' في إعدادات شبكة الواي فاي بهاتفك لتوليد هوية فيزيائية جديدة مع كل اتصال."
                ),
                tint = SignalOrange
            )
        }

        item {
            DefenseStrategyCard(
                icon = Icons.Default.VpnLock,
                title = "5. درع الجيل الخامس 5G المشفر (SUCI Architecture)",
                description = "تشفير معرّف الشريحة هوائياً قبل خروجه من الهاتف:",
                steps = listOf(
                    "في شبكات 5G المستقلة (5G Standalone)، يتم تشفير هوية الشريحة باستخدام تقنية SUCI (Subscription Concealed Identifier).",
                    "يقوم الهاتف بتشفير الـ IMSI بالمفتاح العام لمشغل الشبكة (Public Key Encryption) داخل شريحة الـ SIM نفسها قبل إرسالها عبر الهواء.",
                    "بذلك تصبح مصائد الـ IMSI Catchers عاجزة تماماً عن قراءة هوية صاحب الهاتف عبر أثير الجيل الخامس."
                ),
                tint = Color(0xFF9C27B0)
            )
        }
    }
}

@Composable
private fun InteractiveSecurityAuditView(
    audit: com.example.data.model.SecurityAuditState,
    context: Context
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .background(
                                if (audit.securityScore >= 80) SignalGreen.copy(alpha = 0.15f) else SignalYellow.copy(alpha = 0.15f),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${audit.securityScore}%",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = if (audit.securityScore >= 80) SignalGreen else SignalYellow
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "مؤشر درع الأمان ومكافحة التتبع الحالي",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "مستوى الحماية الحالي لهاتفك ضد أدوات الرصد والاعتراض",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        }

        item {
            Text(
                text = "الفحوصات الأمنية الحية لجهازك:",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = EgyptGold
            )
        }

        item {
            AuditCheckItem(
                title = "تشفير الـ DNS الخاص (Private DNS)",
                status = if (audit.isPrivateDnsActive) "مفعّل وآمن (تشفير DoT نشط)" else "غير مفعّل (استعلامات النطاق مكشوفة للمزود)",
                isGood = audit.isPrivateDnsActive,
                actionLabel = "ضبط الـ DNS",
                onAction = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                    } catch (_: Exception) {}
                }
            )
        }

        item {
            AuditCheckItem(
                title = "أمان شبكة الواي فاي المتصلة",
                status = "تشفير بروتوكول ${audit.wifiSecurityType} قوي ومحمي",
                isGood = audit.isWifiEncrypted,
                actionLabel = "إعدادات Wi-Fi",
                onAction = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                    } catch (_: Exception) {}
                }
            )
        }

        item {
            AuditCheckItem(
                title = "عشوائية عنوان الـ MAC (MAC Randomization)",
                status = "مفعّلة لحجب حساسات التتبع في الأماكن العامة",
                isGood = audit.isMacRandomized,
                actionLabel = "فحص الخصوصية",
                onAction = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                    } catch (_: Exception) {}
                }
            )
        }

        item {
            AuditCheckItem(
                title = "الحماية من مصائد الـ 2G (Anti-StingRay)",
                status = "يُنصح بتعطيل شبكة 2G في إعدادات الشريحة",
                isGood = audit.is2gDisabled,
                actionLabel = "إعدادات الشبكة",
                onAction = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS))
                    } catch (_: Exception) {}
                }
            )
        }

        item {
            AuditCheckItem(
                title = "مستوى خطر تسريب عنوان الـ IP والبيانات",
                status = "مستوى الخطر: ${audit.ipLeakRisk}",
                isGood = audit.ipLeakRisk.contains("منخفض"),
                actionLabel = "إعدادات الأمان",
                onAction = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                    } catch (_: Exception) {}
                }
            )
        }
    }
}

@Composable
private fun InvestigationTechniqueCard(
    number: String,
    title: String,
    shortDesc: String,
    fullExplanation: String,
    threatLevel: String,
    icon: ImageVector
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF262636), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(EgyptGold.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(number, color = EgyptGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = shortDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = EgyptGold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = fullExplanation,
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(EgyptRed.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, contentDescription = null, tint = EgyptRed, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الأثر الجنائي: $threatLevel",
                        color = Color(0xFFFF8A80),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun DefenseStrategyCard(
    icon: ImageVector,
    title: String,
    description: String,
    steps: List<String>,
    tint: Color
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, tint.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(tint.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = tint
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
            Spacer(modifier = Modifier.height(8.dp))

            steps.forEachIndexed { idx, step ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = "• ",
                        color = tint,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = step,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.LightGray,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun AuditCheckItem(
    title: String,
    status: String,
    isGood: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isGood) SignalGreen.copy(alpha = 0.4f) else SignalYellow.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isGood) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (isGood) SignalGreen else SignalYellow,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    Text(status, style = MaterialTheme.typography.bodySmall, color = if (isGood) Color.LightGray else SignalYellow)
                }
            }

            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = EgyptGold.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Text(actionLabel, color = EgyptGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
