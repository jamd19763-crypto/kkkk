package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalYellow
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedometerGauge(
    speedMbps: Float,
    maxSpeed: Float = 100f,
    modifier: Modifier = Modifier
        .size(230.dp)
) {
    val animatedSpeed by animateFloatAsState(
        targetValue = speedMbps.coerceIn(0f, maxSpeed),
        animationSpec = tween(durationMillis = 800),
        label = "speedometer_anim"
    )

    val sweepRatio = (animatedSpeed / maxSpeed).coerceIn(0f, 1f)
    // Gauge sweeps from 135 deg to 405 deg (270 degrees total)
    val startAngle = 135f
    val totalSweep = 270f
    val currentAngle = startAngle + (sweepRatio * totalSweep)

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 14.dp.toPx()
            val diameter = size.minDimension - strokeWidth * 2
            val arcSize = Size(diameter, diameter)
            val topLeft = Offset(
                (size.width - diameter) / 2f,
                (size.height - diameter) / 2f
            )

            // Background Track Arc
            drawArc(
                color = Color(0xFF232328),
                startAngle = startAngle,
                sweepAngle = totalSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Gradient Egyptian Active Speed Arc
            val gradientBrush = Brush.sweepGradient(
                0.0f to EgyptRed,
                0.4f to SignalYellow,
                0.7f to SignalGreen,
                1.0f to EgyptGold
            )

            drawArc(
                brush = gradientBrush,
                startAngle = startAngle,
                sweepAngle = sweepRatio * totalSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Tick Marks around the gauge
            val numTicks = 11
            val center = Offset(size.width / 2f, size.height / 2f)
            val outerRadius = diameter / 2f + strokeWidth * 0.8f
            val innerRadius = outerRadius - 8.dp.toPx()

            for (i in 0 until numTicks) {
                val tickFraction = i.toFloat() / (numTicks - 1)
                val tickAngle = startAngle + tickFraction * totalSweep
                val rad = Math.toRadians(tickAngle.toDouble())

                val start = Offset(
                    center.x + (innerRadius * cos(rad)).toFloat(),
                    center.y + (innerRadius * sin(rad)).toFloat()
                )
                val end = Offset(
                    center.x + (outerRadius * cos(rad)).toFloat(),
                    center.y + (outerRadius * sin(rad)).toFloat()
                )

                val tickColor = if (tickFraction <= sweepRatio) EgyptGold else Color(0xFF555555)
                drawLine(
                    color = tickColor,
                    start = start,
                    end = end,
                    strokeWidth = if (i % 2 == 0) 3.dp.toPx() else 1.5.dp.toPx()
                )
            }

            // Needle Pointer
            val needleLength = diameter / 2f - 18.dp.toPx()
            rotate(degrees = currentAngle, pivot = center) {
                // Needle Body
                drawLine(
                    brush = Brush.horizontalGradient(listOf(EgyptRed, EgyptGold)),
                    start = center,
                    end = Offset(center.x + needleLength, center.y),
                    strokeWidth = 4.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Center Pin / Dial
            drawCircle(
                color = EgyptGold,
                radius = 9.dp.toPx(),
                center = center
            )
            drawCircle(
                color = EgyptRed,
                radius = 4.5.dp.toPx(),
                center = center
            )
        }

        // Center Digital Readout
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                text = String.format(Locale.US, "%.1f", animatedSpeed),
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black
                ),
                color = EgyptWhite
            )
            Text(
                text = "ميجابت / ثانية (Mbps)",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold
                ),
                color = EgyptGold
            )
        }
    }
}
