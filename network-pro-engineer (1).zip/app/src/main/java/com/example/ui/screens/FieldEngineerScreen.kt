package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.DashboardViewModel
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.SignalGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FieldEngineerScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val telemetry by viewModel.telemetry.collectAsState()
    val measurements by viewModel.fieldMeasurements.collectAsState()
    val context = LocalContext.current

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_anim"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0C10))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Section
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Engineering,
                        contentDescription = null,
                        tint = EgyptGold,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "وضع المهندس الميداني (Field Drive Test)",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        ),
                        color = EgyptGold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "تسجيل دوري احترافي كل ثانيتين لمعايير RF (RSRP, RSRQ, SINR, PCI) وحفظ الإحداثيات وتصديرها كملف CSV",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFA0A0A0)
                )
            }
        }

        // Status Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = EgyptDarkSurface),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (telemetry.isEngineerModeActive) EgyptRed else Color(0xFF33333F)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .background(
                                        color = if (telemetry.isEngineerModeActive) EgyptRed.copy(alpha = pulseAlpha) else Color.Gray,
                                        shape = CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (telemetry.isEngineerModeActive) "جاري التسجيل الميداني المباشر..." else "وضع التسجيل متوقف",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (telemetry.isEngineerModeActive) EgyptWhite else Color.Gray
                            )
                        }

                        Text(
                            text = "${measurements.size} نقطة مسجلة",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = EgyptGold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Controls Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.toggleFieldEngineerMode() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (telemetry.isEngineerModeActive) Color(0xFF424242) else EgyptRed
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = if (telemetry.isEngineerModeActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (telemetry.isEngineerModeActive) "إيقاف التسجيل" else "بدء التسجيل (كل 2ث)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.exportFieldMeasurements { csvContent ->
                                    shareCsv(context, csvContent)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                            shape = RoundedCornerShape(10.dp),
                            enabled = measurements.isNotEmpty()
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير CSV", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    if (measurements.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { viewModel.clearFieldMeasurements() },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF555555))
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = Color.LightGray)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تفريغ سجلات القياسات الميدانية", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Live Measurement Table
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Assessment,
                        contentDescription = null,
                        tint = EgyptGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "جدول القياسات الميدانية الحية",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = EgyptWhite
                    )
                }

                Text(
                    text = "عرض أحدث ${measurements.size} عينة",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray
                )
            }
        }

        if (measurements.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "اضغط 'بدء التسجيل' للبدء في حفظ قراءات المسح الميداني",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }
            }
        } else {
            // Horizontal scrollable table
            item {
                val scrollState = rememberScrollState()
                val sdf = SimpleDateFormat("HH:mm:ss", Locale.US)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState)
                        .background(Color(0xFF14141A), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF2E2E38), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .background(Color(0xFF1F1F28), RoundedCornerShape(6.dp))
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        TableCell("الوقت", width = 70.dp, isHeader = true, color = EgyptGold)
                        TableCell("RSRP (dBm)", width = 85.dp, isHeader = true, color = EgyptGold)
                        TableCell("RSRQ (dB)", width = 80.dp, isHeader = true, color = EgyptGold)
                        TableCell("SINR (dB)", width = 75.dp, isHeader = true, color = EgyptGold)
                        TableCell("PCI", width = 60.dp, isHeader = true, color = EgyptGold)
                        TableCell("Cell ID", width = 85.dp, isHeader = true, color = EgyptGold)
                        TableCell("المشغل", width = 95.dp, isHeader = true, color = EgyptGold)
                        TableCell("التردد/Band", width = 100.dp, isHeader = true, color = EgyptGold)
                        TableCell("خط العرض", width = 80.dp, isHeader = true, color = EgyptGold)
                        TableCell("خط الطول", width = 80.dp, isHeader = true, color = EgyptGold)
                    }

                    // Table Rows
                    measurements.take(50).forEachIndexed { index, m ->
                        val bg = if (index % 2 == 0) Color.Transparent else Color(0xFF1A1A22)
                        Row(
                            modifier = Modifier
                                .background(bg, RoundedCornerShape(4.dp))
                                .padding(vertical = 6.dp, horizontal = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            TableCell(sdf.format(Date(m.timestamp)), width = 70.dp, color = Color(0xFFAAAAAA))
                            TableCell("${m.rsrp}", width = 85.dp, color = if (m.rsrp > -85) SignalGreen else EgyptRed)
                            TableCell("${m.rsrq}", width = 80.dp, color = EgyptWhite)
                            TableCell(String.format(Locale.US, "%.1f", m.sinr), width = 75.dp, color = EgyptGold)
                            TableCell("${m.pci}", width = 60.dp, color = EgyptWhite)
                            TableCell("${m.cellId}", width = 85.dp, color = Color(0xFF80D8FF))
                            TableCell(m.operator, width = 95.dp, color = EgyptWhite)
                            TableCell(m.band, width = 100.dp, color = Color(0xFFFFD54F))
                            TableCell(String.format(Locale.US, "%.4f", m.latitude), width = 80.dp, color = Color.Gray)
                            TableCell(String.format(Locale.US, "%.4f", m.longitude), width = 80.dp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false,
    color: Color = EgyptWhite
) {
    Text(
        text = text,
        modifier = Modifier.width(width),
        style = MaterialTheme.typography.bodySmall.copy(
            fontWeight = if (isHeader) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            fontSize = if (isHeader) 12.sp else 11.sp
        ),
        color = color
    )
}

private fun shareCsv(context: Context, csvContent: String) {
    try {
        val sendIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, csvContent)
            putExtra(Intent.EXTRA_SUBJECT, "Egypt_Network_Radar_Field_Test_${System.currentTimeMillis()}.csv")
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "مشاركة تقرير القياس الميداني (CSV)")
        context.startActivity(shareIntent)
    } catch (_: Exception) {
        // Fallback: Copy to clipboard
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Field Measurements CSV", csvContent)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "تم نسخ تقرير CSV إلى الحافظة", Toast.LENGTH_LONG).show()
    }
}
