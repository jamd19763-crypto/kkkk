package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Egyptian National Identity Palette
val EgyptRed = Color(0xFFC8102E)
val EgyptGold = Color(0xFFD4AF37)
val EgyptBlack = Color(0xFF121212)
val EgyptDarkSurface = Color(0xFF1E1E1E)
val EgyptDarkSurfaceVariant = Color(0xFF282828)
val EgyptDarkCard = Color(0xFF1C1C26)
val EgyptWhite = Color(0xFFFFFFFF)

// Egyptian Mobile Operators Official Palette
val OperatorVodafone = Color(0xFFE60000)
val OperatorOrange = Color(0xFFFF7900)
val OperatorEtisalat = Color(0xFF7FB239)
val OperatorWE = Color(0xFF5C2D91)

// Telecom Radar Theme Palette
val TelecomCyan = Color(0xFF00E5FF)
val TelecomBlue = Color(0xFF0288D1)
val TelecomNavy = Color(0xFF0A192F)
val TelecomDarkSurface = Color(0xFF112240)
val TelecomDarkSurfaceVariant = Color(0xFF1B2F52)
val TelecomBackground = Color(0xFF0D0D11)

// Signal Levels
val SignalGreen = Color(0xFF00E676)
val SignalYellow = Color(0xFFFFD600)
val SignalOrange = Color(0xFFFF9100)
val SignalRed = Color(0xFFFF3D00)
val SignalDeadZone = Color(0xFF505050)

val LightTelecomPrimary = Color(0xFFC8102E)
val LightTelecomSecondary = Color(0xFFD4AF37)
val LightTelecomBackground = Color(0xFFF8F9FA)
val LightTelecomSurface = Color(0xFFFFFFFF)
val LightTelecomSurfaceVariant = Color(0xFFE1E8ED)
