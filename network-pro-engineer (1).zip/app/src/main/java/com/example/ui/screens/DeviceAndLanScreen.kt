package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DeepNetworkInfo
import com.example.data.model.DeviceHardwareInfo
import com.example.data.model.LanDevice
import com.example.ui.DashboardViewModel
import com.example.ui.theme.EgyptDarkCard
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalOrange
import com.example.ui.theme.SignalYellow

@Composable
fun DeviceAndLanScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hardwareInfo by viewModel.hardwareInfo.collectAsStateWithLifecycle()
    val deepNetwork by viewModel.deepNetworkInfo.collectAsStateWithLifecycle()
    val lanDevices by viewModel.lanDevices.collectAsStateWithLifecycle()
    val isScanningLan by viewModel.isScanningLan.collectAsStateWithLifecycle()
    val lanScanProgress by viewModel.lanScanProgress.collectAsStateWithLifecycle()

    var selectedSubTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(EgyptDarkSurface)
    ) {
        // Top Sub-Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = Color(0xFF14141E),
            contentColor = EgyptGold,
            edgePadding = 12.dp
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = { Text("معلومات جهازي", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                icon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = { Text("الشبكة والـ IP", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                icon = { Icon(Icons.Default.Dns, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedSubTab == 2,
                onClick = { selectedSubTab = 2 },
                text = { Text("الأجهزة المتصلة (${lanDevices.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                icon = { Icon(Icons.Default.Devices, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        when (selectedSubTab) {
            0 -> HardwareSpecsView(hardwareInfo)
            1 -> DeepNetworkView(deepNetwork, onRefresh = { viewModel.refreshDeepNetworkInfo() })
            2 -> LanDevicesView(
                devices = lanDevices,
                isScanning = isScanningLan,
                progress = lanScanProgress,
                onStartScan = { viewModel.scanLocalNetwork() },
                onOpenRouter = { gatewayIp ->
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://$gatewayIp"))
                    try { context.startActivity(intent) } catch (_: Exception) {}
                }
            )
        }
    }
}

@Composable
private fun HardwareSpecsView(info: DeviceHardwareInfo) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(EgyptGold.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = EgyptGold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "${info.manufacturer} ${info.model}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = "العلامة: ${info.brand} | الكود: ${info.deviceCode}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Color.DarkGray)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        HardwareMetricBadge(label = "الذاكرة العشوائية (RAM)", value = "${info.availableRamMb} / ${info.totalRamMb} MB", icon = Icons.Default.Memory)
                        HardwareMetricBadge(label = "نظام التشغيل", value = info.androidVersion, icon = Icons.Default.Security)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        HardwareMetricBadge(
                            label = "سعة التخزين الداخلي",
                            value = "${String.format("%.1f", info.availableStorageGb)} / ${String.format("%.1f", info.totalStorageGb)} GB",
                            icon = Icons.Default.Computer
                        )
                        HardwareMetricBadge(label = "مستوى التحديث الأمني", value = info.securityPatch, icon = Icons.Default.Security)
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "المعالج وتفاصيل النظام الأساسي (Kernel & SoC)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EgyptGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    InfoRow(label = "معمارية المعالج (ABI)", value = info.cpuAbi)
                    InfoRow(label = "عدد أنوية المعالج (CPU Cores)", value = "${info.cpuCores} أنوية حقيقية")
                    InfoRow(label = "اللوحة الأم (Motherboard)", value = info.board)
                    InfoRow(label = "عتاد الرقاقة (Hardware Chip)", value = info.hardware)
                    InfoRow(label = "إصدار النواة (Kernel)", value = info.kernelVersion)
                    InfoRow(label = "رقم البناء (Build ID)", value = info.buildId)
                    InfoRow(label = "وقت التشغيل المستمر (Uptime)", value = info.uptimeFormatted)
                    InfoRow(label = "مستوى واجهة برمجة التطبيقات (API Level)", value = "Android API ${info.apiLevel}")
                }
            }
        }
    }
}

@Composable
private fun DeepNetworkView(info: DeepNetworkInfo, onRefresh: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تشخيص عناوين الـ IP والمنافذ المباشرة",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = EgyptGold
                )
                Button(
                    onClick = onRefresh,
                    colors = ButtonDefaults.buttonColors(containerColor = EgyptRed.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تحديث فوري", color = Color.White, fontSize = 12.sp)
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF2A2A38), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFF2196F3).copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Dns, contentDescription = null, tint = Color(0xFF2196F3))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "عنوان الـ IP العام (Public IP)",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                            Text(
                                text = info.publicIp,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = EgyptGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Color.DarkGray)
                    Spacer(modifier = Modifier.height(14.dp))

                    InfoRow(label = "عنوان IP المحلي (Local IPv4)", value = info.localIpv4, isCode = true)
                    InfoRow(label = "بوابة الراوتر الافتراضية (Default Gateway)", value = info.gatewayIp, isCode = true)
                    InfoRow(label = "قناع الشبكة الفرعية (Subnet Mask)", value = info.subnetMask, isCode = true)
                    InfoRow(label = "خادم الـ DNS الأساسي (Primary DNS)", value = info.primaryDns, isCode = true)
                    InfoRow(label = "خادم الـ DNS الثانوي (Secondary DNS)", value = info.secondaryDns, isCode = true)
                    InfoRow(label = "واجهة الاتصال النشطة (Interface)", value = info.interfaceName, isCode = true)
                    InfoRow(label = "حجم حزمة البيانات الأقصى (MTU)", value = "${info.mtuSize} Bytes")
                    InfoRow(label = "حالة عنوان الـ MAC الفيزيائي", value = info.macAddressStatus)
                }
            }
        }

        if (info.isWifiConnected) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = SignalGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تفاصيل شبكة Wi-Fi المتصلة الحالية",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = SignalGreen
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        InfoRow(label = "اسم الشبكة (SSID)", value = info.wifiSsid)
                        InfoRow(label = "عنوان الراوتر الفيزيائي (BSSID)", value = info.wifiBssid, isCode = true)
                        InfoRow(label = "قوة إشارة الواي فاي (RSSI)", value = "${info.wifiRssiDbm} dBm")
                        InfoRow(label = "سرعة رابط الاتصال (Link Speed)", value = "${info.wifiLinkSpeedMbps} Mbps")
                        InfoRow(label = "تردد القناة (Frequency)", value = "${info.wifiFrequencyMhz} MHz (${info.wifiBandLabel})")
                        InfoRow(label = "رقم القناة اللاسلكية (Channel)", value = "القناة ${info.wifiChannel}")
                        InfoRow(label = "معيار الواي فاي (Wi-Fi Standard)", value = info.wifiStandard)
                    }
                }
            }
        }
    }
}

@Composable
private fun LanDevicesView(
    devices: List<LanDevice>,
    isScanning: Boolean,
    progress: Pair<Int, Int>,
    onStartScan: () -> Unit,
    onOpenRouter: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ماسح أجهزة الشبكة المحلية (LAN Scanner)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = EgyptGold
                            )
                            Text(
                                text = "كشف جميع الهواتف، الحواسيب، الراوتر، والشاشات المتصلة بنفس شبكتك",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الأجهزة المكتشفة: ${devices.size}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = SignalGreen
                        )

                        Button(
                            onClick = onStartScan,
                            enabled = !isScanning,
                            colors = ButtonDefaults.buttonColors(containerColor = EgyptGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isScanning) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("جاري الفحص (${progress.first}/${progress.second})", color = Color.Black, fontSize = 12.sp)
                            } else {
                                Icon(Icons.Default.Lan, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("بدء مسح الشبكة", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        items(devices) { device ->
            LanDeviceCard(
                device = device,
                onOpenRouter = { onOpenRouter(device.ipAddress) }
            )
        }
    }
}

@Composable
private fun LanDeviceCard(
    device: LanDevice,
    onOpenRouter: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = when {
                device.isCurrentDevice -> Color(0xFF1E281E)
                device.isGateway -> Color(0xFF282418)
                else -> EgyptDarkCard
            }
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                when {
                    device.isCurrentDevice -> SignalGreen.copy(alpha = 0.5f)
                    device.isGateway -> EgyptGold.copy(alpha = 0.5f)
                    else -> Color(0xFF262636)
                },
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(
                                when {
                                    device.isCurrentDevice -> SignalGreen.copy(alpha = 0.2f)
                                    device.isGateway -> EgyptGold.copy(alpha = 0.2f)
                                    else -> Color.DarkGray
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                device.isGateway -> Icons.Default.Router
                                device.isCurrentDevice -> Icons.Default.PhoneAndroid
                                device.deviceCategory.contains("شاشة") -> Icons.Default.Tv
                                device.deviceCategory.contains("حاسوب") -> Icons.Default.Computer
                                else -> Icons.Default.Devices
                            },
                            contentDescription = null,
                            tint = when {
                                device.isCurrentDevice -> SignalGreen
                                device.isGateway -> EgyptGold
                                else -> Color.LightGray
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = device.ipAddress,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = Color.White
                            )
                            if (device.isCurrentDevice) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .background(SignalGreen.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("جهازك الحالي", color = SignalGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            } else if (device.isGateway) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .background(EgyptGold.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("بوابة الراوتر", color = EgyptGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text(
                            text = device.hostname,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${device.pingLatencyMs} ms",
                        color = if (device.pingLatencyMs < 20) SignalGreen else SignalYellow,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "النوع/المصنّع: ${device.vendorName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                    Text(
                        text = device.openPortsSummary,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.LightGray
                    )
                }

                if (device.isGateway) {
                    Button(
                        onClick = onOpenRouter,
                        colors = ButtonDefaults.buttonColors(containerColor = EgyptGold.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.OpenInBrowser, contentDescription = null, tint = EgyptGold, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("لوحة الراوتر", color = EgyptGold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun HardwareMetricBadge(label: String, value: String, icon: ImageVector) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = EgyptGold, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
    }
}

@Composable
private fun InfoRow(label: String, value: String, isCode: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = if (isCode) FontFamily.Monospace else FontFamily.Default
            ),
            color = Color.White
        )
    }
}
