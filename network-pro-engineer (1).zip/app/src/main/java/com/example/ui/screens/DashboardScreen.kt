package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.NetworkTelemetry
import com.example.ui.components.OperatorBadge
import com.example.ui.components.PermissionsCard
import com.example.ui.components.SignalBarsIndicator
import com.example.ui.components.SpeedometerGauge
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalOrange
import com.example.ui.theme.SignalYellow
import com.example.utils.NetworkUtils

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    telemetry: NetworkTelemetry,
    isScanning: Boolean,
    isServiceRunning: Boolean,
    onRefresh: () -> Unit,
    onSaveReading: () -> Unit,
    onToggleService: () -> Unit,
    onOpenNetScan: () -> Unit = {},
    onToggleFieldEngineer: () -> Unit = {},
    onOpenReportTower: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val cell = telemetry.servingCell

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0B0F))
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Permissions banner if needed
        PermissionsCard(onPermissionsGranted = onRefresh)

        // Egyptian Operators Identification Badge
        OperatorBadge(
            operatorArabicName = cell?.operatorArabicName ?: "فودافون مصر",
            operatorEnglishName = cell?.operatorName ?: "Vodafone Egypt",
            simPhoneNumber = telemetry.simPhoneNumber,
            mccMnc = "${cell?.mcc ?: "602"} ${cell?.mnc ?: "02"}",
            networkGen = cell?.networkType ?: "4G LTE+"
        )

        // Main Speedometer and Signal Quality Hero Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = EgyptDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, EgyptGold.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (telemetry.isSimulated) SignalOrange else SignalGreen)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (telemetry.isSimulated) "المحاكاة الهندسية النشطة" else "متصل بالشبكة الحية",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = if (telemetry.isSimulated) SignalOrange else SignalGreen
                        )
                    }

                    // Governorate and district pill
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF202028), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${telemetry.currentGovernorate} - ${telemetry.currentDistrict}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EgyptGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Custom Canvas Speedometer
                SpeedometerGauge(
                    speedMbps = telemetry.speedMbps,
                    maxSpeed = 100f
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Signal Quality and Bars
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF141418), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "جودة إشارة البرج الحالي",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray
                        )
                        Text(
                            text = cell?.signalQuality ?: "تغطية ممتازة (Excellent)",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = EgyptWhite
                        )
                    }

                    SignalBarsIndicator(bars = cell?.signalBars ?: 4)
                }
            }
        }

        // Action Toolbar (NetScan, Refresh, Save, Field Engineer Mode)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // NetScan Button
            Button(
                onClick = onOpenNetScan,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("btn_netscan"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F1F2A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, EgyptGold),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Radar, contentDescription = null, tint = EgyptGold, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("NetScan", color = EgyptGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            // Refresh Button
            Button(
                onClick = onRefresh,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("btn_refresh"),
                colors = ButtonDefaults.buttonColors(containerColor = EgyptRed),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تحديث", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            // Save Reading Button
            Button(
                onClick = onSaveReading,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("btn_save_reading"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.BookmarkAdd, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("حفظ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Secondary Actions (Field Engineer Mode & Report Tower)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onToggleFieldEngineer,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (telemetry.isEngineerModeActive) EgyptRed else Color(0xFF4A4A58)
                )
            ) {
                Icon(
                    Icons.Default.Engineering,
                    contentDescription = null,
                    tint = if (telemetry.isEngineerModeActive) EgyptRed else EgyptGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (telemetry.isEngineerModeActive) "إيقاف المهندس" else "وضع المهندس",
                    color = if (telemetry.isEngineerModeActive) EgyptRed else EgyptWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = onOpenReportTower,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4A4A58))
            ) {
                Icon(Icons.Default.CellTower, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تبليغ عن برج", color = EgyptWhite, fontSize = 12.sp)
            }
        }

        // Section: RF Technical Parameters Grid (RSRP, RSRQ, SINR, PCI, EARFCN, TAC/LAC)
        Text(
            text = "المعايير الهندسية الدقيقة (RF Telecom Parameters)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = EgyptGold
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 2
        ) {
            // RSRP
            MetricBox(
                label = "قوة الإشارة (RSRP)",
                value = "${cell?.rsrp ?: -85} dBm",
                subtext = "الحد الأدنى -140 / الأقصى -44",
                valueColor = if ((cell?.rsrp ?: -85) > -85) SignalGreen else SignalOrange,
                modifier = Modifier.weight(1f)
            )

            // RSRQ
            MetricBox(
                label = "جودة الإشارة (RSRQ)",
                value = "${cell?.rsrq ?: -9} dB",
                subtext = "النطاق القياسي: -3 إلى -20",
                valueColor = EgyptWhite,
                modifier = Modifier.weight(1f)
            )

            // SINR
            MetricBox(
                label = "نسبة الإشارة للتشويش (SINR)",
                value = "${cell?.rssnr ?: 22.0} dB",
                subtext = "تشويش منخفض وجودة فائقة",
                valueColor = EgyptGold,
                modifier = Modifier.weight(1f)
            )

            // PCI
            MetricBox(
                label = "معرف الخلية المادي (PCI)",
                value = "${cell?.pci ?: 284}",
                subtext = "Physical Cell Identifier",
                valueColor = Color(0xFF80D8FF),
                modifier = Modifier.weight(1f)
            )

            // Cell ID
            MetricBox(
                label = "معرف البرج (Cell ID)",
                value = "${cell?.cellIdDec ?: 28475932L}",
                subtext = "Hex: ${cell?.cellIdHex ?: "0x1B27F1C"}",
                valueColor = EgyptWhite,
                modifier = Modifier.weight(1f)
            )

            // TAC / LAC
            MetricBox(
                label = "رمز التتبع (TAC / LAC)",
                value = "${cell?.tacOrLac ?: 4820}",
                subtext = "Tracking Area Code",
                valueColor = Color(0xFFFFD54F),
                modifier = Modifier.weight(1f)
            )

            // EARFCN & Frequency
            MetricBox(
                label = "قناة التردد (EARFCN)",
                value = "${cell?.earfcn ?: 1650}",
                subtext = "${cell?.bandName ?: "Band 3 (1800 MHz)"}",
                valueColor = Color(0xFFB39DDB),
                modifier = Modifier.weight(1f)
            )

            // CQI
            MetricBox(
                label = "مؤشر جودة القناة (CQI)",
                value = "${cell?.cqi ?: 14} / 15",
                subtext = "Channel Quality Indicator",
                valueColor = SignalGreen,
                modifier = Modifier.weight(1f)
            )
        }

        // Section: Distance to Serving Tower & Bearing
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = EgyptDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C35))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "المسافة المقدرة إلى البرج الخلوي",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = EgyptGold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        val dist = telemetry.distanceMeters ?: 380.0
                        Text(
                            text = NetworkUtils.formatDistance(dist),
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = EgyptWhite
                        )
                        Text(
                            text = "طريقة الحساب: ${telemetry.distanceMethod}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFAAAAAA)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Color(0xFF1B1B22), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "الاتجاه: ${String.format("%.0f", telemetry.bearingDegrees ?: 52f)}°",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = EgyptGold
                        )
                    }
                }
            }
        }

        // Section: Neighbor Cells List
        if (telemetry.neighborCells.isNotEmpty()) {
            Text(
                text = "الأبراج والقطاعات المجاورة (${telemetry.neighborCells.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = EgyptWhite
            )

            telemetry.neighborCells.forEach { neighbor ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141419))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${neighbor.operatorName} - PCI: ${neighbor.pci}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = EgyptWhite
                            )
                            Text(
                                text = "Cell ID: ${neighbor.cellId} | EARFCN: ${neighbor.earfcn}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${neighbor.rsrp} dBm",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (neighbor.rsrp > -85) SignalGreen else EgyptRed
                            )
                            Text(
                                text = neighbor.signalQuality,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFAAAAAA)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(80.dp))
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
    subtext: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFF15151B), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF252530), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFAAAAAA)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                ),
                color = valueColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtext,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = Color.Gray
            )
        }
    }
}
