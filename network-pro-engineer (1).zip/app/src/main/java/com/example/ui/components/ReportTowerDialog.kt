package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite

@Composable
fun ReportTowerDialog(
    isOpen: Boolean,
    currentLat: Double,
    currentLon: Double,
    onDismiss: () -> Unit,
    onSubmit: (cellId: Long, operator: String, band: String, freqMhz: Double, lat: Double, lon: Double, address: String, notes: String) -> Unit
) {
    if (!isOpen) return

    var cellIdInput by remember { mutableStateOf("") }
    var operatorInput by remember { mutableStateOf("فودافون مصر") }
    var bandInput by remember { mutableStateOf("Band 3 (1800 MHz)") }
    var addressInput by remember { mutableStateOf("") }
    var notesInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = EgyptDarkSurface,
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CellTower,
                    contentDescription = null,
                    tint = EgyptGold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تبليغ عن برج خلوي غير مسجل",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = EgyptWhite
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "سيتم تسجيل بيانات البرج في قاعدة البيانات المحلية ومشاركتها مع خريطة الرادار لتحسين دقة التغطية في مصر.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFA0A0A0)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = cellIdInput,
                    onValueChange = { cellIdInput = it },
                    label = { Text("معرف البرج (Cell ID)") },
                    placeholder = { Text("مثال: 28475932") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = operatorInput,
                    onValueChange = { operatorInput = it },
                    label = { Text("شركة الاتصالات") },
                    placeholder = { Text("فودافون / أورانج / اتصالات / وي") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = bandInput,
                    onValueChange = { bandInput = it },
                    label = { Text("نطاق التردد / الجيل") },
                    placeholder = { Text("4G LTE / 5G Sub-6 / Band 1/3/8") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = addressInput,
                    onValueChange = { addressInput = it },
                    label = { Text("العنوان أو المنطقة التقريبية") },
                    placeholder = { Text("مثال: شارع مصطفى النحاس، مدينة نصر") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("ملاحظات إضافية") },
                    placeholder = { Text("مثال: برج جديد تم تركيبه أعلى المبنى") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cid = cellIdInput.trim().toLongOrNull() ?: System.currentTimeMillis() % 100000000
                    onSubmit(
                        cid,
                        operatorInput.ifBlank { "فودافون مصر" },
                        bandInput.ifBlank { "Band 3" },
                        1800.0,
                        currentLat,
                        currentLon,
                        addressInput,
                        notesInput
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EgyptRed)
            ) {
                Text("حفظ وتبليغ", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = Color.Gray)
            }
        }
    )
}
