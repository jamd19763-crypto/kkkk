package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DnsBenchmarkResult
import com.example.data.model.NetworkTelemetry
import com.example.ui.DashboardViewModel
import com.example.ui.theme.EgyptDarkCard
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalOrange
import com.example.ui.theme.SignalYellow
import com.example.utils.NetworkUtils
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NetworkBoosterScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val dnsResults by viewModel.dnsBenchmarkResults.collectAsStateWithLifecycle()
    val isTestingDns by viewModel.isBenchmarkingDns.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(EgyptDarkSurface)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EgyptGold.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(EgyptGold.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = EgyptGold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "مُعزز الإشارة وتسريع الإنترنت",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = EgyptGold
                            )
                            Text(
                                text = "أدوات هندسية لتقوية التقاط الشبكة وتخفيض زمن الاستجابة (Ping)",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.LightGray
                            )
                        }
                    }
                }
            }
        }

        // 1. Antenna Compass towards Tower
        item {
            TowerDirectionCompassCard(telemetry)
        }

        // 2. Radio Flush / Airplane Reset Tool
        item {
            RadioFlushCard(
                onFlush = {
                    viewModel.refreshNow()
                    try {
                        context.startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
                    } catch (_: Exception) {}
                }
            )
        }

        // 3. DNS Benchmark Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF2E2E40), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "اختبار وتسريع خوادم الـ DNS",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = EgyptGold
                            )
                            Text(
                                text = "قياس سرعة الاستجابة واختيار الخادم الأسرع لتصفح الإنترنت والألعاب",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }

                        Button(
                            onClick = { viewModel.benchmarkDns() },
                            enabled = !isTestingDns,
                            colors = ButtonDefaults.buttonColors(containerColor = EgyptGold),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            if (isTestingDns) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("بدء الاختبار", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // DNS Results List
        items(dnsResults) { result ->
            DnsResultCard(
                result = result,
                onCopy = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    val clip = ClipData.newPlainText("Private DNS", result.dotHostname)
                    clipboard?.setPrimaryClip(clip)
                }
            )
        }

        // 4. Engineering Optimization Tips
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FlashOn, contentDescription = null, tint = EgyptGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "نصائح هندسية حقيقية لتقوية الإنترنت في جهازك:",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = EgyptGold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    OptimizationTipItem(
                        title = "1. التبديل لتردد Wi-Fi 5 GHz في الراوتر",
                        description = "تردد 2.4GHz شديد الازدحام بالتداخل مع راوترات الجيران وموجات البلوتوث. التبديل لـ 5GHz يمنحك سرعة مضاعفة وبنج منخفض للألعاب."
                    )
                    OptimizationTipItem(
                        title = "2. تفعيل ميزة VoLTE للمكالمات الصوتية",
                        description = "المكالمات العادية تجبر الهاتف على الرجوع إلى 3G مما يقطع بيانات 4G. ميزة VoLTE تبقيك على أسرع تردد 4G طوال المكالمة."
                    )
                    OptimizationTipItem(
                        title = "3. تقييد بيانات الخلفية للتطبيقات المستهلكة",
                        description = "تطبيقات مثل TikTok وفيسبوك تستهلك النطاق الترددي في الخلفية وترفع الـ Ping. تفعيل توفير البيانات يركز سرعة الإنترنت في التطبيق المفتوح فقط."
                    )
                    OptimizationTipItem(
                        title = "4. ضبط خادم الـ Private DNS المشفر",
                        description = "وضع الخادم الأسرع (مثل one.one.one.one) يسرع زمن فتح المواقع والتطبيقات بنسبة تصل إلى 40% مقارنة بـ DNS مزود الخدمة الافتراضي."
                    )
                }
            }
        }
    }
}

@Composable
private fun TowerDirectionCompassCard(telemetry: NetworkTelemetry) {
    val bearing = telemetry.bearingDegrees ?: 0f
    val distanceFormatted = NetworkUtils.formatDistanceArabic(telemetry.distanceMeters)
    val compassDir = NetworkUtils.bearingToCompassArabic(bearing)

    val animatedBearing by animateFloatAsState(
        targetValue = bearing,
        animationSpec = tween(durationMillis = 800),
        label = "compass_rotation"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SignalGreen.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(SignalGreen.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Explore, contentDescription = null, tint = SignalGreen, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "بوصلة التوجيه الهوائي نحو البرج (Tower Compass)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = SignalGreen
                    )
                    Text(
                        text = "وجّه هاتفك نحو زاوية البرج للحصول على أعلى RSRP وأفضل اتصال",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Interactive Compass Graphic
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .background(Color(0xFF101018), CircleShape)
                        .border(2.dp, EgyptGold.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(120.dp)) {
                        val radius = size.minDimension / 2
                        val center = Offset(size.width / 2, size.height / 2)

                        // Outer ring markers (N, S, E, W)
                        drawCircle(
                            color = Color(0xFF1E1E2C),
                            radius = radius,
                            center = center,
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }

                    // Rotating Arrow pointing to the tower bearing
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(animatedBearing),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(90.dp)) {
                            val w = size.width
                            val h = size.height
                            // Red pointer to tower
                            val path = Path().apply {
                                moveTo(w / 2, 8f)
                                lineTo(w / 2 - 14f, h / 2)
                                lineTo(w / 2 + 14f, h / 2)
                                close()
                            }
                            drawPath(path, color = EgyptRed)

                            // Gray tail
                            val tailPath = Path().apply {
                                moveTo(w / 2, h - 8f)
                                lineTo(w / 2 - 10f, h / 2)
                                lineTo(w / 2 + 10f, h / 2)
                                close()
                            }
                            drawPath(tailPath, color = Color.Gray)

                            drawCircle(color = EgyptGold, radius = 6f, center = Offset(w / 2, h / 2))
                        }
                    }

                    // Center Tower Icon
                    Icon(
                        Icons.Default.CellTower,
                        contentDescription = null,
                        tint = EgyptGold,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = "الاتجاه: $compassDir",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "المسافة للبرج: $distanceFormatted",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = EgyptGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "قوة الإشارة: ${telemetry.servingCell?.rsrp ?: -95} dBm",
                        style = MaterialTheme.typography.bodySmall,
                        color = SignalGreen
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "التردد: ${telemetry.servingCell?.bandName ?: "Band 3 (1800 MHz)"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.LightGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1B201B), RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "💡 نصيحة التوجيه: تحرك نحو النافذة أو الجهة المطلة على ($compassDir) لتقليل الحجب الإسمنتي ورفع سرعة الإنترنت وقوة الإشارة فوراً.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SignalGreen,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
private fun RadioFlushCard(onFlush: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = EgyptDarkCard),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, EgyptRed.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(EgyptRed.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, tint = EgyptRed, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "إنعاش المودم الراديوي (Cellular Radio Flush)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EgyptGold
                    )
                    Text(
                        text = "إجبار الهاتف على التبديل لأقوى وأحدث تردد خلوي متاح",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "غالباً ما يعلق الهاتف في قطاع مزدحم أو تردد بطيء (مثل Band 8 أو 3G). الضغط على إنعاش الراديو يعيد التفاوض الراديوي مع البرج ويجبر الهاتف على الارتباط بالتردد الأسرع (Band 3 / Band 1 أو 5G).",
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray,
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onFlush,
                colors = ButtonDefaults.buttonColors(containerColor = EgyptRed),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.AirplanemodeActive, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تنشيط وإنعاش الراديو الخلوي الآن", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun DnsResultCard(
    result: DnsBenchmarkResult,
    onCopy: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (result.isFastest) Color(0xFF242216) else EgyptDarkCard
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (result.isFastest) EgyptGold.copy(alpha = 0.6f) else Color(0xFF282838),
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (result.isFastest) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = EgyptGold, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Column {
                        Text(
                            text = result.providerName,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (result.isFastest) EgyptGold else Color.White
                        )
                        Text(
                            text = "IP: ${result.primaryIp} | DoT: ${result.dotHostname}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(
                            when {
                                result.latencyMs < 35 -> SignalGreen.copy(alpha = 0.2f)
                                result.latencyMs < 80 -> SignalYellow.copy(alpha = 0.2f)
                                else -> SignalOrange.copy(alpha = 0.2f)
                            },
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${result.latencyMs} ms",
                        color = if (result.latencyMs < 35) SignalGreen else SignalYellow,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = result.description,
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = result.status,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (result.latencyMs < 50) SignalGreen else Color.Gray
                )

                Button(
                    onClick = onCopy,
                    colors = ButtonDefaults.buttonColors(containerColor = EgyptGold.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = EgyptGold, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ للـ Private DNS", color = EgyptGold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun OptimizationTipItem(title: String, description: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = Color.LightGray,
            lineHeight = 18.sp
        )
    }
}
