@echo off
chcp 65001 > nul
echo ===================================================
echo     بناء تطبيق مصر الرقمية (Digital Egypt)
echo             تحويل المشروع إلى ملف APK
echo ===================================================
echo.

REM التحقق من وجود ملف .env
if not exist ".env" (
    echo [1/3] إنشاء ملف .env الافتراضي...
    type nul > .env
)

REM فحص ملف التوقيع debug.keystore
if not exist "debug.keystore" (
    echo [2/3] تجهيز مفتاح التوقيع التجريبي...
    if exist "debug.keystore.base64" (
        certutil -decode debug.keystore.base64 debug.keystore > nul 2>&1
    )
)

echo [3/3] جاري تجميع وبناء ملف الـ APK (الرجاء الانتظار دقائق)...
call gradlew.bat assembleDebug --no-daemon

if %ERRORLEVEL% equ 0 (
    echo.
    echo ===================================================
    echo  تم بناء وتوليد ملف الـ APK بنجاح!
    echo ===================================================
    echo المسار: app\build\outputs\apk\debug\app-debug.apk
    echo.
    if exist "app\build\outputs\apk\debug" (
        explorer app\build\outputs\apk\debug
    )
) else (
    echo.
    echo [خطأ] فشل البناء. يرجى التأكد من تثبيت Java JDK 17 و Android SDK على جهازك.
)

pause
