package com.example.embedding

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.DeflaterOutputStream
import java.util.zip.InflaterInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.random.Random

/**
 * Data Craft Studio - Embedding & Injection Engine
 * 
 * High-performance on-device suite designed for research and educational analysis:
 * 1. TextEmbeddingEngine: Zero-width steganography, Unicode override injection, compressed text payloads.
 * 2. ImageEmbeddingEngine: Injects raw payloads into PNG/JPEG bitstreams, builds multi-format headers.
 * 3. AudioEmbeddingEngine: MP3 frame padding, multi-format audio headers (MP3/WAV/OGG).
 * 4. VideoEmbeddingEngine: MP4 ISO Base Media container embedding, multi-format video headers (MP4/AVI/MKV).
 * 5. StickerEmbeddingEngine: WebP alpha channel graphics embedding, dual WebP/PNG headers.
 * 6. CompressionEngine: Repeated Deflate/Inflate cycles, recursive zip payload generation.
 * 7. BinaryDataEngine: Deterministic pattern synthesis, cryptographically secure binary merging.
 * 8. UnicodeEngine: Wide Unicode range synthesis, BiDi control marks, and directional overrides.
 */

// ============================================================================
// 1. Text Embedding Engine (محرك دمج النصوص)
// ============================================================================

class TextEmbeddingEngine {

    companion object {
        private val ZERO_WIDTH_CHARS = charArrayOf(
            '\u200B', // Zero-Width Space
            '\u200C', // Zero-Width Non-Joiner
            '\u200D', // Zero-Width Joiner
            '\u2060', // Word Joiner
            '\uFEFF', // Zero-Width No-Break Space / BOM
            '\u2061', // Function Application
            '\u2062', // Invisible Times
            '\u2063'  // Invisible Separator
        )

        private val OVERRIDE_CHARS = charArrayOf(
            '\u202E', // Right-to-Left Override (RLO)
            '\u202D', // Left-to-Right Override (LRO)
            '\u2066', // Left-to-Right Isolate (LRI)
            '\u2067', // Right-to-Left Isolate (RLI)
            '\u2068', // First Strong Isolate (FSI)
            '\u2069'  // Pop Directional Isolate (PDI)
        )
    }

    /**
     * Embeds arbitrary text payload into a host visible text using 2-bit Zero-Width encoding.
     * The host text remains visually unaltered in standard rendering engines.
     *
     * @param visibleText The surface text visible to end users.
     * @param hiddenData The secret payload to embed invisibly.
     * @return Formatted string containing visible text followed by invisible zero-width characters.
     */
    fun embedTextInText(visibleText: String, hiddenData: String): String {
        return try {
            if (hiddenData.isEmpty()) return visibleText

            // Convert hidden data into 8-bit binary strings
            val binaryData = hiddenData.toByteArray(Charsets.UTF_8).joinToString("") { byte ->
                String.format("%8s", Integer.toBinaryString(byte.toInt() and 0xFF)).replace(' ', '0')
            }

            // Convert binary into 2-bit Zero-Width representations
            val hiddenString = StringBuilder(binaryData.length / 2)
            for (i in binaryData.indices step 2) {
                val bits = binaryData.substring(i, minOf(i + 2, binaryData.length))
                val index = when (bits) {
                    "00" -> 0
                    "01" -> 1
                    "10" -> 2
                    else -> 3
                }
                hiddenString.append(ZERO_WIDTH_CHARS[index])
            }

            visibleText + hiddenString.toString()
        } catch (e: Exception) {
            visibleText
        }
    }

    /**
     * Extracts and decodes hidden payload embedded via [embedTextInText].
     */
    fun extractTextFromText(embeddedText: String): String {
        return try {
            val bitBuilder = StringBuilder()
            for (ch in embeddedText) {
                val index = ZERO_WIDTH_CHARS.indexOf(ch)
                if (index in 0..3) {
                    val bits = when (index) {
                        0 -> "00"
                        1 -> "01"
                        2 -> "10"
                        else -> "11"
                    }
                    bitBuilder.append(bits)
                }
            }

            val bitString = bitBuilder.toString()
            if (bitString.length < 8) return ""

            val byteCount = bitString.length / 8
            val bytes = ByteArray(byteCount)
            for (i in 0 until byteCount) {
                val byteStr = bitString.substring(i * 8, (i + 1) * 8)
                bytes[i] = byteStr.toInt(2).toByte()
            }
            String(bytes, Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Embeds payload into text using Right-to-Left Override and directional isolates.
     */
    fun embedWithUnicodeOverride(visibleText: String, hiddenData: String): String {
        return try {
            val result = StringBuilder(visibleText.length + hiddenData.length * 2 + 10)
            result.append(visibleText)
            result.append('\u202E') // RTL Override

            for (i in hiddenData.indices) {
                result.append(hiddenData[i])
                if (i % 10 == 0) {
                    result.append(OVERRIDE_CHARS.random())
                }
            }

            result.append('\u202C') // Pop Directional Formatting
            result.toString()
        } catch (e: Exception) {
            visibleText + hiddenData
        }
    }

    /**
     * Compresses the hidden payload via DeflaterOutputStream and embeds it safely
     * as Base64 wrapped between zero-width boundaries.
     */
    fun embedCompressedData(visibleText: String, hiddenData: String): String {
        return try {
            val compressed = compressData(hiddenData.toByteArray(Charsets.UTF_8))
            val base64Data = Base64.encodeToString(compressed, Base64.NO_WRAP)
            visibleText + "\u200B" + base64Data + "\u200C"
        } catch (e: Exception) {
            visibleText + "\u200B" + hiddenData + "\u200C"
        }
    }

    /**
     * Extracts and decompresses payload embedded via [embedCompressedData].
     */
    fun extractCompressedData(embeddedText: String): String {
        return try {
            val start = embeddedText.indexOf('\u200B')
            val end = embeddedText.lastIndexOf('\u200C')
            if (start != -1 && end != -1 && end > start) {
                val b64 = embeddedText.substring(start + 1, end).trim()
                val compressed = Base64.decode(b64, Base64.NO_WRAP)
                val decompressed = decompressData(compressed)
                String(decompressed, Charsets.UTF_8)
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    private fun compressData(data: ByteArray): ByteArray {
        val outputStream = ByteArrayOutputStream()
        val deflater = DeflaterOutputStream(outputStream)
        deflater.write(data)
        deflater.close()
        return outputStream.toByteArray()
    }

    private fun decompressData(data: ByteArray): ByteArray {
        val inputStream = ByteArrayInputStream(data)
        val inflater = InflaterInputStream(inputStream)
        return inflater.readBytes()
    }
}

// ============================================================================
// 2. Image Embedding Engine (محرك دمج الصور)
// ============================================================================

class ImageEmbeddingEngine {

    /**
     * Synthesizes a PNG image of requested dimensions and injects an arbitrary byte payload
     * directly into the image byte stream.
     *
     * @param width Image width in pixels.
     * @param height Image height in pixels.
     * @param embeddedDataSize Byte size of the injected payload.
     * @return Combined PNG and embedded payload byte array.
     */
    fun embedDataInPNG(width: Int, height: Int, embeddedDataSize: Long): ByteArray {
        return try {
            val safeWidth = width.coerceIn(1, 4096)
            val safeHeight = height.coerceIn(1, 4096)
            val safePayloadSize = embeddedDataSize.coerceIn(0L, 50L * 1024 * 1024).toInt()

            val bitmap = Bitmap.createBitmap(safeWidth, safeHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.BLACK)

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            val pngData = outputStream.toByteArray()

            val embeddedData = ByteArray(safePayloadSize) { index ->
                (index * 31 + 17).toByte() // Deterministic synthetic pattern
            }

            val combinedData = ByteArray(pngData.size + embeddedData.size)
            System.arraycopy(pngData, 0, combinedData, 0, pngData.size)
            System.arraycopy(embeddedData, 0, combinedData, pngData.size, embeddedData.size)

            combinedData
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Synthesizes a JPEG image and injects arbitrary data at the tail of the bitstream.
     */
    fun embedDataInJPEG(width: Int, height: Int, embeddedDataSize: Long): ByteArray {
        return try {
            val safeWidth = width.coerceIn(1, 4096)
            val safeHeight = height.coerceIn(1, 4096)
            val safePayloadSize = embeddedDataSize.coerceIn(0L, 50L * 1024 * 1024).toInt()

            val bitmap = Bitmap.createBitmap(safeWidth, safeHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
            val jpegData = outputStream.toByteArray()

            val embeddedData = ByteArray(safePayloadSize) { index ->
                (index * 7 + 3).toByte()
            }

            jpegData + embeddedData
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Constructs a polyglot test image with stacked magic byte headers for PNG, JPEG, and GIF formats.
     */
    fun createMultiHeaderImage(dataSize: Long): ByteArray {
        return try {
            val safeSize = dataSize.coerceIn(1L, 20L * 1024 * 1024).toInt()

            val pngHeader = byteArrayOf(
                0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
            )
            val jpegHeader = byteArrayOf(
                0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte()
            )
            val gifHeader = byteArrayOf(0x47, 0x49, 0x46, 0x38, 0x39, 0x61)

            val data = ByteArray(safeSize) { index ->
                (index * 13 + 5).toByte()
            }

            pngHeader + jpegHeader + gifHeader + data
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Helper to write embedded image bytes directly to a cache file.
     */
    fun embedDataInPNGFile(context: Context, width: Int, height: Int, embeddedDataSize: Long): File {
        val file = File(context.cacheDir, "embedded_image_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { it.write(embedDataInPNG(width, height, embeddedDataSize)) }
        return file
    }
}

// ============================================================================
// 3. Audio Embedding Engine (محرك دمج الملفات الصوتية)
// ============================================================================

class AudioEmbeddingEngine {

    /**
     * Injects synthetic payload into an MP3 audio bitstream with custom ID3v2 header.
     *
     * @param audioDataSize Simulated audio frame byte size.
     * @param embeddedDataSize Size of injected payload.
     * @return Complete MP3 byte array with embedded payload.
     */
    fun embedDataInMP3(audioDataSize: Long, embeddedDataSize: Long): ByteArray {
        return try {
            val safeAudioSize = audioDataSize.coerceIn(1L, 50L * 1024 * 1024).toInt()
            val safeEmbeddedSize = embeddedDataSize.coerceIn(0L, 50L * 1024 * 1024).toInt()

            val mp3Header = byteArrayOf(
                0xFF.toByte(), 0xFB.toByte(), 0x90.toByte(), 0x00.toByte(),
                0x49.toByte(), 0x44.toByte(), 0x33.toByte(), 0x03.toByte()
            )

            val audioData = ByteArray(safeAudioSize) { index ->
                (index * 29 + 11).toByte()
            }

            val embeddedData = ByteArray(safeEmbeddedSize) { index ->
                (index * 17 + 7).toByte()
            }

            mp3Header + audioData + embeddedData
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Constructs a polyglot audio file incorporating headers for MP3, WAV (RIFF), and OGG (OggS).
     */
    fun createMultiHeaderAudio(dataSize: Long): ByteArray {
        return try {
            val safeSize = dataSize.coerceIn(1L, 20L * 1024 * 1024).toInt()

            val mp3Header = byteArrayOf(
                0xFF.toByte(), 0xFB.toByte(), 0x90.toByte(), 0x00.toByte()
            )
            val wavHeader = byteArrayOf(
                0x52, 0x49, 0x46, 0x46, 0x57, 0x41, 0x56, 0x45 // RIFF WAVE
            )
            val oggHeader = byteArrayOf(
                0x4F, 0x67, 0x67, 0x53 // OggS
            )

            val data = ByteArray(safeSize) { index ->
                (index * 23 + 13).toByte()
            }

            mp3Header + wavHeader + oggHeader + data
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Helper to write embedded audio bytes to file.
     */
    fun embedDataInMP3File(context: Context, audioDataSize: Long, embeddedDataSize: Long): File {
        val file = File(context.cacheDir, "embedded_audio_${System.currentTimeMillis()}.mp3")
        FileOutputStream(file).use { it.write(embedDataInMP3(audioDataSize, embeddedDataSize)) }
        return file
    }
}

// ============================================================================
// 4. Video Embedding Engine (محرك دمج ملفات الفيديو)
// ============================================================================

class VideoEmbeddingEngine {

    /**
     * Constructs an MP4 ISO Base Media container (ftypmp42) and injects embedded payload data.
     *
     * @param videoDataSize Simulated video sample data size in bytes.
     * @param embeddedDataSize Size of injected payload in bytes.
     * @return Byte array containing MP4 container structure with embedded payload.
     */
    fun embedDataInMP4(videoDataSize: Long, embeddedDataSize: Long): ByteArray {
        return try {
            val safeVideoSize = videoDataSize.coerceIn(1L, 50L * 1024 * 1024).toInt()
            val safeEmbeddedSize = embeddedDataSize.coerceIn(0L, 50L * 1024 * 1024).toInt()

            val mp4Header = byteArrayOf(
                0x00, 0x00, 0x00, 0x18, // 24-byte box size
                0x66, 0x74, 0x79, 0x70, // 'ftyp'
                0x6D, 0x70, 0x34, 0x32  // 'mp42'
            )

            val videoData = ByteArray(safeVideoSize) { index ->
                (index * 37 + 19).toByte()
            }

            val embeddedData = ByteArray(safeEmbeddedSize) { index ->
                (index * 11 + 3).toByte()
            }

            mp4Header + videoData + embeddedData
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Constructs a polyglot video file with stacked MP4, AVI, and Matroska (MKV) headers.
     */
    fun createMultiHeaderVideo(dataSize: Long): ByteArray {
        return try {
            val safeSize = dataSize.coerceIn(1L, 20L * 1024 * 1024).toInt()

            val mp4Header = byteArrayOf(
                0x00, 0x00, 0x00, 0x18,
                0x66, 0x74, 0x79, 0x70
            )
            val aviHeader = byteArrayOf(
                0x52, 0x49, 0x46, 0x46, 0x41, 0x56, 0x49 // RIFFAVI
            )
            val mkvHeader = byteArrayOf(
                0x1A, 0x45, 0xDF.toByte(), 0xA3.toByte() // EBML ID for MKV
            )

            val data = ByteArray(safeSize) { index ->
                (index * 41 + 23).toByte()
            }

            mp4Header + aviHeader + mkvHeader + data
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Helper to write embedded video bytes to a file.
     */
    fun embedDataInMP4File(context: Context, videoDataSize: Long, embeddedDataSize: Long): File {
        val file = File(context.cacheDir, "embedded_video_${System.currentTimeMillis()}.mp4")
        FileOutputStream(file).use { it.write(embedDataInMP4(videoDataSize, embeddedDataSize)) }
        return file
    }
}

// ============================================================================
// 5. Sticker Embedding Engine (محرك دمج الملصقات)
// ============================================================================

class StickerEmbeddingEngine {

    /**
     * Generates a transparent WebP circular badge and appends arbitrary data to the file bitstream.
     *
     * @param width Canvas width in pixels.
     * @param height Canvas height in pixels.
     * @param embeddedDataSize Byte size of the injected payload.
     * @return WebP byte array containing graphic asset and injected data.
     */
    fun embedDataInWebP(width: Int, height: Int, embeddedDataSize: Long): ByteArray {
        return try {
            val safeWidth = width.coerceIn(1, 2048)
            val safeHeight = height.coerceIn(1, 2048)
            val safePayloadSize = embeddedDataSize.coerceIn(0L, 50L * 1024 * 1024).toInt()

            val bitmap = Bitmap.createBitmap(safeWidth, safeHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.TRANSPARENT)

            val paint = Paint().apply {
                color = Color.RED
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            canvas.drawCircle(safeWidth / 2f, safeHeight / 2f, safeWidth / 4f, paint)

            val outputStream = ByteArrayOutputStream()
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION")
                Bitmap.CompressFormat.WEBP
            }
            bitmap.compress(format, 100, outputStream)
            val webpData = outputStream.toByteArray()

            val embeddedData = ByteArray(safePayloadSize) { index ->
                (index * 19 + 7).toByte()
            }

            webpData + embeddedData
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Constructs a multi-header asset with WebP RIFF and PNG signatures.
     */
    fun createMultiHeaderSticker(dataSize: Long): ByteArray {
        return try {
            val safeSize = dataSize.coerceIn(1L, 20L * 1024 * 1024).toInt()

            val webpHeader = byteArrayOf(
                0x52, 0x49, 0x46, 0x46, 0x57, 0x45, 0x42, 0x50 // RIFFWEBP
            )
            val pngHeader = byteArrayOf(
                0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
            )

            val data = ByteArray(safeSize) { index ->
                (index * 31 + 17).toByte()
            }

            webpHeader + pngHeader + data
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Helper to write embedded WebP sticker to file.
     */
    fun embedDataInWebPFile(context: Context, width: Int, height: Int, embeddedDataSize: Long): File {
        val file = File(context.cacheDir, "embedded_sticker_${System.currentTimeMillis()}.webp")
        FileOutputStream(file).use { it.write(embedDataInWebP(width, height, embeddedDataSize)) }
        return file
    }
}

// ============================================================================
// 6. Compression Engine (محرك الضغط المتكرر)
// ============================================================================

class CompressionEngine {

    /**
     * Iteratively compresses byte array multiple times using the Deflate algorithm.
     *
     * @param data Input byte array.
     * @param iterations Number of sequential compression rounds.
     * @return Repeatedly compressed byte array.
     */
    fun compressRepeatedly(data: ByteArray, iterations: Int): ByteArray {
        var currentData = data
        val safeIterations = iterations.coerceIn(1, 10)
        repeat(safeIterations) {
            currentData = compress(currentData)
        }
        return currentData
    }

    /**
     * Iteratively decompresses byte array across specified rounds.
     */
    fun decompressRepeatedly(data: ByteArray, iterations: Int): ByteArray {
        var currentData = data
        val safeIterations = iterations.coerceIn(1, 10)
        repeat(safeIterations) {
            currentData = decompress(currentData)
        }
        return currentData
    }

    private fun compress(data: ByteArray): ByteArray {
        return try {
            val outputStream = ByteArrayOutputStream()
            val deflater = DeflaterOutputStream(outputStream)
            deflater.write(data)
            deflater.close()
            outputStream.toByteArray()
        } catch (e: Exception) {
            data
        }
    }

    private fun decompress(data: ByteArray): ByteArray {
        return try {
            val inputStream = ByteArrayInputStream(data)
            val inflater = InflaterInputStream(inputStream)
            inflater.readBytes()
        } catch (e: Exception) {
            data
        }
    }

    /**
     * Generates a zip archive containing high-ratio repetitive patterns for decompression profiling.
     *
     * @param compressedSize Target compression limit indicator.
     * @param decompressedSize Uncompressed stream length represented in the archive.
     * @return Valid ZIP file byte array.
     */
    fun createZipBomb(compressedSize: Long, decompressedSize: Long): ByteArray {
        return try {
            val outputStream = ByteArrayOutputStream()
            val zipOutputStream = ZipOutputStream(outputStream)

            val entry = ZipEntry("data.txt")
            zipOutputStream.putNextEntry(entry)

            val chunk = ByteArray(1024) { index -> (index % 256).toByte() }
            val targetSize = decompressedSize.coerceIn(1024L, 50L * 1024 * 1024)
            var written = 0L

            while (written < targetSize) {
                val toWrite = minOf(chunk.size.toLong(), targetSize - written).toInt()
                zipOutputStream.write(chunk, 0, toWrite)
                written += toWrite
            }

            zipOutputStream.closeEntry()
            zipOutputStream.close()

            outputStream.toByteArray()
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Helper to write zip payload to file.
     */
    fun createZipBombFile(context: Context, compressedSize: Long, decompressedSize: Long): File {
        val file = File(context.cacheDir, "zip_archive_${System.currentTimeMillis()}.zip")
        FileOutputStream(file).use { it.write(createZipBomb(compressedSize, decompressedSize)) }
        return file
    }
}

// ============================================================================
// 7. Binary Data Engine (محرك البيانات الثنائية)
// ============================================================================

class BinaryDataEngine {

    /**
     * Synthesizes deterministic patterned binary streams.
     *
     * @param size Stream length in bytes.
     * @param pattern Pattern multiplier value.
     */
    fun createBinaryData(size: Long, pattern: Int = 0xFF): ByteArray {
        val safeSize = size.coerceIn(1L, 50L * 1024 * 1024).toInt()
        return ByteArray(safeSize) { index ->
            (index * pattern % 256).toByte()
        }
    }

    /**
     * Generates cryptographically pseudorandom binary stream of requested size.
     */
    fun createRandomBinaryData(size: Long): ByteArray {
        val safeSize = size.coerceIn(1L, 50L * 1024 * 1024).toInt()
        return ByteArray(safeSize) {
            Random.nextInt(256).toByte()
        }
    }

    /**
     * Efficiently merges a collection of binary arrays into a single contiguous byte array.
     */
    fun mergeBinaryData(dataList: List<ByteArray>): ByteArray {
        return try {
            val totalSize = dataList.sumOf { it.size }
            val result = ByteArray(totalSize)
            var offset = 0

            for (data in dataList) {
                System.arraycopy(data, 0, result, offset, data.size)
                offset += data.size
            }

            result
        } catch (e: Exception) {
            ByteArray(0)
        }
    }
}

// ============================================================================
// 8. Unicode Engine (محرك Unicode)
// ============================================================================

class UnicodeEngine {

    companion object {
        private val UNICODE_RANGES = listOf(
            0x0000..0x007F,  // Basic Latin
            0x0080..0x00FF,  // Latin-1 Supplement
            0x202A..0x202E,  // Directional Characters
            0x2066..0x2069,  // Directional Isolates
            0x200B..0x200F,  // Zero-Width Characters
            0xFEFF..0xFEFF,  // Byte Order Mark (BOM)
            0x1F600..0x1F64F // Emoticons
        )

        private val ZERO_WIDTH_CHARS = charArrayOf('\u200B', '\u200C', '\u200D', '\u2060', '\uFEFF')
    }

    /**
     * Synthesizes complex multilingual Unicode text spanning multiple distinct character blocks.
     *
     * @param size Target character length.
     * @return Generated string composed of diverse Unicode points.
     */
    fun generateUnicodeText(size: Long): String {
        return try {
            val safeSize = size.coerceIn(1L, 100_000L)
            val result = StringBuilder(safeSize.toInt())
            var currentSize = 0L

            while (currentSize < safeSize) {
                val range = UNICODE_RANGES.random()
                val codePoint = range.random()
                result.append(Character.toChars(codePoint))
                currentSize = result.length.toLong()
            }

            result.toString()
        } catch (e: Exception) {
            "DATA_CRAFT_UNICODE"
        }
    }

    /**
     * Generates a string comprised exclusively of randomly selected Zero-Width invisible characters.
     */
    fun generateZeroWidthChars(count: Int): String {
        val safeCount = count.coerceIn(1, 100_000)
        return StringBuilder(safeCount).apply {
            repeat(safeCount) {
                append(ZERO_WIDTH_CHARS.random())
            }
        }.toString()
    }

    /**
     * Generates non-printable ASCII control characters (0x00 to 0x1F).
     */
    fun generateControlChars(count: Int): String {
        val safeCount = count.coerceIn(1, 50_000)
        return StringBuilder(safeCount).apply {
            repeat(safeCount) {
                append(Random.nextInt(0x20).toChar())
            }
        }.toString()
    }

    /**
     * Generates repeated Right-to-Left Override (\u202E) control characters.
     */
    fun generateRTLOverrideChars(count: Int): String {
        val safeCount = count.coerceIn(1, 50_000)
        return StringBuilder(safeCount).apply {
            repeat(safeCount) {
                append('\u202E')
            }
        }.toString()
    }
}

// ============================================================================
// 9. Unified Embedding Engine Facade (الواجهة الموحدة للمحرك)
// ============================================================================

/**
 * Singleton facade providing access to all embedding and injection capabilities.
 */
object EmbeddingEngine {
    val text = TextEmbeddingEngine()
    val image = ImageEmbeddingEngine()
    val audio = AudioEmbeddingEngine()
    val video = VideoEmbeddingEngine()
    val sticker = StickerEmbeddingEngine()
    val compression = CompressionEngine()
    val binary = BinaryDataEngine()
    val unicode = UnicodeEngine()
}
