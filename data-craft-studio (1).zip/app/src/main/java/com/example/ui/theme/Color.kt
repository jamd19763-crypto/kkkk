package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonGreen = Color(0xFF00FF41)
val NeonGreenDim = Color(0xFF00B32D)
val NeonRed = Color(0xFFFF0033)
val NeonRedDim = Color(0xFFB30024)
val NeonCyan = Color(0xFF00E5FF)
val NeonAmber = Color(0xFFFFB300)

val CyberBlack = Color(0xFF070A0E)
val CyberDark = Color(0xFF0D1117)
val CyberCard = Color(0xFF161B22)
val CyberCardBorder = Color(0xFF30363D)
val CyberCardHover = Color(0xFF21262D)

val TextPrimary = Color(0xFFE6EDF3)
val TextSecondary = Color(0xFF8B949E)
val TextGreen = Color(0xFF00FF41)
val TextRed = Color(0xFFFF4D6D)
