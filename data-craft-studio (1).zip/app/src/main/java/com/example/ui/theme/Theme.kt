package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CyberColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = CyberBlack,
    primaryContainer = Color(0xFF003810),
    onPrimaryContainer = NeonGreen,

    secondary = NeonCyan,
    onSecondary = CyberBlack,
    secondaryContainer = Color(0xFF00363D),
    onSecondaryContainer = NeonCyan,

    tertiary = NeonRed,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF4A000D),
    onTertiaryContainer = NeonRed,

    background = CyberBlack,
    onBackground = TextPrimary,

    surface = CyberDark,
    onSurface = TextPrimary,
    surfaceVariant = CyberCard,
    onSurfaceVariant = TextSecondary,

    outline = CyberCardBorder,
    outlineVariant = Color(0xFF21262D),

    error = NeonRed,
    onError = Color.White,
    errorContainer = Color(0xFF3B0007),
    onErrorContainer = Color(0xFFFF8095)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    // We enforce the developer cyberpunk neon dark scheme for the researcher lab UI
    MaterialTheme(
        colorScheme = CyberColorScheme,
        typography = Typography,
        content = content
    )
}
