package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                DataCraftStudioApp()
            }
        }
    }
}

/**
 * Main application navigation and shell with cyberpunk neon aesthetics.
 */
@Composable
fun DataCraftStudioApp(viewModel: LabViewModel = viewModel()) {
    val context = LocalContext.current
    var currentTab by rememberSaveable { mutableIntStateOf(0) }

    val stats by viewModel.stats.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val statusText by viewModel.statusText.collectAsState()
    val latestResult by viewModel.latestResult.collectAsState()

    var showResultDialog by remember { mutableStateOf(false) }

    // Automatically prompt modal when new result is generated
    val activeResult = latestResult
    val hasResult = activeResult != null

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack),
        topBar = {
            TopStatusBar(
                stats = stats,
                isLoading = isLoading,
                progress = progress,
                statusText = statusText
            )
        },
        bottomBar = {
            BottomCyberNav(
                currentTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CyberBlack)
        ) {
            when (currentTab) {
                0 -> DataEmbeddingLab(viewModel = viewModel)
                1 -> PerformanceAnalysisLab(viewModel = viewModel)
                2 -> MediaCreationLab(viewModel = viewModel)
                3 -> ToolsCenter(viewModel = viewModel)
            }
        }
    }

    // Modal dialog for viewing details and sharing result
    if (hasResult && activeResult != null) {
        ResultDetailDialog(
            result = activeResult,
            onDismiss = { viewModel.clearResult() },
            onShare = { viewModel.shareResult(context, activeResult) }
        )
    }
}

/**
 * Top persistent status and telemetry bar.
 */
@Composable
fun TopStatusBar(
    stats: LabStats,
    isLoading: Boolean,
    progress: Float,
    statusText: String
) {
    Surface(
        color = CyberDark,
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .border(1.dp, CyberCardBorder)
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(NeonGreen, CircleShape)
                            .border(1.dp, Color.White, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "استوديو هندسة البيانات",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "DATA CRAFT STUDIO",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontSize = 9.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(NeonGreen.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .border(1.dp, NeonGreen.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "محلي • V1.0",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Live metrics counter strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatBadge(label = "العمليات", value = "${stats.operationsCount}")
                StatBadge(label = "المعالجة", value = "${stats.bytesProcessed / 1024} ك.ب")
                StatBadge(label = "المدمج", value = "${stats.bytesEmbedded} ب")
                StatBadge(label = "الملفات", value = "${stats.filesGeneratedCount}")
                StatBadge(label = "الذاكرة", value = "%.1f م.ب".format(stats.peakMemoryMb))
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Dynamic progress and status text
            AnimatedVisibility(visible = isLoading) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp),
                        color = NeonGreen,
                        trackColor = CyberCardBorder
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }

            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall,
                color = if (isLoading) NeonAmber else TextSecondary,
                maxLines = 1
            )
        }
    }
}

@Composable
fun StatBadge(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 9.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = NeonGreen,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

/**
 * Bottom navigation bar supporting 4 labs with navigationBars insets handling.
 */
@Composable
fun BottomCyberNav(
    currentTab: Int,
    onTabSelected: (Int) -> Unit
) {
    val items = listOf(
        NavItem("تضمين البيانات", "تضمين", Icons.Default.VisibilityOff),
        NavItem("تحليل الأداء", "تحليل", Icons.Default.Analytics),
        NavItem("صناعة الوسائط", "وسائط", Icons.Default.VideoLibrary),
        NavItem("مركز الأدوات", "أدوات", Icons.Default.Terminal)
    )

    NavigationBar(
        containerColor = CyberDark,
        contentColor = TextPrimary,
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .border(1.dp, CyberCardBorder)
    ) {
        items.forEachIndexed { index, item ->
            val isSelected = currentTab == index
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(index) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = if (isSelected) NeonGreen else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) NeonGreen else TextSecondary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = NeonGreen,
                    unselectedIconColor = TextSecondary,
                    selectedTextColor = NeonGreen,
                    unselectedTextColor = TextSecondary,
                    indicatorColor = NeonGreen.copy(alpha = 0.15f)
                ),
                modifier = Modifier.testTag("nav_tab_$index")
            )
        }
    }
}

data class NavItem(val label: String, val arabicLabel: String, val icon: ImageVector)

/**
 * Dialog displaying result artifact, preview content, and Share button.
 */
@Composable
fun ResultDetailDialog(
    result: OutputResult,
    onDismiss: () -> Unit,
    onShare: () -> Unit
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberDark,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.border(1.dp, NeonGreen, RoundedCornerShape(12.dp)),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = result.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = TextSecondary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = result.summary,
                    style = MaterialTheme.typography.bodySmall,
                    color = NeonCyan,
                    fontWeight = FontWeight.Medium
                )

                if (result.file != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CyberCard, RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "الملف المنشأ: ${result.file.name}\nالحجم: ${result.file.length()} بايت\nالنوع: ${result.mimeType}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary
                        )
                    }
                }

                if (!result.content.isNullOrEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CyberBlack, RoundedCornerShape(8.dp))
                            .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = result.content,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!result.content.isNullOrEmpty()) {
                    CyberOutlinedButton(
                        text = "نسخ النص",
                        modifier = Modifier.width(90.dp),
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("DataCraft", result.content))
                            Toast.makeText(context, "تم النسخ إلى الحافظة", Toast.LENGTH_SHORT).show()
                        }
                    )
                }

                CyberButton(
                    text = "مشاركة الهدف",
                    modifier = Modifier.width(130.dp),
                    onClick = onShare
                )
            }
        },
        dismissButton = {
            CyberOutlinedButton(
                text = "إغلاق",
                borderColor = CyberCardBorder,
                modifier = Modifier.width(80.dp),
                onClick = onDismiss
            )
        }
    )
}
