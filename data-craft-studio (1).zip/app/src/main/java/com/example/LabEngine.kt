package com.example

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.util.Base64
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.ln
import kotlin.math.sin

/**
 * Log entry for the live system event console.
 */
data class LogEntry(
    val id: Long = System.currentTimeMillis() + (0..999).random(),
    val timestamp: String = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date()),
    val level: LogLevel = LogLevel.INFO,
    val tag: String,
    val message: String
)

enum class LogLevel {
    INFO, SUCCESS, WARN, ERROR
}

/**
 * Statistics counters maintained across all lab tools.
 */
data class LabStats(
    val operationsCount: Int = 0,
    val bytesProcessed: Long = 0L,
    val bytesEmbedded: Long = 0L,
    val filesGeneratedCount: Int = 0,
    val benchmarksCompleted: Int = 0,
    val peakMemoryMb: Double = 0.0
)

/**
 * Settings for the studio execution environment.
 */
data class LabSettings(
    val defaultBufferSizeKb: Int = 64,
    val benchmarkIterations: Int = 1000,
    val compressionLevel: Int = 6,
    val enableVerboseLogging: Boolean = true
)

/**
 * Represents a generated output result that can be viewed or shared.
 */
data class OutputResult(
    val title: String,
    val summary: String,
    val content: String? = null,
    val file: File? = null,
    val mimeType: String = "text/plain"
)

/**
 * Central ViewModel managing state, event logs, statistics, and async tasks.
 */
class LabViewModel : ViewModel() {

    private val _stats = MutableStateFlow(LabStats())
    val stats: StateFlow<LabStats> = _stats.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _statusText = MutableStateFlow("النظام جاهز - استوديو معالجة البيانات")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _latestResult = MutableStateFlow<OutputResult?>(null)
    val latestResult: StateFlow<OutputResult?> = _latestResult.asStateFlow()

    private val _settings = MutableStateFlow(LabSettings())
    val settings: StateFlow<LabSettings> = _settings.asStateFlow()

    init {
        addLog(LogLevel.INFO, "SYSTEM", "Data Craft Studio initialized. All modules local and active.")
        updateMemoryStat()
    }

    fun addLog(level: LogLevel, tag: String, message: String) {
        val entry = LogEntry(level = level, tag = tag, message = message)
        _logs.update { (listOf(entry) + it).take(300) }
    }

    fun clearLogs() {
        _logs.value = emptyList()
        addLog(LogLevel.INFO, "LOGS", "Event log buffer cleared.")
    }

    fun clearResult() {
        _latestResult.value = null
    }

    fun setResult(result: OutputResult) {
        _latestResult.value = result
    }

    fun updateSettings(newSettings: LabSettings) {
        _settings.value = newSettings
        addLog(LogLevel.INFO, "SETTINGS", "Settings updated: Buffer=${newSettings.defaultBufferSizeKb}KB, Iterations=${newSettings.benchmarkIterations}")
    }

    fun incrementStats(
        bytesProc: Long = 0L,
        bytesEmb: Long = 0L,
        filesGen: Int = 0,
        benchmarks: Int = 0
    ) {
        _stats.update { current ->
            current.copy(
                operationsCount = current.operationsCount + 1,
                bytesProcessed = current.bytesProcessed + bytesProc,
                bytesEmbedded = current.bytesEmbedded + bytesEmb,
                filesGeneratedCount = current.filesGeneratedCount + filesGen,
                benchmarksCompleted = current.benchmarksCompleted + benchmarks
            )
        }
        updateMemoryStat()
    }

    fun updateMemoryStat() {
        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024.0 * 1024.0)
        _stats.update { it.copy(peakMemoryMb = maxOf(it.peakMemoryMb, usedMb)) }
    }

    fun executeTask(
        taskName: String,
        action: suspend () -> OutputResult
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            _progress.value = 0f
            _statusText.value = "Executing: $taskName..."
            addLog(LogLevel.INFO, "TASK", "Starting: $taskName")
            val startTime = System.currentTimeMillis()
            try {
                _progress.value = 0.3f
                val result = withContext(Dispatchers.Default) { action() }
                _progress.value = 1f
                val elapsed = System.currentTimeMillis() - startTime
                _latestResult.value = result
                addLog(LogLevel.SUCCESS, "TASK", "Completed '$taskName' in ${elapsed}ms")
                _statusText.value = "Completed: $taskName (${elapsed}ms)"
            } catch (e: Exception) {
                addLog(LogLevel.ERROR, "TASK", "Error in '$taskName': ${e.message ?: e.toString()}")
                _statusText.value = "Failed: $taskName"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun shareResult(context: Context, result: OutputResult) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                if (result.file != null && result.file.exists()) {
                    val uri: Uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        result.file
                    )
                    putExtra(Intent.EXTRA_STREAM, uri)
                    type = result.mimeType
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } else {
                    putExtra(Intent.EXTRA_TEXT, result.content ?: result.summary)
                    type = "text/plain"
                }
                putExtra(Intent.EXTRA_SUBJECT, result.title)
            }
            context.startActivity(Intent.createChooser(intent, "Share ${result.title}"))
            addLog(LogLevel.SUCCESS, "SHARE", "Triggered share sheet for '${result.title}'")
        } catch (e: Exception) {
            addLog(LogLevel.ERROR, "SHARE", "Failed to share: ${e.message}")
        }
    }
}

/**
 * Text Steganography using Unicode Zero-Width character encoding.
 */
object StegoUtils {
    // Zero-width characters for binary encoding
    const val ZW_ZERO = '\u200B' // Zero-width space represents binary 0
    const val ZW_ONE = '\u200C'  // Zero-width non-joiner represents binary 1
    const val ZW_MARK = '\u200D' // Zero-width joiner represents delimiter
    const val ZW_HEADER = '\uFEFF' // Byte-order mark as stego header

    /**
     * Encodes hidden text inside visible carrier text using Zero-Width characters.
     */
    fun encodeTextInText(carrier: String, hidden: String): String {
        val hiddenBytes = hidden.toByteArray(StandardCharsets.UTF_8)
        val binaryBuilder = java.lang.StringBuilder()
        binaryBuilder.append(ZW_HEADER)
        for (b in hiddenBytes) {
            val byteVal = b.toInt() and 0xFF
            for (i in 7 downTo 0) {
                val bit = (byteVal shr i) and 1
                binaryBuilder.append(if (bit == 0) ZW_ZERO else ZW_ONE)
            }
            binaryBuilder.append(ZW_MARK)
        }
        binaryBuilder.append(ZW_HEADER)

        // Inject inside carrier after first word or at midpoint
        val spaceIndex = carrier.indexOf(' ')
        return if (spaceIndex != -1) {
            carrier.substring(0, spaceIndex + 1) + binaryBuilder.toString() + carrier.substring(spaceIndex + 1)
        } else {
            carrier + binaryBuilder.toString()
        }
    }

    /**
     * Decodes and extracts any zero-width hidden text from carrier text.
     */
    fun decodeTextFromText(carrier: String): String {
        val startHeader = carrier.indexOf(ZW_HEADER)
        if (startHeader == -1) return "No stego header found in text."
        val endHeader = carrier.indexOf(ZW_HEADER, startHeader + 1)
        if (endHeader == -1) return "Incomplete stego packet: missing terminating header."

        val payload = carrier.substring(startHeader + 1, endHeader)
        val bytesList = mutableListOf<Byte>()
        val byteTokens = payload.split(ZW_MARK)

        for (token in byteTokens) {
            if (token.isEmpty()) continue
            var currentByte = 0
            var bitCount = 0
            for (ch in token) {
                if (ch == ZW_ZERO) {
                    currentByte = (currentByte shl 1)
                    bitCount++
                } else if (ch == ZW_ONE) {
                    currentByte = (currentByte shl 1) or 1
                    bitCount++
                }
            }
            if (bitCount == 8) {
                bytesList.add(currentByte.toByte())
            }
        }

        return if (bytesList.isNotEmpty()) {
            String(bytesList.toByteArray(), StandardCharsets.UTF_8)
        } else {
            "No valid binary byte sequences decoded."
        }
    }

    /**
     * Strips all hidden zero-width and invisible control characters.
     */
    fun stripZeroWidthChars(text: String): String {
        return text.replace(Regex("[\\u200B\\u200C\\u200D\\u2060\\uFEFF\\u202E\\u202D\\u2066\\u2067]"), "")
    }
}

/**
 * Media and file synthesis utilities.
 */
object MediaUtils {

    /**
     * Creates a valid PNG image with embedded metadata and optional custom byte padding.
     */
    fun createPngWithEmbeddedData(
        context: Context,
        width: Int,
        height: Int,
        metadataKey: String,
        metadataValue: String,
        paddingKb: Int
    ): File {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint().apply {
            color = android.graphics.Color.rgb(13, 17, 23)
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

        // Draw cyber matrix grid and text on bitmap
        paint.color = android.graphics.Color.rgb(0, 255, 65)
        paint.strokeWidth = 2f
        for (i in 0..width step 40) {
            canvas.drawLine(i.toFloat(), 0f, i.toFloat(), height.toFloat(), paint)
        }
        paint.textSize = 24f
        canvas.drawText("DATA CRAFT EMBED", 20f, 50f, paint)

        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos)
        val pngBytes = bos.toByteArray()

        // Inject custom tEXt chunk before IEND chunk (last 12 bytes of standard PNG)
        val textKeyword = metadataKey.toByteArray(StandardCharsets.ISO_8859_1)
        val textText = metadataValue.toByteArray(StandardCharsets.ISO_8859_1)
        val chunkData = ByteArray(textKeyword.size + 1 + textText.size)
        System.arraycopy(textKeyword, 0, chunkData, 0, textKeyword.size)
        chunkData[textKeyword.size] = 0 // null separator
        System.arraycopy(textText, 0, chunkData, textKeyword.size + 1, textText.size)

        val chunkLength = chunkData.size
        val chunkType = "tEXt".toByteArray(StandardCharsets.US_ASCII)

        val chunkStream = ByteArrayOutputStream()
        val lenBuf = ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(chunkLength).array()
        chunkStream.write(lenBuf)
        chunkStream.write(chunkType)
        chunkStream.write(chunkData)

        // Calculate CRC32 for chunk
        val crc = java.util.zip.CRC32()
        crc.update(chunkType)
        crc.update(chunkData)
        val crcBuf = ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(crc.value.toInt()).array()
        chunkStream.write(crcBuf)

        // Optional custom padding bytes in custom 'paDd' chunk
        if (paddingKb > 0) {
            val padData = ByteArray(paddingKb * 1024) { (it % 256).toByte() }
            val padType = "paDd".toByteArray(StandardCharsets.US_ASCII)
            val padLenBuf = ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(padData.size).array()
            chunkStream.write(padLenBuf)
            chunkStream.write(padType)
            chunkStream.write(padData)
            val padCrc = java.util.zip.CRC32()
            padCrc.update(padType)
            padCrc.update(padData)
            val padCrcBuf = ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(padCrc.value.toInt()).array()
            chunkStream.write(padCrcBuf)
        }

        val iendIndex = maxOf(0, pngBytes.size - 12)
        val outputFile = File(context.cacheDir, "embedded_image_${System.currentTimeMillis()}.png")
        FileOutputStream(outputFile).use { fos ->
            fos.write(pngBytes, 0, iendIndex)
            fos.write(chunkStream.toByteArray())
            fos.write(pngBytes, iendIndex, pngBytes.size - iendIndex)
        }
        return outputFile
    }

    /**
     * Creates a valid MP3 file with custom ID3v2 header and embedded payload metadata.
     */
    fun createMp3WithMetadata(
        context: Context,
        title: String,
        embeddedSecret: String,
        audioLengthSeconds: Int
    ): File {
        val outputFile = File(context.cacheDir, "embedded_audio_${System.currentTimeMillis()}.mp3")
        FileOutputStream(outputFile).use { fos ->
            // Construct ID3v2.3 Tag
            val id3Stream = ByteArrayOutputStream()
            // TXXX (User-defined text information) Frame
            val frameData = ByteArrayOutputStream()
            frameData.write(0) // Encoding: ISO-8859-1
            frameData.write("RESEARCH_PAYLOAD\u0000".toByteArray(StandardCharsets.ISO_8859_1))
            frameData.write(embeddedSecret.toByteArray(StandardCharsets.ISO_8859_1))
            val frameBytes = frameData.toByteArray()

            id3Stream.write("TXXX".toByteArray(StandardCharsets.US_ASCII))
            val frameLenBuf = ByteBuffer.allocate(4).putInt(frameBytes.size).array()
            id3Stream.write(frameLenBuf)
            id3Stream.write(byteArrayOf(0, 0)) // Flags
            id3Stream.write(frameBytes)

            // TIT2 (Title) Frame
            val titleFrameData = ByteArrayOutputStream()
            titleFrameData.write(0)
            titleFrameData.write(title.toByteArray(StandardCharsets.ISO_8859_1))
            val titleBytes = titleFrameData.toByteArray()
            id3Stream.write("TIT2".toByteArray(StandardCharsets.US_ASCII))
            id3Stream.write(ByteBuffer.allocate(4).putInt(titleBytes.size).array())
            id3Stream.write(byteArrayOf(0, 0))
            id3Stream.write(titleBytes)

            val tagPayload = id3Stream.toByteArray()
            val tagSize = tagPayload.size

            // ID3v2 Header: "ID3" + version (3,0) + flags (0) + syncsafe size (4 bytes)
            fos.write("ID3".toByteArray(StandardCharsets.US_ASCII))
            fos.write(byteArrayOf(0x03, 0x00, 0x00))
            // Convert tagSize to syncsafe integer (7 bits per byte)
            val syncSafe = byteArrayOf(
                ((tagSize shr 21) and 0x7F).toByte(),
                ((tagSize shr 14) and 0x7F).toByte(),
                ((tagSize shr 7) and 0x7F).toByte(),
                (tagSize and 0x7F).toByte()
            )
            fos.write(syncSafe)
            fos.write(tagPayload)

            // Generate valid synthetic MPEG-1 Layer III audio frame headers (MPEG Audio Header: 0xFF 0xFB 0x90 0x64)
            // Bitrate 128kbps, 44100Hz, Padding=0 -> Frame size = 144 * 128000 / 44100 = 417 bytes
            val frameHeader = byteArrayOf(0xFF.toByte(), 0xFB.toByte(), 0x90.toByte(), 0x64.toByte())
            val framePayload = ByteArray(417 - 4) { (it % 128).toByte() }
            val framesCount = audioLengthSeconds * 38 // ~38 frames per second
            repeat(framesCount) {
                fos.write(frameHeader)
                fos.write(framePayload)
            }
        }
        return outputFile
    }

    /**
     * Creates a valid MP4 file container with custom metadata boxes (udta / meta) and embedded data.
     */
    fun createMp4WithMetadata(
        context: Context,
        title: String,
        embeddedSecret: String
    ): File {
        val outputFile = File(context.cacheDir, "embedded_video_${System.currentTimeMillis()}.mp4")
        FileOutputStream(outputFile).use { fos ->
            // Write 'ftyp' box
            val ftypPayload = ByteArrayOutputStream()
            ftypPayload.write("isom".toByteArray(StandardCharsets.US_ASCII)) // Major brand
            ftypPayload.write(byteArrayOf(0, 0, 2, 0)) // Minor version
            ftypPayload.write("isomiso2mp41".toByteArray(StandardCharsets.US_ASCII)) // Compatible brands
            writeMp4Box(fos, "ftyp", ftypPayload.toByteArray())

            // Write 'moov' container box with 'udta' containing custom payload
            val udtaPayload = ByteArrayOutputStream()
            val customDataBytes = embeddedSecret.toByteArray(StandardCharsets.UTF_8)
            writeMp4Box(udtaPayload, "data", customDataBytes)
            val udtaBytes = udtaPayload.toByteArray()

            val moovPayload = ByteArrayOutputStream()
            writeMp4Box(moovPayload, "udta", udtaBytes)
            // Write dummy 'mvhd' header
            val mvhdBytes = ByteArray(100) { 0 }
            writeMp4Box(moovPayload, "mvhd", mvhdBytes)
            writeMp4Box(fos, "moov", moovPayload.toByteArray())

            // Write 'mdat' box with dummy media samples
            val mdatBytes = ByteArray(1024 * 16) { (it % 255).toByte() }
            writeMp4Box(fos, "mdat", mdatBytes)
        }
        return outputFile
    }

    private fun writeMp4Box(out: java.io.OutputStream, type: String, payload: ByteArray) {
        val size = payload.size + 8
        val header = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN)
            .putInt(size)
            .put(type.toByteArray(StandardCharsets.US_ASCII))
            .array()
        out.write(header)
        out.write(payload)
    }

    /**
     * Creates a valid WebP sticker with custom dimensions and RIFF metadata.
     */
    fun createWebpSticker(
        context: Context,
        width: Int,
        height: Int,
        label: String
    ): File {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(0, 255, 65)
            style = Paint.Style.STROKE
            strokeWidth = 10f
        }
        // Draw round sticker border
        canvas.drawCircle(width / 2f, height / 2f, (width / 2f) - 16f, paint)

        // Draw inner glow fill
        paint.style = Paint.Style.FILL
        paint.color = android.graphics.Color.rgb(22, 27, 34)
        canvas.drawCircle(width / 2f, height / 2f, (width / 2f) - 20f, paint)

        paint.color = android.graphics.Color.rgb(0, 255, 65)
        paint.textSize = 36f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("⚡ STICKER ⚡", width / 2f, height / 2f - 10f, paint)
        paint.textSize = 24f
        paint.color = android.graphics.Color.WHITE
        canvas.drawText(label, width / 2f, height / 2f + 40f, paint)

        val outputFile = File(context.cacheDir, "custom_sticker_${System.currentTimeMillis()}.webp")
        FileOutputStream(outputFile).use { fos ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bitmap.compress(Bitmap.CompressFormat.WEBP_LOSSLESS, 100, fos)
            } else {
                @Suppress("DEPRECATION")
                bitmap.compress(Bitmap.CompressFormat.WEBP, 100, fos)
            }
        }
        return outputFile
    }

    /**
     * Creates a ZIP archive with nested structured files and custom compression payloads.
     */
    fun createZipArchive(
        context: Context,
        fileCount: Int,
        fileSizeKb: Int,
        nestedZip: Boolean
    ): File {
        val zipFile = File(context.cacheDir, "data_archive_${System.currentTimeMillis()}.zip")
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            zos.setLevel(Deflater.BEST_COMPRESSION)
            for (i in 1..fileCount) {
                val entry = ZipEntry("dataset/payload_data_$i.bin")
                zos.putNextEntry(entry)
                val buffer = ByteArray(fileSizeKb * 1024) { (it % 127).toByte() }
                zos.write(buffer)
                zos.closeEntry()
            }
            if (nestedZip) {
                val nestedEntry = ZipEntry("nested_sub_archive.zip")
                zos.putNextEntry(nestedEntry)
                val nestedBos = ByteArrayOutputStream()
                ZipOutputStream(nestedBos).use { nzos ->
                    nzos.putNextEntry(ZipEntry("secret_embedded.txt"))
                    nzos.write("DATA CRAFT STUDIO - INNER PAYLOAD ARCHIVE".toByteArray())
                    nzos.closeEntry()
                }
                zos.write(nestedBos.toByteArray())
                zos.closeEntry()
            }
        }
        return zipFile
    }

    /**
     * Synthesizes audio PCM Sine wave formatted as a standard WAV file.
     */
    fun createWavAudio(
        context: Context,
        frequencyHz: Double,
        durationSeconds: Int
    ): File {
        val sampleRate = 44100
        val numSamples = durationSeconds * sampleRate
        val pcmData = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val angle = 2.0 * Math.PI * i * frequencyHz / sampleRate
            pcmData[i] = (sin(angle) * Short.MAX_VALUE * 0.75).toInt().toShort()
        }

        val outputFile = File(context.cacheDir, "synth_tone_${System.currentTimeMillis()}.wav")
        FileOutputStream(outputFile).use { fos ->
            val dataBytes = numSamples * 2
            val totalSize = 36 + dataBytes

            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(totalSize)
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16) // Subchunk1Size for PCM
            header.putShort(1) // AudioFormat: PCM = 1
            header.putShort(1) // NumChannels: Mono = 1
            header.putInt(sampleRate)
            header.putInt(sampleRate * 2) // ByteRate
            header.putShort(2) // BlockAlign
            header.putShort(16) // BitsPerSample
            header.put("data".toByteArray())
            header.putInt(dataBytes)

            fos.write(header.array())
            val buffer = ByteBuffer.allocate(dataBytes).order(ByteOrder.LITTLE_ENDIAN)
            for (sample in pcmData) {
                buffer.putShort(sample)
            }
            fos.write(buffer.array())
        }
        return outputFile
    }

    /**
     * Generates a standard GPX location tracking file with custom coordinates.
     */
    fun createGpxFile(
        context: Context,
        pointsCount: Int,
        startLat: Double,
        startLon: Double
    ): File {
        val file = File(context.cacheDir, "location_track_${System.currentTimeMillis()}.gpx")
        file.printWriter().use { out ->
            out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
            out.println("<gpx version=\"1.1\" creator=\"DataCraftStudio\" xmlns=\"http://www.topografix.com/GPX/1/1\">")
            out.println("  <trk>")
            out.println("    <name>Research Data Stream</name>")
            out.println("    <trkseg>")
            for (i in 0 until pointsCount) {
                val lat = startLat + (i * 0.0005)
                val lon = startLon + (i * 0.0007)
                val ele = 100.0 + (i * 1.5)
                out.println("      <trkpt lat=\"$lat\" lon=\"$lon\">")
                out.println("        <ele>$ele</ele>")
                out.println("        <time>${SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date(System.currentTimeMillis() + i * 1000))}</time>")
                out.println("      </trkpt>")
            }
            out.println("    </trkseg>")
            out.println("  </trk>")
            out.println("</gpx>")
        }
        return file
    }

    /**
     * Generates a standard vCard (.vcf) with customized research properties.
     */
    fun createVcfContact(
        context: Context,
        name: String,
        org: String,
        payloadNote: String
    ): File {
        val file = File(context.cacheDir, "contact_${System.currentTimeMillis()}.vcf")
        file.printWriter().use { out ->
            out.println("BEGIN:VCARD")
            out.println("VERSION:3.0")
            out.println("FN:$name")
            out.println("ORG:$org")
            out.println("TITLE:Data Security Researcher")
            out.println("TEL;TYPE=WORK,VOICE:+1-800-DATA-CRAFT")
            out.println("EMAIL;TYPE=PREF,INTERNET:research@datacraft.local")
            out.println("NOTE:$payloadNote")
            out.println("X-DATA-CRAFT-PAYLOAD:${Base64.encodeToString(payloadNote.toByteArray(), Base64.NO_WRAP)}")
            out.println("END:VCARD")
        }
        return file
    }

    /**
     * Generates a massive Unicode text string containing stress-test characters.
     */
    fun createLargeText(charCount: Int, includeBiDi: Boolean, includeEmojis: Boolean): String {
        val bidiChars = charArrayOf('\u202E', '\u202D', '\u2066', '\u2067', '\u200E', '\u200F')
        val emojiList = listOf("😀", "😈", "💀", "🔥", "☠️", "⚡", "💣", "🧨", "🔪", "🩸", "🛡️", "🛰️")
        val standardChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 \n"

        val sb = java.lang.StringBuilder(charCount)
        val rand = SecureRandom()
        for (i in 0 until charCount) {
            when {
                includeBiDi && i % 100 == 0 -> sb.append(bidiChars[rand.nextInt(bidiChars.size)])
                includeEmojis && i % 15 == 0 -> sb.append(emojiList[rand.nextInt(emojiList.size)])
                else -> sb.append(standardChars[rand.nextInt(standardChars.length)])
            }
        }
        return sb.toString()
    }
}

/**
 * Performance and Data Analysis utilities.
 */
object AnalysisUtils {

    /**
     * Calculates Shannon entropy of a byte array (bits per byte, 0.0 to 8.0).
     */
    fun calculateEntropy(data: ByteArray): Double {
        if (data.isEmpty()) return 0.0
        val frequency = IntArray(256)
        for (b in data) {
            frequency[b.toInt() and 0xFF]++
        }
        var entropy = 0.0
        val total = data.size.toDouble()
        for (count in frequency) {
            if (count > 0) {
                val p = count / total
                entropy -= p * (ln(p) / ln(2.0))
            }
        }
        return entropy
    }

    /**
     * Detects magic byte signatures and file format information.
     */
    fun detectMagicFormat(bytes: ByteArray): Pair<String, String> {
        if (bytes.size < 4) return "Unknown" to "Insufficient bytes"
        val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }

        return when {
            bytes.size >= 8 && bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() &&
                    bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte() ->
                "PNG Image" to "MIME: image/png, Magic: 89 50 4E 47 0D 0A 1A 0A"

            bytes.size >= 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte() ->
                "JPEG Image" to "MIME: image/jpeg, Magic: FF D8 FF"

            bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte() &&
                    (bytes[2] == 0x03.toByte() || bytes[2] == 0x05.toByte()) ->
                "ZIP Archive" to "MIME: application/zip, Magic: 50 4B (PK..)"

            bytes.size >= 3 && bytes[0] == 0x49.toByte() && bytes[1] == 0x44.toByte() && bytes[2] == 0x33.toByte() ->
                "MP3 Audio (ID3v2)" to "MIME: audio/mpeg, Header: ID3 Tag detected"

            bytes.size >= 4 && bytes[0] == 0x25.toByte() && bytes[1] == 0x50.toByte() &&
                    bytes[2] == 0x44.toByte() && bytes[3] == 0x46.toByte() ->
                "PDF Document" to "MIME: application/pdf, Magic: %PDF-"

            bytes.size >= 12 && String(bytes.sliceArray(0..3)) == "RIFF" &&
                    String(bytes.sliceArray(8..11)) == "WEBP" ->
                "WebP Image" to "MIME: image/webp, Container: RIFF....WEBP"

            bytes.size >= 12 && String(bytes.sliceArray(0..3)) == "RIFF" &&
                    String(bytes.sliceArray(8..11)) == "WAVE" ->
                "WAV Audio" to "MIME: audio/wav, Container: RIFF....WAVE"

            bytes.size >= 8 && String(bytes.sliceArray(4..7)) == "ftyp" ->
                "MP4 / ISO Base Media" to "MIME: video/mp4, Box: ftyp"

            bytes.size >= 2 && bytes[0] == 0x1F.toByte() && bytes[1] == 0x8B.toByte() ->
                "GZIP Compressed Data" to "MIME: application/gzip, Magic: 1F 8B"

            else -> "Binary Stream" to "Signature: $hex"
        }
    }

    /**
     * Benchmarks processing speed of various byte operations.
     */
    fun benchmarkSpeed(iterations: Int, payloadSizeKb: Int): Map<String, Double> {
        val testBytes = ByteArray(payloadSizeKb * 1024) { (it % 256).toByte() }
        val results = mutableMapOf<String, Double>()

        // 1. SHA-256 Hashing Throughput
        val md = MessageDigest.getInstance("SHA-256")
        val startSha = System.nanoTime()
        repeat(iterations) {
            md.reset()
            md.update(testBytes)
            md.digest()
        }
        val elapsedShaSec = (System.nanoTime() - startSha) / 1_000_000_000.0
        val totalMb = (payloadSizeKb * iterations) / 1024.0
        results["SHA-256 Throughput (MB/s)"] = if (elapsedShaSec > 0) totalMb / elapsedShaSec else 0.0

        // 2. Base64 Encoding Throughput
        val startB64 = System.nanoTime()
        repeat(iterations) {
            Base64.encode(testBytes, Base64.NO_WRAP)
        }
        val elapsedB64Sec = (System.nanoTime() - startB64) / 1_000_000_000.0
        results["Base64 Throughput (MB/s)"] = if (elapsedB64Sec > 0) totalMb / elapsedB64Sec else 0.0

        // 3. Array Copy / Memory Transfer Throughput
        val dest = ByteArray(testBytes.size)
        val startCopy = System.nanoTime()
        repeat(iterations * 4) {
            System.arraycopy(testBytes, 0, dest, 0, testBytes.size)
        }
        val elapsedCopySec = (System.nanoTime() - startCopy) / 1_000_000_000.0
        val totalCopyMb = (payloadSizeKb * iterations * 4) / 1024.0
        results["Memory Copy Rate (MB/s)"] = if (elapsedCopySec > 0) totalCopyMb / elapsedCopySec else 0.0

        return results
    }

    /**
     * Analyzes Unicode string metrics (surrogates, code points, grapheme clusters).
     */
    fun analyzeUnicode(text: String): Map<String, Any> {
        val codePoints = text.codePointCount(0, text.length)
        var surrogatePairs = 0
        var zeroWidthCount = 0
        var bidiControls = 0
        var emojisCount = 0

        for (i in text.indices) {
            val ch = text[i]
            if (ch in listOf('\u200B', '\u200C', '\u200D', '\u2060', '\uFEFF')) zeroWidthCount++
            if (ch in listOf('\u202E', '\u202D', '\u2066', '\u2067', '\u200E', '\u200F')) bidiControls++
            if (Character.isSurrogate(ch)) surrogatePairs++
        }
        val utf8Bytes = text.toByteArray(StandardCharsets.UTF_8).size
        val utf16Bytes = text.toByteArray(StandardCharsets.UTF_16).size

        return mapOf(
            "Char Length" to text.length,
            "Code Points" to codePoints,
            "Surrogate Units" to surrogatePairs,
            "Zero-Width Chars" to zeroWidthCount,
            "BiDi Override Tokens" to bidiControls,
            "UTF-8 Bytes" to utf8Bytes,
            "UTF-16 Bytes" to utf16Bytes,
            "UTF-8 / Char Ratio" to "%.2f".format(utf8Bytes.toDouble() / maxOf(1, text.length))
        )
    }
}

/**
 * Data Encryption and Compression utilities.
 */
object CryptoUtils {

    /**
     * Compresses data using GZIP stream.
     */
    fun compressGzip(data: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(data) }
        return bos.toByteArray()
    }

    /**
     * Decompresses data using GZIP stream.
     */
    fun decompressGzip(compressed: ByteArray): ByteArray {
        val bis = java.io.ByteArrayInputStream(compressed)
        val bos = ByteArrayOutputStream()
        GZIPInputStream(bis).use { gis ->
            val buffer = ByteArray(1024)
            var len: Int
            while (gis.read(buffer).also { len = it } > 0) {
                bos.write(buffer, 0, len)
            }
        }
        return bos.toByteArray()
    }

    /**
     * Encrypts plaintext using AES-GCM (256-bit).
     */
    fun encryptAesGcm(plainText: String, secretPassphrase: String): Pair<String, String> {
        val keyBytes = MessageDigest.getInstance("SHA-256").digest(secretPassphrase.toByteArray())
        val keySpec = SecretKeySpec(keyBytes, "AES")
        val iv = ByteArray(12).apply { SecureRandom().nextBytes(this) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, GCMParameterSpec(128, iv))
        val cipherBytes = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))

        val fullCipherPayload = ByteArray(iv.size + cipherBytes.size)
        System.arraycopy(iv, 0, fullCipherPayload, 0, iv.size)
        System.arraycopy(cipherBytes, 0, fullCipherPayload, iv.size, cipherBytes.size)

        val base64Output = Base64.encodeToString(fullCipherPayload, Base64.NO_WRAP)
        val hexOutput = fullCipherPayload.joinToString("") { "%02x".format(it) }
        return base64Output to hexOutput
    }

    /**
     * Decrypts ciphertext formatted as base64 with prepended 12-byte IV using AES-GCM.
     */
    fun decryptAesGcm(base64Payload: String, secretPassphrase: String): String {
        val fullCipher = Base64.decode(base64Payload, Base64.NO_WRAP)
        if (fullCipher.size < 13) return "Payload too short for AES-GCM IV and ciphertext."
        val iv = fullCipher.copyOfRange(0, 12)
        val cipherBytes = fullCipher.copyOfRange(12, fullCipher.size)

        val keyBytes = MessageDigest.getInstance("SHA-256").digest(secretPassphrase.toByteArray())
        val keySpec = SecretKeySpec(keyBytes, "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, keySpec, GCMParameterSpec(128, iv))
        val plainBytes = cipher.doFinal(cipherBytes)
        return String(plainBytes, StandardCharsets.UTF_8)
    }

    /**
     * Fast XOR cipher stream for educational analysis.
     */
    fun xorTransform(data: ByteArray, key: ByteArray): ByteArray {
        val result = ByteArray(data.size)
        for (i in data.indices) {
            result[i] = (data[i].toInt() xor key[i % key.size].toInt()).toByte()
        }
        return result
    }
}
