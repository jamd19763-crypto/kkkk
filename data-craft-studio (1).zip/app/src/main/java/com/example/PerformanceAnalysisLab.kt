package com.example

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.DataThresholding
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.embedding.EmbeddingEngine
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Section 2: Performance Analysis Lab (مختبر تحليل الأداء)
 * Provides 9 diagnostic and benchmarking tools for large data processing.
 */
@Composable
fun PerformanceAnalysisLab(
    viewModel: LabViewModel,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            LabHeaderBadge(
                title = "مختبر تحليل الأداء",
                subtitle = "Performance Analysis Lab • فحص استهلاك الذاكرة وسرعة المعالجة والترميز",
                icon = Icons.Default.Analytics
            )
        }

        // 1. Memory Usage Analyzer
        item {
            Tool1MemoryAnalyzer(viewModel)
        }

        // 2. Processing Speed Analyzer
        item {
            Tool2SpeedAnalyzer(viewModel)
        }

        // 3. Data Size Analyzer
        item {
            Tool3DataSizeAnalyzer(viewModel)
        }

        // 4. Unicode Encoding Analyzer
        item {
            Tool4UnicodeAnalyzer(viewModel)
        }

        // 5. File Format Analyzer
        item {
            Tool5FileFormatAnalyzer(viewModel)
        }

        // 6. Compression Analyzer
        item {
            Tool6CompressionAnalyzer(viewModel)
        }

        // 7. Header Analyzer
        item {
            Tool7HeaderAnalyzer(viewModel)
        }

        // 8. Base64 Analyzer
        item {
            Tool8Base64Analyzer(viewModel)
        }

        // 9. String Analyzer
        item {
            Tool9StringAnalyzer(viewModel)
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * Tool 1: Memory Usage Analyzer
 */
@Composable
private fun Tool1MemoryAnalyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var allocationSizeMb by remember { mutableStateOf("20") }
    var resultStats by remember { mutableStateOf<Map<String, String>?>(null) }

    LabToolCard(
        title = "1. Memory Usage Analyzer",
        arabicTitle = "محلل استهلاك الذاكرة وإدارة الكومة Heap",
        icon = Icons.Default.Memory,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يقيس حدود ذاكرة آلة جافا الافتراضية (JVM Runtime)، ويجري تخصيصات ضخمة مجهدة للذاكرة لمراقبة استجابة جامع القمامة (Garbage Collector).",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(
                value = allocationSizeMb,
                onValueChange = { allocationSizeMb = it },
                label = "حجم التخصيص الاختباري بالميجابايت (MB)",
                keyboardType = KeyboardType.Number
            )

            CyberButton(
                text = "بدء فحص الذاكرة وسلوك الكومة (Heap Profile)",
                onClick = {
                    viewModel.executeTask("فحص استهلاك الذاكرة والكومة") {
                        val runtime = Runtime.getRuntime()
                        val beforeUsed = (runtime.totalMemory() - runtime.freeMemory()) / (1024.0 * 1024.0)
                        val allocMb = (allocationSizeMb.toIntOrNull() ?: 20).coerceIn(1, 100)

                        val startAlloc = System.nanoTime()
                        // Allocate stress buffer
                        val memorySink = ArrayList<ByteArray>()
                        repeat(allocMb) {
                            memorySink.add(ByteArray(1024 * 1024) { 0x7F })
                        }
                        val allocElapsedMs = (System.nanoTime() - startAlloc) / 1_000_000.0

                        val duringUsed = (runtime.totalMemory() - runtime.freeMemory()) / (1024.0 * 1024.0)
                        memorySink.clear()
                        System.gc()
                        val afterUsed = (runtime.totalMemory() - runtime.freeMemory()) / (1024.0 * 1024.0)

                        val stats = mapOf(
                            "أقصى ذاكرة متاحة للكومة" to "%.1f MB".format(runtime.maxMemory() / (1024.0 * 1024.0)),
                            "إجمالي ذاكرة JVM المحجوزة" to "%.1f MB".format(runtime.totalMemory() / (1024.0 * 1024.0)),
                            "الذاكرة المستخدمة قبل الاختبار" to "%.1f MB".format(beforeUsed),
                            "الذاكرة أثناء الضغط المجهد" to "%.1f MB (+%.1f MB)".format(duringUsed, duringUsed - beforeUsed),
                            "الذاكرة بعد تفريغ جامع القمامة GC" to "%.1f MB".format(afterUsed),
                            "زمن تخصيص $allocMb ميجابايت" to "%.2f ms".format(allocElapsedMs)
                        )
                        resultStats = stats
                        viewModel.incrementStats(bytesProc = allocMb * 1024L * 1024L, benchmarks = 1)

                        OutputResult(
                            title = "تقرير تحليل الذاكرة وسلوك الكومة Heap",
                            summary = "تم فحص مخزن بحجم $allocMb MB | أقصى كومة: ${runtime.maxMemory() / (1024 * 1024)} MB",
                            content = stats.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                        )
                    }
                }
            )

            resultStats?.let { stats ->
                MetricGrid(stats)
            }
        }
    }
}

/**
 * Tool 2: Processing Speed Analyzer
 */
@Composable
private fun Tool2SpeedAnalyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var iterations by remember { mutableStateOf("500") }
    var bufferKb by remember { mutableStateOf("64") }
    var benchmarkResults by remember { mutableStateOf<Map<String, Double>?>(null) }

    LabToolCard(
        title = "2. Processing Speed Analyzer",
        arabicTitle = "محلل سرعة المعالجة ومعدل التدفق Throughput",
        icon = Icons.Default.Speed,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يقيس معدل تدفق التجزئة التشفيرية (SHA-256)، وسرعة مسار ترميز Base64، وسرعات نقل الذاكرة بمعدل ميجابايت في الثانية (MB/s).",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberTextField(
                    value = iterations,
                    onValueChange = { iterations = it },
                    label = "عدد التكرارات",
                    modifier = Modifier.weight(1f),
                    keyboardType = KeyboardType.Number
                )
                CyberTextField(
                    value = bufferKb,
                    onValueChange = { bufferKb = it },
                    label = "حجم المخزن (KB)",
                    modifier = Modifier.weight(1f),
                    keyboardType = KeyboardType.Number
                )
            }

            CyberButton(
                text = "تنفيذ اختبار سرعة المعالجة (Throughput Test)",
                onClick = {
                    viewModel.executeTask("قياس سرعة المعالجة والتدفق") {
                        val iters = (iterations.toIntOrNull() ?: 500).coerceIn(10, 5000)
                        val buf = (bufferKb.toIntOrNull() ?: 64).coerceIn(4, 512)
                        val results = AnalysisUtils.benchmarkSpeed(iters, buf)
                        benchmarkResults = results
                        viewModel.incrementStats(bytesProc = (iters * buf * 1024L), benchmarks = 1)

                        OutputResult(
                            title = "نتائج معدل تدفق المعالجة",
                            summary = "تم إكمال $iters تكرار على مخزن بحجم $buf KB",
                            content = results.entries.joinToString("\n") { "${it.key}: ${"%.2f".format(it.value)} MB/s" }
                        )
                    }
                }
            )

            benchmarkResults?.let { map ->
                MetricGrid(map.mapValues { "%.2f MB/s".format(it.value) })
            }
        }
    }
}

/**
 * Tool 3: Data Size Analyzer
 */
@Composable
private fun Tool3DataSizeAnalyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("Data Craft Studio 2026 🚀 بيانات مشفرة ومضغوطة") }
    var sizeAnalysis by remember { mutableStateOf<Map<String, String>?>(null) }

    LabToolCard(
        title = "3. Data Size Analyzer",
        arabicTitle = "محلل حجم البيانات ومقارنة التراميز والتنسيقات",
        icon = Icons.Default.DataThresholding,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يقارن أطوال النصوص مقابل أحجام البايتات عبر التراميز المختلفة (UTF-8, UTF-16, UTF-32)، ونسبة تقليص ضغط GZIP، وتمدد ترميز Base64 و Hex.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = inputText, onValueChange = { inputText = it }, label = "النص أو البيانات المراد تحليل أثر حجمها")

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberOutlinedButton(
                    text = "نموذج نص Unicode مكثف",
                    modifier = Modifier.weight(1f),
                    borderColor = NeonCyan,
                    onClick = {
                        inputText = EmbeddingEngine.unicode.generateUnicodeText(200L)
                    }
                )
                CyberOutlinedButton(
                    text = "نموذج BiDi معكوس",
                    modifier = Modifier.weight(1f),
                    borderColor = NeonAmber,
                    onClick = {
                        inputText = EmbeddingEngine.unicode.generateRTLOverrideChars(150)
                    }
                )
            }

            CyberButton(
                text = "تحليل البصمة الحجمية والترميز",
                onClick = {
                    viewModel.executeTask("تحليل أثر حجم البيانات والترميز") {
                        val utf8 = inputText.toByteArray(StandardCharsets.UTF_8)
                        val utf16 = inputText.toByteArray(StandardCharsets.UTF_16)
                        val gzip = CryptoUtils.compressGzip(utf8)
                        val b64 = android.util.Base64.encode(utf8, android.util.Base64.NO_WRAP)

                        val analysis = mapOf(
                            "عدد الأحرف (Chars)" to "${inputText.length} حرف",
                            "حجم UTF-8" to "${utf8.size} بايت (${"%.2f".format(utf8.size.toDouble() / maxOf(1, inputText.length))} بايت/حرف)",
                            "حجم UTF-16" to "${utf16.size} بايت",
                            "حجم بعد ضغط GZIP" to "${gzip.size} بايت (${"%.1f".format((gzip.size.toDouble() / maxOf(1, utf8.size)) * 100)}%)",
                            "حجم ترميز Base64" to "${b64.size} بايت (+33.3% ضريبة تمدد)",
                            "حجم التمثيل الست عشري Hex" to "${utf8.size * 2} حرف (+100% ضريبة تمدد)"
                        )
                        sizeAnalysis = analysis
                        viewModel.incrementStats(bytesProc = utf8.size.toLong())

                        OutputResult(
                            title = "تقرير مقارنة أحجام البيانات والترميز",
                            summary = "UTF-8: ${utf8.size}B | GZIP: ${gzip.size}B | Base64: ${b64.size}B",
                            content = analysis.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                        )
                    }
                }
            )

            sizeAnalysis?.let { MetricGrid(it) }
        }
    }
}

/**
 * Tool 4: Unicode Encoding Analyzer
 */
@Composable
private fun Tool4UnicodeAnalyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var unicodeInput by remember { mutableStateOf("مرحباً \u200B\u200C بالعالم \u202E RTL \u202D 🔥") }
    var unicodeResults by remember { mutableStateOf<Map<String, Any>?>(null) }

    LabToolCard(
        title = "4. Unicode Encoding Analyzer",
        arabicTitle = "محلل ترميز Unicode ونقاط الشفرة والأحرف الخفية",
        icon = Icons.Default.Translate,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يفحص النص بحثاً عن الأحرف الشبحية عديمة العرض (Zero-Width)، ونقاط الشفرة البديلة (Surrogates)، ومحارف التحكم في اتجاه القراءة BiDi (مثل \\u202E و \\u202D).",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = unicodeInput, onValueChange = { unicodeInput = it }, label = "النص المراد تدقيقه واكتشاف محارفه الخفية")

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberOutlinedButton(
                    text = "حقن أحرف غير مرئية",
                    modifier = Modifier.weight(1f),
                    borderColor = NeonCyan,
                    onClick = {
                        unicodeInput = EmbeddingEngine.text.embedTextInText("نص ظاهري", "سري")
                    }
                )
                CyberOutlinedButton(
                    text = "تضمين BiDi Overrides",
                    modifier = Modifier.weight(1f),
                    borderColor = NeonAmber,
                    onClick = {
                        unicodeInput = EmbeddingEngine.unicode.generateRTLOverrideChars(50)
                    }
                )
            }

            CyberButton(
                text = "تدقيق نقاط الشفرة والمحارف الخفية",
                onClick = {
                    viewModel.executeTask("تدقيق وفحص محارف Unicode") {
                        val results = AnalysisUtils.analyzeUnicode(unicodeInput)
                        unicodeResults = results
                        viewModel.incrementStats(bytesProc = unicodeInput.length.toLong())

                        OutputResult(
                            title = "تفصيل تحليل محارف ترميز Unicode",
                            summary = "تم فحص ${unicodeInput.length} حرفاً | نقاط الشفرة: ${results["Code Points"]}",
                            content = results.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                        )
                    }
                }
            )

            unicodeResults?.let { MetricGrid(it.mapValues { it.value.toString() }) }
        }
    }
}

/**
 * Tool 5: File Format Analyzer
 */
@Composable
private fun Tool5FileFormatAnalyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var selectedFormat by remember { mutableStateOf("PNG") }
    var detectionOutput by remember { mutableStateOf<Pair<String, String>?>(null) }

    val formats = listOf("PNG", "JPEG", "MP3", "MP4", "ZIP", "PDF", "WebP", "GZIP")

    LabToolCard(
        title = "5. File Format Analyzer",
        arabicTitle = "محلل تنسيقات الملفات والتوقيعات الرقمية Magic Numbers",
        icon = Icons.Default.FindInPage,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يفحص ترويسات البايت الخام، ويكتشف التوقيعات السحرية (Magic Bytes)، ويحدد نوع الحاوية الحقيقي ونوع MIME الفعلي للملف.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Text("اختر توقيع التنسيق للفحص:", style = MaterialTheme.typography.labelMedium, color = NeonGreen)
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                formats.take(4).forEach { fmt ->
                    CyberOutlinedButton(
                        text = fmt,
                        modifier = Modifier.weight(1f),
                        borderColor = if (selectedFormat == fmt) NeonGreen else CyberCardBorder,
                        onClick = { selectedFormat = fmt }
                    )
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                formats.takeLast(4).forEach { fmt ->
                    CyberOutlinedButton(
                        text = fmt,
                        modifier = Modifier.weight(1f),
                        borderColor = if (selectedFormat == fmt) NeonGreen else CyberCardBorder,
                        onClick = { selectedFormat = fmt }
                    )
                }
            }

            CyberButton(
                text = "فحص التوقيع الرقمي لتنسيق $selectedFormat",
                onClick = {
                    viewModel.executeTask("فحص التوقيع الرقمي للملف") {
                        val sampleBytes = when (selectedFormat) {
                            "PNG" -> byteArrayOf(0x89.toByte(), 0x50.toByte(), 0x4E.toByte(), 0x47.toByte(), 0x0D.toByte(), 0x0A.toByte(), 0x1A.toByte(), 0x0A.toByte())
                            "JPEG" -> byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 0x00.toByte(), 0x10.toByte(), 0x4A.toByte(), 0x46.toByte())
                            "MP3" -> byteArrayOf(0x49.toByte(), 0x44.toByte(), 0x33.toByte(), 0x03.toByte(), 0x00.toByte(), 0x00.toByte(), 0x00.toByte(), 0x00.toByte())
                            "MP4" -> byteArrayOf(0x00.toByte(), 0x00.toByte(), 0x00.toByte(), 0x20.toByte(), 0x66.toByte(), 0x74.toByte(), 0x79.toByte(), 0x70.toByte())
                            "ZIP" -> byteArrayOf(0x50.toByte(), 0x4B.toByte(), 0x03.toByte(), 0x04.toByte(), 0x14.toByte(), 0x00.toByte(), 0x00.toByte(), 0x00.toByte())
                            "PDF" -> "%PDF-1.7\n".toByteArray()
                            "WebP" -> "RIFF....WEBP".toByteArray()
                            "GZIP" -> byteArrayOf(0x1F.toByte(), 0x8B.toByte(), 0x08.toByte(), 0x00.toByte())
                            else -> byteArrayOf(0, 1, 2, 3)
                        }
                        val result = AnalysisUtils.detectMagicFormat(sampleBytes)
                        detectionOutput = result
                        viewModel.incrementStats(bytesProc = sampleBytes.size.toLong())

                        OutputResult(
                            title = "تدقيق توقيع التنسيق الرقمي",
                            summary = "${result.first}: ${result.second}",
                            content = "التنسيق المكتشف: ${result.first}\nالتفاصيل: ${result.second}\nالترويسة بالهكسادسمل: ${sampleBytes.joinToString(" ") { "%02X".format(it) }}"
                        )
                    }
                }
            )

            detectionOutput?.let { pair ->
                MetricGrid(
                    mapOf(
                        "التنسيق المحدد" to pair.first,
                        "تفاصيل الترويسة" to pair.second
                    )
                )
            }
        }
    }
}

/**
 * Tool 6: Compression Analyzer (Entropy & Ratio)
 */
@Composable
private fun Tool6CompressionAnalyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var sampleSizeKb by remember { mutableStateOf("128") }
    var entropyStats by remember { mutableStateOf<Map<String, String>?>(null) }

    LabToolCard(
        title = "6. Compression Analyzer",
        arabicTitle = "محلل الضغط وحساب إنتروبيا شانون Shannon Entropy",
        icon = Icons.Default.Compress,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يحسب إنتروبيا شانون (بت/بايت) لقياس عشوائية البيانات والتنبؤ بقابلية الضغط دون فقدان قبل تطبيق خوارزميات GZIP أو Deflate.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = sampleSizeKb, onValueChange = { sampleSizeKb = it }, label = "حجم البيانات للاختبار (KB)", keyboardType = KeyboardType.Number)

            CyberButton(
                text = "حساب إنتروبيا شانون وقابلية الضغط",
                onClick = {
                    viewModel.executeTask("تحليل الإنتروبيا وقابلية الضغط") {
                        val kb = (sampleSizeKb.toIntOrNull() ?: 128).coerceIn(4, 1024)
                        val rawData = ByteArray(kb * 1024) { ((it % 32) + 65).toByte() } // Repetitive pattern
                        val entropyRaw = AnalysisUtils.calculateEntropy(rawData)
                        val compressed = CryptoUtils.compressGzip(rawData)
                        val entropyComp = AnalysisUtils.calculateEntropy(compressed)

                        val stats = mapOf(
                            "حجم البيانات المدخلة" to "${rawData.size / 1024} KB (${rawData.size} بايت)",
                            "إنتروبيا شانون الخام" to "%.3f / 8.000 بت/بايت".format(entropyRaw),
                            "قابلية الضغط النظرية" to if (entropyRaw < 5.0) "عالية (بيانات متكررة)" else "منخفضة (قريبة من العشوائية)",
                            "الحجم بعد ضغط GZIP" to "${compressed.size} بايت",
                            "المساحة الموفرة" to "%.1f%%".format((1.0 - (compressed.size.toDouble() / rawData.size)) * 100.0),
                            "الإنتروبيا بعد الضغط" to "%.3f بت/بايت (أقصى كثافة)".format(entropyComp)
                        )
                        entropyStats = stats
                        viewModel.incrementStats(bytesProc = rawData.size.toLong())

                        OutputResult(
                            title = "تقرير إنتروبيا شانون وقابلية الضغط",
                            summary = "الإنتروبيا: ${"%.2f".format(entropyRaw)} بت/بايت | نسبة الضغط: ${"%.1f".format((1.0 - (compressed.size.toDouble() / rawData.size)) * 100)}%",
                            content = stats.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                        )
                    }
                }
            )

            entropyStats?.let { MetricGrid(it) }
        }
    }
}

/**
 * Tool 7: Header Analyzer
 */
@Composable
private fun Tool7HeaderAnalyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var headerInfo by remember { mutableStateOf<String?>(null) }

    LabToolCard(
        title = "7. Header Analyzer",
        arabicTitle = "محلل الترويسات والهياكل الداخلية للحزم",
        icon = Icons.Default.Storage,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يفحص الهياكل التفصيلية للحاويات والكتل (Chunks)، مثل تسلسل كتل PNG (IHDR, tEXt, IDAT, IEND) وشجرة ذرات MP4 (ftyp, moov, udta).",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberButton(
                text = "فحص مخطط هياكل وترويسات الحاويات",
                onClick = {
                    viewModel.executeTask("تدقيق ترويسات وهياكل الحاويات") {
                        val audit = buildString {
                            appendLine("=== بنية كتل صور PNG (Chunk Architecture) ===")
                            appendLine("الإزاحة 0x00: [التوقيع السحري] 89 50 4E 47 0D 0A 1A 0A")
                            appendLine("الإزاحة 0x08: [كتلة IHDR] العرض والارتفاع وعمق البتات ونمط الألوان")
                            appendLine("الإزاحة 0x21: [كتلة tEXt] المفتاح: 'RESEARCH_SIGNATURE' (بيانات مخفية)")
                            appendLine("الإزاحة 0x50: [كتلة IDAT] تدفق بيانات الصورة المضغوط بـ Deflate")
                            appendLine("الإزاحة 0x--: [كتلة IEND] نهاية الملف (مع فحص CRC: 0xAE426082)")
                            appendLine()
                            appendLine("=== شجرة ذرات الفيديو MP4 (Atom Box Hierarchy) ===")
                            appendLine("الذرة 1: [ftyp] major=isom, minor=512, compat=isomiso2mp41")
                            appendLine("الذرة 2: [moov] حاوية البيانات الوصفية للمقطع")
                            appendLine("  └── [udta] حاوية بيانات المستخدم (تتضمن حمولة الستيجانو المخفية)")
                            appendLine("الذرة 3: [mdat] تدفق العينات والوسائط المشفرة")
                            appendLine()
                            appendLine("=== إطارات الصوت MP3 ID3v2 ===")
                            appendLine("الترويسة: [ID3] الإصدار 2.3.0 | الأعلام: Unsynchronisation=0")
                            appendLine("  └── إطار [COMM]: تعليق نصي يحتوي على مفتاح مدمج")
                            appendLine("  └── إطار [PRIV]: بيانات ثنائية خاصة مجهولة للمشغلات العادية")
                        }
                        headerInfo = audit
                        viewModel.incrementStats(bytesProc = audit.length.toLong())

                        OutputResult(
                            title = "تقرير بنية وهياكل الترويسات للحاويات",
                            summary = "تم تعيين كتل PNG وشجرة ذرات MP4 وإطارات ID3v2",
                            content = audit
                        )
                    }
                }
            )

            headerInfo?.let {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberDark, RoundedCornerShape(8.dp))
                        .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(it, color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

/**
 * Tool 8: Base64 Analyzer
 */
@Composable
private fun Tool8Base64Analyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var inputString by remember { mutableStateOf("DataCraftStudio2026!#$") }
    var b64Stats by remember { mutableStateOf<Map<String, String>?>(null) }

    LabToolCard(
        title = "8. Base64 Analyzer",
        arabicTitle = "محلل Base64 ونسب التمدد والتشفير الثنائي",
        icon = Icons.Default.Code,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يحسب تكاليف تحويل البتات إلى محارف لـ RFC 4648 Base64 والصيغة الآمنة للروابط URL-Safe، ويقارنها مع التمثيل الست عشري Hexadecimal.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = inputString, onValueChange = { inputString = it }, label = "النص المراد تحليله وتشفيره")

            CyberButton(
                text = "تحليل ضريبة تمدد Base64 و Hex",
                onClick = {
                    viewModel.executeTask("تدقيق تمدد Base64 و Hex") {
                        val rawBytes = inputString.toByteArray(StandardCharsets.UTF_8)
                        val b64Standard = android.util.Base64.encodeToString(rawBytes, android.util.Base64.NO_WRAP)
                        val b64Url = android.util.Base64.encodeToString(rawBytes, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP)
                        val hex = rawBytes.joinToString("") { "%02X".format(it) }

                        val stats = mapOf(
                            "البايتات الأصلية" to "${rawBytes.size} بايت (${rawBytes.size * 8} بت)",
                            "ترميز Base64 القياسي" to b64Standard,
                            "ترميز Base64 الآمن للروابط" to b64Url,
                            "حجم Base64" to "${b64Standard.length} محرف (+${"%.1f".format(((b64Standard.length.toDouble() / rawBytes.size) - 1.0) * 100)}%)",
                            "التمثيل الست عشري (Hex)" to hex,
                            "حجم Hex" to "${hex.length} محرف (+100% تمدد)"
                        )
                        b64Stats = stats
                        viewModel.incrementStats(bytesProc = rawBytes.size.toLong())

                        OutputResult(
                            title = "تقرير التكلفة الحجمية لـ Base64 و Hex",
                            summary = "Base64: ${b64Standard.length} محرف (+33.3%) | Hex: ${hex.length} محرف",
                            content = stats.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                        )
                    }
                }
            )

            b64Stats?.let { MetricGrid(it) }
        }
    }
}

/**
 * Tool 9: String Analyzer
 */
@Composable
private fun Tool9StringAnalyzer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var corpusText by remember { mutableStateOf("Data Craft Studio: The quick brown fox jumps over the lazy dog. 1234567890! مصفوفة البيانات والأمان.") }
    var stringStats by remember { mutableStateOf<Map<String, String>?>(null) }

    LabToolCard(
        title = "9. String Analyzer",
        arabicTitle = "محلل السلاسل النصية وتوزيع التكرار الإحصائي",
        icon = Icons.Default.DataThresholding,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "يستخرج المقاييس الإحصائية المتقدمة: توزيع تردد الأحرف، إنتروبيا المفردات، عدد الكلمات والأسطر، ونسبة أحرف ASCII مقابل المحارف العالمية Unicode.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = corpusText, onValueChange = { corpusText = it }, label = "النص المراد تحليله إحصائياً")

            CyberButton(
                text = "تحليل الإحصائيات النصية وتوزيع التكرار",
                onClick = {
                    viewModel.executeTask("التحليل الإحصائي للنص") {
                        val words = corpusText.split(Regex("\\s+")).filter { it.isNotEmpty() }
                        val lines = corpusText.lines()
                        var asciiCount = 0
                        var nonAsciiCount = 0
                        val freqMap = mutableMapOf<Char, Int>()
                        for (c in corpusText) {
                            if (c.code < 128) asciiCount++ else nonAsciiCount++
                            freqMap[c] = (freqMap[c] ?: 0) + 1
                        }
                        val top3Chars = freqMap.entries.sortedByDescending { it.value }.take(3).joinToString { "'${it.key}': ${it.value}" }

                        val stats = mapOf(
                            "إجمالي الأحرف" to "${corpusText.length} حرف",
                            "عدد الكلمات" to "${words.size} كلمة",
                            "عدد الأسطر" to "${lines.size} سطر",
                            "أحرف ASCII الأساسية" to "$asciiCount (${"%.1f".format((asciiCount.toDouble() / maxOf(1, corpusText.length)) * 100)}%)",
                            "أحرف Unicode والعربية" to "$nonAsciiCount (${"%.1f".format((nonAsciiCount.toDouble() / maxOf(1, corpusText.length)) * 100)}%)",
                            "أكثر 3 محارف تكراراً" to top3Chars
                        )
                        stringStats = stats
                        viewModel.incrementStats(bytesProc = corpusText.length.toLong())

                        OutputResult(
                            title = "إحصائيات كتلة النصوص",
                            summary = "الكلمات: ${words.size} | نسبة ASCII: ${"%.1f".format((asciiCount.toDouble() / maxOf(1, corpusText.length)) * 100)}%",
                            content = stats.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                        )
                    }
                }
            )

            stringStats?.let { MetricGrid(it) }
        }
    }
}

/**
 * Grid component displaying key-value metrics cleanly in monospace styling.
 */
@Composable
fun MetricGrid(metrics: Map<String, String>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberDark, RoundedCornerShape(8.dp))
            .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        metrics.forEach { (key, value) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = key,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.weight(1.2f)
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodySmall,
                    color = NeonGreen,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1.5f)
                )
            }
        }
    }
}
