package com.example

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ContactPage
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.PhotoAlbum
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.embedding.EmbeddingEngine
import java.io.File
import java.io.FileOutputStream

/**
 * Section 1: Data Embedding Lab (مختبر البيانات المدمجة)
 * Provides 9 steganography and data embedding tools.
 */
@Composable
fun DataEmbeddingLab(
    viewModel: LabViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            LabHeaderBadge(
                title = "مختبر البيانات المدمجة",
                subtitle = "Data Embedding Lab • إخفاء وتضمين البيانات والوسائط",
                icon = Icons.Default.VisibilityOff
            )
        }

        // 1. Text-in-Text Embedding
        item {
            Tool1TextInText(viewModel)
        }

        // 2. Image Data Embedding
        item {
            Tool2ImageEmbedding(viewModel, context)
        }

        // 3. Audio Data Embedding
        item {
            Tool3AudioEmbedding(viewModel, context)
        }

        // 4. Video Data Embedding
        item {
            Tool4VideoEmbedding(viewModel, context)
        }

        // 5. Custom Sticker Creator
        item {
            Tool5StickerCreator(viewModel, context)
        }

        // 6. Compressed File Generator
        item {
            Tool6ZipGenerator(viewModel, context)
        }

        // 7. Location Data Generator
        item {
            Tool7LocationGenerator(viewModel, context)
        }

        // 8. Contact Data Generator
        item {
            Tool8ContactGenerator(viewModel, context)
        }

        // 9. Large Text Generator
        item {
            Tool9LargeTextGenerator(viewModel)
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun LabHeaderBadge(title: String, subtitle: String, icon: ImageVector) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberDark),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NeonGreen.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(NeonGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .border(1.dp, NeonGreen, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NeonGreen,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}

/**
 * Tool 1: Text-in-Text Zero-Width Embedding & Decoding
 */
@Composable
private fun Tool1TextInText(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var carrierText by remember { mutableStateOf("مرحبًا بالعالم العربي") }
    var hiddenSecret by remember { mutableStateOf("TopSecretData123") }
    var embedMode by remember { mutableStateOf("أحرف Zero-Width غير مرئية") }
    var outputResultText by remember { mutableStateOf("") }

    val modes = listOf("أحرف Zero-Width غير مرئية", "عكس الاتجاه RTL Override", "بيانات مضغوطة Deflate Base64")

    LabToolCard(
        title = "1. Text-in-Text Embedding",
        arabicTitle = "تضمين نص داخل نص بأحرف غير مرئية",
        icon = Icons.Default.TextFields,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "دمج نصوص وبيانات سرية داخل نصوص طبيعية باستخدام تقنيات Zero-Width و Unicode Override وضغط Deflate.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(
                value = carrierText,
                onValueChange = { carrierText = it },
                label = "Carrier Text (النص الظاهر)"
            )

            CyberTextField(
                value = hiddenSecret,
                onValueChange = { hiddenSecret = it },
                label = "Secret Payload to Hide (النص المخفي)"
            )

            // Mode Selector
            Text("طريقة الدمج والتضمين:", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
            modes.forEach { m ->
                CyberOutlinedButton(
                    text = m,
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (embedMode == m) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { embedMode = m }
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberButton(
                    text = "تضمين البيانات (Embed)",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.executeTask("تضمين نص داخل نص ($embedMode)") {
                            val encoded = when (embedMode) {
                                "عكس الاتجاه RTL Override" -> EmbeddingEngine.text.embedWithUnicodeOverride(carrierText, hiddenSecret)
                                "بيانات مضغوطة Deflate Base64" -> EmbeddingEngine.text.embedCompressedData(carrierText, hiddenSecret)
                                else -> EmbeddingEngine.text.embedTextInText(carrierText, hiddenSecret)
                            }
                            outputResultText = encoded
                            val hiddenBytes = hiddenSecret.toByteArray().size
                            viewModel.incrementStats(bytesProc = carrierText.length.toLong(), bytesEmb = hiddenBytes.toLong())
                            OutputResult(
                                title = "تم إنشاء النص المدمج بنجاح",
                                summary = "التقنية: $embedMode | البيانات المخفية: $hiddenBytes بايت",
                                content = encoded
                            )
                        }
                    }
                )

                CyberOutlinedButton(
                    text = "فك التضمين (Decode)",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.executeTask("استخراج البيانات المخفية") {
                            val extracted = when (embedMode) {
                                "بيانات مضغوطة Deflate Base64" -> {
                                    val r = EmbeddingEngine.text.extractCompressedData(carrierText)
                                    if (r.isNotEmpty()) r else "لم يتم العثور على بيانات مضغوطة صالحة"
                                }
                                else -> {
                                    val r1 = EmbeddingEngine.text.extractTextFromText(carrierText)
                                    if (r1.isNotEmpty()) r1 else DataProcessingEngine.text.extractHiddenText(carrierText)
                                }
                            }
                            outputResultText = extracted
                            OutputResult(
                                title = "البيانات المستخرجة من النص",
                                summary = "تم فك ترميز الحزمة غير المرئية من النص الحامل",
                                content = extracted
                            )
                        }
                    }
                )
            }

            if (outputResultText.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberDark, RoundedCornerShape(8.dp))
                        .border(1.dp, NeonGreen.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text("Output Result:", color = NeonGreen, style = MaterialTheme.typography.labelMedium)
                        Text(outputResultText, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

/**
 * Tool 2: Image Data Embedding (PNG / Metadata / Padding)
 */
@Composable
private fun Tool2ImageEmbedding(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var metaKey by remember { mutableStateOf("X-RESEARCH-SIGNATURE") }
    var metaVal by remember { mutableStateOf("Alpha77-Embedded-Token") }
    var paddingKb by remember { mutableStateOf("128") }
    var imageMode by remember { mutableStateOf("صورة PNG مع بيانات مضمنة") }

    val modes = listOf("صورة PNG مع بيانات مضمنة", "صورة JPEG مع وسوم مدمجة", "ترويسات متعددة (Multi-Header PNG/JPEG/GIF)")

    LabToolCard(
        title = "2. Image Data Embedding",
        arabicTitle = "تضمين بيانات داخل صور PNG/JPEG",
        icon = Icons.Default.Image,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "إنشاء صور PNG و JPEG مع حقن بيانات ثنائية وكتل حشو مخصصة، أو توليد صور بترويسات هجينة متعددة الصيغ.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = metaKey, onValueChange = { metaKey = it }, label = "Metadata Header Key / العنوان التعريفي")
            CyberTextField(value = metaVal, onValueChange = { metaVal = it }, label = "Embedded Payload String / نص الحمولة")
            CyberTextField(
                value = paddingKb,
                onValueChange = { paddingKb = it },
                label = "حجم البيانات المضمنة (KB)",
                keyboardType = KeyboardType.Number
            )

            Text("صيغة التضمين ونوع الترويسة:", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
            modes.forEach { m ->
                CyberOutlinedButton(
                    text = m,
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (imageMode == m) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { imageMode = m }
                )
            }

            CyberButton(
                text = "توليد الصورة المدمجة (Synthesize Image)",
                onClick = {
                    viewModel.executeTask("تضمين بيانات الصور ($imageMode)") {
                        val pad = paddingKb.toIntOrNull() ?: 128
                        val (file, mime) = when (imageMode) {
                            "صورة JPEG مع وسوم مدمجة" -> {
                                val bytes = EmbeddingEngine.image.embedDataInJPEG(300, 300, pad * 1024L)
                                val f = File(context.cacheDir, "embedded_${System.currentTimeMillis()}.jpg")
                                FileOutputStream(f).use { it.write(bytes) }
                                Pair(f, "image/jpeg")
                            }
                            "ترويسات متعددة (Multi-Header PNG/JPEG/GIF)" -> {
                                val bytes = EmbeddingEngine.image.createMultiHeaderImage(pad * 1024L)
                                val f = File(context.cacheDir, "multiheader_${System.currentTimeMillis()}.bin")
                                FileOutputStream(f).use { it.write(bytes) }
                                Pair(f, "application/octet-stream")
                            }
                            else -> {
                                val f = EmbeddingEngine.image.embedDataInPNGFile(context, 300, 300, pad * 1024L)
                                Pair(f, "image/png")
                            }
                        }
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, bytesEmb = (pad * 1024L) + metaVal.length, filesGen = 1)
                        OutputResult(
                            title = "تم إنشاء الصورة مع البيانات المضمنة",
                            summary = "الصيغة: $imageMode | الحجم: ${totalBytes / 1024} KB",
                            content = "مسار الملف: ${file.name}\nالحجم الإجمالي: $totalBytes بايت\nالمفتاح/الوسم: $metaKey -> $metaVal",
                            file = file,
                            mimeType = mime
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 3: Audio Data Embedding (MP3 / ID3v2 / Multi-Header)
 */
@Composable
private fun Tool3AudioEmbedding(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("Audio Tone Track 01") }
    var secret by remember { mutableStateOf("RESEARCH_KEY_9921_X") }
    var paddingKb by remember { mutableStateOf("64") }
    var audioMode by remember { mutableStateOf("ملف MP3 مع وسوم ID3v2 مدمجة") }

    val modes = listOf("ملف MP3 مع وسوم ID3v2 مدمجة", "ملف صوتي بترويسات متعددة (Multi-Header MP3/WAV/OGG)")

    LabToolCard(
        title = "3. Audio Data Embedding",
        arabicTitle = "تضمين بيانات داخل ملفات صوتية MP3",
        icon = Icons.Default.Audiotrack,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "دمج حمولات بحثية داخل ملفات MP3 في إطارات ID3v2 TXXX أو إنشاء ملفات صوتية بترويسات هجينة متوافقة مع عدة مشغلات.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = title, onValueChange = { title = it }, label = "Audio Title Track / عنوان المقطع الصوتي")
            CyberTextField(value = secret, onValueChange = { secret = it }, label = "Embedded ID3v2 Payload / البيانات المخفية")
            CyberTextField(
                value = paddingKb,
                onValueChange = { paddingKb = it },
                label = "حجم البيانات المضمنة (KB)",
                keyboardType = KeyboardType.Number
            )

            Text("صيغة التضمين ونوع الترويسة:", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
            modes.forEach { m ->
                CyberOutlinedButton(
                    text = m,
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (audioMode == m) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { audioMode = m }
                )
            }

            CyberButton(
                text = "توليد الملف الصوتي المدمج (Synthesize Audio)",
                onClick = {
                    viewModel.executeTask("تضمين بيانات صوتية ($audioMode)") {
                        val pad = paddingKb.toIntOrNull() ?: 64
                        val (file, mime) = when (audioMode) {
                            "ملف صوتي بترويسات متعددة (Multi-Header MP3/WAV/OGG)" -> {
                                val bytes = EmbeddingEngine.audio.createMultiHeaderAudio(pad * 1024L)
                                val f = File(context.cacheDir, "multiheader_audio_${System.currentTimeMillis()}.bin")
                                FileOutputStream(f).use { it.write(bytes) }
                                Pair(f, "audio/mpeg")
                            }
                            else -> {
                                val f = EmbeddingEngine.audio.embedDataInMP3File(context, 32 * 1024L, pad * 1024L)
                                Pair(f, "audio/mpeg")
                            }
                        }
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, bytesEmb = (pad * 1024L) + secret.length, filesGen = 1)
                        OutputResult(
                            title = "تم إنشاء الملف الصوتي مع البيانات المضمنة",
                            summary = "النمط: $audioMode | الحجم: ${totalBytes / 1024} KB",
                            content = "المسار: ${file.name}\nالحجم: $totalBytes بايت\nالحمولة المدمجة: $secret",
                            file = file,
                            mimeType = mime
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 4: Video Data Embedding (MP4 / moov / udta / Multi-Header)
 */
@Composable
private fun Tool4VideoEmbedding(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("Cyber Stream Vid 01") }
    var secret by remember { mutableStateOf("STEGO_VIDEO_BOX_88194") }
    var paddingKb by remember { mutableStateOf("128") }
    var videoMode by remember { mutableStateOf("حاوية MP4 مع صندوق udta مدمج") }

    val modes = listOf("حاوية MP4 مع صندوق udta مدمج", "فيديو بترويسات متعددة (Multi-Header MP4/AVI/MKV)")

    LabToolCard(
        title = "4. Video Data Embedding",
        arabicTitle = "تضمين بيانات داخل ملفات فيديو MP4",
        icon = Icons.Default.Movie,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "دمج حمولات داخل حاويات MP4 ISO Base Media في صناديق moov->udta، أو إنشاء ملفات فيديو بترويسات هجينة متقدمة.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = title, onValueChange = { title = it }, label = "Video Clip Title / عنوان مقطع الفيديو")
            CyberTextField(value = secret, onValueChange = { secret = it }, label = "Embedded Box Payload / الحمولة المدمجة")
            CyberTextField(
                value = paddingKb,
                onValueChange = { paddingKb = it },
                label = "حجم البيانات المضمنة (KB)",
                keyboardType = KeyboardType.Number
            )

            Text("صيغة التضمين ونوع الترويسة:", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
            modes.forEach { m ->
                CyberOutlinedButton(
                    text = m,
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (videoMode == m) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { videoMode = m }
                )
            }

            CyberButton(
                text = "توليد ملف الفيديو المدمج (Synthesize Video)",
                onClick = {
                    viewModel.executeTask("تضمين بيانات الفيديو ($videoMode)") {
                        val pad = paddingKb.toIntOrNull() ?: 128
                        val (file, mime) = when (videoMode) {
                            "فيديو بترويسات متعددة (Multi-Header MP4/AVI/MKV)" -> {
                                val bytes = EmbeddingEngine.video.createMultiHeaderVideo(pad * 1024L)
                                val f = File(context.cacheDir, "multiheader_vid_${System.currentTimeMillis()}.bin")
                                FileOutputStream(f).use { it.write(bytes) }
                                Pair(f, "video/mp4")
                            }
                            else -> {
                                val f = EmbeddingEngine.video.embedDataInMP4File(context, 64 * 1024L, pad * 1024L)
                                Pair(f, "video/mp4")
                            }
                        }
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, bytesEmb = (pad * 1024L) + secret.length, filesGen = 1)
                        OutputResult(
                            title = "تم إنشاء ملف الفيديو مع البيانات المضمنة",
                            summary = "النمط: $videoMode | الحجم: ${totalBytes / 1024} KB",
                            content = "المسار: ${file.name}\nالحجم: $totalBytes بايت\nالصندوق المدمج: udta -> $secret",
                            file = file,
                            mimeType = mime
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 5: Custom Sticker Creator (WebP / Multi-Header)
 */
@Composable
private fun Tool5StickerCreator(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var label by remember { mutableStateOf("SECURITY LAB") }
    var dimension by remember { mutableStateOf("512") }
    var paddingKb by remember { mutableStateOf("32") }
    var stickerMode by remember { mutableStateOf("ملصق WebP مع بيانات مضمنة") }

    val modes = listOf("ملصق WebP مع بيانات مضمنة", "ملصق بترويسات متعددة (Multi-Header WebP/PNG)")

    LabToolCard(
        title = "5. Custom Sticker Creator",
        arabicTitle = "إنشاء ملصقات WebP مخصصة",
        icon = Icons.Default.PhotoAlbum,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "إنشاء ملصقات WebP مع رسوميات مخصصة وشفافية ألفا وحقن كتل بيانات ثنائية، أو ملصقات بترويسات هجينة.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = label, onValueChange = { label = it }, label = "Sticker Text Label / النص المطبوع على الملصق")
            CyberTextField(
                value = dimension,
                onValueChange = { dimension = it },
                label = "الأبعاد بالبكسل (e.g. 512)",
                keyboardType = KeyboardType.Number
            )
            CyberTextField(
                value = paddingKb,
                onValueChange = { paddingKb = it },
                label = "حجم البيانات المضمنة في الملصق (KB)",
                keyboardType = KeyboardType.Number
            )

            Text("نوع الملصق والترويسة:", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
            modes.forEach { m ->
                CyberOutlinedButton(
                    text = m,
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (stickerMode == m) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { stickerMode = m }
                )
            }

            CyberButton(
                text = "توليد ملصق WebP المدمج (Generate Sticker)",
                onClick = {
                    viewModel.executeTask("إنشاء ملصق WebP ($stickerMode)") {
                        val dim = dimension.toIntOrNull() ?: 512
                        val pad = paddingKb.toIntOrNull() ?: 32
                        val (file, mime) = when (stickerMode) {
                            "ملصق بترويسات متعددة (Multi-Header WebP/PNG)" -> {
                                val bytes = EmbeddingEngine.sticker.createMultiHeaderSticker(pad * 1024L)
                                val f = File(context.cacheDir, "multiheader_sticker_${System.currentTimeMillis()}.bin")
                                FileOutputStream(f).use { it.write(bytes) }
                                Pair(f, "image/webp")
                            }
                            else -> {
                                val f = EmbeddingEngine.sticker.embedDataInWebPFile(context, dim, dim, pad * 1024L)
                                Pair(f, "image/webp")
                            }
                        }
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)
                        OutputResult(
                            title = "تم إنشاء الملصق مع البيانات المضمنة",
                            summary = "الأبعاد: ${dim}x${dim} | الحجم: ${totalBytes / 1024} KB",
                            content = "الصيغة: $stickerMode\nالمسار: ${file.name}\nالحجم الإجمالي: $totalBytes بايت",
                            file = file,
                            mimeType = mime
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 6: Compressed File Generator (ZIP with recursion)
 */
@Composable
private fun Tool6ZipGenerator(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var fileCount by remember { mutableStateOf("5") }
    var sizePerFileKb by remember { mutableStateOf("64") }
    var nestedZip by remember { mutableStateOf(true) }
    var zipMode by remember { mutableStateOf("أرشيف ZIP متعدد الملفات") }

    val modes = listOf("أرشيف ZIP متعدد الملفات", "حزمة مضغوطة متداخلة (Zip Bomb Profiler)")

    LabToolCard(
        title = "6. Compressed File Generator",
        arabicTitle = "مولد ملفات مضغوطة ZIP مع تكرار",
        icon = Icons.Default.Archive,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "إنشاء حزم ZIP قياسية أو متداخلة أو حزم تكرارية لاختبار قدرة المحركات على معالجة الملفات المضغوطة.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = fileCount, onValueChange = { fileCount = it }, label = "عدد الملفات داخل الأرشيف", keyboardType = KeyboardType.Number)
            CyberTextField(value = sizePerFileKb, onValueChange = { sizePerFileKb = it }, label = "حجم كل ملف (KB)", keyboardType = KeyboardType.Number)

            Text("نوع الأرشيف:", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
            modes.forEach { m ->
                CyberOutlinedButton(
                    text = m,
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (zipMode == m) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { zipMode = m }
                )
            }

            if (zipMode == "أرشيف ZIP متعدد الملفات") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = nestedZip,
                        onCheckedChange = { nestedZip = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonGreen, checkedTrackColor = NeonGreen.copy(alpha = 0.4f))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("تضمين أرشيف فرعي متداخل (.zip داخل .zip)", color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                }
            }

            CyberButton(
                text = "إنشاء أرشيف مضغوط ZIP",
                onClick = {
                    viewModel.executeTask("إنشاء ملف مضغوط ($zipMode)") {
                        val count = fileCount.toIntOrNull() ?: 5
                        val kb = sizePerFileKb.toIntOrNull() ?: 64
                        val file = if (zipMode == "حزمة مضغوطة متداخلة (Zip Bomb Profiler)") {
                            EmbeddingEngine.compression.createZipBombFile(context, count.toLong() * 1024L, kb.toLong() * 1024L)
                        } else {
                            DataProcessingEngine.compression.createRepeatedZipArchive(context, count, kb, nestedZip)
                        }
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = (count * kb * 1024L), filesGen = 1)
                        OutputResult(
                            title = "تم إنشاء أرشيف ZIP بنجاح",
                            summary = "النمط: $zipMode ($totalBytes بايت)",
                            content = "الملف: ${file.name}\nالحجم الكلي: $totalBytes بايت\nنوع الأرشيف: $zipMode",
                            file = file,
                            mimeType = "application/zip"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 7: Location Data Generator (GPX)
 */
@Composable
private fun Tool7LocationGenerator(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var waypoints by remember { mutableStateOf("100") }
    var lat by remember { mutableStateOf("24.7136") }
    var lon by remember { mutableStateOf("46.6753") }

    LabToolCard(
        title = "7. Location Data Generator",
        arabicTitle = "مولد بيانات الموقع GPX",
        icon = Icons.Default.LocationOn,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "Generates customized GPX track log stream with coordinates, timestamps, and elevations for testing geofencing and parser performance.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = waypoints, onValueChange = { waypoints = it }, label = "Track Points Count", keyboardType = KeyboardType.Number)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberTextField(value = lat, onValueChange = { lat = it }, label = "Start Latitude", modifier = Modifier.weight(1f))
                CyberTextField(value = lon, onValueChange = { lon = it }, label = "Start Longitude", modifier = Modifier.weight(1f))
            }

            CyberButton(
                text = "Generate GPX Coordinates Track",
                onClick = {
                    viewModel.executeTask("Location Data Generator") {
                        val count = waypoints.toIntOrNull() ?: 100
                        val startLat = lat.toDoubleOrNull() ?: 24.7136
                        val startLon = lon.toDoubleOrNull() ?: 46.6753
                        val file = MediaUtils.createGpxFile(context, count, startLat, startLon)
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)
                        OutputResult(
                            title = "Generated GPX Location Stream",
                            summary = "Generated $count track points ($totalBytes bytes)",
                            content = file.readText().take(1200) + "\n... [Total ${file.length()} bytes]",
                            file = file,
                            mimeType = "application/gpx+xml"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 8: Contact Data Generator (VCF vCard)
 */
@Composable
private fun Tool8ContactGenerator(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("Dr. Tariq Al-Mansoor") }
    var org by remember { mutableStateOf("Data Craft Security Research Center") }
    var payloadNote by remember { mutableStateOf("CONFIDENTIAL_STATION_TOKEN_9918") }

    LabToolCard(
        title = "8. Contact Data Generator",
        arabicTitle = "مولد جهات الاتصال vCard مع بيانات مخصصة",
        icon = Icons.Default.ContactPage,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "Generates standard vCard (.vcf) contacts containing extended research headers, base64 payload tokens, and custom metadata fields.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = name, onValueChange = { name = it }, label = "Full Contact Name")
            CyberTextField(value = org, onValueChange = { org = it }, label = "Organization Name")
            CyberTextField(value = payloadNote, onValueChange = { payloadNote = it }, label = "Custom Embedded Note / Token")

            CyberButton(
                text = "Generate vCard (.vcf)",
                onClick = {
                    viewModel.executeTask("Contact Data Generator") {
                        val file = MediaUtils.createVcfContact(context, name, org, payloadNote)
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, bytesEmb = payloadNote.length.toLong(), filesGen = 1)
                        OutputResult(
                            title = "Generated vCard Contact",
                            summary = "Generated vCard for $name ($totalBytes bytes)",
                            content = file.readText(),
                            file = file,
                            mimeType = "text/vcard"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 9: Large Text Generator
 */
@Composable
private fun Tool9LargeTextGenerator(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var charCount by remember { mutableStateOf("50000") }
    var unicodeEngineType by remember { mutableStateOf("Unicode مختلط ومكثف") }

    val types = listOf("Unicode مختلط ومكثف", "أحرف BiDi معكوسة الاتجاه", "محرك النصوص الضخمة")

    LabToolCard(
        title = "9. Large Text Generator",
        arabicTitle = "مولد النصوص الضخمة مع أحرف Unicode المتنوعة",
        icon = Icons.Default.Notes,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "توليد نصوص عملاقة باختبارات التحمل، تشمل محارف Unicode نادرة ورموز تحكم وعكس الاتجاه BiDi ورموز تعبيرية لإجهاد المحللات النصية.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = charCount, onValueChange = { charCount = it }, label = "عدد الأحرف المطلوب توليدها", keyboardType = KeyboardType.Number)

            Text("نوع مجموعة المحارف:", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
            types.forEach { t ->
                CyberOutlinedButton(
                    text = t,
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (unicodeEngineType == t) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { unicodeEngineType = t }
                )
            }

            CyberButton(
                text = "توليد النص الضخم (Generate Text)",
                onClick = {
                    viewModel.executeTask("توليد نص ضخم ($unicodeEngineType)") {
                        val count = (charCount.toIntOrNull() ?: 50000).coerceIn(100, 500000)
                        val text = when (unicodeEngineType) {
                            "Unicode مختلط ومكثف" -> EmbeddingEngine.unicode.generateUnicodeText(count.toLong())
                            "أحرف BiDi معكوسة الاتجاه" -> EmbeddingEngine.unicode.generateRTLOverrideChars(count)
                            else -> DataProcessingEngine.text.generateMassiveText(count.toLong())
                        }
                        val totalBytes = text.toByteArray().size
                        viewModel.incrementStats(bytesProc = totalBytes.toLong())
                        OutputResult(
                            title = "تم توليد النص الضخم بنجاح",
                            summary = "النمط: $unicodeEngineType | تم إنشاء $count حرفاً ($totalBytes بايت بصيغة UTF-8)",
                            content = text.take(1000) + "\n... [معاينة مقتطعة: إجمالي ${text.length} حرف]"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Reusable Card container for lab tools.
 */
@Composable
fun LabToolCard(
    title: String,
    arabicTitle: String,
    icon: ImageVector,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (expanded) NeonGreen.copy(alpha = 0.6f) else CyberCardBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(if (expanded) NeonGreen.copy(alpha = 0.2f) else CyberDark, RoundedCornerShape(8.dp))
                        .border(1.dp, if (expanded) NeonGreen else CyberCardBorder, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (expanded) NeonGreen else NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = arabicTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                Text(
                    text = if (expanded) "▲" else "▼",
                    color = if (expanded) NeonGreen else TextSecondary,
                    fontSize = 12.sp
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 14.dp)) {
                    content()
                }
            }
        }
    }
}

/**
 * Standard Cyber-themed text field.
 */
@Composable
fun CyberTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, style = MaterialTheme.typography.bodySmall) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = modifier,
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonGreen,
            unfocusedBorderColor = CyberCardBorder,
            focusedLabelColor = NeonGreen,
            unfocusedLabelColor = TextSecondary,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            cursorColor = NeonGreen
        ),
        shape = RoundedCornerShape(8.dp)
    )
}

/**
 * Standard Cyber-themed filled action button.
 */
@Composable
fun CyberButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.fillMaxWidth(),
    color: Color = NeonGreen,
    textColor: Color = Color.Black
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = textColor),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.testTag("cyber_button")
    ) {
        Text(text = text, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
    }
}

/**
 * Standard Cyber-themed outlined button.
 */
@Composable
fun CyberOutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.fillMaxWidth(),
    borderColor: Color = NeonGreen
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.border(1.dp, borderColor, RoundedCornerShape(8.dp)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = borderColor)
    ) {
        Text(text = text, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
    }
}
