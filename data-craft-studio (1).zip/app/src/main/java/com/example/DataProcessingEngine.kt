package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import java.util.Random
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.ln
import kotlin.math.sin

/**
 * Data Processing Engine for Data Craft Studio.
 * High-performance on-device processing engine dealing with massive text synthesis,
 * media synthesis with custom headers/padding, compression, binary patterns,
 * and Unicode manipulation.
 */

// ============================================================================
// 1. Text Generation Engine (محرك توليد النصوص الضخمة والإخفاء)
// ============================================================================

/**
 * Engine for generating massive corpora of diverse Unicode characters,
 * repeated patterns, and Zero-Width steganographic payloads.
 */
class TextGenerationEngine(private val random: Random = SecureRandom()) {

    companion object {
        val UNICODE_CONTROL_CHARS = charArrayOf(
            '\u202E', // Right-to-Left Override (RLO)
            '\u202D', // Left-to-Right Override (LRO)
            '\u2066', // Left-to-Right Isolate (LRI)
            '\u2067', // Right-to-Left Isolate (RLI)
            '\u2068', // First Strong Isolate (FSI)
            '\u2069', // Pop Directional Isolate (PDI)
            '\u200B', // Zero-Width Space (ZWSP)
            '\u200C', // Zero-Width Non-Joiner (ZWNJ)
            '\u200D', // Zero-Width Joiner (ZWJ)
            '\u2060', // Word Joiner (WJ)
            '\uFEFF', // Zero-Width No-Break Space / BOM
            '\u0000', '\u0001', '\u0002', '\u0003', '\u0004' // Control chars
        )

        const val EMOJIS = "😀😈💀🔥☠️⚡💣🧨🔪🩸👁️🗨️🫀🧠🦠🛡️🚀🛰️"
        const val SPECIAL_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?"
        val ZERO_WIDTH_ARRAY = charArrayOf('\u200B', '\u200C', '\u200D', '\u2060', '\uFEFF')
    }

    /**
     * Generates massive text with diverse Unicode characters, control marks, emojis,
     * and repeated sequences up to the requested target size.
     * Uses optimized StringBuilder chunking to maintain high throughput and minimize allocations.
     *
     * @param targetSize Number of characters to generate.
     * @return Massive generated string.
     */
    fun generateMassiveText(targetSize: Long): String {
        return try {
            val clampedSize = targetSize.coerceIn(1L, 10_000_000L).toInt()
            val result = StringBuilder(minOf(clampedSize, 1_000_000))
            var currentSize = 0

            // Pre-cached blocks to speed up generation for large target sizes
            val zerosBlock = "\u0000".repeat(100)
            val aBlock = "A".repeat(500)

            while (currentSize < clampedSize) {
                val remaining = clampedSize - currentSize
                when (random.nextInt(5)) {
                    0 -> {
                        val charToAdd = UNICODE_CONTROL_CHARS[random.nextInt(UNICODE_CONTROL_CHARS.size)]
                        result.append(charToAdd)
                    }
                    1 -> {
                        val emojiIndex = random.nextInt(EMOJIS.length - 2)
                        result.append(EMOJIS.substring(emojiIndex, emojiIndex + 2))
                    }
                    2 -> {
                        val charToAdd = SPECIAL_CHARS[random.nextInt(SPECIAL_CHARS.length)]
                        result.append(charToAdd)
                    }
                    3 -> {
                        val count = minOf(random.nextInt(100) + 1, remaining)
                        if (count >= 100) result.append(zerosBlock) else result.append("\u0000".repeat(count))
                    }
                    4 -> {
                        val count = minOf(random.nextInt(500) + 1, remaining)
                        if (count >= 500) result.append(aBlock) else result.append("A".repeat(count))
                    }
                }
                currentSize = result.length
            }

            if (result.length > clampedSize) {
                result.substring(0, clampedSize)
            } else {
                result.toString()
            }
        } catch (e: Exception) {
            "Error during massive text generation: ${e.message}"
        }
    }

    /**
     * Generates carrier text containing hidden binary data encoded into Zero-Width characters.
     *
     * @param visibleText Plain visible text carrier.
     * @param hiddenData Secret data to conceal.
     * @return Concealed carrier string with zero-width invisible markers.
     */
    fun generateHiddenText(visibleText: String, hiddenData: String): String {
        return try {
            val hiddenBytes = hiddenData.toByteArray(StandardCharsets.UTF_8)
            // Convert hidden data bytes into binary string representation
            val binaryData = hiddenBytes.joinToString("") { byte ->
                String.format("%8s", Integer.toBinaryString(byte.toInt() and 0xFF)).replace(' ', '0')
            }

            // Convert binary into Zero-Width characters (ZWSP for 0, ZWNJ for 1)
            val hiddenString = StringBuilder(binaryData.length + 2)
            hiddenString.append('\uFEFF') // Stego packet start delimiter
            for (bit in binaryData) {
                hiddenString.append(if (bit == '0') '\u200B' else '\u200C')
            }
            hiddenString.append('\uFEFF') // Stego packet end delimiter

            // Append or embed into carrier
            val spaceIndex = visibleText.indexOf(' ')
            if (spaceIndex != -1) {
                visibleText.substring(0, spaceIndex + 1) + hiddenString.toString() + visibleText.substring(spaceIndex + 1)
            } else {
                visibleText + hiddenString.toString()
            }
        } catch (e: Exception) {
            visibleText
        }
    }

    /**
     * Extracts hidden secret data encoded in Zero-Width characters from a text string.
     *
     * @param text Tainted text containing zero-width sequence.
     * @return Decoded plaintext or error description.
     */
    fun extractHiddenText(text: String): String {
        return try {
            val startIdx = text.indexOf('\uFEFF')
            if (startIdx == -1) return "لا توجد بيانات مخفية (No stego header found)"
            val endIdx = text.indexOf('\uFEFF', startIdx + 1)
            if (endIdx == -1) return "حزمة البيانات غير مكتملة (Incomplete stego packet)"

            val stream = text.substring(startIdx + 1, endIdx)
            val bitBuilder = StringBuilder()
            for (ch in stream) {
                when (ch) {
                    '\u200B' -> bitBuilder.append('0')
                    '\u200C' -> bitBuilder.append('1')
                }
            }

            val bits = bitBuilder.toString()
            if (bits.length % 8 != 0 && bits.length < 8) {
                return "البيانات المستخرجة تالفة (Invalid bitstream length)"
            }

            val byteCount = bits.length / 8
            val bytes = ByteArray(byteCount)
            for (i in 0 until byteCount) {
                val byteStr = bits.substring(i * 8, (i + 1) * 8)
                bytes[i] = byteStr.toInt(2).toByte()
            }

            String(bytes, StandardCharsets.UTF_8)
        } catch (e: Exception) {
            "فشل في استخراج البيانات: ${e.message}"
        }
    }

    /**
     * Generates repeated pattern text quickly.
     */
    fun generateRepeatedText(pattern: String, count: Long): String {
        val safeCount = count.coerceIn(1L, 1_000_000L).toInt()
        val sb = StringBuilder(pattern.length * safeCount)
        repeat(safeCount) {
            sb.append(pattern)
        }
        return sb.toString()
    }
}

// ============================================================================
// 2. Image Creation Engine (محرك إنشاء الصور المخصصة)
// ============================================================================

/**
 * Engine for creating valid custom-sized bitmap graphics (PNG, JPEG)
 * and appending custom padding/metadata payloads.
 */
class ImageCreationEngine(private val random: Random = SecureRandom()) {

    /**
     * Creates a custom PNG image byte array with custom trailing/padding data.
     *
     * @param width Image width in pixels.
     * @param height Image height in pixels.
     * @param extraDataSize Number of additional bytes to append.
     * @return Raw PNG byte array combined with extra payload.
     */
    fun createCustomImage(width: Int, height: Int, extraDataSize: Int): ByteArray {
        return try {
            val safeW = width.coerceIn(10, 2048)
            val safeH = height.coerceIn(10, 2048)
            val bitmap = Bitmap.createBitmap(safeW, safeH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.BLACK)

            // Draw high-contrast cyber diagnostic grid
            val paint = Paint().apply {
                color = Color.rgb(0, 255, 65)
                strokeWidth = 2f
            }
            for (x in 0..safeW step 32) {
                canvas.drawLine(x.toFloat(), 0f, x.toFloat(), safeH.toFloat(), paint)
            }
            for (y in 0..safeH step 32) {
                canvas.drawLine(0f, y.toFloat(), safeW.toFloat(), y.toFloat(), paint)
            }

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            val pngData = outputStream.toByteArray()

            val safeExtra = extraDataSize.coerceIn(0, 50 * 1024 * 1024)
            val extraData = ByteArray(safeExtra) {
                val b = ByteArray(1)
                random.nextBytes(b)
                b[0]
            }

            // Return combined PNG data and extra binary payload
            pngData + extraData
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Creates a custom JPEG image byte array with metadata and extra payload.
     *
     * @param width Image width in pixels.
     * @param height Image height in pixels.
     * @param extraDataSize Number of additional bytes to append.
     * @return Raw JPEG byte array combined with extra payload.
     */
    fun createCustomJPEG(width: Int, height: Int, extraDataSize: Int): ByteArray {
        return try {
            val safeW = width.coerceIn(10, 2048)
            val safeH = height.coerceIn(10, 2048)
            val bitmap = Bitmap.createBitmap(safeW, safeH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)

            val paint = Paint().apply {
                color = Color.BLUE
                strokeWidth = 3f
            }
            canvas.drawCircle(safeW / 2f, safeH / 2f, minOf(safeW, safeH) / 3f, paint)

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
            val jpegData = outputStream.toByteArray()

            val safeExtra = extraDataSize.coerceIn(0, 50 * 1024 * 1024)
            val extraData = ByteArray(safeExtra) {
                val b = ByteArray(1)
                random.nextBytes(b)
                b[0]
            }

            jpegData + extraData
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Helper to write created custom image directly to a cache file.
     */
    fun createCustomImageFile(
        context: Context,
        width: Int,
        height: Int,
        extraDataSize: Int,
        format: String = "PNG"
    ): File {
        val isPng = format.equals("PNG", ignoreCase = true)
        val ext = if (isPng) "png" else "jpg"
        val bytes = if (isPng) createCustomImage(width, height, extraDataSize) else createCustomJPEG(width, height, extraDataSize)
        val file = File(context.cacheDir, "custom_image_${System.currentTimeMillis()}.$ext")
        FileOutputStream(file).use { it.write(bytes) }
        return file
    }
}

// ============================================================================
// 3. Audio Creation Engine (محرك إنشاء الملفات الصوتية)
// ============================================================================

/**
 * Engine for synthesizing MP3 audio files with custom ID3 headers
 * and WAV PCM audio streams.
 */
class AudioCreationEngine(private val random: Random = SecureRandom()) {

    /**
     * Creates an MP3 audio byte array with a valid MP3 sync header and custom payload data.
     *
     * @param dataSize Target byte size of the payload.
     * @return MP3 header combined with payload data.
     */
    fun createCustomMP3(dataSize: Long): ByteArray {
        return try {
            val mp3Header = byteArrayOf(
                0xFF.toByte(), 0xFB.toByte(), 0x90.toByte(), 0x00.toByte(),
                0x49.toByte(), 0x44.toByte(), 0x33.toByte(), 0x03.toByte()
            )

            val safeSize = dataSize.coerceIn(0L, 50L * 1024 * 1024).toInt()
            val data = ByteArray(safeSize) {
                val b = ByteArray(1)
                random.nextBytes(b)
                b[0]
            }

            mp3Header + data
        } catch (e: Exception) {
            byteArrayOf(0xFF.toByte(), 0xFB.toByte(), 0x90.toByte(), 0x00.toByte())
        }
    }

    /**
     * Creates a standard uncompressed 16-bit PCM Mono WAV audio stream with pure sine tone.
     *
     * @param sampleRate Sample rate in Hz (e.g. 44100).
     * @param durationSeconds Duration in seconds.
     * @param frequency Tone frequency in Hz (e.g. 440.0).
     * @return Complete RIFF/WAVE byte array.
     */
    fun createCustomWAV(sampleRate: Int = 44100, durationSeconds: Int = 3, frequency: Double = 440.0): ByteArray {
        return try {
            val totalSamples = sampleRate * durationSeconds.coerceIn(1, 60)
            val subChunk2Size = totalSamples * 2 // 16-bit = 2 bytes per sample
            val chunkSize = 36 + subChunk2Size

            val stream = ByteArrayOutputStream(chunkSize + 8)
            val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)

            // RIFF header
            bb.put("RIFF".toByteArray(StandardCharsets.US_ASCII))
            bb.putInt(chunkSize)
            bb.put("WAVE".toByteArray(StandardCharsets.US_ASCII))

            // fmt subchunk
            bb.put("fmt ".toByteArray(StandardCharsets.US_ASCII))
            bb.putInt(16) // SubChunk1Size (16 for PCM)
            bb.putShort(1) // AudioFormat (1 = PCM)
            bb.putShort(1) // NumChannels (1 = Mono)
            bb.putInt(sampleRate) // SampleRate
            bb.putInt(sampleRate * 2) // ByteRate (SampleRate * NumChannels * BitsPerSample/8)
            bb.putShort(2) // BlockAlign (NumChannels * BitsPerSample/8)
            bb.putShort(16) // BitsPerSample

            // data subchunk
            bb.put("data".toByteArray(StandardCharsets.US_ASCII))
            bb.putInt(subChunk2Size)

            stream.write(bb.array())

            // Synthesize PCM samples
            val sampleBuffer = ByteBuffer.allocate(subChunk2Size).order(ByteOrder.LITTLE_ENDIAN)
            val angleStep = 2.0 * Math.PI * frequency / sampleRate
            for (i in 0 until totalSamples) {
                val sampleValue = (sin(angleStep * i) * 32767.0).toInt().toShort()
                sampleBuffer.putShort(sampleValue)
            }
            stream.write(sampleBuffer.array())

            stream.toByteArray()
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Helper to write created custom audio directly to a cache file.
     */
    fun createCustomAudioFile(context: Context, dataSize: Long): File {
        val bytes = createCustomMP3(dataSize)
        val file = File(context.cacheDir, "custom_audio_${System.currentTimeMillis()}.mp3")
        FileOutputStream(file).use { it.write(bytes) }
        return file
    }
}

// ============================================================================
// 4. Video Creation Engine (محرك إنشاء ملفات الفيديو)
// ============================================================================

/**
 * Engine for constructing ISO Base Media MP4 container byte streams
 * with custom atom hierarchy and data payload.
 */
class VideoCreationEngine(private val random: Random = SecureRandom()) {

    /**
     * Creates an MP4 container byte array with standard ftyp box header and custom payload data.
     *
     * @param dataSize Target byte size of payload.
     * @return Valid MP4 box header combined with payload bytes.
     */
    fun createCustomMP4(dataSize: Long): ByteArray {
        return try {
            val mp4Header = byteArrayOf(
                0x00, 0x00, 0x00, 0x18, // box size = 24 bytes
                0x66, 0x74, 0x79, 0x70, // 'ftyp'
                0x6D, 0x70, 0x34, 0x32, // major_brand = 'mp42'
                0x00, 0x00, 0x00, 0x00, // minor_version = 0
                0x69, 0x73, 0x6F, 0x6D, // compatible_brands: 'isom'
                0x6D, 0x70, 0x34, 0x32  // 'mp42'
            )

            val safeSize = dataSize.coerceIn(0L, 50L * 1024 * 1024).toInt()
            val data = ByteArray(safeSize) {
                val b = ByteArray(1)
                random.nextBytes(b)
                b[0]
            }

            mp4Header + data
        } catch (e: Exception) {
            byteArrayOf(0x00, 0x00, 0x00, 0x18, 0x66, 0x74, 0x79, 0x70)
        }
    }

    /**
     * Helper to write created custom video directly to a cache file.
     */
    fun createCustomVideoFile(context: Context, dataSize: Long): File {
        val bytes = createCustomMP4(dataSize)
        val file = File(context.cacheDir, "custom_video_${System.currentTimeMillis()}.mp4")
        FileOutputStream(file).use { it.write(bytes) }
        return file
    }
}

// ============================================================================
// 5. Sticker Creation Engine (محرك إنشاء الملصقات)
// ============================================================================

/**
 * Engine for synthesizing WebP format stickers with transparency and custom payload data.
 */
class StickerCreationEngine(private val random: Random = SecureRandom()) {

    /**
     * Creates a custom WebP sticker byte array with alpha transparency and extra payload.
     *
     * @param width Sticker width in pixels.
     * @param height Sticker height in pixels.
     * @param extraDataSize Number of additional bytes to append.
     * @return WebP byte array combined with extra payload.
     */
    fun createCustomSticker(width: Int, height: Int, extraDataSize: Int): ByteArray {
        return try {
            val safeW = width.coerceIn(64, 1024)
            val safeH = height.coerceIn(64, 1024)
            val bitmap = Bitmap.createBitmap(safeW, safeH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.TRANSPARENT)

            // Draw circular sticker badge
            val paint = Paint().apply {
                color = Color.RED
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            val radius = minOf(safeW, safeH) / 2.5f
            canvas.drawCircle(safeW / 2f, safeH / 2f, radius, paint)

            // Draw inner cyber border
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 8f
            paint.color = Color.YELLOW
            canvas.drawCircle(safeW / 2f, safeH / 2f, radius - 10f, paint)

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.WEBP, 100, outputStream)
            val webpData = outputStream.toByteArray()

            val safeExtra = extraDataSize.coerceIn(0, 50 * 1024 * 1024)
            val extraData = ByteArray(safeExtra) {
                val b = ByteArray(1)
                random.nextBytes(b)
                b[0]
            }

            webpData + extraData
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    /**
     * Helper to write created custom sticker directly to a cache file.
     */
    fun createCustomStickerFile(
        context: Context,
        width: Int,
        height: Int,
        label: String,
        extraDataSize: Int
    ): File {
        val bytes = createCustomSticker(width, height, extraDataSize)
        val file = File(context.cacheDir, "sticker_${System.currentTimeMillis()}.webp")
        FileOutputStream(file).use { it.write(bytes) }
        return file
    }
}

// ============================================================================
// 6. Compression Engine (محرك الضغط المتكرر)
// ============================================================================

/**
 * Engine for GZIP / DEFLATE compression, repeated compression benchmarking,
 * and creating multi-file / nested ZIP archives.
 */
class CompressionEngine {

    /**
     * Compresses byte array using standard GZIP stream.
     */
    fun compressGzip(data: ByteArray): ByteArray {
        return try {
            val bos = ByteArrayOutputStream()
            GZIPOutputStream(bos).use { it.write(data) }
            bos.toByteArray()
        } catch (e: Exception) {
            data
        }
    }

    /**
     * Decompresses GZIP byte stream back into raw bytes.
     */
    fun decompressGzip(compressedData: ByteArray): ByteArray {
        return try {
            val bis = ByteArrayInputStream(compressedData)
            val bos = ByteArrayOutputStream()
            GZIPInputStream(bis).use { gis ->
                val buffer = ByteArray(4096)
                var bytesRead: Int
                while (gis.read(buffer).also { bytesRead = it } != -1) {
                    bos.write(buffer, 0, bytesRead)
                }
            }
            bos.toByteArray()
        } catch (e: Exception) {
            compressedData
        }
    }

    /**
     * Creates a ZIP archive containing multiple synthetic files and optional nested ZIP archives.
     */
    fun createRepeatedZipArchive(
        context: Context,
        fileCount: Int,
        fileSizeKb: Int,
        nested: Boolean = false
    ): File {
        val zipFile = File(context.cacheDir, "archive_${System.currentTimeMillis()}.zip")
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            val count = fileCount.coerceIn(1, 100)
            val size = fileSizeKb.coerceIn(1, 1024)
            val payload = ByteArray(size * 1024) { ((it % 26) + 65).toByte() }

            for (i in 1..count) {
                zos.putNextEntry(ZipEntry("synthetic_payload_$i.dat"))
                zos.write(payload)
                zos.closeEntry()
            }

            if (nested) {
                val nestedBos = ByteArrayOutputStream()
                ZipOutputStream(nestedBos).use { nestedZos ->
                    nestedZos.putNextEntry(ZipEntry("nested_secret.txt"))
                    nestedZos.write("Nested Archive Level 2 Payload".toByteArray(StandardCharsets.UTF_8))
                    nestedZos.closeEntry()
                }
                zos.putNextEntry(ZipEntry("sub_archive.zip"))
                zos.write(nestedBos.toByteArray())
                zos.closeEntry()
            }
        }
        return zipFile
    }

    /**
     * Calculates compression percentage savings.
     */
    fun calculateCompressionRatio(originalSize: Long, compressedSize: Long): Double {
        if (originalSize <= 0) return 0.0
        return (1.0 - (compressedSize.toDouble() / originalSize.toDouble())) * 100.0
    }
}

// ============================================================================
// 7. Binary Data Engine (محرك إنشاء البيانات الثنائية)
// ============================================================================

enum class BinaryPattern {
    RANDOM,
    ZEROES,
    ONES,
    ALTERNATING,
    COUNTER
}

/**
 * Engine for synthesizing raw binary streams with customizable patterns
 * and calculating statistical Shannon entropy.
 */
class BinaryDataEngine(private val random: Random = SecureRandom()) {

    /**
     * Generates a cryptographically random byte array.
     */
    fun generateRandomBinary(size: Long): ByteArray {
        val safeSize = size.coerceIn(1L, 50L * 1024 * 1024).toInt()
        val data = ByteArray(safeSize)
        random.nextBytes(data)
        return data
    }

    /**
     * Generates structured binary streams adhering to specific diagnostic byte patterns.
     */
    fun generatePatternBinary(size: Long, patternType: BinaryPattern): ByteArray {
        val safeSize = size.coerceIn(1L, 50L * 1024 * 1024).toInt()
        val data = ByteArray(safeSize)
        when (patternType) {
            BinaryPattern.RANDOM -> random.nextBytes(data)
            BinaryPattern.ZEROES -> data.fill(0)
            BinaryPattern.ONES -> data.fill(0xFF.toByte())
            BinaryPattern.ALTERNATING -> data.fill(0xAA.toByte())
            BinaryPattern.COUNTER -> {
                for (i in data.indices) {
                    data[i] = (i % 256).toByte()
                }
            }
        }
        return data
    }

    /**
     * Computes Shannon Entropy (in bits per byte, range 0.0 to 8.0)
     * to evaluate randomness and compressibility.
     */
    fun calculateEntropy(data: ByteArray): Double {
        if (data.isEmpty()) return 0.0
        val frequency = IntArray(256)
        for (b in data) {
            frequency[b.toInt() and 0xFF]++
        }
        val len = data.size.toDouble()
        var entropy = 0.0
        val log2 = ln(2.0)
        for (count in frequency) {
            if (count > 0) {
                val p = count / len
                entropy -= p * (ln(p) / log2)
            }
        }
        return entropy
    }
}

// ============================================================================
// 8. Unicode Engine (محرك معالجة أحرف Unicode)
// ============================================================================

data class UnicodeAnalysisResult(
    val characterCount: Int,
    val codePointCount: Int,
    val zeroWidthCount: Int,
    val bidiOverrideCount: Int,
    val surrogatePairCount: Int,
    val asciiCount: Int,
    val nonAsciiCount: Int
)

/**
 * Engine for manipulating and analyzing Unicode strings, Zalgo combining diacritics,
 * BiDi override controls, and homoglyphs.
 */
class UnicodeEngine {

    companion object {
        val COMBINING_MARKS = (0x0300..0x036F).map { it.toChar() }
        val ZERO_WIDTH_CHARS = setOf('\u200B', '\u200C', '\u200D', '\u2060', '\uFEFF')
        val BIDI_OVERRIDE_CHARS = setOf('\u202E', '\u202D', '\u2066', '\u2067', '\u2068', '\u2069')
    }

    /**
     * Generates Zalgo text by appending combining diacritic marks to each character.
     *
     * @param baseText Input text.
     * @param intensity Number of diacritic marks per character (e.g. 5 to 20).
     */
    fun generateZalgoText(baseText: String, intensity: Int = 10): String {
        val safeIntensity = intensity.coerceIn(1, 50)
        val sb = StringBuilder(baseText.length * (safeIntensity + 1))
        for (ch in baseText) {
            sb.append(ch)
            if (!ch.isWhitespace()) {
                repeat(safeIntensity) {
                    sb.append(COMBINING_MARKS.random())
                }
            }
        }
        return sb.toString()
    }

    /**
     * Inserts Right-to-Left Override (RLO) and restoration directional marks.
     */
    fun generateBiDiOverrideText(text: String): String {
        return "\u202E$text\u202D"
    }

    /**
     * Strips all invisible zero-width and directional control characters.
     */
    fun stripInvisibleCharacters(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text) {
            if (!ZERO_WIDTH_CHARS.contains(ch) && !BIDI_OVERRIDE_CHARS.contains(ch)) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Audits and analyzes Unicode code points, surrogate pairs, and invisible tokens.
     */
    fun analyzeCodePoints(text: String): UnicodeAnalysisResult {
        var zeroWidth = 0
        var bidi = 0
        var ascii = 0
        var nonAscii = 0
        val codePoints = text.codePointCount(0, text.length)
        var surrogates = 0

        for (i in text.indices) {
            val ch = text[i]
            if (ch.isSurrogate()) surrogates++
            if (ch.code < 128) ascii++ else nonAscii++
            if (ZERO_WIDTH_CHARS.contains(ch)) zeroWidth++
            if (BIDI_OVERRIDE_CHARS.contains(ch)) bidi++
        }

        return UnicodeAnalysisResult(
            characterCount = text.length,
            codePointCount = codePoints,
            zeroWidthCount = zeroWidth,
            bidiOverrideCount = bidi,
            surrogatePairCount = surrogates / 2,
            asciiCount = ascii,
            nonAsciiCount = nonAscii
        )
    }
}

// ============================================================================
// Master Data Processing Engine Singleton / Facade
// ============================================================================

/**
 * Unified facade providing singleton access to all 8 sub-engines.
 */
object DataProcessingEngine {
    val text = TextGenerationEngine()
    val image = ImageCreationEngine()
    val audio = AudioCreationEngine()
    val video = VideoCreationEngine()
    val sticker = StickerCreationEngine()
    val compression = CompressionEngine()
    val binary = BinaryDataEngine()
    val unicode = UnicodeEngine()
}
