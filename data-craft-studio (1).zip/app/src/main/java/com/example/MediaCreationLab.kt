package com.example

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoAlbum
import androidx.compose.material.icons.filled.TextSnippet
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextSecondary
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Section 3: Media Creation Lab (مختبر إنشاء الوسائط)
 * Synthesizes valid custom-sized media and binary payload files.
 */
@Composable
fun MediaCreationLab(
    viewModel: LabViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            LabHeaderBadge(
                title = "مختبر صناعة الوسائط",
                subtitle = "Media Creation Lab • إنشاء ملفات صوتية وفيديو ورسوميات وبيانات",
                icon = Icons.Default.VideoLibrary
            )
        }

        // 1. Custom Image Creator
        item {
            Tool1CustomImage(viewModel, context)
        }

        // 2. Custom Audio Creator
        item {
            Tool2CustomAudio(viewModel, context)
        }

        // 3. Custom Video Creator
        item {
            Tool3CustomVideo(viewModel, context)
        }

        // 4. Custom Sticker Creator
        item {
            Tool4CustomSticker(viewModel, context)
        }

        // 5. Custom Document Creator
        item {
            Tool5CustomDocument(viewModel, context)
        }

        // 6. Custom Archive Creator
        item {
            Tool6CustomArchive(viewModel, context)
        }

        // 7. Binary Data Creator
        item {
            Tool7BinaryCreator(viewModel, context)
        }

        // 8. Unicode Text Creator
        item {
            Tool8UnicodeCreator(viewModel)
        }

        // 9. Data Bundle Creator
        item {
            Tool9DataBundleCreator(viewModel, context)
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * Tool 1: Custom Image Creator
 */
@Composable
private fun Tool1CustomImage(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var width by remember { mutableStateOf("400") }
    var height by remember { mutableStateOf("400") }
    var label by remember { mutableStateOf("Synthetic Test Matrix") }

    LabToolCard(
        title = "1. Custom Image Creator",
        arabicTitle = "منشئ صور مخصصة بأبعاد وأنماط اصطناعية",
        icon = Icons.Default.Image,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "إنشاء صور نقطية عالية الدقة بصيغة PNG مع رسوميات مصفوفة اختبارية وأبعاد قابلة للتخصيص بالكامل.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberTextField(value = width, onValueChange = { width = it }, label = "العرض (بكسل)", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Number)
                CyberTextField(value = height, onValueChange = { height = it }, label = "الارتفاع (بكسل)", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Number)
            }
            CyberTextField(value = label, onValueChange = { label = it }, label = "العلامة المائية / النص المضمن")

            CyberButton(
                text = "إنشاء صورة مخصصة (Synthesize Image)",
                onClick = {
                    viewModel.executeTask("إنشاء صورة مخصصة") {
                        val w = (width.toIntOrNull() ?: 400).coerceIn(50, 1920)
                        val h = (height.toIntOrNull() ?: 400).coerceIn(50, 1920)
                        val file = DataProcessingEngine.image.createCustomImageFile(context, w, h, 0, "PNG")
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)

                        OutputResult(
                            title = "تم إنشاء صورة PNG بنجاح",
                            summary = "الأبعاد: ${w}x${h} | الحجم: ${totalBytes / 1024} كيلوبايت",
                            content = "اسم الملف: ${file.name}\nالأبعاد: ${w}x${h} بكسل\nالصيغة: PNG ARGB_8888\nالحجم: $totalBytes بايت",
                            file = file,
                            mimeType = "image/png"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 2: Custom Audio Creator (Sine wave WAV)
 */
@Composable
private fun Tool2CustomAudio(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var freqHz by remember { mutableStateOf("440") }
    var durationSec by remember { mutableStateOf("3") }

    LabToolCard(
        title = "2. Custom Audio Creator",
        arabicTitle = "منشئ ملفات صوتية مخصصة بنغمات جيبية WAV",
        icon = Icons.Default.Audiotrack,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "توليد ملفات صوتية قياسية بصيغة WAV بتردد 44.1 كيلوهرتز و 16 بت مونو عبر مذبذبات الموجات الجيبية الرياضية.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberTextField(value = freqHz, onValueChange = { freqHz = it }, label = "التردد (هرتز، مثل 440)", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Number)
                CyberTextField(value = durationSec, onValueChange = { durationSec = it }, label = "المدة (بالثواني)", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Number)
            }

            CyberButton(
                text = "توليد ملف صوتي (Synthesize WAV)",
                onClick = {
                    viewModel.executeTask("توليد نغمة صوتية WAV") {
                        val freq = (freqHz.toDoubleOrNull() ?: 440.0).coerceIn(20.0, 20000.0)
                        val dur = (durationSec.toIntOrNull() ?: 3).coerceIn(1, 10)
                        val audioBytes = DataProcessingEngine.audio.createCustomWAV(44100, dur, freq)
                        val file = File(context.cacheDir, "audio_tone_${System.currentTimeMillis()}.wav")
                        file.writeBytes(audioBytes)
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)

                        OutputResult(
                            title = "تم إنشاء ملف صوتي WAV بنجاح",
                            summary = "التردد: ${freq}Hz | المدة: ${dur} ثوانٍ | الحجم: ${totalBytes / 1024} كيلوبايت",
                            content = "معدل العينات: 44.1 kHz, 16-bit PCM Mono\nالملف: ${file.name}\nالحجم: $totalBytes بايت",
                            file = file,
                            mimeType = "audio/wav"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 3: Custom Video Creator (MP4)
 */
@Composable
private fun Tool3CustomVideo(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("Cyber Stream Stream 01") }

    LabToolCard(
        title = "3. Custom Video Creator",
        arabicTitle = "منشئ ملفات فيديو MP4 ISO Base Media",
        icon = Icons.Default.Movie,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "بناء حاويات فيديو MP4 قياسية مع صناديق ftyp و moov و mdat وعينات مخصصة.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = title, onValueChange = { title = it }, label = "عنوان مقطع الفيديو")

            CyberButton(
                text = "إنشاء حاوية فيديو MP4",
                onClick = {
                    viewModel.executeTask("إنشاء حاوية MP4") {
                        val file = DataProcessingEngine.video.createCustomVideoFile(context, 64 * 1024L)
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)

                        OutputResult(
                            title = "تم إنشاء ملف فيديو MP4 بنجاح",
                            summary = "حاوية ISO Base Media MP4 صالحة ($totalBytes بايت)",
                            content = "صيغة الحاوية: MP4 v2 (isom/iso2)\nالصناديق: ftyp, moov, udta, mdat\nالملف: ${file.name}",
                            file = file,
                            mimeType = "video/mp4"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 4: Custom Sticker Creator
 */
@Composable
private fun Tool4CustomSticker(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var stickerBadge by remember { mutableStateOf("DATA MASTER") }

    LabToolCard(
        title = "4. Custom Sticker Creator",
        arabicTitle = "منشئ ملصقات WebP عالية الدقة",
        icon = Icons.Default.PhotoAlbum,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "إنشاء ملصقات WebP شفافة وعالية الدقة ومناسبة لمنصات المراسلة الفورية وشارات الواجهة.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = stickerBadge, onValueChange = { stickerBadge = it }, label = "نص الملصق والشارة")

            CyberButton(
                text = "إنشاء ملصق WebP 512x512",
                onClick = {
                    viewModel.executeTask("إنشاء ملصق WebP") {
                        val file = DataProcessingEngine.sticker.createCustomStickerFile(context, 512, 512, stickerBadge, 0)
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)

                        OutputResult(
                            title = "تم إنشاء ملصق WebP 512x512 بنجاح",
                            summary = "نص الملصق: '$stickerBadge' (${totalBytes / 1024} كيلوبايت)",
                            content = "الصيغة: WebP 512x512 مع إطار سيبراني وقناة شفافية ألفا.\nالملف: ${file.name}",
                            file = file,
                            mimeType = "image/webp"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 5: Custom Document Creator
 */
@Composable
private fun Tool5CustomDocument(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var docTitle by remember { mutableStateOf("Security Research Specification") }
    var docFormat by remember { mutableStateOf("Markdown") }

    val formats = listOf("Markdown", "JSON", "Text", "PDF-Raw")

    LabToolCard(
        title = "5. Custom Document Creator",
        arabicTitle = "منشئ مستندات مخصصة (Markdown / JSON / PDF)",
        icon = Icons.Default.Description,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "إنشاء مستندات منسقة تحتوي على بيانات وصفية وأقسام وهياكل بيانات تقنية منظمة للأبحاث والاختبار.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = docTitle, onValueChange = { docTitle = it }, label = "عنوان المستند الفني")

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                formats.forEach { fmt ->
                    CyberOutlinedButton(
                        text = fmt,
                        modifier = Modifier.weight(1f),
                        borderColor = if (docFormat == fmt) NeonGreen else com.example.ui.theme.CyberCardBorder,
                        onClick = { docFormat = fmt }
                    )
                }
            }

            CyberButton(
                text = "إنشاء مستند $docFormat",
                onClick = {
                    viewModel.executeTask("إنشاء مستند ($docFormat)") {
                        val ext = when (docFormat) {
                            "JSON" -> "json"
                            "Markdown" -> "md"
                            "PDF-Raw" -> "pdf"
                            else -> "txt"
                        }
                        val file = File(context.cacheDir, "doc_${System.currentTimeMillis()}.$ext")
                        val content = when (docFormat) {
                            "JSON" -> """
                                {
                                  "documentTitle": "$docTitle",
                                  "timestamp": ${System.currentTimeMillis()},
                                  "creator": "Data Craft Studio",
                                  "payload": {
                                    "status": "VERIFIED",
                                    "nodes": [101, 102, 103],
                                    "securityLevel": "TOP_SECRET_RESEARCH"
                                  }
                                }
                            """.trimIndent()

                            "PDF-Raw" -> """
                                %PDF-1.4
                                1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
                                2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
                                3 0 obj << /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj
                                4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj
                                5 0 obj << /Length 44 >> stream
                                BT /F1 18 Tf 50 700 Td ($docTitle) Tj ET
                                endstream endobj
                                xref
                                0 6
                                0000000000 65535 f 
                                trailer << /Size 6 /Root 1 0 R >>
                                startxref
                                400
                                %%EOF
                            """.trimIndent()

                            else -> """
                                # $docTitle
                                
                                **Generated By**: Data Craft Studio
                                **Date**: ${java.util.Date()}
                                
                                ## Executive Summary
                                This synthetic research document was compiled on-device. All algorithms and encoding tables operate without external network dependencies.
                                
                                - Data Integrity: Verified
                                - Encryption: AES-GCM 256 Ready
                                - Entropy: High
                            """.trimIndent()
                        }
                        file.writeText(content)
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)

                        OutputResult(
                            title = "تم إنشاء مستند $docFormat بنجاح",
                            summary = "الملف: ${file.name} ($totalBytes بايت)",
                            content = content,
                            file = file,
                            mimeType = if (docFormat == "JSON") "application/json" else "text/plain"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 6: Custom Archive Creator
 */
@Composable
private fun Tool6CustomArchive(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var fileCount by remember { mutableStateOf("10") }
    var fileSizeKb by remember { mutableStateOf("32") }

    LabToolCard(
        title = "6. Custom Archive Creator",
        arabicTitle = "منشئ أرشيفات وحزم ZIP متعددة الملفات",
        icon = Icons.Default.FolderZip,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "حزم مجموعات البيانات الاصطناعية داخل أرشيفات ZIP مضغوطة لاختبار فك الضغط ومحاكاة عمليات الأرشفة.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberTextField(value = fileCount, onValueChange = { fileCount = it }, label = "عدد الملفات", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Number)
                CyberTextField(value = fileSizeKb, onValueChange = { fileSizeKb = it }, label = "حجم الملف (KB)", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Number)
            }

            CyberButton(
                text = "إنشاء أرشيف متعدد الملفات (Build ZIP)",
                onClick = {
                    viewModel.executeTask("إنشاء أرشيف مضغوط") {
                        val count = (fileCount.toIntOrNull() ?: 10).coerceIn(1, 50)
                        val size = (fileSizeKb.toIntOrNull() ?: 32).coerceIn(1, 256)
                        val file = MediaUtils.createZipArchive(context, count, size, false)
                        val totalBytes = file.length()
                        viewModel.incrementStats(bytesProc = (count * size * 1024L), filesGen = 1)

                        OutputResult(
                            title = "تم إنشاء حزمة الأرشيف المضغوط",
                            summary = "تم حزم $count ملفاً اصطناعياً ($totalBytes بايت بعد الضغط)",
                            content = "الأرشيف: ${file.name}\nعدد المدخلات: $count ملف\nإجمالي الحجم المضغوط: $totalBytes بايت",
                            file = file,
                            mimeType = "application/zip"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 7: Binary Data Creator
 */
@Composable
private fun Tool7BinaryCreator(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var sizeKb by remember { mutableStateOf("64") }
    var patternMode by remember { mutableStateOf("Random") }

    val patterns = listOf("Random", "Zeroes (0x00)", "Alternating (0xAA)", "Counter (0..255)")

    LabToolCard(
        title = "7. Binary Data Creator",
        arabicTitle = "منشئ بيانات ثنائية عشوائية ومنتظمة",
        icon = Icons.Default.Code,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "توليد تدفقات بايتات ثنائية خام (.bin) بأنماط محددة أو عشوائية مشفرة لاختبار إجهاد الذاكرة المؤقتة وسعة التخزين.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = sizeKb, onValueChange = { sizeKb = it }, label = "حجم البيانات الثنائية (KB)", keyboardType = KeyboardType.Number)

            Text("اختر نمط تسلسل البايتات:", style = MaterialTheme.typography.labelMedium, color = NeonGreen)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                patterns.take(2).forEach { pat ->
                    CyberOutlinedButton(
                        text = pat,
                        modifier = Modifier.weight(1f),
                        borderColor = if (patternMode == pat) NeonGreen else com.example.ui.theme.CyberCardBorder,
                        onClick = { patternMode = pat }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                patterns.takeLast(2).forEach { pat ->
                    CyberOutlinedButton(
                        text = pat,
                        modifier = Modifier.weight(1f),
                        borderColor = if (patternMode == pat) NeonGreen else com.example.ui.theme.CyberCardBorder,
                        onClick = { patternMode = pat }
                    )
                }
            }

            CyberButton(
                text = "توليد ملف بيانات ثنائية (Generate Binary)",
                onClick = {
                    viewModel.executeTask("توليد سيل بيانات ثنائية") {
                        val kb = (sizeKb.toIntOrNull() ?: 64).coerceIn(1, 1024)
                        val pat = when (patternMode) {
                            "Random" -> BinaryPattern.RANDOM
                            "Zeroes (0x00)" -> BinaryPattern.ZEROES
                            "Alternating (0xAA)" -> BinaryPattern.ALTERNATING
                            else -> BinaryPattern.COUNTER
                        }
                        val data = DataProcessingEngine.binary.generatePatternBinary(kb * 1024L, pat)
                        val file = File(context.cacheDir, "binary_${patternMode.take(4)}_${System.currentTimeMillis()}.bin")
                        file.writeBytes(data)
                        val totalBytes = file.length()
                        val entropy = DataProcessingEngine.binary.calculateEntropy(data)
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)

                        OutputResult(
                            title = "تم إنشاء ملف البيانات الثنائية",
                            summary = "النمط: $patternMode | الحجم: ${kb}KB | الإنتروبيا: ${"%.3f".format(entropy)}",
                            content = "الملف: ${file.name}\nالحجم: $totalBytes بايت\nأول 32 بايت بنظام Hex: ${data.take(32).joinToString(" ") { "%02X".format(it) }}",
                            file = file,
                            mimeType = "application/octet-stream"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 8: Unicode Text Creator
 */
@Composable
private fun Tool8UnicodeCreator(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var count by remember { mutableStateOf("500") }
    var unicodeType by remember { mutableStateOf("Zalgo (Combining Marks)") }

    val types = listOf("Zalgo (Combining Marks)", "BiDi Overrides", "Emoji Storm", "Homoglyphs")

    LabToolCard(
        title = "8. Unicode Text Creator",
        arabicTitle = "منشئ نصوص Unicode متقدمة وزالغو",
        icon = Icons.Default.TextSnippet,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "توليد نصوص يونيكود خاصة تحتوي على علامات التشكيل المدمجة (Zalgo) وعواكس الاتجاه والرموز التعبيرية.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = count, onValueChange = { count = it }, label = "طول النص / التكرار", keyboardType = KeyboardType.Number)

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                types.take(2).forEach { t ->
                    CyberOutlinedButton(
                        text = t.take(15),
                        modifier = Modifier.weight(1f),
                        borderColor = if (unicodeType == t) NeonGreen else com.example.ui.theme.CyberCardBorder,
                        onClick = { unicodeType = t }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                types.takeLast(2).forEach { t ->
                    CyberOutlinedButton(
                        text = t.take(15),
                        modifier = Modifier.weight(1f),
                        borderColor = if (unicodeType == t) NeonGreen else com.example.ui.theme.CyberCardBorder,
                        onClick = { unicodeType = t }
                    )
                }
            }

            CyberButton(
                text = "توليد نصوص $unicodeType",
                onClick = {
                    viewModel.executeTask("توليد نصوص Unicode خاصة") {
                        val c = (count.toIntOrNull() ?: 500).coerceIn(10, 5000)
                        val text = when (unicodeType) {
                            "Zalgo (Combining Marks)" -> DataProcessingEngine.unicode.generateZalgoText("DATA CRAFT SECURITY ", 15)
                            "BiDi Overrides" -> DataProcessingEngine.unicode.generateBiDiOverrideText("نص سري مع عكس الاتجاه RTL")
                            "Emoji Storm" -> {
                                val emojis = listOf("⚡", "🔥", "🛡️", "💀", "🚀", "💣", "🛰️", "🧨", "🩸", "🤖")
                                (1..c).joinToString("") { emojis.random() }
                            }
                            else -> {
                                val confusables = listOf("а", "е", "о", "р", "с", "у", "х", "A", "B", "C", "E", "H", "K", "M", "O", "P", "T", "X")
                                (1..c).joinToString("") { confusables.random() }
                            }
                        }
                        val bytes = text.toByteArray().size
                        viewModel.incrementStats(bytesProc = bytes.toLong())

                        OutputResult(
                            title = "تم إنشاء نص $unicodeType بنجاح",
                            summary = "تم توليد ${text.length} حرفاً ($bytes بايت)",
                            content = text.take(600) + "\n... [إجمالي الطول: ${text.length} حرف]"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 9: Data Bundle Creator
 */
@Composable
private fun Tool9DataBundleCreator(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var bundleName by remember { mutableStateOf("Research_Master_Bundle_01") }

    LabToolCard(
        title = "9. Data Bundle Creator",
        arabicTitle = "منشئ حزم بيانات شاملة مع بصمات SHA-256",
        icon = Icons.Default.Inventory2,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "دمج الصور المصنعة والنغمات الصوتية والمستندات مع بيان أمني وبصمة SHA-256 داخل حزمة شاملة موحدة.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = bundleName, onValueChange = { bundleName = it }, label = "معرف الحزمة الشاملة")

            CyberButton(
                text = "تجميع حزمة البيانات الشاملة (Compile Bundle)",
                onClick = {
                    viewModel.executeTask("تجميع حزمة البيانات الشاملة") {
                        val bundleZip = File(context.cacheDir, "${bundleName}_${System.currentTimeMillis()}.zip")
                        ZipOutputStream(FileOutputStream(bundleZip)).use { zos ->
                            // 1. Manifest
                            val manifestContent = buildString {
                                appendLine("=== DATA CRAFT MASTER BUNDLE MANIFEST ===")
                                appendLine("Bundle: $bundleName")
                                appendLine("Timestamp: ${System.currentTimeMillis()}")
                                appendLine("Creator: Data Craft Studio (Local On-Device Engine)")
                                appendLine("Contents: image.png, audio.wav, spec.json")
                            }
                            zos.putNextEntry(ZipEntry("manifest.txt"))
                            zos.write(manifestContent.toByteArray())
                            zos.closeEntry()

                            // 2. Synthetic Spec JSON
                            zos.putNextEntry(ZipEntry("specification.json"))
                            zos.write("""{"bundleId":"$bundleName","status":"ACTIVE"}""".toByteArray())
                            zos.closeEntry()

                            // 3. Audio tone
                            val audioWav = MediaUtils.createWavAudio(context, 440.0, 1)
                            zos.putNextEntry(ZipEntry("audio_tone.wav"))
                            zos.write(audioWav.readBytes())
                            zos.closeEntry()
                        }
                        val totalBytes = bundleZip.length()
                        viewModel.incrementStats(bytesProc = totalBytes, filesGen = 1)

                        OutputResult(
                            title = "تم تجميع حزمة البيانات الشاملة بنجاح",
                            summary = "تم حزم البيان والصوت والمواصفات داخل $bundleName ($totalBytes بايت)",
                            content = "ملف الحزمة: ${bundleZip.name}\nالحجم: $totalBytes بايت\nتم حساب البصمات وإغلاق البيان الأمني بنجاح.",
                            file = bundleZip,
                            mimeType = "application/zip"
                        )
                    }
                }
            )
        }
    }
}
