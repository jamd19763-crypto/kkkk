package com.example

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.io.File
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Section 4: Tools Center (مركز الأدوات)
 * Provides auxiliary utilities, cleaner, encryptor, compressor, diagnostics, logs, and report export.
 */
@Composable
fun ToolsCenter(
    viewModel: LabViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            LabHeaderBadge(
                title = "مركز الأدوات والمساعدات",
                subtitle = "Tools & Diagnostics Center • تنظيف، تشفير، ضغط، تقارير وتشخيص شامل",
                icon = Icons.Default.Terminal
            )
        }

        // 1. Run All Tools
        item {
            Tool1RunAll(viewModel, context)
        }

        // 2. Data Cleaner
        item {
            Tool2DataCleaner(viewModel)
        }

        // 3. Data Encryptor
        item {
            Tool3DataEncryptor(viewModel)
        }

        // 4. Data Compressor
        item {
            Tool4DataCompressor(viewModel)
        }

        // 5. System Analyzer
        item {
            Tool5SystemAnalyzer(viewModel, context)
        }

        // 6. Report Generator
        item {
            Tool6ReportGenerator(viewModel, context)
        }

        // 7. Log Viewer
        item {
            Tool7LogViewer(viewModel)
        }

        // 8. Settings Manager
        item {
            Tool8SettingsManager(viewModel)
        }

        // 9. Share Results
        item {
            Tool9ShareResults(viewModel, context)
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * Tool 1: Run All Tools (Batch Test Pipeline)
 */
@Composable
private fun Tool1RunAll(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }

    LabToolCard(
        title = "1. Run All Tools (Batch Pipeline)",
        arabicTitle = "تشغيل جميع الأدوات وإجراء فحص شامل للمنظومة",
        icon = Icons.Default.PlayArrow,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "تشغيل فحص واختبار تلقائي متتابع عبر التشفير وإخفاء البيانات وإنشاء الوسائط وفحص الإنتروبيا وسرعة المعالجة.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberButton(
                text = "⚡ تشغيل حزمة الفحص الشامل التلقائي",
                color = NeonGreen,
                onClick = {
                    viewModel.executeTask("حزمة الفحص التشخيصي الشامل") {
                        viewModel.addLog(LogLevel.INFO, "PIPELINE", "بدء المرحلة 1/5: اختبار إخفاء وتضمين البيانات...")
                        val stego = DataProcessingEngine.text.generateHiddenText("Data Craft Studio", "AlphaHiddenPayload99")
                        val decoded = DataProcessingEngine.text.extractHiddenText(stego)

                        viewModel.addLog(LogLevel.INFO, "PIPELINE", "بدء المرحلة 2/5: إنشاء أصول الوسائط الاصطناعية...")
                        val img = MediaUtils.createPngWithEmbeddedData(context, 200, 200, "AUDIT", "AUTO", 16)
                        val audio = MediaUtils.createWavAudio(context, 440.0, 1)

                        viewModel.addLog(LogLevel.INFO, "PIPELINE", "بدء المرحلة 3/5: قياس إنتاجية وسرعة الهاش والتجزئة...")
                        val speedMap = AnalysisUtils.benchmarkSpeed(200, 32)

                        viewModel.addLog(LogLevel.INFO, "PIPELINE", "بدء المرحلة 4/5: فحص الضغط ومعدل الإنتروبيا...")
                        val sampleData = ByteArray(64 * 1024) { 0x3F }
                        val entropy = AnalysisUtils.calculateEntropy(sampleData)

                        viewModel.addLog(LogLevel.INFO, "PIPELINE", "بدء المرحلة 5/5: التحقق من صحة التشفير العالي...")
                        val (cipherB64, _) = CryptoUtils.encryptAesGcm("PipelineVerificationToken", "MasterPass77")
                        val decrypted = CryptoUtils.decryptAesGcm(cipherB64, "MasterPass77")

                        viewModel.incrementStats(
                            bytesProc = (img.length() + audio.length() + (200 * 32 * 1024L)),
                            bytesEmb = 64,
                            filesGen = 2,
                            benchmarks = 1
                        )

                        val summaryText = buildString {
                            appendLine("=== ملخص الفحص الشامل للمنظومة ===")
                            appendLine("✓ إخفاء واستخراج البيانات: نجاح (المستخرج: '$decoded')")
                            appendLine("✓ توليد الصور: تم إنشاء PNG (${img.length()} بايت)")
                            appendLine("✓ توليد الصوت: تم إنشاء WAV (${audio.length()} بايت)")
                            appendLine("✓ إنتاجية SHA-256: ${"%.2f".format(speedMap["SHA-256 Throughput (MB/s)"] ?: 0.0)} ميجابايت/ثانية")
                            appendLine("✓ إنتروبيا شانون: ${"%.3f".format(entropy)} بت/بايت")
                            appendLine("✓ تشفير وفك تشفير AES-256-GCM: نجاح ('$decrypted')")
                            appendLine("الحالة: جميع المحركات المحلية تعمل بكفاءة تامة")
                        }

                        OutputResult(
                            title = "تقرير الفحص التشخيصي الشامل",
                            summary = "تم تنفيذ 5/5 مراحل اختبار بنجاح محلياً على الجهاز",
                            content = summaryText
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 2: Data Cleaner
 */
@Composable
private fun Tool2DataCleaner(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var dirtyInput by remember { mutableStateOf("Clean \u200B\u200C text \u202E with \u202D hidden \uFEFF chars") }
    var cleanedOutput by remember { mutableStateOf("") }

    LabToolCard(
        title = "2. Data Cleaner",
        arabicTitle = "منظف البيانات وتطهير الأحرف الخفية والمخفية",
        icon = Icons.Default.CleaningServices,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "إزالة أحرف يونيكود الصفرية الخفية (ZWSP, ZWNJ, ZWJ, BOM) ومحددات الاتجاه BiDi لتطهير النصوص من الرموز الخفية.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = dirtyInput, onValueChange = { dirtyInput = it }, label = "النص المراد تطهيره وفحصه من الرموز الخفية")

            CyberButton(
                text = "تطهير النص وإزالة الرموز الخفية",
                onClick = {
                    viewModel.executeTask("تطهير وفحص النصوص") {
                        val beforeLength = dirtyInput.length
                        val cleaned = StegoUtils.stripZeroWidthChars(dirtyInput)
                        val strippedCount = beforeLength - cleaned.length
                        cleanedOutput = cleaned
                        viewModel.incrementStats(bytesProc = beforeLength.toLong())

                        OutputResult(
                            title = "مخرجات النص المطهر",
                            summary = "تمت إزالة $strippedCount من الأحرف والرموز الخفية",
                            content = "الأصلي: $beforeLength حرف\nالمطهر: ${cleaned.length} حرف\nالمحذوف: $strippedCount رمز\nالنتيجة: $cleaned"
                        )
                    }
                }
            )

            if (cleanedOutput.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberDark, RoundedCornerShape(8.dp))
                        .border(1.dp, NeonGreen.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text("النص بعد التطهير: $cleanedOutput", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

/**
 * Tool 3: Data Encryptor
 */
@Composable
private fun Tool3DataEncryptor(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var plainText by remember { mutableStateOf("بيانات سرية للبحث والاختبار 2026") }
    var passphrase by remember { mutableStateOf("CyberMatrixPass123!") }
    var cipherResult by remember { mutableStateOf<Pair<String, String>?>(null) }

    LabToolCard(
        title = "3. Data Encryptor",
        arabicTitle = "مشفر البيانات وفك التشفير بخوارزمية AES-256-GCM",
        icon = Icons.Default.Lock,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "تشفير موثق فائق الأمان (AES-256-GCM) مع متجه تهيئة عشوائي 12-بايت ومفاتيح مشتقة بـ SHA-256.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = plainText, onValueChange = { plainText = it }, label = "البيانات المراد تشفيرها / فك تشفيرها")
            CyberTextField(value = passphrase, onValueChange = { passphrase = it }, label = "كلمة المرور / المفتاح السري")

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberButton(
                    text = "تشفير AES-GCM",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.executeTask("تشفير AES-256-GCM") {
                            val (b64, hex) = CryptoUtils.encryptAesGcm(plainText, passphrase)
                            cipherResult = b64 to hex
                            viewModel.incrementStats(bytesProc = plainText.length.toLong())

                            OutputResult(
                                title = "مخرجات التشفير AES-GCM",
                                summary = "تم التشفير بمفتاح 256-بت ومتجه 12-بايت",
                                content = "Base64: $b64\nHex: $hex"
                            )
                        }
                    }
                )

                CyberOutlinedButton(
                    text = "فك التشفير",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.executeTask("فك تشفير AES-256-GCM") {
                            val decrypted = try {
                                CryptoUtils.decryptAesGcm(plainText, passphrase)
                            } catch (e: Exception) {
                                "فشل فك التشفير: المفتاح غير صحيح أو البيانات تالفة."
                            }
                            OutputResult(
                                title = "النص المفكوك بعد التشفير",
                                summary = "اكتملت عملية فك التشفير",
                                content = decrypted
                            )
                        }
                    }
                )
            }

            cipherResult?.let { (b64, hex) ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberDark, RoundedCornerShape(8.dp))
                        .border(1.dp, NeonGreen.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("النص المشفر بنظام Base64:", color = NeonGreen, style = MaterialTheme.typography.labelSmall)
                    Text(b64, color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                    Text("تدفق البايتات بنظام Hex:", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
                    Text(hex.take(64) + "...", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

/**
 * Tool 4: Data Compressor
 */
@Composable
private fun Tool4DataCompressor(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var textInput by remember { mutableStateOf("Data Craft Studio ".repeat(50)) }
    var compStats by remember { mutableStateOf<Map<String, String>?>(null) }

    LabToolCard(
        title = "4. Data Compressor",
        arabicTitle = "ضاغط البيانات واختبار نسبة التقليص GZIP",
        icon = Icons.Default.Compress,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "ضغط وتحجيم البيانات باستخدام خوارزمية DEFLATE / GZIP وحساب نسب التوفير والمطابقة بدون فقد.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberTextField(value = textInput, onValueChange = { textInput = it }, label = "النص المصدري المراد ضغطه")

            CyberButton(
                text = "ضغط البيانات (Compress with GZIP)",
                onClick = {
                    viewModel.executeTask("ضغط البيانات بخوارزمية GZIP") {
                        val originalBytes = textInput.toByteArray(StandardCharsets.UTF_8)
                        val compressed = DataProcessingEngine.compression.compressGzip(originalBytes)
                        val decompressed = DataProcessingEngine.compression.decompressGzip(compressed)

                        val savedRatio = (1.0 - (compressed.size.toDouble() / maxOf(1, originalBytes.size))) * 100.0
                        val stats = mapOf(
                            "الحجم الأصلي" to "${originalBytes.size} بايت",
                            "الحجم بعد الضغط GZIP" to "${compressed.size} بايت",
                            "نسبة التقليص الموفرة" to "%.2f%%".format(savedRatio),
                            "فحص تكامل البيانات" to if (decompressed.contentEquals(originalBytes)) "مطابق 100% (بدون فقد)" else "فشل التطابق"
                        )
                        compStats = stats
                        viewModel.incrementStats(bytesProc = originalBytes.size.toLong())

                        OutputResult(
                            title = "تقرير ضغط البيانات GZIP",
                            summary = "تم تقليص ${originalBytes.size} بايت إلى ${compressed.size} بايت (توفير ${"%.1f".format(savedRatio)}%)",
                            content = stats.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                        )
                    }
                }
            )

            compStats?.let { MetricGrid(it) }
        }
    }
}

/**
 * Tool 5: System Analyzer
 */
@Composable
private fun Tool5SystemAnalyzer(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    var sysStats by remember { mutableStateOf<Map<String, String>?>(null) }

    LabToolCard(
        title = "5. System Analyzer",
        arabicTitle = "محلل النظام وموارد العتاد والذاكرة",
        icon = Icons.Default.Devices,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "فحص وتدقيق موارد عتاد نظام أندرويد، الأنوية المتاحة، سقف الذاكرة وحجم التخزين الداخلي المتاح.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberButton(
                text = "فحص بيئة الجهاز ومقاييس العتاد",
                onClick = {
                    viewModel.executeTask("تدقيق عتاد النظام") {
                        val runtime = Runtime.getRuntime()
                        val cores = runtime.availableProcessors()
                        val maxHeapMb = runtime.maxMemory() / (1024 * 1024)
                        val totalHeapMb = runtime.totalMemory() / (1024 * 1024)
                        val freeHeapMb = runtime.freeMemory() / (1024 * 1024)

                        val statFs = StatFs(context.filesDir.absolutePath)
                        val freeStorageMb = (statFs.availableBlocksLong * statFs.blockSizeLong) / (1024 * 1024)

                        val stats = mapOf(
                            "إصدار نظام أندرويد" to "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                            "طراز الجهاز" to "${Build.MANUFACTURER} ${Build.MODEL}",
                            "المعمارية المدعومة" to Build.SUPPORTED_ABIS.joinToString(", "),
                            "أنوية المعالج المتاحة" to "$cores أنوية",
                            "الحد الأقصى للذاكرة (Heap)" to "$maxHeapMb ميجابايت",
                            "الذاكرة المحجوزة للـ JVM" to "$totalHeapMb ميجابايت",
                            "الذاكرة الحرة المتبقية" to "$freeHeapMb ميجابايت",
                            "التخزين المتاح للتطبيق" to "$freeStorageMb ميجابايت"
                        )
                        sysStats = stats
                        viewModel.incrementStats(benchmarks = 1)

                        OutputResult(
                            title = "تدقيق عتاد النظام والبيئة التشغيلية",
                            summary = "الأنوية: $cores | الذاكرة: ${maxHeapMb}م.ب | التخزين: ${freeStorageMb}م.ب",
                            content = stats.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                        )
                    }
                }
            )

            sysStats?.let { MetricGrid(it) }
        }
    }
}

/**
 * Tool 6: Report Generator
 */
@Composable
private fun Tool6ReportGenerator(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }

    LabToolCard(
        title = "6. Report Generator",
        arabicTitle = "مولد التقارير الشاملة بصيغة Markdown و JSON",
        icon = Icons.Default.ListAlt,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "تجميع سجلات التدقيق وتقارير قياس الأداء الشاملة لجميع العمليات ومقاييس النظام.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            CyberButton(
                text = "توليد تقرير التدقيق الشامل بصيغة Markdown",
                onClick = {
                    viewModel.executeTask("تجميع تقرير التدقيق") {
                        val stats = viewModel.stats.value
                        val logs = viewModel.logs.value
                        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

                        val report = buildString {
                            appendLine("# استوديو هندسة البيانات - تقرير التدقيق الشامل")
                            appendLine("**تاريخ التوليد**: $dateStr")
                            appendLine("**البيئة التشغيلية**: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) - ${Build.MODEL}")
                            appendLine()
                            appendLine("## 1. إحصائيات الأداء التراكمية")
                            appendLine("- **إجمالي العمليات المنفذة**: ${stats.operationsCount}")
                            appendLine("- **إجمالي البيانات المعالجة**: ${stats.bytesProcessed} بايت (${"%.2f".format(stats.bytesProcessed / (1024.0 * 1024.0))} ميجابايت)")
                            appendLine("- **بيانات الإخفاء المضمنة**: ${stats.bytesEmbedded} بايت")
                            appendLine("- **الملفات المنشأة**: ${stats.filesGeneratedCount}")
                            appendLine("- **الاختبارات المكتملة**: ${stats.benchmarksCompleted}")
                            appendLine("- **ذروة الذاكرة المسجلة**: ${"%.2f".format(stats.peakMemoryMb)} ميجابايت")
                            appendLine()
                            appendLine("## 2. أحدث سجلات الأحداث (آخر ${logs.take(20).size})")
                            logs.take(20).forEach { log ->
                                appendLine("- `[${log.timestamp}]` **[${log.level}]** (${log.tag}): ${log.message}")
                            }
                            appendLine()
                            appendLine("---")
                            appendLine("*Data Craft Studio - محرك معالجة البيانات المتقدم محلياً*")
                        }

                        val reportFile = File(context.cacheDir, "DataCraft_Audit_Report_${System.currentTimeMillis()}.md")
                        reportFile.writeText(report)
                        viewModel.incrementStats(bytesProc = report.length.toLong(), filesGen = 1)

                        OutputResult(
                            title = "تقرير التدقيق والأداء الشامل",
                            summary = "ملف التقرير المجمع: ${reportFile.name} (${report.length} بايت)",
                            content = report,
                            file = reportFile,
                            mimeType = "text/markdown"
                        )
                    }
                }
            )
        }
    }
}

/**
 * Tool 7: Log Viewer
 */
@Composable
private fun Tool7LogViewer(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    val logs by viewModel.logs.collectAsState()
    var filterLevel by remember { mutableStateOf<LogLevel?>(null) }

    LabToolCard(
        title = "7. Log Viewer",
        arabicTitle = "عارض السجلات الحية لجميع العمليات",
        icon = Icons.Default.Terminal,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "بث مباشر لسجلات الأحداث والقياسات لجميع مهام التشفير والإخفاء والاختبار الميداني.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CyberOutlinedButton(
                    text = "الكل (${logs.size})",
                    modifier = Modifier.weight(1f),
                    borderColor = if (filterLevel == null) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { filterLevel = null }
                )
                CyberOutlinedButton(
                    text = "الناجحة",
                    modifier = Modifier.weight(1f),
                    borderColor = if (filterLevel == LogLevel.SUCCESS) NeonGreen else com.example.ui.theme.CyberCardBorder,
                    onClick = { filterLevel = LogLevel.SUCCESS }
                )
                CyberOutlinedButton(
                    text = "الأخطاء",
                    modifier = Modifier.weight(1f),
                    borderColor = if (filterLevel == LogLevel.ERROR) NeonRed else com.example.ui.theme.CyberCardBorder,
                    onClick = { filterLevel = LogLevel.ERROR }
                )
            }

            val displayedLogs = if (filterLevel == null) logs else logs.filter { it.level == filterLevel }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 240.dp)
                    .background(CyberDark, RoundedCornerShape(8.dp))
                    .border(1.dp, com.example.ui.theme.CyberCardBorder, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                if (displayedLogs.isEmpty()) {
                    Text("لا توجد سجلات مطابقة للفلتر المحدد.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(displayedLogs, key = { it.id }) { log ->
                            val color = when (log.level) {
                                LogLevel.SUCCESS -> NeonGreen
                                LogLevel.ERROR -> NeonRed
                                LogLevel.WARN -> NeonAmber
                                LogLevel.INFO -> NeonCyan
                            }
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = log.timestamp,
                                    color = TextSecondary,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.width(80.dp)
                                )
                                Text(
                                    text = "[${log.tag}] ",
                                    color = color,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = log.message,
                                    color = TextPrimary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }

            CyberOutlinedButton(
                text = "مسح سجلات الأحداث",
                borderColor = NeonRed,
                onClick = { viewModel.clearLogs() }
            )
        }
    }
}

/**
 * Tool 8: Settings Manager
 */
@Composable
private fun Tool8SettingsManager(viewModel: LabViewModel) {
    var expanded by remember { mutableStateOf(false) }
    val settings by viewModel.settings.collectAsState()

    var bufferKb by remember(settings) { mutableStateOf(settings.defaultBufferSizeKb.toFloat()) }
    var iterations by remember(settings) { mutableStateOf(settings.benchmarkIterations.toFloat()) }
    var verbose by remember(settings) { mutableStateOf(settings.enableVerboseLogging) }

    LabToolCard(
        title = "8. Settings Manager",
        arabicTitle = "إدارة الإعدادات ومعايير الاختبار والضبط",
        icon = Icons.Default.Settings,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "تخصيص حجم المخزن المؤقت الافتراضي، وتكرارات الاختبارات، ومستوى تفاصيل السجلات.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Text("حجم المخزن المؤقت الافتراضي: ${bufferKb.toInt()} كيلوبايت", color = NeonGreen, style = MaterialTheme.typography.labelMedium)
            Slider(
                value = bufferKb,
                onValueChange = { bufferKb = it },
                valueRange = 16f..1024f,
                steps = 7,
                colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
            )

            Text("تكرارات الاختبارات القياسية: ${iterations.toInt()}", color = NeonGreen, style = MaterialTheme.typography.labelMedium)
            Slider(
                value = iterations,
                onValueChange = { iterations = it },
                valueRange = 100f..5000f,
                steps = 9,
                colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = verbose,
                    onCheckedChange = { verbose = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = NeonGreen, checkedTrackColor = NeonGreen.copy(alpha = 0.4f))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("تفعيل تدفق السجلات والأحداث التفصيلية", color = TextPrimary, style = MaterialTheme.typography.bodySmall)
            }

            CyberButton(
                text = "حفظ إعدادات المنظومة",
                onClick = {
                    val updated = LabSettings(
                        defaultBufferSizeKb = bufferKb.toInt(),
                        benchmarkIterations = iterations.toInt(),
                        enableVerboseLogging = verbose
                    )
                    viewModel.updateSettings(updated)
                }
            )
        }
    }
}

/**
 * Tool 9: Share Results
 */
@Composable
private fun Tool9ShareResults(viewModel: LabViewModel, context: Context) {
    var expanded by remember { mutableStateOf(false) }
    val latestResult by viewModel.latestResult.collectAsState()

    LabToolCard(
        title = "9. Share Results",
        arabicTitle = "مشاركة النتائج والملفات المنشأة مع التطبيقات الأخرى",
        icon = Icons.Default.Share,
        expanded = expanded,
        onToggle = { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "مشاركة آخر مخرجات تم توليدها أو تقارير أو ملفات مباشرة عبر نافذة المشاركة في أندرويد.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            if (latestResult != null) {
                val res = latestResult!!
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberDark, RoundedCornerShape(8.dp))
                        .border(1.dp, NeonGreen.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Text("الهدف النشط للمشاركة:", color = NeonGreen, style = MaterialTheme.typography.labelSmall)
                        Text(res.title, color = TextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text(res.summary, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        if (res.file != null) {
                            Text("الملف: ${res.file.name} (${res.file.length()} بايت)", color = NeonCyan, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                CyberButton(
                    text = "مشاركة الهدف (${res.title})",
                    onClick = {
                        viewModel.shareResult(context, res)
                    }
                )
            } else {
                Text(
                    "لم يتم توليد أي نتائج بعد. قم بتشغيل أي أداة لإنشاء ملف أو نتيجة للمشاركة.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
